import * as APITypes from "../API";
type GeneratedSubscription<InputType, OutputType> = string & {
  __generatedSubscriptionInput: InputType;
  __generatedSubscriptionOutput: OutputType;
};

export const onCreateEmployeeWithoutOwner = /* GraphQL */ `subscription OnCreateEmployeeWithoutOwner(
  $filter: ModelSubscriptionEmployeeFilterInput
) {
  onCreateEmployee(filter: $filter) {
    id
    owner
    disabled
    companyId
    name
    email
    isAdmin
    avatarUrl
    notRelevantParentGoals
    creatorEmail
    language
    locale
    interest
    career
    goals {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    organizationUnitEmployeeJoins {
      nextToken
      __typename
    }
    contributionEmployeeJoins {
      nextToken
      __typename
    }
    ideaEmployeeJoins {
      nextToken
      __typename
    }
    successStoryEmployeeJoins {
      nextToken
      __typename
    }
    helpRequestEmployeeJoins {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateEmployeeSubscriptionVariables,
  APITypes.OnCreateEmployeeSubscription
>;
export const onUpdateEmployeeWithoutOwner = /* GraphQL */ `subscription OnUpdateEmployeeWithoutOwner(
  $filter: ModelSubscriptionEmployeeFilterInput
) {
  onUpdateEmployee(filter: $filter) {
    id
    owner
    disabled
    companyId
    name
    isAdmin
    email
    avatarUrl
    notRelevantParentGoals
    creatorEmail
    goals {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    organizationUnitEmployeeJoins {
      nextToken
      __typename
    }
    contributionEmployeeJoins {
      nextToken
      __typename
    }
    ideaEmployeeJoins {
      nextToken
      __typename
    }
    successStoryEmployeeJoins {
      nextToken
      __typename
    }
    helpRequestEmployeeJoins {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateEmployeeSubscriptionVariables,
  APITypes.OnUpdateEmployeeSubscription
>;
export const onDeleteEmployeeWithoutOwner = /* GraphQL */ `subscription OnDeleteEmployeeWithoutOwner(
  $filter: ModelSubscriptionEmployeeFilterInput
) {
  onDeleteEmployee(filter: $filter) {
    id
    owner
    disabled
    companyId
    name
    email
    avatarUrl
    notRelevantParentGoals
    creatorEmail
    language
    locale
    interest
    career
    goals {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    organizationUnitEmployeeJoins {
      nextToken
      __typename
    }
    contributionEmployeeJoins {
      nextToken
      __typename
    }
    ideaEmployeeJoins {
      nextToken
      __typename
    }
    successStoryEmployeeJoins {
      nextToken
      __typename
    }
    helpRequestEmployeeJoins {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteEmployeeSubscriptionVariables,
  APITypes.OnDeleteEmployeeSubscription
>;