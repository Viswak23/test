/* tslint:disable */
/* eslint-disable */
// this is an auto generated file. This will be overwritten

import * as APITypes from "../API";
type GeneratedSubscription<InputType, OutputType> = string & {
  __generatedSubscriptionInput: InputType;
  __generatedSubscriptionOutput: OutputType;
};

export const onCreateOrganizationUnit = /* GraphQL */ `subscription OnCreateOrganizationUnit(
  $filter: ModelSubscriptionOrganizationUnitFilterInput
  $owner: String
) {
  onCreateOrganizationUnit(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    name
    description
    creatorEmail
    position
    notRelevantParentGoals
    parentOrganizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    childOrzganizationUnits {
      nextToken
      __typename
    }
    goals {
      nextToken
      __typename
    }
    platformIntegration {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    organizationUnitChildOrzganizationUnitsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateOrganizationUnitSubscriptionVariables,
  APITypes.OnCreateOrganizationUnitSubscription
>;
export const onUpdateOrganizationUnit = /* GraphQL */ `subscription OnUpdateOrganizationUnit(
  $filter: ModelSubscriptionOrganizationUnitFilterInput
  $owner: String
) {
  onUpdateOrganizationUnit(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    name
    description
    creatorEmail
    position
    notRelevantParentGoals
    parentOrganizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    childOrzganizationUnits {
      nextToken
      __typename
    }
    goals {
      nextToken
      __typename
    }
    platformIntegration {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    organizationUnitChildOrzganizationUnitsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateOrganizationUnitSubscriptionVariables,
  APITypes.OnUpdateOrganizationUnitSubscription
>;
export const onDeleteOrganizationUnit = /* GraphQL */ `subscription OnDeleteOrganizationUnit(
  $filter: ModelSubscriptionOrganizationUnitFilterInput
  $owner: String
) {
  onDeleteOrganizationUnit(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    name
    description
    creatorEmail
    position
    notRelevantParentGoals
    parentOrganizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    childOrzganizationUnits {
      nextToken
      __typename
    }
    goals {
      nextToken
      __typename
    }
    platformIntegration {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    organizationUnitChildOrzganizationUnitsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteOrganizationUnitSubscriptionVariables,
  APITypes.OnDeleteOrganizationUnitSubscription
>;
export const onCreateNorthStar = /* GraphQL */ `subscription OnCreateNorthStar(
  $filter: ModelSubscriptionNorthStarFilterInput
  $owner: String
) {
  onCreateNorthStar(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    title
    description
    attachments
    creatorEmail
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateNorthStarSubscriptionVariables,
  APITypes.OnCreateNorthStarSubscription
>;
export const onUpdateNorthStar = /* GraphQL */ `subscription OnUpdateNorthStar(
  $filter: ModelSubscriptionNorthStarFilterInput
  $owner: String
) {
  onUpdateNorthStar(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    title
    description
    attachments
    creatorEmail
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateNorthStarSubscriptionVariables,
  APITypes.OnUpdateNorthStarSubscription
>;
export const onDeleteNorthStar = /* GraphQL */ `subscription OnDeleteNorthStar(
  $filter: ModelSubscriptionNorthStarFilterInput
  $owner: String
) {
  onDeleteNorthStar(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    title
    description
    attachments
    creatorEmail
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteNorthStarSubscriptionVariables,
  APITypes.OnDeleteNorthStarSubscription
>;
export const onCreateNotification = /* GraphQL */ `subscription OnCreateNotification(
  $filter: ModelSubscriptionNotificationFilterInput
  $owner: String
) {
  onCreateNotification(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    notificationType
    type
    toEmployeeEmail
    isRead
    eventId
    goalId
    createdAt
    expireAt
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateNotificationSubscriptionVariables,
  APITypes.OnCreateNotificationSubscription
>;
export const onUpdateNotification = /* GraphQL */ `subscription OnUpdateNotification(
  $filter: ModelSubscriptionNotificationFilterInput
  $owner: String
) {
  onUpdateNotification(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    notificationType
    type
    toEmployeeEmail
    isRead
    eventId
    goalId
    createdAt
    expireAt
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateNotificationSubscriptionVariables,
  APITypes.OnUpdateNotificationSubscription
>;
export const onDeleteNotification = /* GraphQL */ `subscription OnDeleteNotification(
  $filter: ModelSubscriptionNotificationFilterInput
  $owner: String
) {
  onDeleteNotification(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    notificationType
    type
    toEmployeeEmail
    isRead
    eventId
    goalId
    createdAt
    expireAt
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteNotificationSubscriptionVariables,
  APITypes.OnDeleteNotificationSubscription
>;
export const onCreateCompany = /* GraphQL */ `subscription OnCreateCompany(
  $filter: ModelSubscriptionCompanyFilterInput
  $owner: String
) {
  onCreateCompany(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    name
    creatorEmail
    isSubscribed
    subscriptionId
    customerId
    subscriptionExpireDate
    description
    platformIntegration {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateCompanySubscriptionVariables,
  APITypes.OnCreateCompanySubscription
>;
export const onUpdateCompany = /* GraphQL */ `subscription OnUpdateCompany(
  $filter: ModelSubscriptionCompanyFilterInput
  $owner: String
) {
  onUpdateCompany(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    name
    creatorEmail
    isSubscribed
    subscriptionId
    customerId
    subscriptionExpireDate
    description
    platformIntegration {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateCompanySubscriptionVariables,
  APITypes.OnUpdateCompanySubscription
>;
export const onDeleteCompany = /* GraphQL */ `subscription OnDeleteCompany(
  $filter: ModelSubscriptionCompanyFilterInput
  $owner: String
) {
  onDeleteCompany(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    name
    creatorEmail
    isSubscribed
    subscriptionId
    customerId
    subscriptionExpireDate
    description
    platformIntegration {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteCompanySubscriptionVariables,
  APITypes.OnDeleteCompanySubscription
>;
export const onCreateEmployee = /* GraphQL */ `subscription OnCreateEmployee($filter: ModelSubscriptionEmployeeFilterInput) {
  onCreateEmployee(filter: $filter) {
    id
    owner
    disabled
    companyId
    createdAt
    name
    isAdmin
    email
    avatarUrl
    notRelevantParentGoals
    creatorEmail
    language
    locale
    interest
    career
    goals {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    organizationUnitEmployeeJoins {
      nextToken
      __typename
    }
    contributionEmployeeJoins {
      nextToken
      __typename
    }
    ideaEmployeeJoins {
      nextToken
      __typename
    }
    successStoryEmployeeJoins {
      nextToken
      __typename
    }
    helpRequestEmployeeJoins {
      nextToken
      __typename
    }
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateEmployeeSubscriptionVariables,
  APITypes.OnCreateEmployeeSubscription
>;
export const onUpdateEmployee = /* GraphQL */ `subscription OnUpdateEmployee($filter: ModelSubscriptionEmployeeFilterInput) {
  onUpdateEmployee(filter: $filter) {
    id
    owner
    disabled
    companyId
    createdAt
    name
    isAdmin
    email
    avatarUrl
    notRelevantParentGoals
    creatorEmail
    language
    locale
    interest
    career
    goals {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    organizationUnitEmployeeJoins {
      nextToken
      __typename
    }
    contributionEmployeeJoins {
      nextToken
      __typename
    }
    ideaEmployeeJoins {
      nextToken
      __typename
    }
    successStoryEmployeeJoins {
      nextToken
      __typename
    }
    helpRequestEmployeeJoins {
      nextToken
      __typename
    }
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateEmployeeSubscriptionVariables,
  APITypes.OnUpdateEmployeeSubscription
>;
export const onDeleteEmployee = /* GraphQL */ `subscription OnDeleteEmployee($filter: ModelSubscriptionEmployeeFilterInput) {
  onDeleteEmployee(filter: $filter) {
    id
    owner
    disabled
    companyId
    createdAt
    name
    isAdmin
    email
    avatarUrl
    notRelevantParentGoals
    creatorEmail
    language
    locale
    interest
    career
    goals {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    organizationUnitEmployeeJoins {
      nextToken
      __typename
    }
    contributionEmployeeJoins {
      nextToken
      __typename
    }
    ideaEmployeeJoins {
      nextToken
      __typename
    }
    successStoryEmployeeJoins {
      nextToken
      __typename
    }
    helpRequestEmployeeJoins {
      nextToken
      __typename
    }
    updatedAt
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteEmployeeSubscriptionVariables,
  APITypes.OnDeleteEmployeeSubscription
>;
export const onCreateOrganizationUnitEmployeeJoin = /* GraphQL */ `subscription OnCreateOrganizationUnitEmployeeJoin(
  $filter: ModelSubscriptionOrganizationUnitEmployeeJoinFilterInput
  $owner: String
) {
  onCreateOrganizationUnitEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    createdAt
    organizationUnitId
    employeeId
    updatedAt
    employeeOrganizationUnitEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateOrganizationUnitEmployeeJoinSubscriptionVariables,
  APITypes.OnCreateOrganizationUnitEmployeeJoinSubscription
>;
export const onUpdateOrganizationUnitEmployeeJoin = /* GraphQL */ `subscription OnUpdateOrganizationUnitEmployeeJoin(
  $filter: ModelSubscriptionOrganizationUnitEmployeeJoinFilterInput
  $owner: String
) {
  onUpdateOrganizationUnitEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    createdAt
    organizationUnitId
    employeeId
    updatedAt
    employeeOrganizationUnitEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateOrganizationUnitEmployeeJoinSubscriptionVariables,
  APITypes.OnUpdateOrganizationUnitEmployeeJoinSubscription
>;
export const onDeleteOrganizationUnitEmployeeJoin = /* GraphQL */ `subscription OnDeleteOrganizationUnitEmployeeJoin(
  $filter: ModelSubscriptionOrganizationUnitEmployeeJoinFilterInput
  $owner: String
) {
  onDeleteOrganizationUnitEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    createdAt
    organizationUnitId
    employeeId
    updatedAt
    employeeOrganizationUnitEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteOrganizationUnitEmployeeJoinSubscriptionVariables,
  APITypes.OnDeleteOrganizationUnitEmployeeJoinSubscription
>;
export const onCreateGoal = /* GraphQL */ `subscription OnCreateGoal(
  $filter: ModelSubscriptionGoalFilterInput
  $owner: String
) {
  onCreateGoal(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    createdAt
    title
    description
    startDate
    targetDate
    useTasks
    reward
    attachments
    creatorEmail
    position
    organizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    parentGoal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    childGoals {
      nextToken
      __typename
    }
    comments {
      nextToken
      __typename
    }
    status {
      nextToken
      __typename
    }
    redFlags {
      nextToken
      __typename
    }
    keyResults {
      nextToken
      __typename
    }
    successStories {
      nextToken
      __typename
    }
    events {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    contributions {
      nextToken
      __typename
    }
    ideas {
      nextToken
      __typename
    }
    helpRequests {
      nextToken
      __typename
    }
    isClosed
    statusFlag
    closingNotes
    updatedAt
    organizationUnitGoalsId
    employeeGoalsId
    goalChildGoalsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateGoalSubscriptionVariables,
  APITypes.OnCreateGoalSubscription
>;
export const onUpdateGoal = /* GraphQL */ `subscription OnUpdateGoal(
  $filter: ModelSubscriptionGoalFilterInput
  $owner: String
) {
  onUpdateGoal(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    createdAt
    title
    description
    startDate
    targetDate
    useTasks
    reward
    attachments
    creatorEmail
    position
    organizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    parentGoal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    childGoals {
      nextToken
      __typename
    }
    comments {
      nextToken
      __typename
    }
    status {
      nextToken
      __typename
    }
    redFlags {
      nextToken
      __typename
    }
    keyResults {
      nextToken
      __typename
    }
    successStories {
      nextToken
      __typename
    }
    events {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    contributions {
      nextToken
      __typename
    }
    ideas {
      nextToken
      __typename
    }
    helpRequests {
      nextToken
      __typename
    }
    isClosed
    statusFlag
    closingNotes
    updatedAt
    organizationUnitGoalsId
    employeeGoalsId
    goalChildGoalsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateGoalSubscriptionVariables,
  APITypes.OnUpdateGoalSubscription
>;
export const onDeleteGoal = /* GraphQL */ `subscription OnDeleteGoal(
  $filter: ModelSubscriptionGoalFilterInput
  $owner: String
) {
  onDeleteGoal(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    createdAt
    title
    description
    startDate
    targetDate
    useTasks
    reward
    attachments
    creatorEmail
    position
    organizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    parentGoal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    childGoals {
      nextToken
      __typename
    }
    comments {
      nextToken
      __typename
    }
    status {
      nextToken
      __typename
    }
    redFlags {
      nextToken
      __typename
    }
    keyResults {
      nextToken
      __typename
    }
    successStories {
      nextToken
      __typename
    }
    events {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    contributions {
      nextToken
      __typename
    }
    ideas {
      nextToken
      __typename
    }
    helpRequests {
      nextToken
      __typename
    }
    isClosed
    statusFlag
    closingNotes
    updatedAt
    organizationUnitGoalsId
    employeeGoalsId
    goalChildGoalsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteGoalSubscriptionVariables,
  APITypes.OnDeleteGoalSubscription
>;
export const onCreateStatus = /* GraphQL */ `subscription OnCreateStatus(
  $filter: ModelSubscriptionStatusFilterInput
  $owner: String
) {
  onCreateStatus(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    status
    goingWell
    toImprove
    challenges
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalStatusId
    statusEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateStatusSubscriptionVariables,
  APITypes.OnCreateStatusSubscription
>;
export const onUpdateStatus = /* GraphQL */ `subscription OnUpdateStatus(
  $filter: ModelSubscriptionStatusFilterInput
  $owner: String
) {
  onUpdateStatus(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    status
    goingWell
    toImprove
    challenges
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalStatusId
    statusEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateStatusSubscriptionVariables,
  APITypes.OnUpdateStatusSubscription
>;
export const onDeleteStatus = /* GraphQL */ `subscription OnDeleteStatus(
  $filter: ModelSubscriptionStatusFilterInput
  $owner: String
) {
  onDeleteStatus(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    status
    goingWell
    toImprove
    challenges
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalStatusId
    statusEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteStatusSubscriptionVariables,
  APITypes.OnDeleteStatusSubscription
>;
export const onCreateRedFlag = /* GraphQL */ `subscription OnCreateRedFlag(
  $filter: ModelSubscriptionRedFlagFilterInput
  $owner: String
) {
  onCreateRedFlag(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    text
    resolved
    resolvedTime
    resolvedBy
    resolvedComment
    reopenedTime
    reopenedBy
    reopenedComment
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    events {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    goalRedFlagsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateRedFlagSubscriptionVariables,
  APITypes.OnCreateRedFlagSubscription
>;
export const onUpdateRedFlag = /* GraphQL */ `subscription OnUpdateRedFlag(
  $filter: ModelSubscriptionRedFlagFilterInput
  $owner: String
) {
  onUpdateRedFlag(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    text
    resolved
    resolvedTime
    resolvedBy
    resolvedComment
    reopenedTime
    reopenedBy
    reopenedComment
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    events {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    goalRedFlagsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateRedFlagSubscriptionVariables,
  APITypes.OnUpdateRedFlagSubscription
>;
export const onDeleteRedFlag = /* GraphQL */ `subscription OnDeleteRedFlag(
  $filter: ModelSubscriptionRedFlagFilterInput
  $owner: String
) {
  onDeleteRedFlag(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    text
    resolved
    resolvedTime
    resolvedBy
    resolvedComment
    reopenedTime
    reopenedBy
    reopenedComment
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    events {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    goalRedFlagsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteRedFlagSubscriptionVariables,
  APITypes.OnDeleteRedFlagSubscription
>;
export const onCreateKeyResult = /* GraphQL */ `subscription OnCreateKeyResult(
  $filter: ModelSubscriptionKeyResultFilterInput
  $owner: String
) {
  onCreateKeyResult(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    description
    statusFlag
    statusText
    initialValue
    targetValue
    currentValue
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    events {
      nextToken
      __typename
    }
    updates {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    goalKeyResultsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateKeyResultSubscriptionVariables,
  APITypes.OnCreateKeyResultSubscription
>;
export const onUpdateKeyResult = /* GraphQL */ `subscription OnUpdateKeyResult(
  $filter: ModelSubscriptionKeyResultFilterInput
  $owner: String
) {
  onUpdateKeyResult(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    description
    statusFlag
    statusText
    initialValue
    targetValue
    currentValue
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    events {
      nextToken
      __typename
    }
    updates {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    goalKeyResultsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateKeyResultSubscriptionVariables,
  APITypes.OnUpdateKeyResultSubscription
>;
export const onDeleteKeyResult = /* GraphQL */ `subscription OnDeleteKeyResult(
  $filter: ModelSubscriptionKeyResultFilterInput
  $owner: String
) {
  onDeleteKeyResult(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    description
    statusFlag
    statusText
    initialValue
    targetValue
    currentValue
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    events {
      nextToken
      __typename
    }
    updates {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    goalKeyResultsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteKeyResultSubscriptionVariables,
  APITypes.OnDeleteKeyResultSubscription
>;
export const onCreateKeyResultUpdate = /* GraphQL */ `subscription OnCreateKeyResultUpdate(
  $filter: ModelSubscriptionKeyResultUpdateFilterInput
  $owner: String
) {
  onCreateKeyResultUpdate(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    currentValueBefore
    currentValueAfter
    statusFlagBefore
    statusFlagAfter
    text
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    dateOfUpdate
    createdAt
    updatedAt
    keyResultUpdatesId
    keyResultUpdateEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateKeyResultUpdateSubscriptionVariables,
  APITypes.OnCreateKeyResultUpdateSubscription
>;
export const onUpdateKeyResultUpdate = /* GraphQL */ `subscription OnUpdateKeyResultUpdate(
  $filter: ModelSubscriptionKeyResultUpdateFilterInput
  $owner: String
) {
  onUpdateKeyResultUpdate(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    currentValueBefore
    currentValueAfter
    statusFlagBefore
    statusFlagAfter
    text
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    dateOfUpdate
    createdAt
    updatedAt
    keyResultUpdatesId
    keyResultUpdateEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateKeyResultUpdateSubscriptionVariables,
  APITypes.OnUpdateKeyResultUpdateSubscription
>;
export const onDeleteKeyResultUpdate = /* GraphQL */ `subscription OnDeleteKeyResultUpdate(
  $filter: ModelSubscriptionKeyResultUpdateFilterInput
  $owner: String
) {
  onDeleteKeyResultUpdate(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    currentValueBefore
    currentValueAfter
    statusFlagBefore
    statusFlagAfter
    text
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    dateOfUpdate
    createdAt
    updatedAt
    keyResultUpdatesId
    keyResultUpdateEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteKeyResultUpdateSubscriptionVariables,
  APITypes.OnDeleteKeyResultUpdateSubscription
>;
export const onCreateSuccessStory = /* GraphQL */ `subscription OnCreateSuccessStory(
  $filter: ModelSubscriptionSuccessStoryFilterInput
  $owner: String
) {
  onCreateSuccessStory(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    name
    attachments
    employeeJoins {
      nextToken
      __typename
    }
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalSuccessStoriesId
    successStoryEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateSuccessStorySubscriptionVariables,
  APITypes.OnCreateSuccessStorySubscription
>;
export const onUpdateSuccessStory = /* GraphQL */ `subscription OnUpdateSuccessStory(
  $filter: ModelSubscriptionSuccessStoryFilterInput
  $owner: String
) {
  onUpdateSuccessStory(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    name
    attachments
    employeeJoins {
      nextToken
      __typename
    }
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalSuccessStoriesId
    successStoryEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateSuccessStorySubscriptionVariables,
  APITypes.OnUpdateSuccessStorySubscription
>;
export const onDeleteSuccessStory = /* GraphQL */ `subscription OnDeleteSuccessStory(
  $filter: ModelSubscriptionSuccessStoryFilterInput
  $owner: String
) {
  onDeleteSuccessStory(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    name
    attachments
    employeeJoins {
      nextToken
      __typename
    }
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalSuccessStoriesId
    successStoryEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteSuccessStorySubscriptionVariables,
  APITypes.OnDeleteSuccessStorySubscription
>;
export const onCreateTask = /* GraphQL */ `subscription OnCreateTask(
  $filter: ModelSubscriptionTaskFilterInput
  $owner: String
) {
  onCreateTask(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    title
    description
    startDate
    targetDate
    status
    attachments
    creatorEmail
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    employeeTasksId
    goalTasksId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateTaskSubscriptionVariables,
  APITypes.OnCreateTaskSubscription
>;
export const onUpdateTask = /* GraphQL */ `subscription OnUpdateTask(
  $filter: ModelSubscriptionTaskFilterInput
  $owner: String
) {
  onUpdateTask(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    title
    description
    startDate
    targetDate
    status
    attachments
    creatorEmail
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    employeeTasksId
    goalTasksId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateTaskSubscriptionVariables,
  APITypes.OnUpdateTaskSubscription
>;
export const onDeleteTask = /* GraphQL */ `subscription OnDeleteTask(
  $filter: ModelSubscriptionTaskFilterInput
  $owner: String
) {
  onDeleteTask(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    title
    description
    startDate
    targetDate
    status
    attachments
    creatorEmail
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    employeeTasksId
    goalTasksId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteTaskSubscriptionVariables,
  APITypes.OnDeleteTaskSubscription
>;
export const onCreateContribution = /* GraphQL */ `subscription OnCreateContribution(
  $filter: ModelSubscriptionContributionFilterInput
  $owner: String
) {
  onCreateContribution(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    description
    attachments
    employeeJoins {
      nextToken
      __typename
    }
    creatorEmail
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalContributionsId
    contributionEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateContributionSubscriptionVariables,
  APITypes.OnCreateContributionSubscription
>;
export const onUpdateContribution = /* GraphQL */ `subscription OnUpdateContribution(
  $filter: ModelSubscriptionContributionFilterInput
  $owner: String
) {
  onUpdateContribution(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    description
    attachments
    employeeJoins {
      nextToken
      __typename
    }
    creatorEmail
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalContributionsId
    contributionEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateContributionSubscriptionVariables,
  APITypes.OnUpdateContributionSubscription
>;
export const onDeleteContribution = /* GraphQL */ `subscription OnDeleteContribution(
  $filter: ModelSubscriptionContributionFilterInput
  $owner: String
) {
  onDeleteContribution(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    description
    attachments
    employeeJoins {
      nextToken
      __typename
    }
    creatorEmail
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalContributionsId
    contributionEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteContributionSubscriptionVariables,
  APITypes.OnDeleteContributionSubscription
>;
export const onCreateIdea = /* GraphQL */ `subscription OnCreateIdea(
  $filter: ModelSubscriptionIdeaFilterInput
  $owner: String
) {
  onCreateIdea(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    title
    description
    attachments
    creatorEmail
    employeeJoins {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalIdeasId
    ideaEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateIdeaSubscriptionVariables,
  APITypes.OnCreateIdeaSubscription
>;
export const onUpdateIdea = /* GraphQL */ `subscription OnUpdateIdea(
  $filter: ModelSubscriptionIdeaFilterInput
  $owner: String
) {
  onUpdateIdea(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    title
    description
    attachments
    creatorEmail
    employeeJoins {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalIdeasId
    ideaEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateIdeaSubscriptionVariables,
  APITypes.OnUpdateIdeaSubscription
>;
export const onDeleteIdea = /* GraphQL */ `subscription OnDeleteIdea(
  $filter: ModelSubscriptionIdeaFilterInput
  $owner: String
) {
  onDeleteIdea(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    title
    description
    attachments
    creatorEmail
    employeeJoins {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalIdeasId
    ideaEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteIdeaSubscriptionVariables,
  APITypes.OnDeleteIdeaSubscription
>;
export const onCreateHelpRequest = /* GraphQL */ `subscription OnCreateHelpRequest(
  $filter: ModelSubscriptionHelpRequestFilterInput
  $owner: String
) {
  onCreateHelpRequest(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    title
    description
    resolved
    resolvedTime
    resolvedBy
    resolvedComment
    reopenedTime
    reopenedBy
    reopenedComment
    attachments
    notRelevantForEmployees
    creatorEmail
    employeeJoins {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalHelpRequestsId
    helpRequestEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateHelpRequestSubscriptionVariables,
  APITypes.OnCreateHelpRequestSubscription
>;
export const onUpdateHelpRequest = /* GraphQL */ `subscription OnUpdateHelpRequest(
  $filter: ModelSubscriptionHelpRequestFilterInput
  $owner: String
) {
  onUpdateHelpRequest(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    title
    description
    resolved
    resolvedTime
    resolvedBy
    resolvedComment
    reopenedTime
    reopenedBy
    reopenedComment
    attachments
    notRelevantForEmployees
    creatorEmail
    employeeJoins {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalHelpRequestsId
    helpRequestEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateHelpRequestSubscriptionVariables,
  APITypes.OnUpdateHelpRequestSubscription
>;
export const onDeleteHelpRequest = /* GraphQL */ `subscription OnDeleteHelpRequest(
  $filter: ModelSubscriptionHelpRequestFilterInput
  $owner: String
) {
  onDeleteHelpRequest(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    title
    description
    resolved
    resolvedTime
    resolvedBy
    resolvedComment
    reopenedTime
    reopenedBy
    reopenedComment
    attachments
    notRelevantForEmployees
    creatorEmail
    employeeJoins {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalHelpRequestsId
    helpRequestEventId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteHelpRequestSubscriptionVariables,
  APITypes.OnDeleteHelpRequestSubscription
>;
export const onCreateComment = /* GraphQL */ `subscription OnCreateComment(
  $filter: ModelSubscriptionCommentFilterInput
  $owner: String
) {
  onCreateComment(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    text
    hostGoalId
    creatorEmail
    replies {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    status {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    redFlag {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    parentComment {
      id
      owner
      companyId
      text
      hostGoalId
      creatorEmail
      createdAt
      updatedAt
      goalCommentsId
      statusCommentsId
      redFlagCommentsId
      keyResultCommentsId
      keyResultUpdateCommentsId
      successStoryCommentsId
      taskCommentsId
      contributionCommentsId
      ideaCommentsId
      helpRequestCommentsId
      commentRepliesId
      eventCommentsId
      __typename
    }
    task {
      id
      owner
      companyId
      title
      description
      startDate
      targetDate
      status
      attachments
      creatorEmail
      createdAt
      updatedAt
      employeeTasksId
      goalTasksId
      __typename
    }
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    keyResultUpdate {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    createdAt
    updatedAt
    goalCommentsId
    statusCommentsId
    redFlagCommentsId
    keyResultCommentsId
    keyResultUpdateCommentsId
    successStoryCommentsId
    taskCommentsId
    contributionCommentsId
    ideaCommentsId
    helpRequestCommentsId
    commentRepliesId
    eventCommentsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateCommentSubscriptionVariables,
  APITypes.OnCreateCommentSubscription
>;
export const onUpdateComment = /* GraphQL */ `subscription OnUpdateComment(
  $filter: ModelSubscriptionCommentFilterInput
  $owner: String
) {
  onUpdateComment(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    text
    hostGoalId
    creatorEmail
    replies {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    status {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    redFlag {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    parentComment {
      id
      owner
      companyId
      text
      hostGoalId
      creatorEmail
      createdAt
      updatedAt
      goalCommentsId
      statusCommentsId
      redFlagCommentsId
      keyResultCommentsId
      keyResultUpdateCommentsId
      successStoryCommentsId
      taskCommentsId
      contributionCommentsId
      ideaCommentsId
      helpRequestCommentsId
      commentRepliesId
      eventCommentsId
      __typename
    }
    task {
      id
      owner
      companyId
      title
      description
      startDate
      targetDate
      status
      attachments
      creatorEmail
      createdAt
      updatedAt
      employeeTasksId
      goalTasksId
      __typename
    }
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    keyResultUpdate {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    createdAt
    updatedAt
    goalCommentsId
    statusCommentsId
    redFlagCommentsId
    keyResultCommentsId
    keyResultUpdateCommentsId
    successStoryCommentsId
    taskCommentsId
    contributionCommentsId
    ideaCommentsId
    helpRequestCommentsId
    commentRepliesId
    eventCommentsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateCommentSubscriptionVariables,
  APITypes.OnUpdateCommentSubscription
>;
export const onDeleteComment = /* GraphQL */ `subscription OnDeleteComment(
  $filter: ModelSubscriptionCommentFilterInput
  $owner: String
) {
  onDeleteComment(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    text
    hostGoalId
    creatorEmail
    replies {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    status {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    redFlag {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    parentComment {
      id
      owner
      companyId
      text
      hostGoalId
      creatorEmail
      createdAt
      updatedAt
      goalCommentsId
      statusCommentsId
      redFlagCommentsId
      keyResultCommentsId
      keyResultUpdateCommentsId
      successStoryCommentsId
      taskCommentsId
      contributionCommentsId
      ideaCommentsId
      helpRequestCommentsId
      commentRepliesId
      eventCommentsId
      __typename
    }
    task {
      id
      owner
      companyId
      title
      description
      startDate
      targetDate
      status
      attachments
      creatorEmail
      createdAt
      updatedAt
      employeeTasksId
      goalTasksId
      __typename
    }
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    keyResultUpdate {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    createdAt
    updatedAt
    goalCommentsId
    statusCommentsId
    redFlagCommentsId
    keyResultCommentsId
    keyResultUpdateCommentsId
    successStoryCommentsId
    taskCommentsId
    contributionCommentsId
    ideaCommentsId
    helpRequestCommentsId
    commentRepliesId
    eventCommentsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteCommentSubscriptionVariables,
  APITypes.OnDeleteCommentSubscription
>;
export const onCreateEvent = /* GraphQL */ `subscription OnCreateEvent(
  $filter: ModelSubscriptionEventFilterInput
  $owner: String
) {
  onCreateEvent(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    createdAt
    type
    eventType
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    keyResultUpdate {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    redFlag {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    status {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    likes
    updatedAt
    goalEventsId
    redFlagEventsId
    keyResultEventsId
    eventKeyResultUpdateId
    eventSuccessStoryId
    eventStatusId
    eventContributionId
    eventIdeaId
    eventHelpRequestId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateEventSubscriptionVariables,
  APITypes.OnCreateEventSubscription
>;
export const onUpdateEvent = /* GraphQL */ `subscription OnUpdateEvent(
  $filter: ModelSubscriptionEventFilterInput
  $owner: String
) {
  onUpdateEvent(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    createdAt
    type
    eventType
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    keyResultUpdate {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    redFlag {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    status {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    likes
    updatedAt
    goalEventsId
    redFlagEventsId
    keyResultEventsId
    eventKeyResultUpdateId
    eventSuccessStoryId
    eventStatusId
    eventContributionId
    eventIdeaId
    eventHelpRequestId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateEventSubscriptionVariables,
  APITypes.OnUpdateEventSubscription
>;
export const onDeleteEvent = /* GraphQL */ `subscription OnDeleteEvent(
  $filter: ModelSubscriptionEventFilterInput
  $owner: String
) {
  onDeleteEvent(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    createdAt
    type
    eventType
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    keyResultUpdate {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    redFlag {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    status {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    likes
    updatedAt
    goalEventsId
    redFlagEventsId
    keyResultEventsId
    eventKeyResultUpdateId
    eventSuccessStoryId
    eventStatusId
    eventContributionId
    eventIdeaId
    eventHelpRequestId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteEventSubscriptionVariables,
  APITypes.OnDeleteEventSubscription
>;
export const onCreateIdeaEmployeeJoin = /* GraphQL */ `subscription OnCreateIdeaEmployeeJoin(
  $filter: ModelSubscriptionIdeaEmployeeJoinFilterInput
  $owner: String
) {
  onCreateIdeaEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeIdeaEmployeeJoinsId
    ideaEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateIdeaEmployeeJoinSubscriptionVariables,
  APITypes.OnCreateIdeaEmployeeJoinSubscription
>;
export const onUpdateIdeaEmployeeJoin = /* GraphQL */ `subscription OnUpdateIdeaEmployeeJoin(
  $filter: ModelSubscriptionIdeaEmployeeJoinFilterInput
  $owner: String
) {
  onUpdateIdeaEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeIdeaEmployeeJoinsId
    ideaEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateIdeaEmployeeJoinSubscriptionVariables,
  APITypes.OnUpdateIdeaEmployeeJoinSubscription
>;
export const onDeleteIdeaEmployeeJoin = /* GraphQL */ `subscription OnDeleteIdeaEmployeeJoin(
  $filter: ModelSubscriptionIdeaEmployeeJoinFilterInput
  $owner: String
) {
  onDeleteIdeaEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeIdeaEmployeeJoinsId
    ideaEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteIdeaEmployeeJoinSubscriptionVariables,
  APITypes.OnDeleteIdeaEmployeeJoinSubscription
>;
export const onCreateSuccessStoryEmployeeJoin = /* GraphQL */ `subscription OnCreateSuccessStoryEmployeeJoin(
  $filter: ModelSubscriptionSuccessStoryEmployeeJoinFilterInput
  $owner: String
) {
  onCreateSuccessStoryEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeSuccessStoryEmployeeJoinsId
    successStoryEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateSuccessStoryEmployeeJoinSubscriptionVariables,
  APITypes.OnCreateSuccessStoryEmployeeJoinSubscription
>;
export const onUpdateSuccessStoryEmployeeJoin = /* GraphQL */ `subscription OnUpdateSuccessStoryEmployeeJoin(
  $filter: ModelSubscriptionSuccessStoryEmployeeJoinFilterInput
  $owner: String
) {
  onUpdateSuccessStoryEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeSuccessStoryEmployeeJoinsId
    successStoryEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateSuccessStoryEmployeeJoinSubscriptionVariables,
  APITypes.OnUpdateSuccessStoryEmployeeJoinSubscription
>;
export const onDeleteSuccessStoryEmployeeJoin = /* GraphQL */ `subscription OnDeleteSuccessStoryEmployeeJoin(
  $filter: ModelSubscriptionSuccessStoryEmployeeJoinFilterInput
  $owner: String
) {
  onDeleteSuccessStoryEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeSuccessStoryEmployeeJoinsId
    successStoryEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteSuccessStoryEmployeeJoinSubscriptionVariables,
  APITypes.OnDeleteSuccessStoryEmployeeJoinSubscription
>;
export const onCreateContributionEmployeeJoin = /* GraphQL */ `subscription OnCreateContributionEmployeeJoin(
  $filter: ModelSubscriptionContributionEmployeeJoinFilterInput
  $owner: String
) {
  onCreateContributionEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeContributionEmployeeJoinsId
    contributionEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateContributionEmployeeJoinSubscriptionVariables,
  APITypes.OnCreateContributionEmployeeJoinSubscription
>;
export const onUpdateContributionEmployeeJoin = /* GraphQL */ `subscription OnUpdateContributionEmployeeJoin(
  $filter: ModelSubscriptionContributionEmployeeJoinFilterInput
  $owner: String
) {
  onUpdateContributionEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeContributionEmployeeJoinsId
    contributionEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateContributionEmployeeJoinSubscriptionVariables,
  APITypes.OnUpdateContributionEmployeeJoinSubscription
>;
export const onDeleteContributionEmployeeJoin = /* GraphQL */ `subscription OnDeleteContributionEmployeeJoin(
  $filter: ModelSubscriptionContributionEmployeeJoinFilterInput
  $owner: String
) {
  onDeleteContributionEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeContributionEmployeeJoinsId
    contributionEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteContributionEmployeeJoinSubscriptionVariables,
  APITypes.OnDeleteContributionEmployeeJoinSubscription
>;
export const onCreateHelpRequestEmployeeJoin = /* GraphQL */ `subscription OnCreateHelpRequestEmployeeJoin(
  $filter: ModelSubscriptionHelpRequestEmployeeJoinFilterInput
  $owner: String
) {
  onCreateHelpRequestEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeHelpRequestEmployeeJoinsId
    helpRequestEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreateHelpRequestEmployeeJoinSubscriptionVariables,
  APITypes.OnCreateHelpRequestEmployeeJoinSubscription
>;
export const onUpdateHelpRequestEmployeeJoin = /* GraphQL */ `subscription OnUpdateHelpRequestEmployeeJoin(
  $filter: ModelSubscriptionHelpRequestEmployeeJoinFilterInput
  $owner: String
) {
  onUpdateHelpRequestEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeHelpRequestEmployeeJoinsId
    helpRequestEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdateHelpRequestEmployeeJoinSubscriptionVariables,
  APITypes.OnUpdateHelpRequestEmployeeJoinSubscription
>;
export const onDeleteHelpRequestEmployeeJoin = /* GraphQL */ `subscription OnDeleteHelpRequestEmployeeJoin(
  $filter: ModelSubscriptionHelpRequestEmployeeJoinFilterInput
  $owner: String
) {
  onDeleteHelpRequestEmployeeJoin(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeHelpRequestEmployeeJoinsId
    helpRequestEmployeeJoinsId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeleteHelpRequestEmployeeJoinSubscriptionVariables,
  APITypes.OnDeleteHelpRequestEmployeeJoinSubscription
>;
export const onCreatePlatformIntegration = /* GraphQL */ `subscription OnCreatePlatformIntegration(
  $filter: ModelSubscriptionPlatformIntegrationFilterInput
  $owner: String
) {
  onCreatePlatformIntegration(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    company {
      id
      owner
      companyId
      name
      creatorEmail
      isSubscribed
      subscriptionId
      customerId
      subscriptionExpireDate
      description
      createdAt
      updatedAt
      __typename
    }
    organizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    platform
    connectionHook
    oauthToken
    teamId
    metadata
    createdAt
    updatedAt
    organizationUnitPlatformIntegrationId
    companyPlatformIntegrationId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnCreatePlatformIntegrationSubscriptionVariables,
  APITypes.OnCreatePlatformIntegrationSubscription
>;
export const onUpdatePlatformIntegration = /* GraphQL */ `subscription OnUpdatePlatformIntegration(
  $filter: ModelSubscriptionPlatformIntegrationFilterInput
  $owner: String
) {
  onUpdatePlatformIntegration(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    company {
      id
      owner
      companyId
      name
      creatorEmail
      isSubscribed
      subscriptionId
      customerId
      subscriptionExpireDate
      description
      createdAt
      updatedAt
      __typename
    }
    organizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    platform
    connectionHook
    oauthToken
    teamId
    metadata
    createdAt
    updatedAt
    organizationUnitPlatformIntegrationId
    companyPlatformIntegrationId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnUpdatePlatformIntegrationSubscriptionVariables,
  APITypes.OnUpdatePlatformIntegrationSubscription
>;
export const onDeletePlatformIntegration = /* GraphQL */ `subscription OnDeletePlatformIntegration(
  $filter: ModelSubscriptionPlatformIntegrationFilterInput
  $owner: String
) {
  onDeletePlatformIntegration(filter: $filter, owner: $owner) {
    id
    owner
    companyId
    company {
      id
      owner
      companyId
      name
      creatorEmail
      isSubscribed
      subscriptionId
      customerId
      subscriptionExpireDate
      description
      createdAt
      updatedAt
      __typename
    }
    organizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    platform
    connectionHook
    oauthToken
    teamId
    metadata
    createdAt
    updatedAt
    organizationUnitPlatformIntegrationId
    companyPlatformIntegrationId
    __typename
  }
}
` as GeneratedSubscription<
  APITypes.OnDeletePlatformIntegrationSubscriptionVariables,
  APITypes.OnDeletePlatformIntegrationSubscription
>;
