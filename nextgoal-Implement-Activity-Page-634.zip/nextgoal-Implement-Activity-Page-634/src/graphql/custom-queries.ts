/* tslint:disable */
/* eslint-disable */

import * as APITypes from "../API";
type GeneratedQuery<InputType, OutputType> = string & {
  __generatedQueryInput: InputType;
  __generatedQueryOutput: OutputType;
};

export const listOrganizationUnitsWithEmployees =
  /* GraphQL */ `query listOrganizationUnitsWithEmployees(
  $companyId: ID!
  $position: ModelIntKeyConditionInput
  $sortDirection: ModelSortDirection
  $filter: ModelOrganizationUnitFilterInput
  $limit: Int
  $nextToken: String
) {
  organizationUnitByCompany(
    companyId: $companyId
    position: $position
    sortDirection: $sortDirection
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      companyId
      name
      position
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      notRelevantParentGoals
      parentOrganizationUnit {
        id
      }
      __typename
    }
    nextToken
    __typename
  }
}

` as GeneratedQuery<
    APITypes.ListOrganizationUnitsQueryVariables,
    APITypes.ListOrganizationUnitsQuery
  >;

export const listGoalsWithListInfo = /* GraphQL */ `query listGoalsWithListInfo(
  $companyId: ID!
  $position: ModelIntKeyConditionInput
  $sortDirection: ModelSortDirection
  $filter: ModelGoalFilterInput
  $limit: Int
  $nextToken: String
) {
  goalsByCompany(companyId: $companyId
    position: $position
    sortDirection: $sortDirection,
    filter: $filter,
    limit: $limit, 
    nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      title
      description
      reward
      startDate
      targetDate
      useTasks
      position
      createdAt
      creatorEmail
      updatedAt
      isClosed
      closingNotes
      statusFlag
      attachments
      organizationUnitGoalsId
      goalChildGoalsId
      employeeGoalsId
      __typename
      organizationUnit {
        id
        owner
        companyId
        name
        __typename
      }
      parentGoal {
        id
        owner
        companyId
        title
        description
        startDate
        targetDate
        __typename
      }
      childGoals {
        nextToken
        __typename
      }
      comments {
        nextToken
        __typename
        items {
          id
          owner
          companyId
          text
          createdAt
          hostGoalId
          creatorEmail
          replies {
            nextToken
            __typename
            items {
              id
              text
              createdAt
              creatorEmail
            }
          }
        }
      }
      status {
        nextToken
        __typename
        items {
          id
          owner
          companyId
          status
          goingWell
          toImprove
          challenges
          attachments
          createdAt
          creatorEmail
          goalStatusId
          comments {
            nextToken
            __typename
            items {
              id
              owner
              companyId
              text
              createdAt
              hostGoalId
              creatorEmail
              replies {
                nextToken
                __typename
                items {
                  id
                  text
                  createdAt
                  creatorEmail
                }
              }
            }
          }
        }
      }
      redFlags {
        items {
          id
          owner
          companyId
          createdAt
          text
          resolved
          resolvedTime
          resolvedBy
          resolvedComment
          reopenedTime
          reopenedBy
          reopenedComment
          goalRedFlagsId
          attachments
          creatorEmail
          comments {
            nextToken
            __typename
            items {
              id
              owner
              companyId
              text
              createdAt
              hostGoalId
              creatorEmail
              replies {
                nextToken
                __typename
                items {
                  id
                  text
                  createdAt
                  creatorEmail
                }
              }
            }
          }
        }
        nextToken
        __typename
      }
      keyResults {
        items {
          id
          owner
          companyId
          createdAt
          updatedAt
          description
          statusFlag
          statusText
          initialValue
          targetValue
          currentValue
          attachments
          creatorEmail
          goalKeyResultsId
          goal {
            id
            title
            organizationUnit {
              id
            }
          }
          updates {
            items {
              id
              owner
              companyId
              createdAt
              currentValueBefore
              currentValueAfter
              statusFlagBefore
              statusFlagAfter
              text
              attachments
              creatorEmail
              keyResultUpdatesId
              dateOfUpdate
              comments {
                nextToken
                __typename
                items {
                  id
                  owner
                  companyId
                  text
                  createdAt
                  hostGoalId
                  creatorEmail
                  replies {
                    nextToken
                    __typename
                    items {
                      id
                      text
                      createdAt
                      creatorEmail
                    }
                  }
                }
              }
            }
          }
          comments {
            nextToken
            __typename
            items {
              id
              owner
              companyId
              text
              createdAt
              hostGoalId
              creatorEmail
              replies {
                nextToken
                __typename
                items {
                  id
                  text
                  createdAt
                  creatorEmail
                }
              }
            }
          }
        }
        nextToken
        __typename
      }
      successStories {
        nextToken
        __typename
        items {
          id
          owner
          companyId
          name
          createdAt
          attachments
          goalSuccessStoriesId
          employeeJoins {
            nextToken
            __typename
            items {
              id
              employeeSuccessStoryEmployeeJoinsId
            }
          }
          creatorEmail
          goal {
            id
          }
          comments {
            nextToken
            __typename
            items {
              id
              owner
              companyId
              text
              createdAt
              hostGoalId
              creatorEmail
              replies {
                nextToken
                __typename
                items {
                  id
                  text
                  createdAt
                  creatorEmail
                }
              }
            }
          }
        }
      }
      events {
        nextToken
        __typename
      }
      employee {
        id
        owner
        companyId
        name
        email
        __typename
      }
      contributions {
        nextToken
        __typename
        items {
          id
          owner
          companyId
          createdAt
          description
          attachments
          goalContributionsId
          employeeJoins {
            nextToken
            __typename
            items {
              id
              employeeContributionEmployeeJoinsId
            }
          }
          comments {
            nextToken
            __typename
            items {
              id
              owner
              companyId
              text
              createdAt
              hostGoalId
              creatorEmail
              replies {
                nextToken
                __typename
                items {
                  id
                  text
                  createdAt
                  creatorEmail
                }
              }
            }
          }
        }
      }
      tasks {
        items {
          id
          owner
          companyId
          createdAt
          title
          description
          startDate
          targetDate
          status
          employee {
            id
            name
            email
          }
          comments {
            nextToken
            __typename
            items {
              id
              owner
              companyId
              text
              createdAt
              hostGoalId
              creatorEmail
              replies {
                nextToken
                __typename
                items {
                  id
                  text
                  createdAt
                  creatorEmail
                }
              }
            }
          }
        }
        nextToken
        __typename
      }
      ideas {
        items {
          id
          owner
          companyId
          title
          description
          createdAt
          updatedAt
          goalIdeasId
          attachments
          creatorEmail
          employeeJoins {
            nextToken
            __typename
            items {
              id
              employeeIdeaEmployeeJoinsId
            }
          }
          comments {
            nextToken
            __typename
            items {
              id
              owner
              companyId
              text
              createdAt
              hostGoalId
              creatorEmail
              replies {
                nextToken
                __typename
                items {
                  id
                  text
                  createdAt
                  creatorEmail
                }
              }
            }
          }
        }
        nextToken
        __typename
      }
      helpRequests {
        items {
          id
          owner
          companyId
          title
          description
          resolved
          resolvedTime
          resolvedBy
          resolvedComment
          reopenedTime
          reopenedBy
          reopenedComment
          createdAt
          updatedAt
          goalHelpRequestsId
          attachments
          notRelevantForEmployees
          creatorEmail
          employeeJoins {
            nextToken
            __typename
            items {
              id
              employeeHelpRequestEmployeeJoinsId
            }
          }
          comments {
            nextToken
            __typename
            items {
              id
              owner
              companyId
              text
              createdAt
              hostGoalId
              creatorEmail
              replies {
                nextToken
                __typename
                items {
                  id
                  text
                  createdAt
                  creatorEmail
                }
              }
            }
          }
        }
        nextToken
        __typename
      }
    }
    nextToken
    __typename
  }
},

` as GeneratedQuery<
  APITypes.GoalsByCompanyQueryVariables,
  APITypes.GoalsByCompanyQuery
>;

export const integrationByCompanyForCache = /* GraphQL */ `query IntegrationByCompanyForCache(
  $companyId: ID!
  $sortDirection: ModelSortDirection
  $filter: ModelPlatformIntegrationFilterInput
  $limit: Int
  $nextToken: String
) {
  integrationByCompany(
    companyId: $companyId
    sortDirection: $sortDirection
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      companyId
      platform
      organizationUnitPlatformIntegrationId
      companyPlatformIntegrationId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.IntegrationByCompanyQueryVariables,
  APITypes.IntegrationByCompanyQuery
>;