import * as APITypes from "../API";
type GeneratedMutation<InputType, OutputType> = string & {
  __generatedQueryInput: InputType;
  __generatedQueryOutput: OutputType;
};

//custom query to avoid unauthorized access to child entities
export const createEmployeeCustom = /* GraphQL */ `
  mutation CreateEmployeeCustom(
    $input: CreateEmployeeInput!
    $condition: ModelEmployeeConditionInput
  ) {
    createEmployee(input: $input, condition: $condition) {
      id
      owner
      disabled
      companyId
      name
      email
      isAdmin
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      createdAt
      updatedAt
      __typename
    }
  }
`;

export const createKeyResultUpdateWithGoal =
  /* GraphQL */ `mutation CreateKeyResultUpdateWithGoal(
    $input: CreateKeyResultUpdateInput!
    $condition: ModelKeyResultUpdateConditionInput
  ) {
    createKeyResultUpdate(input: $input, condition: $condition) {
      id
      owner
      companyId
      keyResult {
        id
        owner
        companyId
        description
        statusFlag
        statusText
        initialValue
        targetValue
        currentValue
        attachments
        creatorEmail
        createdAt
        updatedAt
        goalKeyResultsId
        goal {
          id
          employeeGoalsId
        }
        __typename
      }
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      comments {
        nextToken
        __typename
      }
      creatorEmail
      event {
        id
        owner
        companyId
        createdAt
        type
        eventType
        updatedAt
        goalEventsId
        redFlagEventsId
        keyResultEventsId
        eventKeyResultUpdateId
        eventSuccessStoryId
        eventStatusId
        eventContributionId
        eventIdeaId
        eventHelpRequestId
        __typename
      }
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
  }
  ` as GeneratedMutation<
    APITypes.CreateKeyResultUpdateMutationVariables,
    APITypes.CreateKeyResultUpdateMutation
  >;
