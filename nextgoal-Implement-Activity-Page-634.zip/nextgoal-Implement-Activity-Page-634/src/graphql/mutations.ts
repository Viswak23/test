/* tslint:disable */
/* eslint-disable */
// this is an auto generated file. This will be overwritten

import * as APITypes from "../API";
type GeneratedMutation<InputType, OutputType> = string & {
  __generatedMutationInput: InputType;
  __generatedMutationOutput: OutputType;
};

export const createOrganizationUnit = /* GraphQL */ `mutation CreateOrganizationUnit(
  $input: CreateOrganizationUnitInput!
  $condition: ModelOrganizationUnitConditionInput
) {
  createOrganizationUnit(input: $input, condition: $condition) {
    id
    owner
    companyId
    name
    description
    creatorEmail
    position
    notRelevantParentGoals
    parentOrganizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    childOrzganizationUnits {
      nextToken
      __typename
    }
    goals {
      nextToken
      __typename
    }
    platformIntegration {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    organizationUnitChildOrzganizationUnitsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateOrganizationUnitMutationVariables,
  APITypes.CreateOrganizationUnitMutation
>;
export const updateOrganizationUnit = /* GraphQL */ `mutation UpdateOrganizationUnit(
  $input: UpdateOrganizationUnitInput!
  $condition: ModelOrganizationUnitConditionInput
) {
  updateOrganizationUnit(input: $input, condition: $condition) {
    id
    owner
    companyId
    name
    description
    creatorEmail
    position
    notRelevantParentGoals
    parentOrganizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    childOrzganizationUnits {
      nextToken
      __typename
    }
    goals {
      nextToken
      __typename
    }
    platformIntegration {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    organizationUnitChildOrzganizationUnitsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateOrganizationUnitMutationVariables,
  APITypes.UpdateOrganizationUnitMutation
>;
export const deleteOrganizationUnit = /* GraphQL */ `mutation DeleteOrganizationUnit(
  $input: DeleteOrganizationUnitInput!
  $condition: ModelOrganizationUnitConditionInput
) {
  deleteOrganizationUnit(input: $input, condition: $condition) {
    id
    owner
    companyId
    name
    description
    creatorEmail
    position
    notRelevantParentGoals
    parentOrganizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    childOrzganizationUnits {
      nextToken
      __typename
    }
    goals {
      nextToken
      __typename
    }
    platformIntegration {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    organizationUnitChildOrzganizationUnitsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteOrganizationUnitMutationVariables,
  APITypes.DeleteOrganizationUnitMutation
>;
export const createNorthStar = /* GraphQL */ `mutation CreateNorthStar(
  $input: CreateNorthStarInput!
  $condition: ModelNorthStarConditionInput
) {
  createNorthStar(input: $input, condition: $condition) {
    id
    owner
    companyId
    title
    description
    attachments
    creatorEmail
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateNorthStarMutationVariables,
  APITypes.CreateNorthStarMutation
>;
export const updateNorthStar = /* GraphQL */ `mutation UpdateNorthStar(
  $input: UpdateNorthStarInput!
  $condition: ModelNorthStarConditionInput
) {
  updateNorthStar(input: $input, condition: $condition) {
    id
    owner
    companyId
    title
    description
    attachments
    creatorEmail
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateNorthStarMutationVariables,
  APITypes.UpdateNorthStarMutation
>;
export const deleteNorthStar = /* GraphQL */ `mutation DeleteNorthStar(
  $input: DeleteNorthStarInput!
  $condition: ModelNorthStarConditionInput
) {
  deleteNorthStar(input: $input, condition: $condition) {
    id
    owner
    companyId
    title
    description
    attachments
    creatorEmail
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteNorthStarMutationVariables,
  APITypes.DeleteNorthStarMutation
>;
export const createNotification = /* GraphQL */ `mutation CreateNotification(
  $input: CreateNotificationInput!
  $condition: ModelNotificationConditionInput
) {
  createNotification(input: $input, condition: $condition) {
    id
    owner
    companyId
    notificationType
    type
    toEmployeeEmail
    isRead
    eventId
    goalId
    createdAt
    expireAt
    updatedAt
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateNotificationMutationVariables,
  APITypes.CreateNotificationMutation
>;
export const updateNotification = /* GraphQL */ `mutation UpdateNotification(
  $input: UpdateNotificationInput!
  $condition: ModelNotificationConditionInput
) {
  updateNotification(input: $input, condition: $condition) {
    id
    owner
    companyId
    notificationType
    type
    toEmployeeEmail
    isRead
    eventId
    goalId
    createdAt
    expireAt
    updatedAt
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateNotificationMutationVariables,
  APITypes.UpdateNotificationMutation
>;
export const deleteNotification = /* GraphQL */ `mutation DeleteNotification(
  $input: DeleteNotificationInput!
  $condition: ModelNotificationConditionInput
) {
  deleteNotification(input: $input, condition: $condition) {
    id
    owner
    companyId
    notificationType
    type
    toEmployeeEmail
    isRead
    eventId
    goalId
    createdAt
    expireAt
    updatedAt
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteNotificationMutationVariables,
  APITypes.DeleteNotificationMutation
>;
export const createCompany = /* GraphQL */ `mutation CreateCompany(
  $input: CreateCompanyInput!
  $condition: ModelCompanyConditionInput
) {
  createCompany(input: $input, condition: $condition) {
    id
    owner
    companyId
    name
    creatorEmail
    isSubscribed
    subscriptionId
    customerId
    subscriptionExpireDate
    description
    platformIntegration {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateCompanyMutationVariables,
  APITypes.CreateCompanyMutation
>;
export const updateCompany = /* GraphQL */ `mutation UpdateCompany(
  $input: UpdateCompanyInput!
  $condition: ModelCompanyConditionInput
) {
  updateCompany(input: $input, condition: $condition) {
    id
    owner
    companyId
    name
    creatorEmail
    isSubscribed
    subscriptionId
    customerId
    subscriptionExpireDate
    description
    platformIntegration {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateCompanyMutationVariables,
  APITypes.UpdateCompanyMutation
>;
export const deleteCompany = /* GraphQL */ `mutation DeleteCompany(
  $input: DeleteCompanyInput!
  $condition: ModelCompanyConditionInput
) {
  deleteCompany(input: $input, condition: $condition) {
    id
    owner
    companyId
    name
    creatorEmail
    isSubscribed
    subscriptionId
    customerId
    subscriptionExpireDate
    description
    platformIntegration {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteCompanyMutationVariables,
  APITypes.DeleteCompanyMutation
>;
export const createEmployee = /* GraphQL */ `mutation CreateEmployee(
  $input: CreateEmployeeInput!
  $condition: ModelEmployeeConditionInput
) {
  createEmployee(input: $input, condition: $condition) {
    id
    owner
    disabled
    companyId
    createdAt
    name
    isAdmin
    email
    avatarUrl
    notRelevantParentGoals
    creatorEmail
    language
    locale
    interest
    career
    goals {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    organizationUnitEmployeeJoins {
      nextToken
      __typename
    }
    contributionEmployeeJoins {
      nextToken
      __typename
    }
    ideaEmployeeJoins {
      nextToken
      __typename
    }
    successStoryEmployeeJoins {
      nextToken
      __typename
    }
    helpRequestEmployeeJoins {
      nextToken
      __typename
    }
    updatedAt
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateEmployeeMutationVariables,
  APITypes.CreateEmployeeMutation
>;
export const updateEmployee = /* GraphQL */ `mutation UpdateEmployee(
  $input: UpdateEmployeeInput!
  $condition: ModelEmployeeConditionInput
) {
  updateEmployee(input: $input, condition: $condition) {
    id
    owner
    disabled
    companyId
    createdAt
    name
    isAdmin
    email
    avatarUrl
    notRelevantParentGoals
    creatorEmail
    language
    locale
    interest
    career
    goals {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    organizationUnitEmployeeJoins {
      nextToken
      __typename
    }
    contributionEmployeeJoins {
      nextToken
      __typename
    }
    ideaEmployeeJoins {
      nextToken
      __typename
    }
    successStoryEmployeeJoins {
      nextToken
      __typename
    }
    helpRequestEmployeeJoins {
      nextToken
      __typename
    }
    updatedAt
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateEmployeeMutationVariables,
  APITypes.UpdateEmployeeMutation
>;
export const deleteEmployee = /* GraphQL */ `mutation DeleteEmployee(
  $input: DeleteEmployeeInput!
  $condition: ModelEmployeeConditionInput
) {
  deleteEmployee(input: $input, condition: $condition) {
    id
    owner
    disabled
    companyId
    createdAt
    name
    isAdmin
    email
    avatarUrl
    notRelevantParentGoals
    creatorEmail
    language
    locale
    interest
    career
    goals {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    organizationUnitEmployeeJoins {
      nextToken
      __typename
    }
    contributionEmployeeJoins {
      nextToken
      __typename
    }
    ideaEmployeeJoins {
      nextToken
      __typename
    }
    successStoryEmployeeJoins {
      nextToken
      __typename
    }
    helpRequestEmployeeJoins {
      nextToken
      __typename
    }
    updatedAt
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteEmployeeMutationVariables,
  APITypes.DeleteEmployeeMutation
>;
export const createOrganizationUnitEmployeeJoin = /* GraphQL */ `mutation CreateOrganizationUnitEmployeeJoin(
  $input: CreateOrganizationUnitEmployeeJoinInput!
  $condition: ModelOrganizationUnitEmployeeJoinConditionInput
) {
  createOrganizationUnitEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    createdAt
    organizationUnitId
    employeeId
    updatedAt
    employeeOrganizationUnitEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateOrganizationUnitEmployeeJoinMutationVariables,
  APITypes.CreateOrganizationUnitEmployeeJoinMutation
>;
export const updateOrganizationUnitEmployeeJoin = /* GraphQL */ `mutation UpdateOrganizationUnitEmployeeJoin(
  $input: UpdateOrganizationUnitEmployeeJoinInput!
  $condition: ModelOrganizationUnitEmployeeJoinConditionInput
) {
  updateOrganizationUnitEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    createdAt
    organizationUnitId
    employeeId
    updatedAt
    employeeOrganizationUnitEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateOrganizationUnitEmployeeJoinMutationVariables,
  APITypes.UpdateOrganizationUnitEmployeeJoinMutation
>;
export const deleteOrganizationUnitEmployeeJoin = /* GraphQL */ `mutation DeleteOrganizationUnitEmployeeJoin(
  $input: DeleteOrganizationUnitEmployeeJoinInput!
  $condition: ModelOrganizationUnitEmployeeJoinConditionInput
) {
  deleteOrganizationUnitEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    createdAt
    organizationUnitId
    employeeId
    updatedAt
    employeeOrganizationUnitEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteOrganizationUnitEmployeeJoinMutationVariables,
  APITypes.DeleteOrganizationUnitEmployeeJoinMutation
>;
export const createGoal = /* GraphQL */ `mutation CreateGoal(
  $input: CreateGoalInput!
  $condition: ModelGoalConditionInput
) {
  createGoal(input: $input, condition: $condition) {
    id
    owner
    companyId
    createdAt
    title
    description
    startDate
    targetDate
    useTasks
    reward
    attachments
    creatorEmail
    position
    organizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    parentGoal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    childGoals {
      nextToken
      __typename
    }
    comments {
      nextToken
      __typename
    }
    status {
      nextToken
      __typename
    }
    redFlags {
      nextToken
      __typename
    }
    keyResults {
      nextToken
      __typename
    }
    successStories {
      nextToken
      __typename
    }
    events {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    contributions {
      nextToken
      __typename
    }
    ideas {
      nextToken
      __typename
    }
    helpRequests {
      nextToken
      __typename
    }
    isClosed
    statusFlag
    closingNotes
    updatedAt
    organizationUnitGoalsId
    employeeGoalsId
    goalChildGoalsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateGoalMutationVariables,
  APITypes.CreateGoalMutation
>;
export const updateGoal = /* GraphQL */ `mutation UpdateGoal(
  $input: UpdateGoalInput!
  $condition: ModelGoalConditionInput
) {
  updateGoal(input: $input, condition: $condition) {
    id
    owner
    companyId
    createdAt
    title
    description
    startDate
    targetDate
    useTasks
    reward
    attachments
    creatorEmail
    position
    organizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    parentGoal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    childGoals {
      nextToken
      __typename
    }
    comments {
      nextToken
      __typename
    }
    status {
      nextToken
      __typename
    }
    redFlags {
      nextToken
      __typename
    }
    keyResults {
      nextToken
      __typename
    }
    successStories {
      nextToken
      __typename
    }
    events {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    contributions {
      nextToken
      __typename
    }
    ideas {
      nextToken
      __typename
    }
    helpRequests {
      nextToken
      __typename
    }
    isClosed
    statusFlag
    closingNotes
    updatedAt
    organizationUnitGoalsId
    employeeGoalsId
    goalChildGoalsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateGoalMutationVariables,
  APITypes.UpdateGoalMutation
>;
export const deleteGoal = /* GraphQL */ `mutation DeleteGoal(
  $input: DeleteGoalInput!
  $condition: ModelGoalConditionInput
) {
  deleteGoal(input: $input, condition: $condition) {
    id
    owner
    companyId
    createdAt
    title
    description
    startDate
    targetDate
    useTasks
    reward
    attachments
    creatorEmail
    position
    organizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    parentGoal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    childGoals {
      nextToken
      __typename
    }
    comments {
      nextToken
      __typename
    }
    status {
      nextToken
      __typename
    }
    redFlags {
      nextToken
      __typename
    }
    keyResults {
      nextToken
      __typename
    }
    successStories {
      nextToken
      __typename
    }
    events {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    contributions {
      nextToken
      __typename
    }
    ideas {
      nextToken
      __typename
    }
    helpRequests {
      nextToken
      __typename
    }
    isClosed
    statusFlag
    closingNotes
    updatedAt
    organizationUnitGoalsId
    employeeGoalsId
    goalChildGoalsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteGoalMutationVariables,
  APITypes.DeleteGoalMutation
>;
export const createStatus = /* GraphQL */ `mutation CreateStatus(
  $input: CreateStatusInput!
  $condition: ModelStatusConditionInput
) {
  createStatus(input: $input, condition: $condition) {
    id
    owner
    companyId
    status
    goingWell
    toImprove
    challenges
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalStatusId
    statusEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateStatusMutationVariables,
  APITypes.CreateStatusMutation
>;
export const updateStatus = /* GraphQL */ `mutation UpdateStatus(
  $input: UpdateStatusInput!
  $condition: ModelStatusConditionInput
) {
  updateStatus(input: $input, condition: $condition) {
    id
    owner
    companyId
    status
    goingWell
    toImprove
    challenges
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalStatusId
    statusEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateStatusMutationVariables,
  APITypes.UpdateStatusMutation
>;
export const deleteStatus = /* GraphQL */ `mutation DeleteStatus(
  $input: DeleteStatusInput!
  $condition: ModelStatusConditionInput
) {
  deleteStatus(input: $input, condition: $condition) {
    id
    owner
    companyId
    status
    goingWell
    toImprove
    challenges
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalStatusId
    statusEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteStatusMutationVariables,
  APITypes.DeleteStatusMutation
>;
export const createRedFlag = /* GraphQL */ `mutation CreateRedFlag(
  $input: CreateRedFlagInput!
  $condition: ModelRedFlagConditionInput
) {
  createRedFlag(input: $input, condition: $condition) {
    id
    owner
    companyId
    text
    resolved
    resolvedTime
    resolvedBy
    resolvedComment
    reopenedTime
    reopenedBy
    reopenedComment
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    events {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    goalRedFlagsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateRedFlagMutationVariables,
  APITypes.CreateRedFlagMutation
>;
export const updateRedFlag = /* GraphQL */ `mutation UpdateRedFlag(
  $input: UpdateRedFlagInput!
  $condition: ModelRedFlagConditionInput
) {
  updateRedFlag(input: $input, condition: $condition) {
    id
    owner
    companyId
    text
    resolved
    resolvedTime
    resolvedBy
    resolvedComment
    reopenedTime
    reopenedBy
    reopenedComment
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    events {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    goalRedFlagsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateRedFlagMutationVariables,
  APITypes.UpdateRedFlagMutation
>;
export const deleteRedFlag = /* GraphQL */ `mutation DeleteRedFlag(
  $input: DeleteRedFlagInput!
  $condition: ModelRedFlagConditionInput
) {
  deleteRedFlag(input: $input, condition: $condition) {
    id
    owner
    companyId
    text
    resolved
    resolvedTime
    resolvedBy
    resolvedComment
    reopenedTime
    reopenedBy
    reopenedComment
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    events {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    goalRedFlagsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteRedFlagMutationVariables,
  APITypes.DeleteRedFlagMutation
>;
export const createKeyResult = /* GraphQL */ `mutation CreateKeyResult(
  $input: CreateKeyResultInput!
  $condition: ModelKeyResultConditionInput
) {
  createKeyResult(input: $input, condition: $condition) {
    id
    owner
    companyId
    description
    statusFlag
    statusText
    initialValue
    targetValue
    currentValue
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    events {
      nextToken
      __typename
    }
    updates {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    goalKeyResultsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateKeyResultMutationVariables,
  APITypes.CreateKeyResultMutation
>;
export const updateKeyResult = /* GraphQL */ `mutation UpdateKeyResult(
  $input: UpdateKeyResultInput!
  $condition: ModelKeyResultConditionInput
) {
  updateKeyResult(input: $input, condition: $condition) {
    id
    owner
    companyId
    description
    statusFlag
    statusText
    initialValue
    targetValue
    currentValue
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    events {
      nextToken
      __typename
    }
    updates {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    goalKeyResultsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateKeyResultMutationVariables,
  APITypes.UpdateKeyResultMutation
>;
export const deleteKeyResult = /* GraphQL */ `mutation DeleteKeyResult(
  $input: DeleteKeyResultInput!
  $condition: ModelKeyResultConditionInput
) {
  deleteKeyResult(input: $input, condition: $condition) {
    id
    owner
    companyId
    description
    statusFlag
    statusText
    initialValue
    targetValue
    currentValue
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    events {
      nextToken
      __typename
    }
    updates {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    goalKeyResultsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteKeyResultMutationVariables,
  APITypes.DeleteKeyResultMutation
>;
export const createKeyResultUpdate = /* GraphQL */ `mutation CreateKeyResultUpdate(
  $input: CreateKeyResultUpdateInput!
  $condition: ModelKeyResultUpdateConditionInput
) {
  createKeyResultUpdate(input: $input, condition: $condition) {
    id
    owner
    companyId
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    currentValueBefore
    currentValueAfter
    statusFlagBefore
    statusFlagAfter
    text
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    dateOfUpdate
    createdAt
    updatedAt
    keyResultUpdatesId
    keyResultUpdateEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateKeyResultUpdateMutationVariables,
  APITypes.CreateKeyResultUpdateMutation
>;
export const updateKeyResultUpdate = /* GraphQL */ `mutation UpdateKeyResultUpdate(
  $input: UpdateKeyResultUpdateInput!
  $condition: ModelKeyResultUpdateConditionInput
) {
  updateKeyResultUpdate(input: $input, condition: $condition) {
    id
    owner
    companyId
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    currentValueBefore
    currentValueAfter
    statusFlagBefore
    statusFlagAfter
    text
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    dateOfUpdate
    createdAt
    updatedAt
    keyResultUpdatesId
    keyResultUpdateEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateKeyResultUpdateMutationVariables,
  APITypes.UpdateKeyResultUpdateMutation
>;
export const deleteKeyResultUpdate = /* GraphQL */ `mutation DeleteKeyResultUpdate(
  $input: DeleteKeyResultUpdateInput!
  $condition: ModelKeyResultUpdateConditionInput
) {
  deleteKeyResultUpdate(input: $input, condition: $condition) {
    id
    owner
    companyId
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    currentValueBefore
    currentValueAfter
    statusFlagBefore
    statusFlagAfter
    text
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    dateOfUpdate
    createdAt
    updatedAt
    keyResultUpdatesId
    keyResultUpdateEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteKeyResultUpdateMutationVariables,
  APITypes.DeleteKeyResultUpdateMutation
>;
export const createSuccessStory = /* GraphQL */ `mutation CreateSuccessStory(
  $input: CreateSuccessStoryInput!
  $condition: ModelSuccessStoryConditionInput
) {
  createSuccessStory(input: $input, condition: $condition) {
    id
    owner
    companyId
    name
    attachments
    employeeJoins {
      nextToken
      __typename
    }
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalSuccessStoriesId
    successStoryEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateSuccessStoryMutationVariables,
  APITypes.CreateSuccessStoryMutation
>;
export const updateSuccessStory = /* GraphQL */ `mutation UpdateSuccessStory(
  $input: UpdateSuccessStoryInput!
  $condition: ModelSuccessStoryConditionInput
) {
  updateSuccessStory(input: $input, condition: $condition) {
    id
    owner
    companyId
    name
    attachments
    employeeJoins {
      nextToken
      __typename
    }
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalSuccessStoriesId
    successStoryEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateSuccessStoryMutationVariables,
  APITypes.UpdateSuccessStoryMutation
>;
export const deleteSuccessStory = /* GraphQL */ `mutation DeleteSuccessStory(
  $input: DeleteSuccessStoryInput!
  $condition: ModelSuccessStoryConditionInput
) {
  deleteSuccessStory(input: $input, condition: $condition) {
    id
    owner
    companyId
    name
    attachments
    employeeJoins {
      nextToken
      __typename
    }
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalSuccessStoriesId
    successStoryEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteSuccessStoryMutationVariables,
  APITypes.DeleteSuccessStoryMutation
>;
export const createTask = /* GraphQL */ `mutation CreateTask(
  $input: CreateTaskInput!
  $condition: ModelTaskConditionInput
) {
  createTask(input: $input, condition: $condition) {
    id
    owner
    companyId
    title
    description
    startDate
    targetDate
    status
    attachments
    creatorEmail
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    employeeTasksId
    goalTasksId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateTaskMutationVariables,
  APITypes.CreateTaskMutation
>;
export const updateTask = /* GraphQL */ `mutation UpdateTask(
  $input: UpdateTaskInput!
  $condition: ModelTaskConditionInput
) {
  updateTask(input: $input, condition: $condition) {
    id
    owner
    companyId
    title
    description
    startDate
    targetDate
    status
    attachments
    creatorEmail
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    employeeTasksId
    goalTasksId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateTaskMutationVariables,
  APITypes.UpdateTaskMutation
>;
export const deleteTask = /* GraphQL */ `mutation DeleteTask(
  $input: DeleteTaskInput!
  $condition: ModelTaskConditionInput
) {
  deleteTask(input: $input, condition: $condition) {
    id
    owner
    companyId
    title
    description
    startDate
    targetDate
    status
    attachments
    creatorEmail
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    employeeTasksId
    goalTasksId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteTaskMutationVariables,
  APITypes.DeleteTaskMutation
>;
export const createContribution = /* GraphQL */ `mutation CreateContribution(
  $input: CreateContributionInput!
  $condition: ModelContributionConditionInput
) {
  createContribution(input: $input, condition: $condition) {
    id
    owner
    companyId
    description
    attachments
    employeeJoins {
      nextToken
      __typename
    }
    creatorEmail
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalContributionsId
    contributionEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateContributionMutationVariables,
  APITypes.CreateContributionMutation
>;
export const updateContribution = /* GraphQL */ `mutation UpdateContribution(
  $input: UpdateContributionInput!
  $condition: ModelContributionConditionInput
) {
  updateContribution(input: $input, condition: $condition) {
    id
    owner
    companyId
    description
    attachments
    employeeJoins {
      nextToken
      __typename
    }
    creatorEmail
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalContributionsId
    contributionEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateContributionMutationVariables,
  APITypes.UpdateContributionMutation
>;
export const deleteContribution = /* GraphQL */ `mutation DeleteContribution(
  $input: DeleteContributionInput!
  $condition: ModelContributionConditionInput
) {
  deleteContribution(input: $input, condition: $condition) {
    id
    owner
    companyId
    description
    attachments
    employeeJoins {
      nextToken
      __typename
    }
    creatorEmail
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalContributionsId
    contributionEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteContributionMutationVariables,
  APITypes.DeleteContributionMutation
>;
export const createIdea = /* GraphQL */ `mutation CreateIdea(
  $input: CreateIdeaInput!
  $condition: ModelIdeaConditionInput
) {
  createIdea(input: $input, condition: $condition) {
    id
    owner
    companyId
    title
    description
    attachments
    creatorEmail
    employeeJoins {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalIdeasId
    ideaEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateIdeaMutationVariables,
  APITypes.CreateIdeaMutation
>;
export const updateIdea = /* GraphQL */ `mutation UpdateIdea(
  $input: UpdateIdeaInput!
  $condition: ModelIdeaConditionInput
) {
  updateIdea(input: $input, condition: $condition) {
    id
    owner
    companyId
    title
    description
    attachments
    creatorEmail
    employeeJoins {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalIdeasId
    ideaEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateIdeaMutationVariables,
  APITypes.UpdateIdeaMutation
>;
export const deleteIdea = /* GraphQL */ `mutation DeleteIdea(
  $input: DeleteIdeaInput!
  $condition: ModelIdeaConditionInput
) {
  deleteIdea(input: $input, condition: $condition) {
    id
    owner
    companyId
    title
    description
    attachments
    creatorEmail
    employeeJoins {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalIdeasId
    ideaEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteIdeaMutationVariables,
  APITypes.DeleteIdeaMutation
>;
export const createHelpRequest = /* GraphQL */ `mutation CreateHelpRequest(
  $input: CreateHelpRequestInput!
  $condition: ModelHelpRequestConditionInput
) {
  createHelpRequest(input: $input, condition: $condition) {
    id
    owner
    companyId
    title
    description
    resolved
    resolvedTime
    resolvedBy
    resolvedComment
    reopenedTime
    reopenedBy
    reopenedComment
    attachments
    notRelevantForEmployees
    creatorEmail
    employeeJoins {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalHelpRequestsId
    helpRequestEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateHelpRequestMutationVariables,
  APITypes.CreateHelpRequestMutation
>;
export const updateHelpRequest = /* GraphQL */ `mutation UpdateHelpRequest(
  $input: UpdateHelpRequestInput!
  $condition: ModelHelpRequestConditionInput
) {
  updateHelpRequest(input: $input, condition: $condition) {
    id
    owner
    companyId
    title
    description
    resolved
    resolvedTime
    resolvedBy
    resolvedComment
    reopenedTime
    reopenedBy
    reopenedComment
    attachments
    notRelevantForEmployees
    creatorEmail
    employeeJoins {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalHelpRequestsId
    helpRequestEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateHelpRequestMutationVariables,
  APITypes.UpdateHelpRequestMutation
>;
export const deleteHelpRequest = /* GraphQL */ `mutation DeleteHelpRequest(
  $input: DeleteHelpRequestInput!
  $condition: ModelHelpRequestConditionInput
) {
  deleteHelpRequest(input: $input, condition: $condition) {
    id
    owner
    companyId
    title
    description
    resolved
    resolvedTime
    resolvedBy
    resolvedComment
    reopenedTime
    reopenedBy
    reopenedComment
    attachments
    notRelevantForEmployees
    creatorEmail
    employeeJoins {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalHelpRequestsId
    helpRequestEventId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteHelpRequestMutationVariables,
  APITypes.DeleteHelpRequestMutation
>;
export const createComment = /* GraphQL */ `mutation CreateComment(
  $input: CreateCommentInput!
  $condition: ModelCommentConditionInput
) {
  createComment(input: $input, condition: $condition) {
    id
    owner
    companyId
    text
    hostGoalId
    creatorEmail
    replies {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    status {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    redFlag {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    parentComment {
      id
      owner
      companyId
      text
      hostGoalId
      creatorEmail
      createdAt
      updatedAt
      goalCommentsId
      statusCommentsId
      redFlagCommentsId
      keyResultCommentsId
      keyResultUpdateCommentsId
      successStoryCommentsId
      taskCommentsId
      contributionCommentsId
      ideaCommentsId
      helpRequestCommentsId
      commentRepliesId
      eventCommentsId
      __typename
    }
    task {
      id
      owner
      companyId
      title
      description
      startDate
      targetDate
      status
      attachments
      creatorEmail
      createdAt
      updatedAt
      employeeTasksId
      goalTasksId
      __typename
    }
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    keyResultUpdate {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    createdAt
    updatedAt
    goalCommentsId
    statusCommentsId
    redFlagCommentsId
    keyResultCommentsId
    keyResultUpdateCommentsId
    successStoryCommentsId
    taskCommentsId
    contributionCommentsId
    ideaCommentsId
    helpRequestCommentsId
    commentRepliesId
    eventCommentsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateCommentMutationVariables,
  APITypes.CreateCommentMutation
>;
export const updateComment = /* GraphQL */ `mutation UpdateComment(
  $input: UpdateCommentInput!
  $condition: ModelCommentConditionInput
) {
  updateComment(input: $input, condition: $condition) {
    id
    owner
    companyId
    text
    hostGoalId
    creatorEmail
    replies {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    status {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    redFlag {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    parentComment {
      id
      owner
      companyId
      text
      hostGoalId
      creatorEmail
      createdAt
      updatedAt
      goalCommentsId
      statusCommentsId
      redFlagCommentsId
      keyResultCommentsId
      keyResultUpdateCommentsId
      successStoryCommentsId
      taskCommentsId
      contributionCommentsId
      ideaCommentsId
      helpRequestCommentsId
      commentRepliesId
      eventCommentsId
      __typename
    }
    task {
      id
      owner
      companyId
      title
      description
      startDate
      targetDate
      status
      attachments
      creatorEmail
      createdAt
      updatedAt
      employeeTasksId
      goalTasksId
      __typename
    }
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    keyResultUpdate {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    createdAt
    updatedAt
    goalCommentsId
    statusCommentsId
    redFlagCommentsId
    keyResultCommentsId
    keyResultUpdateCommentsId
    successStoryCommentsId
    taskCommentsId
    contributionCommentsId
    ideaCommentsId
    helpRequestCommentsId
    commentRepliesId
    eventCommentsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateCommentMutationVariables,
  APITypes.UpdateCommentMutation
>;
export const deleteComment = /* GraphQL */ `mutation DeleteComment(
  $input: DeleteCommentInput!
  $condition: ModelCommentConditionInput
) {
  deleteComment(input: $input, condition: $condition) {
    id
    owner
    companyId
    text
    hostGoalId
    creatorEmail
    replies {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    status {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    redFlag {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    parentComment {
      id
      owner
      companyId
      text
      hostGoalId
      creatorEmail
      createdAt
      updatedAt
      goalCommentsId
      statusCommentsId
      redFlagCommentsId
      keyResultCommentsId
      keyResultUpdateCommentsId
      successStoryCommentsId
      taskCommentsId
      contributionCommentsId
      ideaCommentsId
      helpRequestCommentsId
      commentRepliesId
      eventCommentsId
      __typename
    }
    task {
      id
      owner
      companyId
      title
      description
      startDate
      targetDate
      status
      attachments
      creatorEmail
      createdAt
      updatedAt
      employeeTasksId
      goalTasksId
      __typename
    }
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    keyResultUpdate {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    createdAt
    updatedAt
    goalCommentsId
    statusCommentsId
    redFlagCommentsId
    keyResultCommentsId
    keyResultUpdateCommentsId
    successStoryCommentsId
    taskCommentsId
    contributionCommentsId
    ideaCommentsId
    helpRequestCommentsId
    commentRepliesId
    eventCommentsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteCommentMutationVariables,
  APITypes.DeleteCommentMutation
>;
export const createEvent = /* GraphQL */ `mutation CreateEvent(
  $input: CreateEventInput!
  $condition: ModelEventConditionInput
) {
  createEvent(input: $input, condition: $condition) {
    id
    owner
    companyId
    createdAt
    type
    eventType
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    keyResultUpdate {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    redFlag {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    status {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    likes
    updatedAt
    goalEventsId
    redFlagEventsId
    keyResultEventsId
    eventKeyResultUpdateId
    eventSuccessStoryId
    eventStatusId
    eventContributionId
    eventIdeaId
    eventHelpRequestId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateEventMutationVariables,
  APITypes.CreateEventMutation
>;
export const updateEvent = /* GraphQL */ `mutation UpdateEvent(
  $input: UpdateEventInput!
  $condition: ModelEventConditionInput
) {
  updateEvent(input: $input, condition: $condition) {
    id
    owner
    companyId
    createdAt
    type
    eventType
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    keyResultUpdate {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    redFlag {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    status {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    likes
    updatedAt
    goalEventsId
    redFlagEventsId
    keyResultEventsId
    eventKeyResultUpdateId
    eventSuccessStoryId
    eventStatusId
    eventContributionId
    eventIdeaId
    eventHelpRequestId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateEventMutationVariables,
  APITypes.UpdateEventMutation
>;
export const deleteEvent = /* GraphQL */ `mutation DeleteEvent(
  $input: DeleteEventInput!
  $condition: ModelEventConditionInput
) {
  deleteEvent(input: $input, condition: $condition) {
    id
    owner
    companyId
    createdAt
    type
    eventType
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    keyResultUpdate {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    redFlag {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    status {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    likes
    updatedAt
    goalEventsId
    redFlagEventsId
    keyResultEventsId
    eventKeyResultUpdateId
    eventSuccessStoryId
    eventStatusId
    eventContributionId
    eventIdeaId
    eventHelpRequestId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteEventMutationVariables,
  APITypes.DeleteEventMutation
>;
export const createIdeaEmployeeJoin = /* GraphQL */ `mutation CreateIdeaEmployeeJoin(
  $input: CreateIdeaEmployeeJoinInput!
  $condition: ModelIdeaEmployeeJoinConditionInput
) {
  createIdeaEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeIdeaEmployeeJoinsId
    ideaEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateIdeaEmployeeJoinMutationVariables,
  APITypes.CreateIdeaEmployeeJoinMutation
>;
export const updateIdeaEmployeeJoin = /* GraphQL */ `mutation UpdateIdeaEmployeeJoin(
  $input: UpdateIdeaEmployeeJoinInput!
  $condition: ModelIdeaEmployeeJoinConditionInput
) {
  updateIdeaEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeIdeaEmployeeJoinsId
    ideaEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateIdeaEmployeeJoinMutationVariables,
  APITypes.UpdateIdeaEmployeeJoinMutation
>;
export const deleteIdeaEmployeeJoin = /* GraphQL */ `mutation DeleteIdeaEmployeeJoin(
  $input: DeleteIdeaEmployeeJoinInput!
  $condition: ModelIdeaEmployeeJoinConditionInput
) {
  deleteIdeaEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeIdeaEmployeeJoinsId
    ideaEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteIdeaEmployeeJoinMutationVariables,
  APITypes.DeleteIdeaEmployeeJoinMutation
>;
export const createSuccessStoryEmployeeJoin = /* GraphQL */ `mutation CreateSuccessStoryEmployeeJoin(
  $input: CreateSuccessStoryEmployeeJoinInput!
  $condition: ModelSuccessStoryEmployeeJoinConditionInput
) {
  createSuccessStoryEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeSuccessStoryEmployeeJoinsId
    successStoryEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateSuccessStoryEmployeeJoinMutationVariables,
  APITypes.CreateSuccessStoryEmployeeJoinMutation
>;
export const updateSuccessStoryEmployeeJoin = /* GraphQL */ `mutation UpdateSuccessStoryEmployeeJoin(
  $input: UpdateSuccessStoryEmployeeJoinInput!
  $condition: ModelSuccessStoryEmployeeJoinConditionInput
) {
  updateSuccessStoryEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeSuccessStoryEmployeeJoinsId
    successStoryEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateSuccessStoryEmployeeJoinMutationVariables,
  APITypes.UpdateSuccessStoryEmployeeJoinMutation
>;
export const deleteSuccessStoryEmployeeJoin = /* GraphQL */ `mutation DeleteSuccessStoryEmployeeJoin(
  $input: DeleteSuccessStoryEmployeeJoinInput!
  $condition: ModelSuccessStoryEmployeeJoinConditionInput
) {
  deleteSuccessStoryEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeSuccessStoryEmployeeJoinsId
    successStoryEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteSuccessStoryEmployeeJoinMutationVariables,
  APITypes.DeleteSuccessStoryEmployeeJoinMutation
>;
export const createContributionEmployeeJoin = /* GraphQL */ `mutation CreateContributionEmployeeJoin(
  $input: CreateContributionEmployeeJoinInput!
  $condition: ModelContributionEmployeeJoinConditionInput
) {
  createContributionEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeContributionEmployeeJoinsId
    contributionEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateContributionEmployeeJoinMutationVariables,
  APITypes.CreateContributionEmployeeJoinMutation
>;
export const updateContributionEmployeeJoin = /* GraphQL */ `mutation UpdateContributionEmployeeJoin(
  $input: UpdateContributionEmployeeJoinInput!
  $condition: ModelContributionEmployeeJoinConditionInput
) {
  updateContributionEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeContributionEmployeeJoinsId
    contributionEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateContributionEmployeeJoinMutationVariables,
  APITypes.UpdateContributionEmployeeJoinMutation
>;
export const deleteContributionEmployeeJoin = /* GraphQL */ `mutation DeleteContributionEmployeeJoin(
  $input: DeleteContributionEmployeeJoinInput!
  $condition: ModelContributionEmployeeJoinConditionInput
) {
  deleteContributionEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeContributionEmployeeJoinsId
    contributionEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteContributionEmployeeJoinMutationVariables,
  APITypes.DeleteContributionEmployeeJoinMutation
>;
export const createHelpRequestEmployeeJoin = /* GraphQL */ `mutation CreateHelpRequestEmployeeJoin(
  $input: CreateHelpRequestEmployeeJoinInput!
  $condition: ModelHelpRequestEmployeeJoinConditionInput
) {
  createHelpRequestEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeHelpRequestEmployeeJoinsId
    helpRequestEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreateHelpRequestEmployeeJoinMutationVariables,
  APITypes.CreateHelpRequestEmployeeJoinMutation
>;
export const updateHelpRequestEmployeeJoin = /* GraphQL */ `mutation UpdateHelpRequestEmployeeJoin(
  $input: UpdateHelpRequestEmployeeJoinInput!
  $condition: ModelHelpRequestEmployeeJoinConditionInput
) {
  updateHelpRequestEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeHelpRequestEmployeeJoinsId
    helpRequestEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdateHelpRequestEmployeeJoinMutationVariables,
  APITypes.UpdateHelpRequestEmployeeJoinMutation
>;
export const deleteHelpRequestEmployeeJoin = /* GraphQL */ `mutation DeleteHelpRequestEmployeeJoin(
  $input: DeleteHelpRequestEmployeeJoinInput!
  $condition: ModelHelpRequestEmployeeJoinConditionInput
) {
  deleteHelpRequestEmployeeJoin(input: $input, condition: $condition) {
    id
    owner
    companyId
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeHelpRequestEmployeeJoinsId
    helpRequestEmployeeJoinsId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeleteHelpRequestEmployeeJoinMutationVariables,
  APITypes.DeleteHelpRequestEmployeeJoinMutation
>;
export const createPlatformIntegration = /* GraphQL */ `mutation CreatePlatformIntegration(
  $input: CreatePlatformIntegrationInput!
  $condition: ModelPlatformIntegrationConditionInput
) {
  createPlatformIntegration(input: $input, condition: $condition) {
    id
    owner
    companyId
    company {
      id
      owner
      companyId
      name
      creatorEmail
      isSubscribed
      subscriptionId
      customerId
      subscriptionExpireDate
      description
      createdAt
      updatedAt
      __typename
    }
    organizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    platform
    connectionHook
    oauthToken
    teamId
    metadata
    createdAt
    updatedAt
    organizationUnitPlatformIntegrationId
    companyPlatformIntegrationId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.CreatePlatformIntegrationMutationVariables,
  APITypes.CreatePlatformIntegrationMutation
>;
export const updatePlatformIntegration = /* GraphQL */ `mutation UpdatePlatformIntegration(
  $input: UpdatePlatformIntegrationInput!
  $condition: ModelPlatformIntegrationConditionInput
) {
  updatePlatformIntegration(input: $input, condition: $condition) {
    id
    owner
    companyId
    company {
      id
      owner
      companyId
      name
      creatorEmail
      isSubscribed
      subscriptionId
      customerId
      subscriptionExpireDate
      description
      createdAt
      updatedAt
      __typename
    }
    organizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    platform
    connectionHook
    oauthToken
    teamId
    metadata
    createdAt
    updatedAt
    organizationUnitPlatformIntegrationId
    companyPlatformIntegrationId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.UpdatePlatformIntegrationMutationVariables,
  APITypes.UpdatePlatformIntegrationMutation
>;
export const deletePlatformIntegration = /* GraphQL */ `mutation DeletePlatformIntegration(
  $input: DeletePlatformIntegrationInput!
  $condition: ModelPlatformIntegrationConditionInput
) {
  deletePlatformIntegration(input: $input, condition: $condition) {
    id
    owner
    companyId
    company {
      id
      owner
      companyId
      name
      creatorEmail
      isSubscribed
      subscriptionId
      customerId
      subscriptionExpireDate
      description
      createdAt
      updatedAt
      __typename
    }
    organizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    platform
    connectionHook
    oauthToken
    teamId
    metadata
    createdAt
    updatedAt
    organizationUnitPlatformIntegrationId
    companyPlatformIntegrationId
    __typename
  }
}
` as GeneratedMutation<
  APITypes.DeletePlatformIntegrationMutationVariables,
  APITypes.DeletePlatformIntegrationMutation
>;
export const addUserToCognito = /* GraphQL */ `mutation AddUserToCognito(
  $userPoolId: String!
  $email: String!
  $password: String!
) {
  addUserToCognito(userPoolId: $userPoolId, email: $email, password: $password)
}
` as GeneratedMutation<
  APITypes.AddUserToCognitoMutationVariables,
  APITypes.AddUserToCognitoMutation
>;
export const removeUserFromCognito = /* GraphQL */ `mutation RemoveUserFromCognito($userPoolId: String!, $email: String!) {
  removeUserFromCognito(userPoolId: $userPoolId, email: $email)
}
` as GeneratedMutation<
  APITypes.RemoveUserFromCognitoMutationVariables,
  APITypes.RemoveUserFromCognitoMutation
>;
export const EnableUserLogin = /* GraphQL */ `mutation EnableUserLogin($userPoolId: String!, $email: String!) {
  EnableUserLogin(userPoolId: $userPoolId, email: $email)
}
` as GeneratedMutation<
  APITypes.EnableUserLoginMutationVariables,
  APITypes.EnableUserLoginMutation
>;
export const DisableUserLogin = /* GraphQL */ `mutation DisableUserLogin($userPoolId: String!, $email: String!) {
  DisableUserLogin(userPoolId: $userPoolId, email: $email)
}
` as GeneratedMutation<
  APITypes.DisableUserLoginMutationVariables,
  APITypes.DisableUserLoginMutation
>;
export const ToggleAdminRole = /* GraphQL */ `mutation ToggleAdminRole(
  $email: String!
  $isAdmin: Boolean!
  $userPoolId: String!
) {
  ToggleAdminRole(email: $email, isAdmin: $isAdmin, userPoolId: $userPoolId)
}
` as GeneratedMutation<
  APITypes.ToggleAdminRoleMutationVariables,
  APITypes.ToggleAdminRoleMutation
>;
export const CheckCompanyInfo = /* GraphQL */ `mutation CheckCompanyInfo($userPoolId: String!, $company: String!) {
  CheckCompanyInfo(userPoolId: $userPoolId, company: $company)
}
` as GeneratedMutation<
  APITypes.CheckCompanyInfoMutationVariables,
  APITypes.CheckCompanyInfoMutation
>;
export const CheckUserInfo = /* GraphQL */ `mutation CheckUserInfo($userPoolId: String!, $email: String!) {
  CheckUserInfo(userPoolId: $userPoolId, email: $email)
}
` as GeneratedMutation<
  APITypes.CheckUserInfoMutationVariables,
  APITypes.CheckUserInfoMutation
>;
export const CreateUserAndGroup = /* GraphQL */ `mutation CreateUserAndGroup(
  $userPoolId: String
  $identityPoolId: String
  $s3BucketId: String
  $email: String
  $company: String
) {
  CreateUserAndGroup(
    userPoolId: $userPoolId
    identityPoolId: $identityPoolId
    s3BucketId: $s3BucketId
    email: $email
    company: $company
  )
}
` as GeneratedMutation<
  APITypes.CreateUserAndGroupMutationVariables,
  APITypes.CreateUserAndGroupMutation
>;
