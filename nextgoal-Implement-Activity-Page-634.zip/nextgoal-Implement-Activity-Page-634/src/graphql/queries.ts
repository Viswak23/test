/* tslint:disable */
/* eslint-disable */
// this is an auto generated file. This will be overwritten

import * as APITypes from "../API";
type GeneratedQuery<InputType, OutputType> = string & {
  __generatedQueryInput: InputType;
  __generatedQueryOutput: OutputType;
};

export const getOrganizationUnit = /* GraphQL */ `query GetOrganizationUnit($id: ID!) {
  getOrganizationUnit(id: $id) {
    id
    owner
    companyId
    name
    description
    creatorEmail
    position
    notRelevantParentGoals
    parentOrganizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    childOrzganizationUnits {
      nextToken
      __typename
    }
    goals {
      nextToken
      __typename
    }
    platformIntegration {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    organizationUnitChildOrzganizationUnitsId
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetOrganizationUnitQueryVariables,
  APITypes.GetOrganizationUnitQuery
>;
export const listOrganizationUnits = /* GraphQL */ `query ListOrganizationUnits(
  $filter: ModelOrganizationUnitFilterInput
  $limit: Int
  $nextToken: String
) {
  listOrganizationUnits(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListOrganizationUnitsQueryVariables,
  APITypes.ListOrganizationUnitsQuery
>;
export const organizationUnitByCompany = /* GraphQL */ `query OrganizationUnitByCompany(
  $companyId: ID!
  $position: ModelIntKeyConditionInput
  $sortDirection: ModelSortDirection
  $filter: ModelOrganizationUnitFilterInput
  $limit: Int
  $nextToken: String
) {
  organizationUnitByCompany(
    companyId: $companyId
    position: $position
    sortDirection: $sortDirection
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.OrganizationUnitByCompanyQueryVariables,
  APITypes.OrganizationUnitByCompanyQuery
>;
export const getNorthStar = /* GraphQL */ `query GetNorthStar($id: ID!) {
  getNorthStar(id: $id) {
    id
    owner
    companyId
    title
    description
    attachments
    creatorEmail
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetNorthStarQueryVariables,
  APITypes.GetNorthStarQuery
>;
export const listNorthStars = /* GraphQL */ `query ListNorthStars(
  $filter: ModelNorthStarFilterInput
  $limit: Int
  $nextToken: String
) {
  listNorthStars(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListNorthStarsQueryVariables,
  APITypes.ListNorthStarsQuery
>;
export const northStarByCompany = /* GraphQL */ `query NorthStarByCompany(
  $companyId: ID!
  $createdAt: ModelStringKeyConditionInput
  $sortDirection: ModelSortDirection
  $filter: ModelNorthStarFilterInput
  $limit: Int
  $nextToken: String
) {
  northStarByCompany(
    companyId: $companyId
    createdAt: $createdAt
    sortDirection: $sortDirection
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.NorthStarByCompanyQueryVariables,
  APITypes.NorthStarByCompanyQuery
>;
export const getNotification = /* GraphQL */ `query GetNotification($id: ID!) {
  getNotification(id: $id) {
    id
    owner
    companyId
    notificationType
    type
    toEmployeeEmail
    isRead
    eventId
    goalId
    createdAt
    expireAt
    updatedAt
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetNotificationQueryVariables,
  APITypes.GetNotificationQuery
>;
export const listNotifications = /* GraphQL */ `query ListNotifications(
  $filter: ModelNotificationFilterInput
  $limit: Int
  $nextToken: String
) {
  listNotifications(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      notificationType
      type
      toEmployeeEmail
      isRead
      eventId
      goalId
      createdAt
      expireAt
      updatedAt
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListNotificationsQueryVariables,
  APITypes.ListNotificationsQuery
>;
export const notificationsByEmployeeEmail = /* GraphQL */ `query NotificationsByEmployeeEmail(
  $toEmployeeEmail: String!
  $createdAt: ModelStringKeyConditionInput
  $sortDirection: ModelSortDirection
  $filter: ModelNotificationFilterInput
  $limit: Int
  $nextToken: String
) {
  notificationsByEmployeeEmail(
    toEmployeeEmail: $toEmployeeEmail
    createdAt: $createdAt
    sortDirection: $sortDirection
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      companyId
      notificationType
      type
      toEmployeeEmail
      isRead
      eventId
      goalId
      createdAt
      expireAt
      updatedAt
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.NotificationsByEmployeeEmailQueryVariables,
  APITypes.NotificationsByEmployeeEmailQuery
>;
export const getCompany = /* GraphQL */ `query GetCompany($id: ID!) {
  getCompany(id: $id) {
    id
    owner
    companyId
    name
    creatorEmail
    isSubscribed
    subscriptionId
    customerId
    subscriptionExpireDate
    description
    platformIntegration {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetCompanyQueryVariables,
  APITypes.GetCompanyQuery
>;
export const listCompanies = /* GraphQL */ `query ListCompanies(
  $filter: ModelCompanyFilterInput
  $limit: Int
  $nextToken: String
) {
  listCompanies(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      name
      creatorEmail
      isSubscribed
      subscriptionId
      customerId
      subscriptionExpireDate
      description
      createdAt
      updatedAt
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListCompaniesQueryVariables,
  APITypes.ListCompaniesQuery
>;
export const getEmployee = /* GraphQL */ `query GetEmployee($id: ID!) {
  getEmployee(id: $id) {
    id
    owner
    disabled
    companyId
    createdAt
    name
    isAdmin
    email
    avatarUrl
    notRelevantParentGoals
    creatorEmail
    language
    locale
    interest
    career
    goals {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    organizationUnitEmployeeJoins {
      nextToken
      __typename
    }
    contributionEmployeeJoins {
      nextToken
      __typename
    }
    ideaEmployeeJoins {
      nextToken
      __typename
    }
    successStoryEmployeeJoins {
      nextToken
      __typename
    }
    helpRequestEmployeeJoins {
      nextToken
      __typename
    }
    updatedAt
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetEmployeeQueryVariables,
  APITypes.GetEmployeeQuery
>;
export const listEmployees = /* GraphQL */ `query ListEmployees(
  $filter: ModelEmployeeFilterInput
  $limit: Int
  $nextToken: String
) {
  listEmployees(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListEmployeesQueryVariables,
  APITypes.ListEmployeesQuery
>;
export const employeeByCompany = /* GraphQL */ `query EmployeeByCompany(
  $companyId: ID!
  $createdAt: ModelStringKeyConditionInput
  $sortDirection: ModelSortDirection
  $filter: ModelEmployeeFilterInput
  $limit: Int
  $nextToken: String
) {
  employeeByCompany(
    companyId: $companyId
    createdAt: $createdAt
    sortDirection: $sortDirection
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.EmployeeByCompanyQueryVariables,
  APITypes.EmployeeByCompanyQuery
>;
export const getOrganizationUnitEmployeeJoin = /* GraphQL */ `query GetOrganizationUnitEmployeeJoin($id: ID!) {
  getOrganizationUnitEmployeeJoin(id: $id) {
    id
    owner
    companyId
    createdAt
    organizationUnitId
    employeeId
    updatedAt
    employeeOrganizationUnitEmployeeJoinsId
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetOrganizationUnitEmployeeJoinQueryVariables,
  APITypes.GetOrganizationUnitEmployeeJoinQuery
>;
export const listOrganizationUnitEmployeeJoins = /* GraphQL */ `query ListOrganizationUnitEmployeeJoins(
  $filter: ModelOrganizationUnitEmployeeJoinFilterInput
  $limit: Int
  $nextToken: String
) {
  listOrganizationUnitEmployeeJoins(
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      companyId
      createdAt
      organizationUnitId
      employeeId
      updatedAt
      employeeOrganizationUnitEmployeeJoinsId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListOrganizationUnitEmployeeJoinsQueryVariables,
  APITypes.ListOrganizationUnitEmployeeJoinsQuery
>;
export const organizationUnitEmployeeJoinByCompany = /* GraphQL */ `query OrganizationUnitEmployeeJoinByCompany(
  $companyId: ID!
  $sortDirection: ModelSortDirection
  $filter: ModelOrganizationUnitEmployeeJoinFilterInput
  $limit: Int
  $nextToken: String
) {
  organizationUnitEmployeeJoinByCompany(
    companyId: $companyId
    sortDirection: $sortDirection
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      companyId
      createdAt
      organizationUnitId
      employeeId
      updatedAt
      employeeOrganizationUnitEmployeeJoinsId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.OrganizationUnitEmployeeJoinByCompanyQueryVariables,
  APITypes.OrganizationUnitEmployeeJoinByCompanyQuery
>;
export const getGoal = /* GraphQL */ `query GetGoal($id: ID!) {
  getGoal(id: $id) {
    id
    owner
    companyId
    createdAt
    title
    description
    startDate
    targetDate
    useTasks
    reward
    attachments
    creatorEmail
    position
    organizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    parentGoal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    childGoals {
      nextToken
      __typename
    }
    comments {
      nextToken
      __typename
    }
    status {
      nextToken
      __typename
    }
    redFlags {
      nextToken
      __typename
    }
    keyResults {
      nextToken
      __typename
    }
    successStories {
      nextToken
      __typename
    }
    events {
      nextToken
      __typename
    }
    tasks {
      nextToken
      __typename
    }
    contributions {
      nextToken
      __typename
    }
    ideas {
      nextToken
      __typename
    }
    helpRequests {
      nextToken
      __typename
    }
    isClosed
    statusFlag
    closingNotes
    updatedAt
    organizationUnitGoalsId
    employeeGoalsId
    goalChildGoalsId
    __typename
  }
}
` as GeneratedQuery<APITypes.GetGoalQueryVariables, APITypes.GetGoalQuery>;
export const listGoals = /* GraphQL */ `query ListGoals(
  $filter: ModelGoalFilterInput
  $limit: Int
  $nextToken: String
) {
  listGoals(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<APITypes.ListGoalsQueryVariables, APITypes.ListGoalsQuery>;
export const goalsByCompany = /* GraphQL */ `query GoalsByCompany(
  $companyId: ID!
  $position: ModelIntKeyConditionInput
  $sortDirection: ModelSortDirection
  $filter: ModelGoalFilterInput
  $limit: Int
  $nextToken: String
) {
  goalsByCompany(
    companyId: $companyId
    position: $position
    sortDirection: $sortDirection
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GoalsByCompanyQueryVariables,
  APITypes.GoalsByCompanyQuery
>;
export const getStatus = /* GraphQL */ `query GetStatus($id: ID!) {
  getStatus(id: $id) {
    id
    owner
    companyId
    status
    goingWell
    toImprove
    challenges
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalStatusId
    statusEventId
    __typename
  }
}
` as GeneratedQuery<APITypes.GetStatusQueryVariables, APITypes.GetStatusQuery>;
export const listStatuses = /* GraphQL */ `query ListStatuses(
  $filter: ModelStatusFilterInput
  $limit: Int
  $nextToken: String
) {
  listStatuses(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListStatusesQueryVariables,
  APITypes.ListStatusesQuery
>;
export const getRedFlag = /* GraphQL */ `query GetRedFlag($id: ID!) {
  getRedFlag(id: $id) {
    id
    owner
    companyId
    text
    resolved
    resolvedTime
    resolvedBy
    resolvedComment
    reopenedTime
    reopenedBy
    reopenedComment
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    events {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    goalRedFlagsId
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetRedFlagQueryVariables,
  APITypes.GetRedFlagQuery
>;
export const listRedFlags = /* GraphQL */ `query ListRedFlags(
  $filter: ModelRedFlagFilterInput
  $limit: Int
  $nextToken: String
) {
  listRedFlags(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListRedFlagsQueryVariables,
  APITypes.ListRedFlagsQuery
>;
export const getKeyResult = /* GraphQL */ `query GetKeyResult($id: ID!) {
  getKeyResult(id: $id) {
    id
    owner
    companyId
    description
    statusFlag
    statusText
    initialValue
    targetValue
    currentValue
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    events {
      nextToken
      __typename
    }
    updates {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    goalKeyResultsId
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetKeyResultQueryVariables,
  APITypes.GetKeyResultQuery
>;
export const listKeyResults = /* GraphQL */ `query ListKeyResults(
  $filter: ModelKeyResultFilterInput
  $limit: Int
  $nextToken: String
) {
  listKeyResults(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListKeyResultsQueryVariables,
  APITypes.ListKeyResultsQuery
>;
export const getKeyResultUpdate = /* GraphQL */ `query GetKeyResultUpdate($id: ID!) {
  getKeyResultUpdate(id: $id) {
    id
    owner
    companyId
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    currentValueBefore
    currentValueAfter
    statusFlagBefore
    statusFlagAfter
    text
    attachments
    creatorEmail
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    dateOfUpdate
    createdAt
    updatedAt
    keyResultUpdatesId
    keyResultUpdateEventId
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetKeyResultUpdateQueryVariables,
  APITypes.GetKeyResultUpdateQuery
>;
export const listKeyResultUpdates = /* GraphQL */ `query ListKeyResultUpdates(
  $filter: ModelKeyResultUpdateFilterInput
  $limit: Int
  $nextToken: String
) {
  listKeyResultUpdates(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListKeyResultUpdatesQueryVariables,
  APITypes.ListKeyResultUpdatesQuery
>;
export const getSuccessStory = /* GraphQL */ `query GetSuccessStory($id: ID!) {
  getSuccessStory(id: $id) {
    id
    owner
    companyId
    name
    attachments
    employeeJoins {
      nextToken
      __typename
    }
    creatorEmail
    comments {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalSuccessStoriesId
    successStoryEventId
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetSuccessStoryQueryVariables,
  APITypes.GetSuccessStoryQuery
>;
export const listSuccessStories = /* GraphQL */ `query ListSuccessStories(
  $filter: ModelSuccessStoryFilterInput
  $limit: Int
  $nextToken: String
) {
  listSuccessStories(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListSuccessStoriesQueryVariables,
  APITypes.ListSuccessStoriesQuery
>;
export const getTask = /* GraphQL */ `query GetTask($id: ID!) {
  getTask(id: $id) {
    id
    owner
    companyId
    title
    description
    startDate
    targetDate
    status
    attachments
    creatorEmail
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    createdAt
    updatedAt
    employeeTasksId
    goalTasksId
    __typename
  }
}
` as GeneratedQuery<APITypes.GetTaskQueryVariables, APITypes.GetTaskQuery>;
export const listTasks = /* GraphQL */ `query ListTasks(
  $filter: ModelTaskFilterInput
  $limit: Int
  $nextToken: String
) {
  listTasks(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      title
      description
      startDate
      targetDate
      status
      attachments
      creatorEmail
      createdAt
      updatedAt
      employeeTasksId
      goalTasksId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<APITypes.ListTasksQueryVariables, APITypes.ListTasksQuery>;
export const getContribution = /* GraphQL */ `query GetContribution($id: ID!) {
  getContribution(id: $id) {
    id
    owner
    companyId
    description
    attachments
    employeeJoins {
      nextToken
      __typename
    }
    creatorEmail
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalContributionsId
    contributionEventId
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetContributionQueryVariables,
  APITypes.GetContributionQuery
>;
export const listContributions = /* GraphQL */ `query ListContributions(
  $filter: ModelContributionFilterInput
  $limit: Int
  $nextToken: String
) {
  listContributions(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListContributionsQueryVariables,
  APITypes.ListContributionsQuery
>;
export const getIdea = /* GraphQL */ `query GetIdea($id: ID!) {
  getIdea(id: $id) {
    id
    owner
    companyId
    title
    description
    attachments
    creatorEmail
    employeeJoins {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalIdeasId
    ideaEventId
    __typename
  }
}
` as GeneratedQuery<APITypes.GetIdeaQueryVariables, APITypes.GetIdeaQuery>;
export const listIdeas = /* GraphQL */ `query ListIdeas(
  $filter: ModelIdeaFilterInput
  $limit: Int
  $nextToken: String
) {
  listIdeas(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<APITypes.ListIdeasQueryVariables, APITypes.ListIdeasQuery>;
export const getHelpRequest = /* GraphQL */ `query GetHelpRequest($id: ID!) {
  getHelpRequest(id: $id) {
    id
    owner
    companyId
    title
    description
    resolved
    resolvedTime
    resolvedBy
    resolvedComment
    reopenedTime
    reopenedBy
    reopenedComment
    attachments
    notRelevantForEmployees
    creatorEmail
    employeeJoins {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    createdAt
    updatedAt
    goalHelpRequestsId
    helpRequestEventId
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetHelpRequestQueryVariables,
  APITypes.GetHelpRequestQuery
>;
export const listHelpRequests = /* GraphQL */ `query ListHelpRequests(
  $filter: ModelHelpRequestFilterInput
  $limit: Int
  $nextToken: String
) {
  listHelpRequests(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListHelpRequestsQueryVariables,
  APITypes.ListHelpRequestsQuery
>;
export const getComment = /* GraphQL */ `query GetComment($id: ID!) {
  getComment(id: $id) {
    id
    owner
    companyId
    text
    hostGoalId
    creatorEmail
    replies {
      nextToken
      __typename
    }
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    status {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    redFlag {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    event {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    parentComment {
      id
      owner
      companyId
      text
      hostGoalId
      creatorEmail
      createdAt
      updatedAt
      goalCommentsId
      statusCommentsId
      redFlagCommentsId
      keyResultCommentsId
      keyResultUpdateCommentsId
      successStoryCommentsId
      taskCommentsId
      contributionCommentsId
      ideaCommentsId
      helpRequestCommentsId
      commentRepliesId
      eventCommentsId
      __typename
    }
    task {
      id
      owner
      companyId
      title
      description
      startDate
      targetDate
      status
      attachments
      creatorEmail
      createdAt
      updatedAt
      employeeTasksId
      goalTasksId
      __typename
    }
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    keyResultUpdate {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    createdAt
    updatedAt
    goalCommentsId
    statusCommentsId
    redFlagCommentsId
    keyResultCommentsId
    keyResultUpdateCommentsId
    successStoryCommentsId
    taskCommentsId
    contributionCommentsId
    ideaCommentsId
    helpRequestCommentsId
    commentRepliesId
    eventCommentsId
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetCommentQueryVariables,
  APITypes.GetCommentQuery
>;
export const listComments = /* GraphQL */ `query ListComments(
  $filter: ModelCommentFilterInput
  $limit: Int
  $nextToken: String
) {
  listComments(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      text
      hostGoalId
      creatorEmail
      createdAt
      updatedAt
      goalCommentsId
      statusCommentsId
      redFlagCommentsId
      keyResultCommentsId
      keyResultUpdateCommentsId
      successStoryCommentsId
      taskCommentsId
      contributionCommentsId
      ideaCommentsId
      helpRequestCommentsId
      commentRepliesId
      eventCommentsId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListCommentsQueryVariables,
  APITypes.ListCommentsQuery
>;
export const getEvent = /* GraphQL */ `query GetEvent($id: ID!) {
  getEvent(id: $id) {
    id
    owner
    companyId
    createdAt
    type
    eventType
    goal {
      id
      owner
      companyId
      createdAt
      title
      description
      startDate
      targetDate
      useTasks
      reward
      attachments
      creatorEmail
      position
      isClosed
      statusFlag
      closingNotes
      updatedAt
      organizationUnitGoalsId
      employeeGoalsId
      goalChildGoalsId
      __typename
    }
    keyResult {
      id
      owner
      companyId
      description
      statusFlag
      statusText
      initialValue
      targetValue
      currentValue
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalKeyResultsId
      __typename
    }
    keyResultUpdate {
      id
      owner
      companyId
      currentValueBefore
      currentValueAfter
      statusFlagBefore
      statusFlagAfter
      text
      attachments
      creatorEmail
      dateOfUpdate
      createdAt
      updatedAt
      keyResultUpdatesId
      keyResultUpdateEventId
      __typename
    }
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    redFlag {
      id
      owner
      companyId
      text
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalRedFlagsId
      __typename
    }
    status {
      id
      owner
      companyId
      status
      goingWell
      toImprove
      challenges
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalStatusId
      statusEventId
      __typename
    }
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    comments {
      nextToken
      __typename
    }
    likes
    updatedAt
    goalEventsId
    redFlagEventsId
    keyResultEventsId
    eventKeyResultUpdateId
    eventSuccessStoryId
    eventStatusId
    eventContributionId
    eventIdeaId
    eventHelpRequestId
    __typename
  }
}
` as GeneratedQuery<APITypes.GetEventQueryVariables, APITypes.GetEventQuery>;
export const listEvents = /* GraphQL */ `query ListEvents(
  $filter: ModelEventFilterInput
  $limit: Int
  $nextToken: String
) {
  listEvents(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListEventsQueryVariables,
  APITypes.ListEventsQuery
>;
export const eventsByCompanyId = /* GraphQL */ `query EventsByCompanyId(
  $companyId: ID!
  $createdAt: ModelStringKeyConditionInput
  $sortDirection: ModelSortDirection
  $filter: ModelEventFilterInput
  $limit: Int
  $nextToken: String
) {
  eventsByCompanyId(
    companyId: $companyId
    createdAt: $createdAt
    sortDirection: $sortDirection
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      companyId
      createdAt
      type
      eventType
      likes
      updatedAt
      goalEventsId
      redFlagEventsId
      keyResultEventsId
      eventKeyResultUpdateId
      eventSuccessStoryId
      eventStatusId
      eventContributionId
      eventIdeaId
      eventHelpRequestId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.EventsByCompanyIdQueryVariables,
  APITypes.EventsByCompanyIdQuery
>;
export const getIdeaEmployeeJoin = /* GraphQL */ `query GetIdeaEmployeeJoin($id: ID!) {
  getIdeaEmployeeJoin(id: $id) {
    id
    owner
    companyId
    idea {
      id
      owner
      companyId
      title
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalIdeasId
      ideaEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeIdeaEmployeeJoinsId
    ideaEmployeeJoinsId
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetIdeaEmployeeJoinQueryVariables,
  APITypes.GetIdeaEmployeeJoinQuery
>;
export const listIdeaEmployeeJoins = /* GraphQL */ `query ListIdeaEmployeeJoins(
  $filter: ModelIdeaEmployeeJoinFilterInput
  $limit: Int
  $nextToken: String
) {
  listIdeaEmployeeJoins(filter: $filter, limit: $limit, nextToken: $nextToken) {
    items {
      id
      owner
      companyId
      goalId
      createdAt
      updatedAt
      employeeIdeaEmployeeJoinsId
      ideaEmployeeJoinsId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListIdeaEmployeeJoinsQueryVariables,
  APITypes.ListIdeaEmployeeJoinsQuery
>;
export const getSuccessStoryEmployeeJoin = /* GraphQL */ `query GetSuccessStoryEmployeeJoin($id: ID!) {
  getSuccessStoryEmployeeJoin(id: $id) {
    id
    owner
    companyId
    successStory {
      id
      owner
      companyId
      name
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalSuccessStoriesId
      successStoryEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeSuccessStoryEmployeeJoinsId
    successStoryEmployeeJoinsId
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetSuccessStoryEmployeeJoinQueryVariables,
  APITypes.GetSuccessStoryEmployeeJoinQuery
>;
export const listSuccessStoryEmployeeJoins = /* GraphQL */ `query ListSuccessStoryEmployeeJoins(
  $filter: ModelSuccessStoryEmployeeJoinFilterInput
  $limit: Int
  $nextToken: String
) {
  listSuccessStoryEmployeeJoins(
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      companyId
      goalId
      createdAt
      updatedAt
      employeeSuccessStoryEmployeeJoinsId
      successStoryEmployeeJoinsId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListSuccessStoryEmployeeJoinsQueryVariables,
  APITypes.ListSuccessStoryEmployeeJoinsQuery
>;
export const getContributionEmployeeJoin = /* GraphQL */ `query GetContributionEmployeeJoin($id: ID!) {
  getContributionEmployeeJoin(id: $id) {
    id
    owner
    companyId
    contribution {
      id
      owner
      companyId
      description
      attachments
      creatorEmail
      createdAt
      updatedAt
      goalContributionsId
      contributionEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeContributionEmployeeJoinsId
    contributionEmployeeJoinsId
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetContributionEmployeeJoinQueryVariables,
  APITypes.GetContributionEmployeeJoinQuery
>;
export const listContributionEmployeeJoins = /* GraphQL */ `query ListContributionEmployeeJoins(
  $filter: ModelContributionEmployeeJoinFilterInput
  $limit: Int
  $nextToken: String
) {
  listContributionEmployeeJoins(
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      companyId
      goalId
      createdAt
      updatedAt
      employeeContributionEmployeeJoinsId
      contributionEmployeeJoinsId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListContributionEmployeeJoinsQueryVariables,
  APITypes.ListContributionEmployeeJoinsQuery
>;
export const getHelpRequestEmployeeJoin = /* GraphQL */ `query GetHelpRequestEmployeeJoin($id: ID!) {
  getHelpRequestEmployeeJoin(id: $id) {
    id
    owner
    companyId
    helpRequest {
      id
      owner
      companyId
      title
      description
      resolved
      resolvedTime
      resolvedBy
      resolvedComment
      reopenedTime
      reopenedBy
      reopenedComment
      attachments
      notRelevantForEmployees
      creatorEmail
      createdAt
      updatedAt
      goalHelpRequestsId
      helpRequestEventId
      __typename
    }
    employee {
      id
      owner
      disabled
      companyId
      createdAt
      name
      isAdmin
      email
      avatarUrl
      notRelevantParentGoals
      creatorEmail
      language
      locale
      interest
      career
      updatedAt
      __typename
    }
    goalId
    createdAt
    updatedAt
    employeeHelpRequestEmployeeJoinsId
    helpRequestEmployeeJoinsId
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetHelpRequestEmployeeJoinQueryVariables,
  APITypes.GetHelpRequestEmployeeJoinQuery
>;
export const listHelpRequestEmployeeJoins = /* GraphQL */ `query ListHelpRequestEmployeeJoins(
  $filter: ModelHelpRequestEmployeeJoinFilterInput
  $limit: Int
  $nextToken: String
) {
  listHelpRequestEmployeeJoins(
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      companyId
      goalId
      createdAt
      updatedAt
      employeeHelpRequestEmployeeJoinsId
      helpRequestEmployeeJoinsId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListHelpRequestEmployeeJoinsQueryVariables,
  APITypes.ListHelpRequestEmployeeJoinsQuery
>;
export const getPlatformIntegration = /* GraphQL */ `query GetPlatformIntegration($id: ID!) {
  getPlatformIntegration(id: $id) {
    id
    owner
    companyId
    company {
      id
      owner
      companyId
      name
      creatorEmail
      isSubscribed
      subscriptionId
      customerId
      subscriptionExpireDate
      description
      createdAt
      updatedAt
      __typename
    }
    organizationUnit {
      id
      owner
      companyId
      name
      description
      creatorEmail
      position
      notRelevantParentGoals
      createdAt
      updatedAt
      organizationUnitChildOrzganizationUnitsId
      __typename
    }
    platform
    connectionHook
    oauthToken
    teamId
    metadata
    createdAt
    updatedAt
    organizationUnitPlatformIntegrationId
    companyPlatformIntegrationId
    __typename
  }
}
` as GeneratedQuery<
  APITypes.GetPlatformIntegrationQueryVariables,
  APITypes.GetPlatformIntegrationQuery
>;
export const listPlatformIntegrations = /* GraphQL */ `query ListPlatformIntegrations(
  $filter: ModelPlatformIntegrationFilterInput
  $limit: Int
  $nextToken: String
) {
  listPlatformIntegrations(
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      companyId
      platform
      connectionHook
      oauthToken
      teamId
      metadata
      createdAt
      updatedAt
      organizationUnitPlatformIntegrationId
      companyPlatformIntegrationId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.ListPlatformIntegrationsQueryVariables,
  APITypes.ListPlatformIntegrationsQuery
>;
export const integrationByCompany = /* GraphQL */ `query IntegrationByCompany(
  $companyId: ID!
  $sortDirection: ModelSortDirection
  $filter: ModelPlatformIntegrationFilterInput
  $limit: Int
  $nextToken: String
) {
  integrationByCompany(
    companyId: $companyId
    sortDirection: $sortDirection
    filter: $filter
    limit: $limit
    nextToken: $nextToken
  ) {
    items {
      id
      owner
      companyId
      platform
      connectionHook
      oauthToken
      teamId
      metadata
      createdAt
      updatedAt
      organizationUnitPlatformIntegrationId
      companyPlatformIntegrationId
      __typename
    }
    nextToken
    __typename
  }
}
` as GeneratedQuery<
  APITypes.IntegrationByCompanyQueryVariables,
  APITypes.IntegrationByCompanyQuery
>;
