import { defineConfig } from "cypress";
import dotenv from "dotenv";
import {
  aws_cognito_identity_pool_id,
  aws_user_pools_id,
  aws_user_pools_web_client_id,
} from "@/lib/amplifyConfig";
import awsExports from "@/src/aws-exports";

dotenv.config({ path: ".env.local" });
dotenv.config();

export default defineConfig({
  env: {
    cognito_username: process.env.CYPRESS_COGNITO_USERNAME,
    cognito_password: process.env.CYPRESS_COGNITO_PASSWORD,
    awsConfig: {
      ...awsExports,
      aws_user_pools_id,
      aws_user_pools_web_client_id,
      aws_cognito_identity_pool_id,
    },
  },
  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
    baseUrl: "http://localhost:3000",
  },
  defaultCommandTimeout: 50000,
});
