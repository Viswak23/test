// Note: these don't work with "style"; use "sx"!

import { Theme } from "@mui/material/styles";

// HOVERS THAT HAVE NO BACKGROUND:

// Main color to darker ("pressed")
export const hoverMainToPressed = (theme: Theme) => ({
  transition: "0.3s ease",
  color: theme.palette.primary.main,
  "&:hover": {
    color: theme.palette.customColors?.pressed,
  },
});

export const hoverLighterToSecondary = (theme: Theme) => ({
  transition: "0.3s ease",
  color: theme.palette.customColors?.lighter,
  "&:hover": {
    color: theme.palette.secondary.main,
  },
});

export const hoverLighterToMain = (theme: Theme) => ({
  transition: "0.3s ease",
  color: theme.palette.customColors?.lighter,
  "&:hover": {
    color: theme.palette.secondary.main,
  },
});

// North Star btn: main to gold
export const hoverMainToStar = (theme: Theme) => ({
  transition: "0.3 ease",
  color: theme.palette.primary.main,
  "&:hover": {
    backgroundColor: "transparent",
    color: theme.palette.customColors?.star,
  },
});

// From main to green; used for btns that add something generally
export const hoverMainToAdd = (theme: Theme) => ({
  transition: "0.3s ease",
  color: theme.palette.primary.main,
  "&:hover": {
    color: theme.palette.customColors?.add,
  },
});

// From secondary to green; used for btns that add something generally
export const hoverSecondaryToAdd = (theme: Theme) => ({
  transition: "0.3s ease",
  color: theme.palette.secondary.main,
  "&:hover": {
    color: theme.palette.customColors?.add,
  },
});

// Delete [something] btn
export const hoverMainToRed = (theme: Theme) => ({
  transition: "0.3s ease",
  color: theme.palette.primary.main,
  "&:hover": {
    color: theme.palette.customColors?.delete,
  },
});

// Alternative delete [something] btn
export const hoverSecondaryToRed = (theme: Theme) => ({
  transition: "0.5s ease",
  color: theme.palette.secondary.main,
  "&:hover": {
    backgroundColor: "transparent",
    textDecoration: "none",
    color: theme.palette.customColors?.delete,
  },
});

// HOVERS THAT HAVE A BACKGROUND:

// Chatbox & Scroll back up, the round btns
export const hoverMainAndWhiteToOpposite = (theme: Theme) => ({
  transition: "0.3 ease",
  color: theme.palette.customColors?.bright,
  backgroundColor: theme.palette.primary.main,
  "&:hover": {
    backgroundColor: theme.palette.customColors?.pressed,
  },
});

// Contact form btn; main & white to lightest & main
export const hoverMainToLightest = (theme: Theme) => ({
  transition: "background-color 0.5s ease, color 0.3s ease",
  backgroundColor: theme.palette.primary.main,
  color: theme.palette.customColors?.bright,
  "&:hover": {
    backgroundColor: theme.palette.customColors?.lightest,
    color: theme.palette.primary.main,
  },
});

// Open goal btn; green to main w bg
export const hoverAddToMain = (theme: Theme) => ({
  transition: "0.3s ease",
  backgroundColor: theme.palette.customColors?.add,
  color: theme.palette.customColors?.bright,
  "&:hover": {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.customColors?.bright,
  },
});

// Add but w bg
export const hoverSecondaryToAddWBg = (theme: Theme) => ({
  transition: "0.3s ease",
  backgroundColor: theme.palette.secondary.main,
  color: theme.palette.customColors?.bright,
  "&:hover": {
    backgroundColor: theme.palette.customColors?.add,
  },
});

// Close/archive goal btn
export const hoverRedToMain = (theme: Theme) => ({
  transition: "0.3s ease",
  backgroundColor: theme.palette.customColors?.delete,
  color: theme.palette.customColors?.bright,
  "&:hover": {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.customColors?.bright,
  },
});

// Goal not relevant but w bg
export const hoverMainToRedBg = (theme: Theme) => ({
  transition: "0.3s ease",
  color: theme.palette.primary.main,
  backgroundColor: theme.palette.customColors?.lightest,
  "&:hover": {
    backgroundColor: theme.palette.customColors?.delete,
    color: theme.palette.customColors?.bright,
  },
});

export const hoverMenuItem = (theme: Theme) => ({
  transition: "0.3s ease",
  color: theme.palette.customColors?.bright,
  backgroundColor: theme.palette.primary.main,
  "&:hover": {
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.customColors?.lightest,
  },
});

export const hoverMenuButton = (theme: Theme) => ({
  transition: "0.3s ease",
  color: theme.palette.primary.main,
  backgroundColor: theme.palette.background?.default,
  "&:hover": {
    backgroundColor: theme.palette.customColors?.lightest,
  },
});
export const hoverWhiteToGray = (theme: Theme) => ({
  transition: "0.1s ease",
  "&:hover": {
    backgroundColor: theme.palette.grey[100],
  },
});
