import { createTheme } from "@mui/material/styles";
enum CustomColors {
  newWhiteOff = "#EDE8F2",
  newBlack = "#140D1C",
  newGreen = "#17C964",
  newLightGreen = "#74DFA2",
  newYellow = "#F7B750",
  newLightYellow = "#FBDBA7",
  newRed = "#F54180",
  newLightRed = "#FAA0BF",

  // Todo: remove when facelift is done.
  add = "#3F7956", // muted green
  background = "#EFEFEF", // pale gray
  lightred = "#dd2e44",
  delete = "#AA2222", // softer red
  redflag = "#ff0000", // eye-searing red
  star = "#F4A701", // gold-ish
  chick = "#F5F5DC", // chick yellow/warm beige

  night = "#000000", // black
  midnight = "#0f172a", // black-ish (blue tint)
  bright = "#FFFFFF", // white
  textbubble = "#e2e8f0",
  loweropacity = "#9ca09f", // gray; night but w 0.6 opacity
  darkeropacity = "#4a4b4f",

  // theme colors
  pressed = "#142E76", // main color's "shadow" on btn hovers, darker
  lighter = "#7489D3", // a shade lighter than secondary.main
  lighterer = "#9CAAE0",
  lightest = "#C4CBEC",

  babyblue = "#87ceeb", // for links typically

  // Key result graph lines
  graphline1 = "#02b2af",
  graphline2 = "#5c95c6",
  // darkerline = "#19857b",
}

// Extend the PaletteOptions type to include customColors
declare module "@mui/material/styles" {
  interface Palette {
    customColors: typeof CustomColors;
  }
  interface PaletteOptions {
    customColors?: typeof CustomColors;
  }
}

// "rgb(39,41,109)"

// Create a theme instance.
const theme = createTheme({
  palette: {
    primary: {
      main: "#801AE5",
    },
    secondary: {
      main: "#734F96",
    },
    background: {
      default: "#FAF7FC",
    },
    // You can add custom colors to the customColors property
    customColors: CustomColors,
  },
  // In charge of all font types for Workzep:
  typography: {
    allVariants: {
      // list multiple as fallback plan
      fontFamily: "'Manrope'",
    },
    button: {
      textTransform: "none",
    },
  },
  components: {},
});

export default theme;
