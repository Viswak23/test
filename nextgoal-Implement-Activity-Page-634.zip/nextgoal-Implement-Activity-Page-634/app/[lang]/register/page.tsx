import Register from "@/components/Public/Register/Register";
import React from "react";

function page() {
  return <Register />;
}

export default page;
