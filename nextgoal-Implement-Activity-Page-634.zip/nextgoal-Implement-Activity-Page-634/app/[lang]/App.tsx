"use client";
import { useState } from "react";
import { ThemeProvider } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";
import { CacheProvider } from "@emotion/react";
import createEmotionCache from "@/config/createEmotionCache";
import { IntlProvider } from "react-intl";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { Amplify } from "aws-amplify";
import { AuthContext } from "@/contexts/AuthContext";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";

import "dayjs/locale/fi";

import theme from "@/config/theme";
import "@fontsource/roboto/300.css";
import "@fontsource/roboto/400.css";
import "@fontsource/roboto/500.css";
import "@fontsource/roboto/700.css";
import "manrope";

import "@aws-amplify/ui-react/styles.css";

import en from "@/languages/en.json";
import fi from "@/languages/fi.json";
import es from "@/languages/es.json";
import { Authenticator } from "@aws-amplify/ui-react";
import { customAwsExports } from "@/lib/amplifyConfig";

Amplify.configure({
  ...customAwsExports,
  ssr: true,
});

const messages = {
  en,
  fi,
  es,
};

// Client-side cache, shared for the whole session of the user in the browser.
const clientSideEmotionCache = createEmotionCache();

interface AppProps {
  children: React.ReactNode;
  locale?: string;
}

export default function App({ children, locale = "en" }: AppProps) {
  const [currentUser, setCurrentUser] = useState<any>(undefined);
  const emotionCache = clientSideEmotionCache;

  return (
    <IntlProvider locale={locale} messages={(messages as any)[locale]}>
      <CacheProvider value={emotionCache}>
        <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale={locale}>
          <body>
            <ThemeProvider theme={theme}>
              {/* CssBaseline kickstart an elegant, consistent, and simple baseline to build upon. */}
              <CssBaseline />
              <Authenticator.Provider>
                <AuthContext.Provider value={{ currentUser, setCurrentUser }}>
                  <DndProvider backend={HTML5Backend}>{children}</DndProvider>
                </AuthContext.Provider>
              </Authenticator.Provider>
            </ThemeProvider>
          </body>
        </LocalizationProvider>
      </CacheProvider>
    </IntlProvider>
  );
}
