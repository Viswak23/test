"use client";
import { useEffect } from "react";
import { Auth } from "aws-amplify";
import { useAuthContext } from "@/contexts/AuthContext";
import { Box } from "@mui/material";
import CircularProgress from "@mui/material/CircularProgress";
import { redirect } from "next/navigation";
import { getLinkWithLocale } from "@/lib/localisation";
import { useIntl } from "react-intl";

export default function Logout() {
  const authState = useAuthContext();
  const intl = useIntl();

  useEffect(() => {
    const signOut = async () => {
      await Auth.signOut();
    };

    authState?.setCurrentUser(undefined);
    signOut();
    redirect(getLinkWithLocale("/", intl.locale));
  }, [authState, intl.locale]);

  return (
    <Box style={{ width: "auto", height: "auto", textAlign: "center" }}>
      <CircularProgress style={{ marginTop: "64px" }} />
      <div style={{ paddingLeft: "12px", marginTop: "36px" }}>
        {intl.formatMessage({ id: "login.loggingout.message" })}
      </div>
    </Box>
  );
}
