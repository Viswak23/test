import { Metadata } from "next";
import App from "./App";
import { Amplify } from "aws-amplify";
import { customAwsExports } from "@/lib/amplifyConfig";
import "../ui/global.css";

Amplify.configure({
  ...customAwsExports,
  ssr: true,
});

export const metadata: Metadata = {
  title: "Workzep",
  description: "Make your company goals transparent",
  icons: ["/workzep-favicon-ico.ico"],
};

export default function RootLayout({
  // Layouts must accept a children prop.
  // This will be populated with nested layouts or pages
  children,
  params,
}: {
  children: React.ReactNode;
  params: { lang: string };
}) {
  return (
    <html lang={params.lang}>
      <App locale={params.lang}>{children}</App>
    </html>
  );
}
