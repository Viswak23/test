import PrivacyPolicy from "@/components/Public/LegalPages/PrivacyPolicy";
import React from "react";

export default function page() {
  return <PrivacyPolicy />;
}
