import TermsOfService from "@/components/Public/LegalPages/TermsOfService";
import React from "react";

export default function page() {
  return <TermsOfService />;
}
