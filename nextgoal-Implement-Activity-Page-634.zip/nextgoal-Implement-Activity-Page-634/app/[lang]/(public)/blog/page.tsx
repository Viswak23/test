import BlogPage from "@/components/Public/Blog/BlogPage";
import React from "react";

export default function page() {
  return <BlogPage />;
}
