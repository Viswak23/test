"use client"
import SlackIntegration from "@/components/Public/Documentations/SlackIntegration";
import React from "react";

export default function page() {
  return <SlackIntegration />;
}
