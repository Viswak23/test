import Footer from "@/components/Public/Home/Footer/Footer";
import Header from "@/components/Public/Home/Header/Header";
import React from "react";

export default function layout({ children }: { children: React.ReactNode }) {
  return (
    <div>
      <Header />
      {children}
      <Footer />
    </div>
  );
}
