import Home from "@/components/Public/Home/Home";

export default function HomePage() {
  return <Home />;
}
