"use client";

import { useAuthContext } from "@/contexts/AuthContext";
import {
  withAuthenticator,
  WithAuthenticatorProps,
} from "@aws-amplify/ui-react";
import "@aws-amplify/ui-react/styles.css";
import { useSearchParams } from "next/navigation";
import { redirect } from "next/navigation";
import { useEffect } from "react";
import { Auth } from "aws-amplify";
import PageLoading from "@/components/Common/Loading/PageLoading";
import { Amplify } from "aws-amplify";
import { customAwsExports } from "@/lib/amplifyConfig";
import { Pages } from "@/lib/webNavigation";

Amplify.configure({
  ...customAwsExports,
  ssr: true,
});

const Login = ({ user, signOut }: WithAuthenticatorProps) => {
  const searchParams = useSearchParams();
  const authStatus = useAuthContext();

  useEffect(() => {
    const getCurrentUser = async () => {
      await Auth.currentAuthenticatedUser();
    };

    getCurrentUser();

    authStatus?.setCurrentUser(user);
    const origin: any = searchParams?.get("origin");
    const expired: any = searchParams?.get("expired");

    // Don't redirect before the user has been set.
    if (!authStatus?.currentUser) {
      return;
    }
    // if user has been redirected from spicific page, send him back to it
    if (origin) {
      if (expired) {
        // XXX: Currently page reload is required to update the authentication token.
        window.location.href = origin;
      } else {
        redirect(origin);
      }
    } else {
      // else send him to main
      if (expired) {
        // XXX: Currently page reload is required to update the authentication token.
        window.location.href = Pages.appDashboard;
      } else {
        redirect(Pages.appDashboard);
      }
    }
  }, [authStatus, user, searchParams]);

  return <PageLoading />;
};

export default withAuthenticator(Login, { hideSignUp: true });
