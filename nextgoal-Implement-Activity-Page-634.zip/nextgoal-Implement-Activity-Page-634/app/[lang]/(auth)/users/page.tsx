"use client";
import Employees from "@/components/Employee/Employees";

export default function Page() {
  return <Employees />;
}
