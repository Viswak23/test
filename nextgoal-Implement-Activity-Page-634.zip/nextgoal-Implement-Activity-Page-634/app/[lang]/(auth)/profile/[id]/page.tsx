import EmployeesPage from "./EmployeesPage";
import { Amplify } from "aws-amplify";
import { customAwsExports } from "@/lib/amplifyConfig";
Amplify.configure({
  ...customAwsExports,
  ssr: true,
});
//params such as [id] are passed to the page by nextjs
export default async function Page({ params }: { params: { id: string } }) {
  return <EmployeesPage employeeEmail={decodeURIComponent(params.id)} />;
}
