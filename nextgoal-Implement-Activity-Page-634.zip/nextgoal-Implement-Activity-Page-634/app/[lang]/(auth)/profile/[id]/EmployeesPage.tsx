"use client";
import { Employee } from "@/src/API";
import { useIntl } from "react-intl";
import Stack from "@mui/material/Stack";
import EmployeeDetails from "@/components/Employee/EmployeeDetails";
import EmployeeGoals from "@/components/Employee/EmployeeGoals";
import { useEmployees } from "@/contexts/EmployeesContext";
import ScrollBackUpButton from "@/components/Common/Buttons/ScrollBackUpButton";
import PageMessage from "@/components/Common/Message/PageMessage";

interface EmployeePageProps {
  employeeEmail: string;
}

function EmployeePage({ employeeEmail }: EmployeePageProps) {
  const employeeContext = useEmployees();
  const intl = useIntl();

  const employee = employeeContext?.employees?.find(
    (employee: Employee) => employee?.email === employeeEmail
  );

  if (!employee) {
    return (
      <PageMessage
        message={intl.formatMessage({
          id: "mypage.error.loading.failed",
        })}
      />
    );
  }

  return (
      <Stack direction="column" spacing={2}>
        <EmployeeDetails employee={employee} />
        <EmployeeGoals employee={employee} />
        <ScrollBackUpButton />
      </Stack>
  );
}

export default EmployeePage;
