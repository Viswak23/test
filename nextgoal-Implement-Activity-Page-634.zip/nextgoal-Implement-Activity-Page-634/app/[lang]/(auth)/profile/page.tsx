import { Amplify } from "aws-amplify";
import { customAwsExports } from "@/lib/amplifyConfig";
import Profile from "./Profile";
Amplify.configure({
  ...customAwsExports,
  ssr: true,
});
export default async function Page() {
  return <Profile />;
}
