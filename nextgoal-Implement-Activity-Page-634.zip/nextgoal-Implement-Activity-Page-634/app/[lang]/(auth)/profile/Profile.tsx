"use client";
import { useAuthContext } from "@/contexts/AuthContext";
import EmployeePage from "./[id]/EmployeesPage";

export default function Profile() {
    const { currentUser } = useAuthContext() ?? {};
    if (!currentUser?.attributes?.email) {
      return <div>Please log in to view your profile</div>;
    }
    return <EmployeePage employeeEmail={currentUser.attributes.email} />;
  
}
