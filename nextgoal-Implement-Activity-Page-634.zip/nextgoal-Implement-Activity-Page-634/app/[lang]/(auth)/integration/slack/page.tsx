"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import axios from "axios";
import { addPlatformIntegrationDb } from "@/lib/webPlatformIntegration";
import { Container } from "@mui/material";
import { log } from "@/lib/backend/actions/logger";
import { FormattedMessage, useIntl } from "react-intl";
import { Pages } from "@/lib/webNavigation";

export default function Page() {
  const searchParams = useSearchParams(); // Use this to get the query params
  const intl = useIntl();
  const [errorMessage, setErrorMessage] = useState("");

  const addSlackIntegration = async (response: any) => {
    const newIntegration = {
      companyId: "placeholder",
      platform: "SLACK",
      connectionHook: response.data.incoming_webhook?.url,
      oauthToken: response.data.access_token,
      teamId: response.data.team?.id,
      metadata: JSON.stringify({
        channel_id: response.data.incoming_webhook?.channel_id,
        bot_user_id: response.data.bot_user_id,
        scopes: response.data.scope,
      }),
    };

    await addPlatformIntegrationDb(newIntegration);
  };

  useEffect(() => {
    const handleSlackOAuth = async () => {
      const code = searchParams.get("code");
      if (!code) {
        log("Missing Slack OAuth code");
        window.location.href = `${process.env.NEXT_PUBLIC_URL}/${intl.locale}${Pages.appDashboard}`;
        setErrorMessage(
          intl.formatMessage({ id: "integration.slack.code.fails" })
        );
        return;
      }

      try {
        const response = await axios.post(
          "https://slack.com/api/oauth.v2.access",
          null,
          {
            params: {
              client_id: process.env.NEXT_PUBLIC_SLACK_APP_CLIENT_ID,
              client_secret: process.env.NEXT_PUBLIC_SLACK_APP_CLIENT_SECRET,
              code: code,
              redirect_uri: `${process.env.NEXT_PUBLIC_URL}/${intl.locale}/integration/slack`,
            },
          }
        );

        if (response.data.ok) {
          await addSlackIntegration(response);
          setErrorMessage("");
          window.location.href = `${process.env.NEXT_PUBLIC_URL}/${intl.locale}${Pages.appDashboard}`;
        } else {
          setErrorMessage(
            intl.formatMessage({ id: "integration.slack.code.fails" })
          );
          log(`Slack OAuth failed: ${response.data.error}`);
        }
      } catch (error) {
        log(`Error exchanging Slack authorization code. ${error}`);
      }
    };

    handleSlackOAuth();
  }, [intl, searchParams]);

  return (
    <Container sx={{ marginTop: 40 }}>
      <div style={{ textAlign: "center", padding: "50px" }}>
        {errorMessage ? (
          <p>
            <FormattedMessage id="integration.slack.code.fails" />
          </p>
        ) : (
          <>
            <h2>
              <FormattedMessage id="integration.slack.processing" />
            </h2>
            <p>
              <FormattedMessage id="integration.slack.please.wait" />
            </p>
          </>
        )}
      </div>
    </Container>
  );
}
