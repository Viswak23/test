"use client";
import Dashboard from "@/components/Dashboard/Dashboard";

export default function page() {
  return <Dashboard />;
}
