"use client";

import PageMessage from "@/components/Common/Message/PageMessage";
import { log } from "@/lib/backend/actions/logger";
import { Button } from "@mui/material";
import { useEffect } from "react";
import { FormattedMessage, useIntl } from "react-intl";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  const intl = useIntl();

  useEffect(() => {
    // send the error to cloudwatch
    log(`Error Boundary: ${error.message}`);
  }, [error]);

  return (
    <PageMessage
      message={intl.formatMessage({
        id: "general.something.wrong",
      })}
    >
      <Button variant="contained" onClick={() => reset()}>
        <FormattedMessage id="general.try.again" />
      </Button>
    </PageMessage>
  );
}
