import React from "react";
import DataProvider from "./dataProvider";
import { getData } from "@/lib/backend/getData";
import ChatBox from "@/components/Chat/ChatBox";
import { Amplify } from "aws-amplify";
import { customAwsExports } from "@/lib/amplifyConfig";
import WebsocketHandler from "@/components/Common/Dialog/WebsocketHandler";

Amplify.configure({
  ...customAwsExports,
  ssr: true,
});

export default async function layout({
  children,
}: {
  children: React.ReactNode;
}) {
  const {
    goals,
    archive,
    organization,
    events,
    employees,
    organizationUnitEmployeeJoins,
    northStars,
    notifications,
  } = await getData();

  return (
    <DataProvider
      goals={goals}
      archive={archive}
      organization={organization}
      northStars={northStars}
      events={events}
      employees={employees}
      organizationUnitEmployeeJoins={organizationUnitEmployeeJoins}
      notifications={notifications}
    >
      {children}
      <ChatBox />
      <WebsocketHandler />
    </DataProvider>
  );
}
