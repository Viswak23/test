import SettingsPage from "@/components/Settings/SettingsPage";

export default function page() {
  return <SettingsPage />;
}
