"use client";
import PageLoading from "@/components/Common/Loading/PageLoading";
import Layout from "@/components/Layout/Layout";
import { useAuthContext } from "@/contexts/AuthContext";
import { EmployeesProvider } from "@/contexts/EmployeesContext";
import { EventsProvider } from "@/contexts/EventsContext";
import { GoalsProvider } from "@/contexts/GoalsContext";
import { NorthStarsProvider } from "@/contexts/NorthStarsContext";
import { OrganizationProvider } from "@/contexts/OrganizationContext";
import {
  Goal,
  OrganizationUnit,
  NorthStar,
  Employee,
  OrganizationUnitEmployeeJoin,
  Event,
  Notification,
} from "@/src/API";
import { useAuthenticator } from "@aws-amplify/ui-react";
import { StrictMode, useEffect } from "react";
import { Amplify } from "aws-amplify";
import { SettingsProvider } from "@/contexts/SettingsInfo";
// import Message from "@/components/Common/Message/Message";
import { customAwsExports } from "@/lib/amplifyConfig";
import { NotificationsProvider } from "@/contexts/NotificationContext";

Amplify.configure({
  ...customAwsExports,
  ssr: true,
});

type ProviderProps = {
  goals: Goal[];
  archive: Goal[];
  organization: OrganizationUnit[];
  northStars: NorthStar[];
  events: Event[];
  employees: Employee[];
  organizationUnitEmployeeJoins: OrganizationUnitEmployeeJoin[];
  notifications: Notification[];
  children: React.ReactNode;
};

function DataProvider({
  goals,
  archive,
  organization,
  northStars,
  events,
  employees,
  organizationUnitEmployeeJoins,
  notifications,
  children,
}: ProviderProps) {
  const authStatus = useAuthContext();
  const { user, route } = useAuthenticator((context) => [context.user]);
  const dbUser = employees.find(
    (employee) => employee?.email === user?.attributes?.email
  );
  //if user is undefined and already authenticated. set the user to the current user.
  useEffect(() => {
    if (!authStatus?.currentUser && route === "authenticated") {
      authStatus?.setCurrentUser(user);
    }
  }, [authStatus, user, route]);
  if (!authStatus?.currentUser) {
    return <PageLoading />;
  }
  return (
    <SettingsProvider
      initialState={{
        subscriptionDetails: null,
        billingDetails: null,
        dbUser,
        companyDetails: null,
      }}
    >
      <NotificationsProvider initialState={{ notifications }}>
        <GoalsProvider
          initialState={{
            goals,
            archivedGoals: archive,
          }}
        >
          <OrganizationProvider initialState={{ organization }}>
            <EmployeesProvider
              initialState={{
                employees,
                organizationUnitEmployeeJoins,
              }}
            >
              <NorthStarsProvider initialState={{ northStars }}>
                <EventsProvider
                  initialState={{ events: events, currentEvent: null }}
                >
                  <StrictMode>
                    <Layout>{children}</Layout>
                  </StrictMode>
                  {/* we need a better way of showing a message, maybe ReactHotToast?  this message component is causing an error "localStorage is not defined"*/}
                  {/* <Message /> */}
                </EventsProvider>
              </NorthStarsProvider>
            </EmployeesProvider>
          </OrganizationProvider>
        </GoalsProvider>
      </NotificationsProvider>
    </SettingsProvider>
  );
}

export default DataProvider;
