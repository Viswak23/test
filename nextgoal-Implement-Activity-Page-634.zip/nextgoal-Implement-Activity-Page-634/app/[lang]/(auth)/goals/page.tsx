"use client";
import ScrollBackUpButton from "@/components/Common/Buttons/ScrollBackUpButton";
import GoalListMain from "@/components/GoalList/GoalListMain";
import NorthStars from "@/components/NorthStars/NorthStars";
import OrganizationList from "@/components/Organization/OrganizationList";
import { useNorthStars } from "@/contexts/NorthStarsContext";
import { Stack } from "@mui/material";

export default function Page() {
  const northStarsState = useNorthStars()!;
  const smPaddingTop =
    northStarsState.northStars?.length > 0 ? "78px" : "100px";

  return (
    <Stack
      direction="column"
      spacing={4}
      sx={{ paddingTop: { xs: "24px", sm: smPaddingTop } }}
      data-cy="main-page"
    >
      {northStarsState.northStars?.length > 0 && <NorthStars />}
      <GoalListMain />
      <OrganizationList />
      <ScrollBackUpButton />
    </Stack>
  );
}
