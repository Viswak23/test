"use client";

import { Stack } from "@mui/material";
import GoalListArchive from "@/components/GoalList/GoalListArchive";
import { Amplify } from "aws-amplify";
import { customAwsExports } from "@/lib/amplifyConfig";

Amplify.configure({
  ...customAwsExports,
  ssr: true,
});

export default function page() {
  return (
    <Stack direction="column" spacing={4}>
      <GoalListArchive />
    </Stack>
  );
}
