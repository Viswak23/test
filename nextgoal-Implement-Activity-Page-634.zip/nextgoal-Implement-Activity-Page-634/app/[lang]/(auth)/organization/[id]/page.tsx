import OrganizationPageContent from "@/components/Organization/OrganizationPageContent";
import { Amplify } from "aws-amplify";
import { customAwsExports } from "@/lib/amplifyConfig";

Amplify.configure({
  ...customAwsExports,
  ssr: true,
});

export default async function page({ params }: { params: { id: string } }) {
  return <OrganizationPageContent organizationUnitId={params.id} />;
}
