import { Amplify } from "aws-amplify";
import { customAwsExports } from "@/lib/amplifyConfig";
import SingleFeedPage from "@/components/Feeds/SingleFeedPage";
import { headers } from "next/headers";
import { getEventById } from "@/lib/backend/events";

Amplify.configure({
  ...customAwsExports,
  ssr: true,
});

export default async function page({ params }: { params: { id: string } }) {
  const req = {
    headers: {
      cookie: headers().get("cookie"),
    },
  };

  const event = await getEventById(req, params.id);
  return <SingleFeedPage event={event} />;
}
