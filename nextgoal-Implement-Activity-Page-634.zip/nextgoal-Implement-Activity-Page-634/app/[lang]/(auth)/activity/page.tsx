"use client";
import ActivityPage from "@/components/Feeds/ActivityPage";

const Home: React.FC = () => {
  return <ActivityPage />;
};

export default Home;