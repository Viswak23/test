import {
  CreateSuccessStoryInput,
  CreateSuccessStoryMutation,
  DeleteSuccessStoryMutation,
  SuccessStory,
  UpdateSuccessStoryInput,
  UpdateSuccessStoryMutation,
  Event,
} from "@/src/API";
import {
  createSuccessStory,
  deleteSuccessStory,
  updateSuccessStory,
} from "@/src/graphql/mutations";
import {
  DeleteEventType,
  EventOwner,
  EventType,
  addEvent,
  deleteEventsDb,
  getDeleteEvents,
} from "./webEvents";
import {
  createApiRequest,
  getCompanyId,
  removeUndefinedAndNullFields,
} from "./webHelpers";
import { deleteCommentsWithReplies } from "./webComments";
import { EmployeeWithAvatarUrl } from "@/contexts/EmployeesContext";
import {
  EmployeeJoinType,
  addEmployeeJoins,
  addNewEmployeeJoins,
  deleteRemovedEmployeeJoins,
} from "./webEmployee";
import { AttachmentFile, deleteAttachments } from "./webAttachment";

// Adds an success story to a goal and returns updated goal
export async function addSuccessStoryDb(
  newSuccessStory: CreateSuccessStoryInput,
  taggedEmployees: (EmployeeWithAvatarUrl | null)[],
  employeeGoal: boolean,
  allEmployees: EmployeeWithAvatarUrl[] | undefined
) {
  newSuccessStory.companyId = await getCompanyId();
  const resultSs = await createApiRequest<CreateSuccessStoryMutation>(
    createSuccessStory,
    newSuccessStory,
    "createSuccessStory"
  );

  if (resultSs) {
    // Add join table entries for the taggedEmployees
    if (taggedEmployees.length > 0) {
      const joinInfo = {
        goalId: newSuccessStory.goalSuccessStoriesId,
        successStoryEmployeeJoinsId: resultSs.id,
      };
      await addEmployeeJoins(
        taggedEmployees,
        joinInfo,
        EmployeeJoinType.SuccessStory
      );
    }
    if (resultSs && !employeeGoal) {
      addEvent(
        EventType.SUCCESS_STORY_ADDED,
        resultSs.goalSuccessStoriesId,
        allEmployees,
        taggedEmployees,
        {
          eventSuccessStoryId: resultSs.id,
        }
      );
    }
  }
  return resultSs;
}

// Updates existing success story
export async function updateSuccessStoryDb(
  updatedSuccessStory: UpdateSuccessStoryInput,
  originalSuccessStory?: SuccessStory,
  employees?: (EmployeeWithAvatarUrl | null)[]
) {
  const updateObject: UpdateSuccessStoryInput = removeUndefinedAndNullFields({
    id: updatedSuccessStory.id,
    name: updatedSuccessStory.name,
    attachments: updatedSuccessStory.attachments,
  });
  const resultSs = await createApiRequest<UpdateSuccessStoryMutation>(
    updateSuccessStory,
    updateObject,
    "updateSuccessStory"
  );

  // If the employee joins are given, update them.
  if (originalSuccessStory && employees) {
    // Delete removed employeeJoins
    await deleteRemovedEmployeeJoins(
      originalSuccessStory.employeeJoins,
      employees,
      EmployeeJoinType.SuccessStory
    );

    // Add new employeeJoins.
    const joinInfo = {
      goalId: originalSuccessStory.goalSuccessStoriesId,
      successStoryEmployeeJoinsId: originalSuccessStory.id,
    };
    await addNewEmployeeJoins(
      originalSuccessStory.employeeJoins,
      employees,
      joinInfo,
      EmployeeJoinType.SuccessStory
    );
  }

  return resultSs;
}

// Delete given success story including comments and replies from the database.
export async function deleteSuccessStoryDb(
  successStory: SuccessStory,
  attachments: AttachmentFile[],
  events?: Event[]
) {
  // Delete all the comments
  await deleteCommentsWithReplies(successStory.comments?.items || []);
  // Delete all the employee joins
  await deleteRemovedEmployeeJoins(
    successStory.employeeJoins,
    [],
    EmployeeJoinType.SuccessStory
  );
  // Delete all the attachments
  await deleteAttachments(attachments, []);
  await deleteEventsDb(
    getDeleteEvents(events, DeleteEventType.SUCCESS_STORY, successStory.id)
  );
  // Delete the success story
  return await createApiRequest<DeleteSuccessStoryMutation>(
    deleteSuccessStory,
    { id: successStory.id },
    "deleteSuccessStory"
  );
}
