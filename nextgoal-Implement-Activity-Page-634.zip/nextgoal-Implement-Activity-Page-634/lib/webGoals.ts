import {
  daysAgoDayjs,
  diffInDays,
  sortCreatedAtAscending,
  sortCreatedAtDescending,
} from "./time";
import dayjs from "dayjs";
import {
  CreateGoalInput,
  CreateGoalMutation,
  Goal,
  UpdateGoalInput,
  UpdateGoalMutation,
  DeleteGoalMutation,
  Event,
  NorthStar,
  Employee,
  OrganizationUnit,
  OrganizationUnitEmployeeJoin,
} from "@/src/API";
import { createGoal, deleteGoal, updateGoal } from "@/src/graphql/mutations";
import {
  DeleteEventType,
  EventType,
  addEvent,
  deleteEventsDb,
  getDeleteEvents,
} from "./webEvents";
import {
  createApiRequest,
  getCompanyId,
  removeUndefinedAndNullFields,
} from "./webHelpers";
import * as _ from "lodash";
import { ParentGoal } from "@/components/GoalList/GoalListSub";
import { deleteKeyResultDb } from "./webKeyResults";
import { deleteStatusDb } from "./webStatus";
import { deleteRedFlagDb } from "./webRedFlags";
import { deleteIdeaDb } from "./webIdeas";
import { deleteSuccessStoryDb } from "./webSuccessStories";
import { deleteContributionDb } from "./webContributions";
import { saveMessage } from "./localStorage";
import { getAttachmentFile } from "./webAttachment";
import { deleteHelpRequestDb } from "./webHelpRequests";
import { deleteTaskDb } from "./webTasks";
import { IntlShape } from "react-intl";
import { getCompanyDb } from "./webCompany";
import { buildOrganizationPath } from "./webBreadCrumb";
import { log } from "./backend/actions/logger";
import { EmployeeWithAvatarUrl } from "@/contexts/EmployeesContext";

export enum CloseGoalStatus {
  ACHIEVED = "ACHIEVED",
  SOMEWHAT_ACHIEVED = "SOMEWHAT_ACHIEVED",
  FAILED = "FAILED",
}

export async function addGoalDb(
  newGoal: CreateGoalInput,
  employees: EmployeeWithAvatarUrl[] | undefined
) {
  newGoal.companyId = await getCompanyId();
  const resultGoal = await createApiRequest<CreateGoalMutation>(
    createGoal,
    newGoal,
    "createGoal"
  );

  // Don't create an event for employees' own goals
  if (resultGoal.employeeGoalsId == null) {
    // Fire and forget event creation.

    addEvent(EventType.GOAL_ADDED, resultGoal.id, employees);
  }
  return resultGoal;
}

export async function updateGoalDb(updatedGoal: UpdateGoalInput) {
  const updateObject = removeUndefinedAndNullFields({
    id: updatedGoal.id!,
    title: updatedGoal.title,
    description: updatedGoal.description,
    reward: updatedGoal.reward,
    startDate: updatedGoal.startDate,
    targetDate: updatedGoal.targetDate,
    useTasks: updatedGoal.useTasks,
    position: updatedGoal.position,
    attachments: updatedGoal.attachments,
  });
  return await createApiRequest<UpdateGoalMutation>(
    updateGoal,
    updateObject,
    "updateGoal"
  );
}
export async function updateGoalStatus(
  updatedGoal: UpdateGoalInput,
  employees: EmployeeWithAvatarUrl[] | undefined
) {
  const updateObject = removeUndefinedAndNullFields({
    id: updatedGoal.id!,
    isClosed: updatedGoal.isClosed!,
    closingNotes: updatedGoal.closingNotes,
    statusFlag: updatedGoal.statusFlag,
  });
  const resultGoal = await createApiRequest<UpdateGoalMutation>(
    updateGoal,
    updateObject,
    "updateGoal"
  );

  // this will only be called when closing a goal
  if (resultGoal.employeeGoalsId == null) {
    if (resultGoal.isClosed) {
      addEvent(EventType.GOAL_CLOSED, resultGoal.id, employees);
    } else {
      addEvent(EventType.GOAL_OPENED, resultGoal.id, employees);
    }
  }

  return resultGoal;
}

// Delete goal from the database.
async function deleteGoalDb(goal: Goal, events?: Event[]) {
  if (!goal.id) return;

  // Delete the event
  await deleteEventsDb(getDeleteEvents(events, DeleteEventType.GOAL, goal.id));

  return await createApiRequest<DeleteGoalMutation>(
    deleteGoal,
    { id: goal.id },
    "deleteGoal"
  );
}

// Delete given goql and all its children from the database.
export async function deleteGoalWithChildrenDb(
  intl: IntlShape,
  goal: Goal,
  events?: Event[]
) {
  if (!goal.id) return;

  // Delete all children
  goal.keyResults?.items?.forEach(
    async (keyResult) =>
      keyResult?.id && (await deleteKeyResultDb(keyResult, events))
  );
  goal.status?.items?.forEach(async (status) => {
    if (status?.id) {
      const attachments = await Promise.all(
        status.attachments?.map(async (attachment) =>
          getAttachmentFile(attachment)
        ) || []
      );
      await deleteStatusDb(status, attachments, events);
    }
  });
  goal.redFlags?.items?.forEach(async (redFlag) => {
    if (redFlag?.id) {
      const attachments = await Promise.all(
        redFlag.attachments?.map(async (attachment) =>
          getAttachmentFile(attachment)
        ) || []
      );
      await deleteRedFlagDb(redFlag, attachments, events);
    }
  });
  goal.ideas?.items?.forEach(async (idea) => {
    if (idea?.id) {
      const attachments = await Promise.all(
        idea.attachments?.map(async (attachment) =>
          getAttachmentFile(attachment)
        ) || []
      );
      await deleteIdeaDb(idea, attachments, events);
    }
  });
  goal.successStories?.items?.forEach(async (successStory) => {
    if (successStory?.id) {
      const attachments = await Promise.all(
        successStory.attachments?.map(async (attachment) =>
          getAttachmentFile(attachment)
        ) || []
      );
      await deleteSuccessStoryDb(successStory, attachments, events);
    }
  });
  goal.contributions?.items?.forEach(async (contribution) => {
    if (contribution?.id) {
      const attachments = await Promise.all(
        contribution.attachments?.map(async (attachment) =>
          getAttachmentFile(attachment)
        ) || []
      );
      await deleteContributionDb(contribution, attachments, events);
    }
  });
  goal.helpRequests?.items?.forEach(async (helpRequest) => {
    if (helpRequest?.id) {
      const attachments = await Promise.all(
        helpRequest.attachments?.map(async (attachment) =>
          getAttachmentFile(attachment)
        ) || []
      );
      await deleteHelpRequestDb(helpRequest, attachments, events);
    }
  });
  goal.tasks?.items?.forEach(async (task) => {
    if (task?.id) {
      await deleteTaskDb(task.id);
    }
  });

  // Delete the goal itself
  await deleteGoalDb(goal, events);
  saveMessage(intl.formatMessage({ id: "goals.goal.deleted" }));
}

export function calculateProgress(goal: Goal) {
  if (!goal.targetDate) {
    return undefined;
  }

  const startDate = goal.startDate || goal.createdAt;
  const daysPassed = daysAgoDayjs(startDate);
  const daysTotal = diffInDays(startDate, goal.targetDate);
  return Math.min(Math.round((daysPassed / daysTotal) * 100), 100);
}

// Get the goals that has next five closest target dates
export function getNextFiveGoals(goals?: Goal[] | null): Goal[] {
  if (!goals) return [];

  const sortedGoals = goals
    .filter((g) => g.targetDate != null)
    .sort((a, b) => {
      if (!a.targetDate || !b.targetDate) return 0;
      return dayjs(a.targetDate).isBefore(dayjs(b.targetDate)) ? -1 : 1;
    });

  return sortedGoals.slice(0, 5);
}
// Get human readable text for the status flag.
export function getCloseStatusFlagText(statusFlag?: string | null) {
  if (!statusFlag) return "";

  switch (statusFlag) {
    case CloseGoalStatus.ACHIEVED:
      return "goal.status.achieved";
    case CloseGoalStatus.SOMEWHAT_ACHIEVED:
      return "goal.status.somewhat_achieved";
    case CloseGoalStatus.FAILED:
      return "goal.status.failed";
    default:
      return "Error";
  }
}
export function getCloseFlagColor(statusFlag?: string | null) {
  if (!statusFlag) return;
  switch (statusFlag) {
    case CloseGoalStatus.ACHIEVED:
      return "success";
    case CloseGoalStatus.SOMEWHAT_ACHIEVED:
      return "warning";
    case CloseGoalStatus.FAILED:
      return "error";
    default:
      return "default";
  }
}

// Order subitems a way we want to show them.
export function sortGoalSubitems(goal?: Goal) {
  if (!goal) return null;

  const sortedGoal = _.cloneDeep(goal);
  if (!sortedGoal) return null;

  // Sort statuses, newest first.
  // Todo: In the future, can this be done in the database query?
  if (sortedGoal.status?.items) {
    sortedGoal.status.items.sort(sortCreatedAtDescending);
  }

  // Sort red flags, newest first.
  if (sortedGoal.redFlags?.items) {
    sortedGoal.redFlags.items.sort(sortCreatedAtDescending);
  }

  // Sort ideas, newest first.
  if (sortedGoal.ideas?.items) {
    sortedGoal.ideas.items.sort(sortCreatedAtDescending);
  }

  // Sort success stories, newest first.
  if (sortedGoal.successStories?.items) {
    sortedGoal.successStories.items.sort(sortCreatedAtDescending);
  }

  // Sort contributions, newest first.
  if (sortedGoal.contributions?.items) {
    sortedGoal.contributions.items.sort(sortCreatedAtDescending);
  }

  // Sort help requests, newest first.
  if (sortedGoal.helpRequests?.items) {
    sortedGoal.helpRequests.items.sort(sortCreatedAtDescending);
  }

  // Sort keyresults oldest first
  if (sortedGoal.keyResults?.items) {
    sortedGoal.keyResults?.items.sort(sortCreatedAtAscending);
    sortedGoal.keyResults?.items.map((keyResult) => {
      // Sort key resuld updates newest first
      if (keyResult?.updates?.items) {
        keyResult.updates.items.sort(sortCreatedAtDescending);
      }
      return keyResult;
    });
  }

  return sortedGoal;
}

// Sort goals according their position.
export function sortGoals(goals?: Goal[]): Goal[] {
  if (!goals) return [];

  return goals
    .sort((a, b) => (a?.position || 0) - (b?.position || 0))
    .filter((g) => g != undefined);
}

// Get the order list of the parent goals of the given goal
export function getParentsPosition(
  goals: Goal[],
  currentGoalId?: string
): number[] {
  if (!currentGoalId) return [];

  // Get the array of parent goals positions (own position last)
  const goalRoute = [goals.find((goal) => goal.id === currentGoalId)];
  let tempGoal = goalRoute[0];
  while (tempGoal?.goalChildGoalsId) {
    goalRoute.unshift(
      goals.find((goal) => goal.id === tempGoal?.goalChildGoalsId)
    );
    tempGoal = goalRoute[0];
  }

  return goalRoute.map((goal) => goal?.position || 0);
}

// Sort parentgoals according their position.
export function sortParentGoals(parentGoals?: ParentGoal[], goals?: Goal[]) {
  if (!parentGoals) return [];

  // Sort parent goals according their position
  parentGoals.forEach((parentGoal) => {
    parentGoal.positionPath = getParentsPosition(
      goals || [],
      parentGoal?.goal?.id
    );
  });

  // Sort according the following rules:
  // - Use the length of the position path (shorter -> organization own goal, not company goal) -> longer first
  // - Start looking from the betinning of the position path and compare each entry until the first difference is found
  let result = parentGoals.sort((a, b) => {
    if (!b.positionPath) return -1;
    if (!a.positionPath) return 1;

    if (a.positionPath.length === b.positionPath.length) {
      for (let i = 0; i < a.positionPath.length; i++) {
        if (a.positionPath[i] !== b.positionPath[i]) {
          return a.positionPath[i] - b.positionPath[i];
        }
      }
      return 0;
    } else {
      return b.positionPath.length - a.positionPath.length;
    }
  });

  result.forEach((parentGoal) => {
    parentGoal.orgUnitGoals = sortGoals(parentGoal.orgUnitGoals);
  });

  return result;
}

// Get the childGoals of the given goal
export function getChildGoals(goal: Goal, goals?: Goal[]): Goal[] {
  if (!goals) return [];

  return goals.filter((g) => g.goalChildGoalsId === goal.id);
}

export async function getGoalBackgroundInfo(
  intl: IntlShape,
  organizationId?: string | undefined,
  employee?: Employee | undefined,
  goals?: Goal[] | undefined,
  organizations?: OrganizationUnit[] | undefined,
  northStars?: NorthStar[] | undefined,
  organizationUnitEmployeeJoin?: OrganizationUnitEmployeeJoin[] | undefined,
  currentGoal?: Goal | undefined
) {
  try {
    // Personal goal
    if (employee) {
      const { description, hint } = await gatherInfoAndHint(
        intl,
        WorkmateChatType.PERSONAL_GOAL,
        organizationId,
        employee,
        goals,
        organizations,
        northStars,
        organizationUnitEmployeeJoin,
        currentGoal
      );
      return { info: description, hint };
    }

    //Organization goal
    if (organizationId && organizations) {
      const { description, hint } = await gatherInfoAndHint(
        intl,
        WorkmateChatType.ORGANIZATION_GOAL,
        organizationId,
        employee,
        goals,
        organizations,
        northStars,
        organizationUnitEmployeeJoin,
        currentGoal
      );
      return { info: description, hint };
    }

    // Company goal
    const { description, hint } = await gatherInfoAndHint(
      intl,
      WorkmateChatType.COMPANY_GOAL,
      organizationId,
      employee,
      goals,
      organizations,
      northStars,
      organizationUnitEmployeeJoin,
      currentGoal
    );

    return { info: description, hint };
  } catch (error: any) {
    log("Error getting Goal Background Info: " + error.message);
    return { info: "", hint: "" };
  }
}

export function getOrgDescription(
  organizations: OrganizationUnit[],
  organizationId: string,
  intl: IntlShape
) {
  const currentOrg = organizations?.find((org) => org.id === organizationId)!;
  let missingInformation: string[] = [];
  let description = `${intl.formatMessage(
    {
      id: "chat.prefilled.background.info.organization.name",
    },
    { orgName: currentOrg.name }
  )}\n`;

  if (currentOrg.description && currentOrg.description.length > 0)
    description += `${intl.formatMessage(
      {
        id: "chat.prefilled.background.info.organization.description",
      },
      { orgDescription: currentOrg.description }
    )}\n`;
  else {
    missingInformation.push(
      intl.formatMessage(
        {
          id: "chat.background.info.missing.org.description",
        },
        { orgName: currentOrg.name }
      )
    );
  }

  const parentOrg = organizations?.find(
    (org) => org.id === currentOrg.parentOrganizationUnit?.id
  )!;
  if (parentOrg) {
    description += `${intl.formatMessage(
      {
        id: "chat.prefilled.background.info.parent.organization.name",
      },
      { parentOrgName: parentOrg.name }
    )}\n`;

    if (parentOrg.description) {
      description += `${intl.formatMessage(
        {
          id: "chat.prefilled.background.info.parent.organization.description",
        },
        {
          parentOrgName: parentOrg.name,
          parentOrgDescription: parentOrg.description,
        }
      )}\n`;
    } else {
      missingInformation.push(
        intl.formatMessage(
          {
            id: "chat.background.info.missing.org.description",
          },
          { orgName: parentOrg.name }
        )
      );
    }
  }
  return { description, missingInformation };
}

export function getGoalAndKeyResults(
  goals: Goal[],
  intl: IntlShape,
  currentGoal?: Goal,
  isShowingCurrentGoal: boolean = false
) {
  let goal: Goal;
  if (isShowingCurrentGoal && currentGoal) {
    goal = currentGoal;
  } else {
    const companyGoals = goals.filter(
      (goal) =>
        goal !== null && !goal.organizationUnitGoalsId && !goal.employeeGoalsId
    );
    const randomIndex = Math.floor(Math.random() * companyGoals.length);
    goal = companyGoals[randomIndex];
  }

  let description = "";
  let missingInformation: string[] = [];
  if (!goal) {
    return { description, missingInformation };
  }
  if (!isShowingCurrentGoal) {
    description = `${intl.formatMessage({
      id: "chat.prefilled.background.info.organization.goals.info",
    })}\n`;
  }

  description += `${intl.formatMessage(
    {
      id: isShowingCurrentGoal
        ? "chat.prefilled.background.info.company.current.goal.title"
        : "chat.prefilled.background.info.company.random.goal.title",
    },
    { goalTitle: goal.title }
  )}\n`;

  if (goal?.description && goal.description?.length > 0) {
    description += `${intl.formatMessage(
      {
        id: isShowingCurrentGoal
          ? "chat.prefilled.background.info.company.current.goal.description"
          : "chat.prefilled.background.info.company.random.goal.description",
      },
      { goalDescription: goal.description, goalTitle: goal.title }
    )}\n`;
  } else {
    missingInformation.push(
      intl.formatMessage(
        { id: "chat.background.info.missing.goal.description" },
        { goalTitle: goal.title }
      )
    );
  }

  if (goal.keyResults && goal.keyResults?.items?.length > 0) {
    const keyResultsText = goal.keyResults?.items
      .map((e, index) => `\n${index + 1}) ${e?.description}`)
      .join();

    description += `${intl.formatMessage(
      {
        id: "chat.prefilled.background.info.company.goal.keyresults",
      },
      { keyresults: keyResultsText }
    )}\n`;
  } else {
    missingInformation.push(
      intl.formatMessage(
        {
          id: "chat.background.info.missing.goal.keyresult",
        },
        { goalTitle: goal.title }
      )
    );
  }

  return { description, missingInformation };
}

export function getParentOrgGoalAndKeyResults(
  goals: Goal[],
  organizations: OrganizationUnit[],
  organizationId: string,
  intl: IntlShape
) {
  const currentOrg = organizations?.find((org) => org.id === organizationId)!;
  const parentOrgGoals = goals.filter(
    (goal) =>
      goal !== null &&
      goal.organizationUnitGoalsId === currentOrg.parentOrganizationUnit?.id
  );
  let description = "";
  let missingInformation: string[] = [];

  if (parentOrgGoals.length > 0) {
    const randomIndex = Math.floor(Math.random() * parentOrgGoals.length);
    const randomGoal = parentOrgGoals[randomIndex];

    description += `${intl.formatMessage(
      {
        id: "chat.prefilled.background.info.organization.support.goal.title",
      },
      { orgName: currentOrg.name, goalTitle: randomGoal.title }
    )}\n`;

    if (randomGoal.keyResults?.items!.length! > 0) {
      const keyResultsText = randomGoal.keyResults?.items
        .map((e, index) => `\n${index + 1}) ${e?.description}`)
        .join();
      description += `${intl.formatMessage(
        {
          id: "chat.prefilled.background.info.company.goal.keyresults",
        },
        { keyresults: keyResultsText }
      )}\n`;
    } else {
      missingInformation.push(
        intl.formatMessage(
          {
            id: "chat.background.info.missing.goal.keyresult",
          },
          { goalTitle: randomGoal.title }
        )
      );
    }
  }
  return { description, missingInformation };
}

export function getWorkingOrganzation(
  employee: Employee,
  organization: OrganizationUnit[],
  organizationEmployeeJoins: OrganizationUnitEmployeeJoin[],
  intl: IntlShape
) {
  let missingInformation: string[] = [];
  const employeeOrganizations = organizationEmployeeJoins
    ?.filter((join) => join.employeeId === employee?.id)
    .map((join) =>
      organization?.find(
        (organization) => organization?.id === join?.organizationUnitId
      )
    );

  const orgPath = buildOrganizationPath(
    organization,
    employeeOrganizations[
      Math.floor(Math.random() * employeeOrganizations?.length)
    ]?.id!
  );

  // If the employee works in a non top-level Organization unit
  if (orgPath.length > 1) {
    const topLevelOrg = orgPath[0]!;
    const currentOrg = orgPath[orgPath.length - 1];
    if (!topLevelOrg.description) {
      missingInformation.push(
        intl.formatMessage(
          {
            id: "chat.background.info.missing.org.description",
          },
          { orgName: topLevelOrg.name }
        )
      );
    }

    return {
      description: intl.formatMessage(
        {
          id: "chat.prefilled.background.info.personal.goal.work.top.org",
        },
        {
          topLevelOrgName: topLevelOrg.name,
          topLevelOrgDescription: topLevelOrg.description,
          currentOrgName: currentOrg?.name,
        }
      ),
      missingInformation,
    };
  }

  // If the employee works in a top level Organization unit
  const currentOrg = orgPath[orgPath.length - 1]!;
  if (!currentOrg?.description) {
    missingInformation.push(
      intl.formatMessage(
        {
          id: "chat.background.info.missing.org.description",
        },
        { orgName: currentOrg?.name }
      )
    );
  }

  return {
    description: intl.formatMessage(
      {
        id: "chat.prefilled.background.info.personal.goal.work.org",
      },
      {
        currentOrgName: currentOrg?.name,
        currentOrgDescription: currentOrg?.description,
      }
    ),
    missingInformation,
  };
}

export function getInterestAndCareer(employee: Employee, intl: IntlShape) {
  let missingInformation: string[] = [];
  let description = "";
  if (!employee.interest) {
    missingInformation.push(
      intl.formatMessage({
        id: "chat.background.info.missing.personal.interest",
      })
    );
  } else {
    description += intl.formatMessage(
      {
        id: "chat.prefilled.background.info.personal.goal.interest",
      },
      {
        interest: employee.interest,
      }
    );
  }

  if (!employee.career) {
    missingInformation.push(
      intl.formatMessage({
        id: "chat.background.info.missing.personal.career",
      })
    );
  } else {
    description += intl.formatMessage(
      {
        id: "chat.prefilled.background.info.personal.goal.career",
      },
      {
        career: employee.career,
      }
    );
  }

  return {
    description,
    missingInformation,
  };
}

export async function gatherInfoAndHint(
  intl: IntlShape,
  workmateChatType: WorkmateChatType,
  organizationId?: string | undefined,
  employee?: Employee | undefined,
  goals?: Goal[] | undefined,
  organizations?: OrganizationUnit[] | undefined,
  northStars?: NorthStar[] | undefined,
  organizationUnitEmployeeJoin?: OrganizationUnitEmployeeJoin[] | undefined,
  currentGoal?: Goal | undefined
) {
  let missingInformation: string[] = [];
  let description = `${intl.formatMessage({
    id: "chat.prefilled.background.info.description",
  })}\n`;

  // Company description
  const company = await getCompanyDb();
  if (!company.description) {
    missingInformation.push(
      intl.formatMessage({
        id: "chat.background.info.missing.company.description",
      })
    );
  } else {
    description += `${intl.formatMessage(
      {
        id: "chat.prefilled.background.info.company.description",
      },
      { companyDescription: company.description }
    )}\n`;
  }

  switch (workmateChatType) {
    case WorkmateChatType.COMPANY_GOAL:
      // Company northstars
      if (!northStars || northStars?.length === 0) {
        missingInformation.push(
          intl.formatMessage({
            id: "chat.background.info.missing.northstars",
          })
        );
      } else {
        const northStarsText = northStars!
          .map((e, index) => `${index + 1}) ${e.title}`)
          .join("\n");
        description += `${intl.formatMessage(
          {
            id: "chat.prefilled.background.info.company.northstars",
          },
          { northStarsText }
        )}\n`;
      }
      break;
    case WorkmateChatType.ORGANIZATION_GOAL:
      // Current and parent organization description
      const {
        description: orgDescription,
        missingInformation: orgMissingInfo,
      } = getOrgDescription(organizations!, organizationId!, intl);

      // Company goal description

      const {
        description: companyGoalDescription,
        missingInformation: companyGoalMissingInformation,
      } = getGoalAndKeyResults(goals!, intl, currentGoal, false);

      // Parent organization goal and key results
      const {
        description: parentGoalDescription,
        missingInformation: parentGoalMissingInformation,
      } = getParentOrgGoalAndKeyResults(
        goals!,
        organizations!,
        organizationId!,
        intl
      );

      description +=
        orgDescription + companyGoalDescription + parentGoalDescription;
      missingInformation.push(
        ...orgMissingInfo,
        ...companyGoalMissingInformation,
        ...parentGoalMissingInformation
      );
      break;
    case WorkmateChatType.PERSONAL_GOAL:
      const {
        description: workingOrgDescription,
        missingInformation: workingOrgMissingInfo,
      } = getWorkingOrganzation(
        employee!,
        organizations!,
        organizationUnitEmployeeJoin!,
        intl
      );

      const {
        description: personalDescription,
        missingInformation: personalMissingInfo,
      } = getInterestAndCareer(employee!, intl);

      description += workingOrgDescription + personalDescription;
      missingInformation.push(...workingOrgMissingInfo, ...personalMissingInfo);
      break;
    default:
      break;
  }
  if (currentGoal) {
    const {
      description: currentGoalDescription,
      missingInformation: currentGoalMissingInfo,
    } = getGoalAndKeyResults(goals!, intl, currentGoal, true);
    description += currentGoalDescription;
    missingInformation.push(...currentGoalMissingInfo);
  }

  if (missingInformation.length === 0) {
    return { description, hint: "" };
  }
  const hint =
    intl.formatMessage({
      id: "chat.background.info.missing.general",
    }) + missingInformation.join(", ");

  return { description, hint };
}

export const enum WorkmateChatType {
  COMPANY_GOAL,
  ORGANIZATION_GOAL,
  PERSONAL_GOAL,
}
