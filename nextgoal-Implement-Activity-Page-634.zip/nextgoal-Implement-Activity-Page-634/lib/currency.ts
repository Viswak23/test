import { SubscriptionDetails } from "@/contexts/SettingsInfo";
import { toInteger } from "lodash";

export function getSubscriptionCurrency(
  subscriptionDetails: SubscriptionDetails,
  locale: string
) {
  const amount =
    subscriptionDetails?.amount! * toInteger(subscriptionDetails?.quantity!);
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency: subscriptionDetails.currency,
  }).format(amount);
}
