import { useEffect } from "react";
import { useAuthContext } from "@/contexts/AuthContext";
import { Auth } from "aws-amplify";
import { log } from "./backend/actions/logger";

export function useAuthStatus() {
  const authContext = useAuthContext();
  const setCurrentUser = authContext?.setCurrentUser;

  useEffect(() => {
    async function getCurrentUser() {
      const user = await Auth.currentAuthenticatedUser();
      if (setCurrentUser) {
        setCurrentUser(user);
      }
    }

    try {
      getCurrentUser();
    } catch (error: any) {
      log(`useAuthStatus hook: ${error.message}`);
      if (setCurrentUser) {
        setCurrentUser(undefined);
      }
    }
  }, [setCurrentUser]);

  return authContext?.currentUser;
}
