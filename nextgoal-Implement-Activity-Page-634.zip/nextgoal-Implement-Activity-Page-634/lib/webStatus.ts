import {
  CreateStatusInput,
  CreateStatusMutation,
  UpdateStatusInput,
  UpdateStatusMutation,
  Status,
  Event,
  DeleteStatusMutation,
} from "@/src/API";
import {
  createStatus,
  deleteStatus,
  updateStatus,
} from "@/src/graphql/mutations";
import {
  DeleteEventType,
  EventType,
  addEvent,
  deleteEventsDb,
  getDeleteEvents,
} from "./webEvents";
import {
  createApiRequest,
  getCompanyId,
  removeUndefinedAndNullFields,
} from "./webHelpers";
import { deleteCommentsWithReplies } from "./webComments";
import { AttachmentFile, deleteAttachments } from "./webAttachment";
import { EmployeeWithAvatarUrl } from "@/contexts/EmployeesContext";

// Adds a new statsu to a goal and returns updated goal
export async function addStatusDb(
  newStatus: CreateStatusInput,
  employeeGoal: boolean,
  allEmployees: EmployeeWithAvatarUrl[] | undefined
) {
  newStatus.companyId = await getCompanyId();
  const resultStatus = await createApiRequest<CreateStatusMutation>(
    createStatus,
    newStatus,
    "createStatus"
  );

  if (resultStatus && !employeeGoal) {
    addEvent(
      EventType.STATUS_ADDED,
      resultStatus.goalStatusId,
      allEmployees,
      undefined,
      {
        eventStatusId: resultStatus.id,
      }
    );
  }
  return resultStatus;
}

// Updates existing status to a goal and returns updated goal
export async function updateStatusDb(updatedStatus: UpdateStatusInput) {
  // UpdatedStatus contains fields from the original status, so we create a new updateobject.
  const updateObject: UpdateStatusInput = removeUndefinedAndNullFields({
    id: updatedStatus.id,
    status: updatedStatus.status,
    goingWell: updatedStatus.goingWell,
    challenges: updatedStatus.challenges,
    toImprove: updatedStatus.toImprove,
    attachments: updatedStatus.attachments,
  });

  return await createApiRequest<UpdateStatusMutation>(
    updateStatus,
    updateObject,
    "updateStatus"
  );
}

// Delete given status including comments and replies from the database.
export async function deleteStatusDb(
  status: Status,
  attachments: AttachmentFile[],
  events?: Event[]
) {
  // Delete all the comments
  await deleteCommentsWithReplies(status.comments?.items || []);
  // Remove all the attachments
  await deleteAttachments(attachments, []);
  // Delete the event
  await deleteEventsDb(
    getDeleteEvents(events, DeleteEventType.STATUS, status.id)
  );

  // Delete the status
  return await createApiRequest<DeleteStatusMutation>(
    deleteStatus,
    { id: status.id },
    "deleteStatus"
  );
}
