import {
  CreatePlatformIntegrationInput,
  CreatePlatformIntegrationMutation,
  IntegrationByCompanyQuery,
  PlatformIntegration,
} from "@/src/API";
import { createApiRequest } from "./webHelpers";
import { createPlatformIntegration } from "@/src/graphql/mutations";
import { getCompanyDb } from "./webCompany";
import NodeCache from "node-cache";
import { integrationByCompanyForCache } from "@/src/graphql/custom-queries";

const cache = new NodeCache({ stdTTL: 1800 });

export async function addPlatformIntegrationDb(
  newIntegration: CreatePlatformIntegrationInput
) {
  const company = await getCompanyDb();
  newIntegration.companyPlatformIntegrationId = company.id;
  newIntegration.companyId = company.companyId;

  const result = await createApiRequest<CreatePlatformIntegrationMutation>(
    createPlatformIntegration,
    newIntegration,
    "createPlatformIntegration"
  );
  getPlatformIntegrationData(company.companyId, true);
  return result;
}

export async function getPlatformIntegrationFromDb(
  companyId: String
): Promise<PlatformIntegration[]> {
  const result = await createApiRequest<IntegrationByCompanyQuery>(
    integrationByCompanyForCache,
    undefined,
    "integrationByCompany",
    { companyId: companyId }
  );

  return result.items;
}

export async function getPlatformIntegrationData(
  companyId: string,
  resetCache?: boolean
): Promise<PlatformIntegration[]> {
  const cacheKey = `platformIntegration_${companyId}`;

  if (resetCache || !cache.get(cacheKey)) {
    let platformIntegration = await getPlatformIntegrationFromDb(companyId);
    cache.del(cacheKey);
    handlePlatformIntegrationCacheUpdate(cacheKey, platformIntegration);
    return platformIntegration;
  }

  const data = cache.get(cacheKey);
  return data === "NO_INTEGRATION" ? [] : (data as PlatformIntegration[]);
}

function handlePlatformIntegrationCacheUpdate(
  cacheKey: string,
  platformIntegration: PlatformIntegration[]
): PlatformIntegration[] {
  if (!platformIntegration || platformIntegration.length === 0) {
    cache.set(cacheKey, "NO_INTEGRATION");
    return [];
  }

  cache.set(cacheKey, platformIntegration);
  return platformIntegration;
}
