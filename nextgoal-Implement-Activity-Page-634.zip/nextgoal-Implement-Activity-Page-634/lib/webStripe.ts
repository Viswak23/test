import { log } from "./backend/actions/logger";

const mode: "subscription" = "subscription";
export const stripeOptions = {
  mode: mode,
  amount: 8000, //stripe only deals with cents, 8000 is 80.00
  currency: "eur",
};

interface CustomerDetails {
  name: string;
  email: string;
}
export async function createStripeCustomer({ name, email }: CustomerDetails) {
  try {
    const stripe = require("stripe")(process.env.NEXT_PUBLIC_STRIPE_API_SECRET);
    const customer = await stripe.customers.create({
      email: email,
      name: name,
    });

    return { ...customer };
  } catch (error: any) {
    log(`createStripeCustomer: ${error.message}`);
    throw new Error(`Error creating Stripe customer: ${error.message}`);
  }
}
export async function cancelStripeSubscription(subscriptionId: string) {
  try {
    const stripe = require("stripe")(process.env.NEXT_PUBLIC_STRIPE_API_SECRET);

    // cancel the subscription
    const deletedSubscription = await stripe.subscriptions.del(subscriptionId);
    return { ...deletedSubscription };
  } catch (error: any) {
    log(`cancelStripeSubscription: ${error.message}`);
    throw new Error(`Error canceling Stripe subscription: ${error.message}`);
  }
}
export async function deleteStripeCustomer(customerId: string) {
  try {
    const stripe = require("stripe")(process.env.NEXT_PUBLIC_STRIPE_API_SECRET);
    // Delete the customer
    const deletedCustomer = await stripe.customers.del(customerId);
    return { ...deletedCustomer };
  } catch (error: any) {
    log(`deleteStripeCustomer: ${error.message}`);
    throw new Error(`Error deleting Stripe customer: ${error.message}`);
  }
}
export async function updateSubscriptionQuantity(
  subscriptionId: string,
  direction: "increment" | "decrement"
) {
  try {
    const stripe = require("stripe")(process.env.NEXT_PUBLIC_STRIPE_API_SECRET);

    const subscription = await stripe.subscriptions.retrieve(subscriptionId);
    const newQuantity =
      direction === "increment"
        ? subscription.items.data[0].quantity + 1
        : subscription.items.data[0].quantity - 1;

    const updatedSubscription = await stripe.subscriptions.update(
      subscriptionId,
      {
        items: [
          {
            id: subscription.items.data[0].id,
            quantity: newQuantity,
          },
        ],
      }
    );

    return { ...updatedSubscription };
  } catch (error: any) {
    log(`updateSubscriptionQuantity: ${error.message}`);
    throw new Error(
      `Error updating Stripe subscription quantity: ${error.message}`
    );
  }
}
export async function getSubscriptionInfo(subscriptionId: string) {
  try {
    const stripe = require("stripe")(process.env.NEXT_PUBLIC_STRIPE_API_SECRET);
    const subscription = await stripe.subscriptions.retrieve(subscriptionId);
    return { ...subscription };
  } catch (error: any) {
    log(`getSubscriptionInfo: ${error.message}`);
    throw new Error(
      `Error retrieving Stripe subscription info: ${error.message}`
    );
  }
}

export async function getPaymentMethodById(paymentId: string) {
  try {
    const stripe = require("stripe")(process.env.NEXT_PUBLIC_STRIPE_API_SECRET);
    const paymentMethod = await stripe.paymentMethods.retrieve(paymentId);
    return {
      card: paymentMethod.card,
    };
  } catch (error: any) {
    log(`getPaymentMethodById: ${error.message}`);
    throw new Error(`Error retrieving Stripe payment method: ${error.message}`);
  }
}
export async function getCustomerInfo(customerId: string) {
  try {
    const stripe = require("stripe")(process.env.NEXT_PUBLIC_STRIPE_API_SECRET);
    const customer = await stripe.customers.retrieve(customerId);
    return { ...customer };
  } catch (error: any) {
    log(`getCustomerInfo: ${error.message}`);
    throw new Error(`Error retrieving Stripe customer info: ${error.message}`);
  }
}

export const createPortalSession = async (customerId: string) => {
  try {
    const stripe = require("stripe")(process.env.NEXT_PUBLIC_STRIPE_API_SECRET);
    const session = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: `${process.env.NEXT_PUBLIC_URL}/settings`,
    });
    return { ...session };
  } catch (error: any) {
    log(`createPortalSession: ${error.message}`);
    throw new Error(`Error creating Stripe portal session: ${error.message}`);
  }
};
