import {
  Contribution,
  CreateContributionInput,
  CreateContributionMutation,
  DeleteContributionMutation,
  UpdateContributionInput,
  UpdateContributionMutation,
  Event,
} from "@/src/API";

import {
  createContribution,
  updateContribution,
  deleteContribution,
} from "@/src/graphql/mutations";
import {
  DeleteEventType,
  EventType,
  addEvent,
  deleteEventsDb,
  getDeleteEvents,
} from "./webEvents";
import {
  createApiRequest,
  getCompanyId,
  removeUndefinedAndNullFields,
} from "./webHelpers";
import { deleteCommentsWithReplies } from "./webComments";
import { AttachmentFile, deleteAttachments } from "./webAttachment";
import {
  EmployeeJoinType,
  addEmployeeJoins,
  addNewEmployeeJoins,
  deleteRemovedEmployeeJoins,
} from "./webEmployee";
import { EmployeeWithAvatarUrl } from "@/contexts/EmployeesContext";

// Adds a new contribution to the goal
export async function addContributionDb(
  newContribution: CreateContributionInput,
  allEmployees: EmployeeWithAvatarUrl[] | undefined,
  taggedEmployees: (EmployeeWithAvatarUrl | null)[],
  employeeGoal: boolean
) {
  newContribution.companyId = await getCompanyId();
  const resultContribution = await createApiRequest<CreateContributionMutation>(
    createContribution,
    newContribution,
    "createContribution"
  );

  if (resultContribution) {
    // Add join table entries for the taggedEmployees
    if (taggedEmployees.length > 0) {
      const joinInfo = {
        goalId: newContribution.goalContributionsId,
        contributionEmployeeJoinsId: resultContribution.id,
      };
      await addEmployeeJoins(
        taggedEmployees,
        joinInfo,
        EmployeeJoinType.Contribution
      );
    }
    // Don't create an event for taggedEmployees' own goals
    if (!employeeGoal) {
      addEvent(
        EventType.CONTRIBUTION_ADDED,
        resultContribution.goalContributionsId,
        allEmployees,
        taggedEmployees,
        { eventContributionId: resultContribution.id }
      );
    }
  }
  return resultContribution;
}

// Updates existing contribution
export async function updateContributionDb(
  updatedContribution: UpdateContributionInput,
  originalContribution?: Contribution,
  employees?: (EmployeeWithAvatarUrl | null)[]
) {
  // UpdatedStatus contains fields from the original status, so we create a new updateobject.
  const updateObject: UpdateContributionInput = removeUndefinedAndNullFields({
    id: updatedContribution.id,
    description: updatedContribution.description,
    attachments: updatedContribution.attachments,
  });

  const resultContribution = await createApiRequest<UpdateContributionMutation>(
    updateContribution,
    updateObject,
    "updateContribution"
  );

  // If the employee joins are given, update them.
  if (employees && originalContribution) {
    // Delete removed employeeJoins
    await deleteRemovedEmployeeJoins(
      originalContribution.employeeJoins,
      employees,
      EmployeeJoinType.Contribution
    );
    // Add new employeeJoins.
    const joinInfo = {
      goalId: originalContribution.goalContributionsId,
      contributionEmployeeJoinsId: originalContribution.id,
    };
    await addNewEmployeeJoins(
      originalContribution.employeeJoins,
      employees,
      joinInfo,
      EmployeeJoinType.Contribution
    );
  }

  return resultContribution;
}

// Deletes existing contribution
export async function deleteContributionDb(
  contribution: Contribution,
  attachments: AttachmentFile[],
  events?: Event[]
) {
  // Delete all the comments
  await deleteCommentsWithReplies(contribution.comments?.items || []);
  // Delete all the employeeJoins
  await deleteRemovedEmployeeJoins(
    contribution.employeeJoins,
    [],
    EmployeeJoinType.Contribution
  );
  // Remove all the attachments
  await deleteAttachments(attachments, []);
  // Delete the event
  await deleteEventsDb(
    getDeleteEvents(events, DeleteEventType.CONTRIBUTION, contribution.id)
  );
  // Delete the contribution
  return await createApiRequest<DeleteContributionMutation>(
    deleteContribution,
    { id: contribution.id },
    "deleteContribution"
  );
}
