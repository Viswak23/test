import { getAllSubgoals } from "./webSubgoals";
import {
  CreateKeyResultInput,
  CreateKeyResultMutation,
  CreateKeyResultUpdateInput,
  CreateKeyResultUpdateMutation,
  DeleteKeyResultMutation,
  DeleteKeyResultUpdateMutation,
  Goal,
  Event,
  KeyResult,
  UpdateKeyResultInput,
  UpdateKeyResultMutation,
  UpdateKeyResultUpdateInput,
  UpdateKeyResultUpdateMutation,
} from "@/src/API";
import {
  createKeyResult,
  deleteKeyResult,
  deleteKeyResultUpdate,
  updateKeyResult,
  updateKeyResultUpdate,
} from "@/src/graphql/mutations";
import {
  DeleteEventType,
  EventType,
  addEvent,
  deleteEventsDb,
  getDeleteEvents,
} from "./webEvents";
import {
  createApiRequest,
  getCompanyId,
  removeUndefinedAndNullFields,
} from "./webHelpers";
import { deleteCommentsWithReplies } from "./webComments";
import { IntlShape } from "react-intl";
import { createKeyResultUpdateWithGoal } from "@/src/graphql/custom-mutations";
import { EmployeeWithAvatarUrl } from "@/contexts/EmployeesContext";

export enum KeyResultStatus {
  UNKNOWN = "UNKNOWN",
  COMPLETED = "COMPLETED",
  ON_TRACK = "ON_TRACK",
  AT_RISK = "AT_RISK",
  BEHIND = "BEHIND",
  FAILED = "FAILED",
}

// The first color of each status is the default color. The others are used in order in a graph when there are multiple keyresults in the same status.
const KeyResultStatusColors = {
  [KeyResultStatus.UNKNOWN]: [
    "#8A8D90",
    "#D2D2D2",
    "#B8BBBE",
    "#6A6E73",
    "#E2E2E2",
  ],
  [KeyResultStatus.COMPLETED]: [
    "#4CB140",
    "#23511E",
    "#7CC674",
    "#38812F",
    "#BDE2B9",
  ],
  [KeyResultStatus.ON_TRACK]: [
    "#00006C",
    "#519DE9",
    "#004B95",
    "#8BC1F7",
    "#002F5D",
  ],
  [KeyResultStatus.AT_RISK]: [
    "#F4C145",
    "#F0AB00",
    "#F6D173",
    "#C58C00",
    "#F9E0A2",
  ],
  [KeyResultStatus.BEHIND]: [
    "#EC7A08",
    "#C46100",
    "#F4B678",
    "#EF9234",
    "#8F4700",
  ],
  [KeyResultStatus.FAILED]: [
    "#C9190B",
    "#A30000",
    "#7D1007",
    "#570000",
    "#470000",
  ],
};

// Get human readable text for the status flag.
export function getStatusFlagText(intl: IntlShape, statusFlag?: string | null) {
  if (!statusFlag) return "";

  switch (statusFlag) {
    case KeyResultStatus.UNKNOWN:
      return intl.formatMessage({ id: "keyresults.status.unknown" });
    case KeyResultStatus.COMPLETED:
      return intl.formatMessage({ id: "keyresults.status.completed" });
    case KeyResultStatus.ON_TRACK:
      return intl.formatMessage({ id: "keyresults.status.on.track" });
    case KeyResultStatus.AT_RISK:
      return intl.formatMessage({ id: "keyresults.status.at.risk" });
    case KeyResultStatus.BEHIND:
      return intl.formatMessage({ id: "keyresults.status.behind" });
    case KeyResultStatus.FAILED:
      return intl.formatMessage({ id: "keyresults.status.failed" });
    default:
      return "Error";
  }
}

// Get the UI color for the status flag.
export function getKeyResultColor(
  statusFlag?: KeyResultStatus | null,
  index: number = 0
) {
  if (!statusFlag) return "gray";

  const colors = KeyResultStatusColors[statusFlag];
  const color = colors[index] ?? "gray";
  return color;
}

// Get the indes for KeyResultStatus enum.
export function getKeyResultIndex(statusFlag: string) {
  switch (statusFlag) {
    case KeyResultStatus.UNKNOWN:
      return 0;
    case KeyResultStatus.COMPLETED:
      return 1;
    case KeyResultStatus.ON_TRACK:
      return 2;
    case KeyResultStatus.AT_RISK:
      return 3;
    case KeyResultStatus.BEHIND:
      return 4;
    case KeyResultStatus.FAILED:
      return 5;
    default:
      return 0;
  }
}

// Get the KeyResultStatus enum for a given index.
export function getKeyResultFlagByIndex(index: number) {
  switch (index) {
    case 0:
      return KeyResultStatus.UNKNOWN;
    case 1:
      return KeyResultStatus.COMPLETED;
    case 2:
      return KeyResultStatus.ON_TRACK;
    case 3:
      return KeyResultStatus.AT_RISK;
    case 4:
      return KeyResultStatus.BEHIND;
    case 5:
      return KeyResultStatus.FAILED;
    default:
      return undefined;
  }
}

function calculateProgressPercent(keyResult: KeyResult | null) {
  if (
    !keyResult ||
    keyResult.targetValue == null ||
    keyResult.initialValue == null
  ) {
    // TODO: Make proper error handling or make undefined/null impossible.
    return 0;
  }
  if (keyResult.targetValue === keyResult.initialValue) {
    return 100;
  }

  const currentValue = keyResult.currentValue || keyResult.initialValue;
  const currentDiff =
    Math.max(keyResult.targetValue, currentValue) -
    Math.min(keyResult.targetValue, currentValue);

  const initialDiff =
    Math.max(keyResult.targetValue, keyResult.initialValue) -
    Math.min(keyResult.targetValue, keyResult.initialValue);

  return Math.round(((initialDiff - currentDiff) / initialDiff) * 100);
}

// Get human readable text for the status flag readiness.
export function getProgressString(keyResult: KeyResult | null) {
  if (!keyResult) return "";

  const progress = calculateProgressPercent(keyResult);
  return progress + "%";
}

// Get the current status and progesss.
export function getKeyResultStatusAndProgress(
  intl: IntlShape,
  keyResult: KeyResult | null
) {
  let keyResultStatus = getStatusFlagText(intl, keyResult?.statusFlag!);
  if (keyResult?.targetValue != null) {
    keyResultStatus += ` (${getProgressString(keyResult)} - ${
      keyResult.currentValue || keyResult.initialValue || "-"
    }/${keyResult.targetValue})`;
  }
  return keyResultStatus;
}

// Get a tooltip for a given key result.
export function getKeyResultTooltip(
  intl: IntlShape,
  keyResult: KeyResult | null
) {
  if (!keyResult) return "";
  let tooltip =
    keyResult.description +
    " - " +
    getStatusFlagText(intl, keyResult.statusFlag);
  if (keyResult.targetValue != null) {
    tooltip += ` (${getProgressString(keyResult)} - ${
      keyResult.currentValue || keyResult.initialValue || "-"
    } / ${keyResult.targetValue})`;
  }

  return tooltip;
}

// Return all the key results from every goal.
export function getKeyResults(goals?: Goal[] | null): Array<KeyResult | null> {
  if (!goals) return [];

  return goals.flatMap((goal) => goal.keyResults?.items || []);
}

// Return all the key results from a given goal and all the subgoals of that goal.
export function getAllGoalsKeyResults(
  goalId?: string,
  goals?: Goal[]
): Array<KeyResult | null> {
  if (!goals || !goalId) return [];

  const allGoals = getAllSubgoals(goalId, goals);
  const currentGoal = goals.find((g) => g.id === goalId);
  if (currentGoal) {
    allGoals.push(currentGoal);
  }

  return getKeyResults(allGoals);
}

// Calculates a summary for key results either for the given keyresults -list or given goal.
export function calculateKeyResultsSummary(
  goals?: Goal[],
  goalId?: string,
  keyResults?: Array<KeyResult | null>
) {
  const summary = [0, 0, 0, 0, 0, 0];
  // Goals have to exist.
  if (
    (!goals && !goalId && !keyResults) ||
    (!keyResults && (!goals || !goalId))
  )
    return summary;

  // If key results are given, use the list. Otherwise get the key results from the goal and it subgoals.
  const localKeyResults = keyResults
    ? keyResults
    : getAllGoalsKeyResults(goalId, goals);
  localKeyResults.forEach((kr) => {
    if (kr?.statusFlag) {
      summary[getKeyResultIndex(kr?.statusFlag)]++;
    } else {
      summary[getKeyResultIndex(KeyResultStatus.UNKNOWN)]++;
    }
  });

  return summary;
}

// Calculate an average for the key results progress. Use only key results that have a target value.
export function calculateKeyResultsProgress(keyResults?: (KeyResult | null)[]) {
  let countWithTargetValue = 0;
  let sum = 0;

  if (!keyResults || keyResults.length === 0) {
    return 0;
  }

  keyResults.forEach((kr) => {
    const progress = calculateProgressPercent(kr);
    if (progress >= 0) {
      sum += progress;
      countWithTargetValue++;
    }
  });

  return countWithTargetValue > 0 ? Math.round(sum / countWithTargetValue) : 0;
}

// Adds an key result to a goal
export async function addKeyResultDb(
  newKeyResult: CreateKeyResultInput,
  employeeGoal: boolean,
  allEmployees: EmployeeWithAvatarUrl[] | undefined
) {
  newKeyResult.companyId = await getCompanyId();
  const resultKeyResult = await createApiRequest<CreateKeyResultMutation>(
    createKeyResult,
    newKeyResult,
    "createKeyResult"
  );

  if (resultKeyResult && !employeeGoal) {
    addEvent(
      EventType.KEY_RESULT_ADDED,
      resultKeyResult.goalKeyResultsId,
      allEmployees,
      undefined,
      {
        keyResultEventsId: resultKeyResult.id,
      }
    );
  }
  return resultKeyResult;
}

// Updateds a given key result
export async function updateKeyResultDb(
  updatedKeyResult: UpdateKeyResultInput
) {
  const updateObject: UpdateKeyResultInput = removeUndefinedAndNullFields({
    id: updatedKeyResult.id,
    description: updatedKeyResult.description,
    statusFlag: updatedKeyResult.statusFlag,
    statusText: updatedKeyResult.statusText,
    initialValue: updatedKeyResult.initialValue,
    targetValue: updatedKeyResult.targetValue,
    currentValue: updatedKeyResult.currentValue,
    attachments: updatedKeyResult.attachments,
  });

  return await createApiRequest<UpdateKeyResultMutation>(
    updateKeyResult,
    updateObject,
    "updateKeyResult"
  );
}

export async function deleteKeyResultUpdateDb(
  keyResultUpdateId: string,
  events?: Event[]
) {
  // Delete the event
  await deleteEventsDb(
    getDeleteEvents(
      events,
      DeleteEventType.KEY_RESULT_UPDATE,
      keyResultUpdateId
    )
  );

  return await createApiRequest<DeleteKeyResultUpdateMutation>(
    deleteKeyResultUpdate,
    { id: keyResultUpdateId },
    "deleteKeyResultUpdate"
  );
}

// Delete given key result including updates, comments and replies from the database.
export async function deleteKeyResultDb(
  keyResult: KeyResult,
  events?: Event[]
) {
  if (!keyResult.id) return;

  // Delete all the updates
  const updateIds = keyResult.updates?.items
    ?.map((update) => update && update.id)
    .filter(Boolean);
  await Promise.all(
    updateIds?.map(
      (updateId) => updateId && deleteKeyResultUpdateDb(updateId, events)
    ) || []
  );
  // Delete all the comments
  await deleteCommentsWithReplies(keyResult.comments?.items || []);
  // Delete the event
  await deleteEventsDb(
    getDeleteEvents(events, DeleteEventType.KEY_RESULT, keyResult.id)
  );

  // Delete the key result
  return await createApiRequest<DeleteKeyResultMutation>(
    deleteKeyResult,
    { id: keyResult.id },
    "deleteKeyResult"
  );
}

// Add key result status update
export async function addKeyResultUpdateDb(
  keyResultUpdate: CreateKeyResultUpdateInput,
  employeeGoal: boolean,
  goalId: string,
  allEmployees: EmployeeWithAvatarUrl[] | undefined
) {
  keyResultUpdate.companyId = await getCompanyId();
  const resultKeyResultUpdate =
    await createApiRequest<CreateKeyResultUpdateMutation>(
      createKeyResultUpdateWithGoal,
      keyResultUpdate,
      "createKeyResultUpdate"
    );

  if (resultKeyResultUpdate && !employeeGoal) {
    addEvent(
      EventType.KEY_RESULT_UPDATE_ADDED,
      goalId,
      allEmployees,
      undefined,
      {
        eventKeyResultUpdateId: resultKeyResultUpdate.id,
      }
    );

    return resultKeyResultUpdate;
  }
}

// Updates existing key result status update
export async function updateKeyResultUpdateDb(
  updatedKeyResultUpdate: UpdateKeyResultUpdateInput
) {
  const updateObject = removeUndefinedAndNullFields({
    id: updatedKeyResultUpdate.id,
    owner: updatedKeyResultUpdate.owner,
    companyId: updatedKeyResultUpdate.companyId,
    currentValueBefore: updatedKeyResultUpdate.currentValueBefore,
    currentValueAfter: updatedKeyResultUpdate.currentValueAfter,
    statusFlagBefore: updatedKeyResultUpdate.statusFlagBefore,
    statusFlagAfter: updatedKeyResultUpdate.statusFlagAfter,
    text: updatedKeyResultUpdate.text,
    creatorEmail: updatedKeyResultUpdate.creatorEmail,
    dateOfUpdate: updatedKeyResultUpdate.dateOfUpdate,
    keyResultUpdatesId: updatedKeyResultUpdate.keyResultUpdatesId,
    keyResultUpdateEventId: updatedKeyResultUpdate.keyResultUpdateEventId,
  });

  return await createApiRequest<UpdateKeyResultUpdateMutation>(
    updateKeyResultUpdate,
    updateObject,
    "updateKeyResultUpdate"
  );
}

// Return true if keyresult has data for graph.
export const showKeyResultGraph = (keyResult?: KeyResult) => {
  return (
    keyResult?.initialValue || keyResult?.targetValue || keyResult?.currentValue
  );
};

// Get the readiness % value for the graph.
export const getKeyResultReadiness = (
  currentValue: number,
  targetValue: number
) => {
  if (targetValue === 0) {
    return 0;
  }
  return Math.round((currentValue / targetValue) * 100);
};
