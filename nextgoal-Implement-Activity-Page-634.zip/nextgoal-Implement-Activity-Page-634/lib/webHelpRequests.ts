import { EmployeeWithAvatarUrl } from "@/contexts/EmployeesContext";
import {
  CreateHelpRequestInput,
  CreateHelpRequestMutation,
  DeleteHelpRequestMutation,
  Goal,
  Event,
  HelpRequest,
  UpdateHelpRequestInput,
  UpdateHelpRequestMutation,
} from "@/src/API";
import {
  createApiRequest,
  getCompanyId,
  removeUndefinedAndNullFields,
} from "./webHelpers";
import {
  createHelpRequest,
  deleteHelpRequest,
  updateHelpRequest,
} from "@/src/graphql/mutations";
import {
  EmployeeJoinType,
  addEmployeeJoins,
  addNewEmployeeJoins,
  deleteRemovedEmployeeJoins,
} from "./webEmployee";
import {
  DeleteEventType,
  EventType,
  addEvent,
  deleteEventsDb,
  getDeleteEvents,
} from "./webEvents";
import { AttachmentFile, deleteAttachments } from "./webAttachment";
import { deleteCommentsWithReplies } from "./webComments";
import { getAllSubgoals } from "./webSubgoals";
import { sortCreatedAtDescending } from "./time";

// Adds a new help request to the goal
export async function addHelpRequestDb(
  newHelpRequest: CreateHelpRequestInput,
  taggedEmployees: (EmployeeWithAvatarUrl | null)[],
  allEmployees: EmployeeWithAvatarUrl[] | undefined,
  employeeGoal: boolean
) {
  newHelpRequest.companyId = await getCompanyId();
  const resultHr = await createApiRequest<CreateHelpRequestMutation>(
    createHelpRequest,
    newHelpRequest,
    "createHelpRequest"
  );

  if (resultHr) {
    // Add join table entries for the taggedEmployees
    if (taggedEmployees.length > 0) {
      const joinInfo = {
        goalId: resultHr.goalHelpRequestsId,
        helpRequestEmployeeJoinsId: resultHr.id,
      };
      await addEmployeeJoins(
        taggedEmployees,
        joinInfo,
        EmployeeJoinType.HelpRequest
      );
    }

    if (resultHr && !employeeGoal) {
      // Add event to the event table
      addEvent(
        EventType.HELP_REQUEST_ADDED,
        resultHr.goalHelpRequestsId,
        allEmployees,
        taggedEmployees,
        {
          eventHelpRequestId: resultHr.id,
        }
      );
    }
  }
  return resultHr;
}

// Updates existing helpRequest
export async function updateHelpRequestDb(
  updatedHelpRequest: UpdateHelpRequestInput,
  employeeGoal: boolean,
  allEmployees: EmployeeWithAvatarUrl[] | undefined,
  originalHelpRequest?: HelpRequest,
  taggedEmployees?: EmployeeWithAvatarUrl[] | undefined
) {
  const updateObject: UpdateHelpRequestInput = removeUndefinedAndNullFields({
    id: updatedHelpRequest.id,
    title: updatedHelpRequest.title,
    description: updatedHelpRequest.description,
    resolved: updatedHelpRequest.resolved,
    resolvedTime: updatedHelpRequest.resolvedTime,
    resolvedBy: updatedHelpRequest.resolvedBy,
    resolvedComment: updatedHelpRequest.resolvedComment,
    reopenedTime: updatedHelpRequest.reopenedTime,
    reopenedBy: updatedHelpRequest.reopenedBy,
    reopenedComment: updatedHelpRequest.reopenedComment,
    attachments: updatedHelpRequest.attachments,
    notRelevantForEmployees: updatedHelpRequest.notRelevantForEmployees,
  });

  const resultHr = await createApiRequest<UpdateHelpRequestMutation>(
    updateHelpRequest,
    updateObject,
    "updateHelpRequest"
  );

  // If the employee joins are given, update them.
  if (taggedEmployees && originalHelpRequest) {
    // Delete removed employeeJoins
    await deleteRemovedEmployeeJoins(
      originalHelpRequest.employeeJoins,
      taggedEmployees,
      EmployeeJoinType.HelpRequest
    );

    // Add new employeeJoins.
    const joinInfo = {
      goalId: originalHelpRequest.goalHelpRequestsId,
      helpRequestEmployeeJoinsId: originalHelpRequest.id,
    };
    await addNewEmployeeJoins(
      originalHelpRequest.employeeJoins,
      taggedEmployees,
      joinInfo,
      EmployeeJoinType.HelpRequest
    );
  }

  // Add resolved and reopned events to the event table
  if (resultHr && !employeeGoal) {
    if (
      originalHelpRequest &&
      !originalHelpRequest.resolved &&
      updateObject.resolved
    ) {
      addEvent(
        EventType.HELP_REQUEST_RESOLVED,
        resultHr.goalHelpRequestsId,
        allEmployees,
        taggedEmployees,
        {
          eventHelpRequestId: resultHr.id,
        }
      );
    }
    if (
      originalHelpRequest &&
      originalHelpRequest.resolved &&
      !updateObject.resolved
    ) {
      addEvent(
        EventType.HELP_REQUEST_REOPENED,
        resultHr.goalHelpRequestsId,
        allEmployees,
        taggedEmployees,
        {
          eventHelpRequestId: resultHr.id,
        }
      );
    }
  }
  return resultHr;
}

// Delete given helpRequest including comments and replies from the database.
export async function deleteHelpRequestDb(
  helpRequest: HelpRequest,
  attachments: AttachmentFile[],
  events?: Event[]
) {
  // Delete all the comments
  await deleteCommentsWithReplies(helpRequest.comments?.items || []);
  // Delete all the employeeJoins
  await deleteRemovedEmployeeJoins(
    helpRequest.employeeJoins,
    [],
    EmployeeJoinType.HelpRequest
  );
  // Remove all the attachments
  await deleteAttachments(attachments, []);
  // Delete the event
  await deleteEventsDb(
    getDeleteEvents(events, DeleteEventType.HELP_REQUEST, helpRequest.id)
  );
  // Delete the helpRequest
  return await createApiRequest<DeleteHelpRequestMutation>(
    deleteHelpRequest,
    { id: helpRequest.id },
    "deleteHelpRequest"
  );
}

// Get all the open help resquests from the goals
export function getHelpRequests(
  goals?: Goal[],
  resolved?: boolean
): (HelpRequest | null)[] {
  if (!goals) {
    return [];
  }

  return goals
    ?.reduce((acc, goal) => {
      return acc.concat(
        goal?.helpRequests?.items?.filter((hr) => !!hr?.resolved == resolved) ??
          []
      );
    }, [] as (HelpRequest | null)[])
    .sort(sortCreatedAtDescending);
}

// Get all the help requests of the given goal and all the subgoals.
export function getAllHelpRequests(
  goal?: Goal | null,
  goals?: Goal[]
): (HelpRequest | null)[] {
  if (!goal || !goals) {
    return [];
  }

  const result = [...(goal?.helpRequests?.items || [])];
  const subgoals = getAllSubgoals(goal.id, goals);
  subgoals.forEach((subgoal) => {
    if (
      subgoal.helpRequests &&
      subgoal.helpRequests.items &&
      subgoal.helpRequests.items.length > 0
    ) {
      result.push(...subgoal.helpRequests.items);
    }
  });
  return result;
}

// Get all the help requests of the subgoals of the given goal.
export function getSubgoalsHelpRequests(
  goal?: Goal | null,
  goals?: Goal[],
  resolved?: boolean
): (HelpRequest | null)[] {
  if (!goal || !goals) {
    return [];
  }

  const subgoals = getAllSubgoals(goal.id, goals);
  return subgoals
    .reduce((acc, goal) => {
      return acc.concat(
        goal.helpRequests?.items?.filter((rf) => !!rf?.resolved === resolved) ??
          []
      );
    }, [] as (HelpRequest | null)[])
    .sort(sortCreatedAtDescending);
}
