export enum Pages {
  publicHome = "/",
  publicBlogs = "/blog",
  appDashboard = "/dashboard",
  appGoals = "/goals",
  appActivity = "/activity",
  appOrganizations = "/organizations",
  appNorthstars = "/northstars",
  appSettings = "/settings",
  appProfile = "/profile",
  none = "",
}

export const getSelectedPage = (pathname: string, locale: string): Pages => {
  const pathWithoutLocale = pathname.replace(`/${locale}`, "/");

  let selected = Pages.none;
  if (pathWithoutLocale === Pages.publicHome) {
    selected = Pages.publicHome;
  } else if (pathWithoutLocale.includes(Pages.appDashboard)) {
    selected = Pages.appDashboard;
  } else if (pathWithoutLocale.includes(Pages.appGoals)) {
    selected = Pages.appGoals;
  } else if (pathWithoutLocale.includes(Pages.appActivity)) {
    selected = Pages.appActivity;
  } else if (pathWithoutLocale.includes(Pages.appOrganizations)) {
    selected = Pages.appOrganizations;
  } else if (pathWithoutLocale.includes(Pages.appNorthstars)) {
    selected = Pages.appNorthstars;
  } else if (pathWithoutLocale.includes(Pages.appSettings)) {
    selected = Pages.appSettings;
  } else if (pathWithoutLocale.includes(Pages.appProfile)) {
    selected = Pages.appProfile;
  }
  return selected;
};
