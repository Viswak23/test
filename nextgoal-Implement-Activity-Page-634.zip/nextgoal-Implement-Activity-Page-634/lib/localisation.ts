export enum SupportedLanguages {
  EN = "en",
  FI = "fi",
}

export enum SupportedLocales {
  ENUS = "en-US",
  ENGB = "en-GB",
  FI = "fi-FI",
}

// Add a language to the internal link.
export function getLinkWithLocale(link: string, locale: string) {
  return `/${locale}${link}`;
}

export function getDayJsLocale(locale?: string | null) {
  switch (locale) {
    case SupportedLocales.FI:
      return "fi";
    case SupportedLocales.ENGB:
      return "en-gb";
    case SupportedLocales.ENUS:
    default:
      return "en";
  }
}
