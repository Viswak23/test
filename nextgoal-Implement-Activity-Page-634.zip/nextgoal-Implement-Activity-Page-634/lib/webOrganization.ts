import {
  CreateOrganizationUnitInput,
  CreateOrganizationUnitMutation,
  DeleteOrganizationUnitEmployeeJoinMutation,
  DeleteOrganizationUnitMutation,
  Goal,
  OrganizationUnit,
  OrganizationUnitEmployeeJoin,
  UpdateOrganizationUnitInput,
  UpdateOrganizationUnitMutation,
} from "@/src/API";
import {
  createOrganizationUnit,
  deleteOrganizationUnit,
  deleteOrganizationUnitEmployeeJoin,
  updateOrganizationUnit,
} from "@/src/graphql/mutations";
import {
  createApiRequest,
  getCompanyId,
  removeUndefinedAndNullFields,
} from "./webHelpers";
import { getAllSubgoals } from "./webSubgoals";

export async function addOrganizationUnitDb(
  newOrganizationUnit: CreateOrganizationUnitInput
) {
  newOrganizationUnit.companyId = await getCompanyId();
  return await createApiRequest<CreateOrganizationUnitMutation>(
    createOrganizationUnit,
    newOrganizationUnit,
    "createOrganizationUnit"
  );
}

export async function updateOrganizationUnitDb(
  updatedOrganizationUnit: UpdateOrganizationUnitInput
) {
  // UpdatedStatus contains fields from the original status, so we create a new updateobject.
  const updateObject: UpdateOrganizationUnitInput =
    removeUndefinedAndNullFields({
      id: updatedOrganizationUnit.id,
      name: updatedOrganizationUnit.name,
      description: updatedOrganizationUnit.description,
      position: updatedOrganizationUnit.position,
      notRelevantParentGoals: updatedOrganizationUnit.notRelevantParentGoals,
    });
  return await createApiRequest<UpdateOrganizationUnitMutation>(
    updateOrganizationUnit,
    updateObject,
    "updateOrganizationUnit"
  );
}

// Delete Organization unit and remove all the employee joins.
export async function deleteOrganizationUnitWithChildrenDb(
  organizationUnit?: OrganizationUnit,
  employeeJoins?: OrganizationUnitEmployeeJoin[]
) {
  if (!organizationUnit) return;

  // Delete all the employee joins.
  const organizationEmployeeJoins = employeeJoins?.filter(
    (e) => e.organizationUnitId === organizationUnit.id
  );
  if (organizationEmployeeJoins && organizationEmployeeJoins.length > 0) {
    await Promise.all(
      organizationEmployeeJoins.map(async (join) =>
        createApiRequest<DeleteOrganizationUnitEmployeeJoinMutation>(
          deleteOrganizationUnitEmployeeJoin,
          { id: join.id },
          "deleteOrganizationUnitEmployeeJoin"
        )
      )
    );
  }

  // Delete the organization unit.
  return await createApiRequest<DeleteOrganizationUnitMutation>(
    deleteOrganizationUnit,
    { id: organizationUnit.id },
    "deleteOrganizationUnit"
  );
}

export function getAllSuborganizations(
  organizationUnitId: string,
  organization?: OrganizationUnit[]
): OrganizationUnit[] {
  if (!organization) return [];

  let suborgs: OrganizationUnit[] = organization.filter(
    (o) =>
      o.parentOrganizationUnit &&
      o.parentOrganizationUnit.id === organizationUnitId
  );
  suborgs.forEach(
    (o) =>
      (suborgs = suborgs.concat(getAllSuborganizations(o.id, organization)))
  );
  return suborgs;
}

// Sort organization units by position
export function sortOrganizationUnits(
  organization?: OrganizationUnit[]
): OrganizationUnit[] {
  if (!organization) return [];

  return organization.sort((a, b) => (a.position || 0) - (b.position || 0));
}

// Get organization unit goals and all the subgoals.
export function getOrganizationUnitGoals(
  organizationUnitId?: string,
  goals?: Goal[]
): Goal[] {
  if (!organizationUnitId || !goals) return [];

  const organizationUnitGoals = goals.filter(
    (g) => g.organizationUnitGoalsId === organizationUnitId
  );
  return organizationUnitGoals.concat(
    organizationUnitGoals.map((g) => getAllSubgoals(g.id, goals)).flat()
  );
}
