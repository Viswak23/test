import {
  CheckCompanyInfo,
  CheckUserInfo,
  CreateUserAndGroup,
} from "@/src/graphql/mutations";
import { API } from "aws-amplify";
import { GRAPHQL_AUTH_MODE } from "@aws-amplify/api";
import awsExports from "@/src/aws-exports";
import { CreateEmployeeInput } from "@/src/API";
import { createEmployeeCustom } from "@/src/graphql/custom-mutations";
import {
  aws_cognito_identity_pool_id,
  aws_user_pools_id,
} from "./amplifyConfig";

//returns true if object exists
export async function checkCompanyInfo(company: string) {
  const response: any = await API.graphql({
    query: CheckCompanyInfo,
    variables: {
      userPoolId: aws_user_pools_id,
      company: company,
    },
    authMode: GRAPHQL_AUTH_MODE.API_KEY,
  });
  if (!response.data) {
    throw new Error("Error while checking Company");
  }
  const data = JSON.parse(response.data?.CheckCompanyInfo);
  if (data.statusCode == 200) return true;
  else return false;
}
//returns true if object exists
export async function checkUserInfo(email: string) {
  const response: any = await API.graphql({
    query: CheckUserInfo,
    variables: {
      userPoolId: aws_user_pools_id,
      email: email,
    },
    authMode: GRAPHQL_AUTH_MODE.API_KEY,
  });
  if (!response.data) {
    throw new Error("Error while checking User");
  }
  const data = JSON.parse(response.data?.CheckUserInfo);
  if (data.statusCode == 200) return true;
  else return false;
}

export async function setupInitialEmployee(newEmployee: CreateEmployeeInput) {
  const response: any = await API.graphql({
    query: CreateUserAndGroup,
    variables: {
      userPoolId: aws_user_pools_id,
      identityPoolId: aws_cognito_identity_pool_id,
      s3BucketId: awsExports.aws_user_files_s3_bucket,
      email: newEmployee.email,
      company: newEmployee.companyId,
    },
    authMode: GRAPHQL_AUTH_MODE.API_KEY,
  });
  if (!response.data.CreateUserAndGroup) {
    throw new Error("Error while creating User");
  }
  const data = await JSON.parse(response.data?.CreateUserAndGroup);
  if (data.statusCode !== 200) {
    throw new Error(data.body); //show the error message returned by the lambda function
  }
  newEmployee.owner = newEmployee.email;

  //add new employee
  const result: any = await API.graphql({
    query: createEmployeeCustom,
    variables: {
      input: newEmployee,
    },
    authMode: GRAPHQL_AUTH_MODE.API_KEY,
  });

  if (result.errors || !result.data?.createEmployee) {
    throw new Error("Error creating employee");
  }

  return data.email;
}
