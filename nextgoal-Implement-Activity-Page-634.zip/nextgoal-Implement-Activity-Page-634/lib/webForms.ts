import * as yup from "yup";
import YupPassword from "yup-password";
import { checkCompanyInfo, checkUserInfo } from "./webRegister";
import { IntlShape } from "react-intl";
import { ValidationError } from "yup";
import { log } from "./backend/actions/logger";
YupPassword(yup);

// Yup schema for form validations
export function getLocalizedRegisterSchema(
  intl: IntlShape,
  setLoading: (state: boolean) => void
) {
  return yup.object({
    firstname: yup
      .string()
      .required(
        intl.formatMessage({ id: "register.form.validation.required" })
      ),
    lastname: yup
      .string()
      .required(
        intl.formatMessage({ id: "register.form.validation.required" })
      ),
    email: yup
      .string()
      .email(
        intl.formatMessage({ id: "register.form.validation.email.invalid" })
      )
      .required(intl.formatMessage({ id: "register.form.validation.required" }))
      .test({
        name: "userExists",
        exclusive: false,
        params: {},
        message: intl.formatMessage({
          id: "register.form.validation.user.exists",
        }),
        test: async (value) => {
          try {
            setLoading(true);
            const userExists = await checkUserInfo(value);
            return !userExists;
          } catch (error: any) {
            log("error validating user email: " + error.message);
            return false;
          } finally {
            setLoading(false);
          }
        },
      }), // Automatic email validation
    company: yup
      .string()
      .required(intl.formatMessage({ id: "register.form.validation.required" }))
      .min(
        2,
        intl.formatMessage({ id: "register.form.validation.company.min" })
      )
      .test({
        name: "companyExists",
        exclusive: false,
        params: {},
        message: intl.formatMessage({
          id: "register.form.validation.company.exists",
        }),
        test: async (value) => {
          try {
            setLoading(true);
            const companyExists = await checkCompanyInfo(value);
            return !companyExists;
          } catch (error: any) {
            log("error validating user company: " + error.message);
            return false;
          } finally {
            setLoading(false);
          }
        },
      }),
    terms: yup.boolean().required(),
  });
}

export function getLocalizedContactSchema(intl: IntlShape) {
  return yup
    .object()
    .shape({
      name: yup.string().required(
        intl.formatMessage({
          id: "public.contact.form.validation.name.required",
        })
      ),
      email: yup.string().email(
        intl.formatMessage({
          id: "public.contact.form.validation.email.invalid",
        })
      ),
      phone: yup.string().matches(
        /^\+?[0-9]{1,15}$/,
        intl.formatMessage({
          id: "public.contact.form.validation.invalid.phone",
        })
      ),
      message: yup.string(),
    })
    .test(
      "email-or-phone",
      intl.formatMessage({ id: "public.contact.form.emailorphone.alert" }),
      function (value) {
        const { email, phone } = value;
        if (!email && !phone) {
          const error = new ValidationError(
            intl.formatMessage({
              id: "public.contact.form.emailorphone.alert",
            }),
            value,
            "email-or-phone"
          );
          error.inner = [
            new ValidationError(
              intl.formatMessage({
                id: "public.contact.form.emailorphone.alert",
              }),
              value,
              "email"
            ),
            new ValidationError(
              intl.formatMessage({
                id: "public.contact.form.emailorphone.alert",
              }),
              value,
              "phone"
            ),
          ];
          throw error;
        }
        return true;
      }
    );
}
export function getLocalizedPublicContactSchema(intl: IntlShape) {
  return yup.object({
    name: yup
      .string()
      .required(
        intl.formatMessage({ id: "register.form.validation.required" })
      ),
    company: yup
      .string()
      .required(
        intl.formatMessage({ id: "register.form.validation.required" })
      ),
    email: yup
      .string()
      .email(
        intl.formatMessage({ id: "register.form.validation.email.invalid" })
      )
      .required(
        intl.formatMessage({ id: "register.form.validation.required" })
      ),
    jobTitle: yup.string(),
  });
}

export function getLocalizedAddEmployeeSchema(intl: IntlShape) {
  return yup.object({
    name: yup
      .string()
      .required(intl.formatMessage({ id: "employee.name.required" })),
    email: yup
      .string()
      .email(
        intl.formatMessage({ id: "register.form.validation.email.invalid" })
      )
      .required(intl.formatMessage({ id: "employee.email.required" }))
      .test({
        name: "userExists",
        exclusive: false,
        params: {},
        message: intl.formatMessage({
          id: "employees.error.email.already.in.use",
        }),
        test: async (value) => {
          const userExists = await checkUserInfo(value);
          return !userExists;
        },
      }), // Automatic email validation
    isAdmin: yup.boolean(),
  });
}

export function validateEmail(email: string) {
  // Regular expression pattern for validating an email address
  const emailRegex = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;

  // Test the email against the regex pattern
  return emailRegex.test(email);
}
