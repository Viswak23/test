const MESSAGE_STORAGE = "message";

export const saveMessage = (message: string) => {
  localStorage.setItem(MESSAGE_STORAGE, message);
};

export const getMessage = () => {
  return localStorage.getItem(MESSAGE_STORAGE);
};

export const deleteMessage = () => {
  localStorage.removeItem(MESSAGE_STORAGE);
};
