import {
  CreateTaskInput,
  CreateTaskMutation,
  DeleteTaskMutation,
  Task,
  UpdateTaskInput,
  UpdateTaskMutation,
} from "@/src/API";
import { createTask, deleteTask, updateTask } from "@/src/graphql/mutations";
import {
  createApiRequest,
  getCompanyId,
  removeUndefinedAndNullFields,
} from "./webHelpers";
import { IntlShape } from "react-intl";

export enum TaskStatus {
  NOT_STARTED = "NOT_STARTED",
  IN_PROGRESS = "IN_PROGRESS",
  ON_HOLD = "ON_HOLD",
  COMPLETED = "COMPLETED",
  CANCELLED = "CANCELLED",
}

// Adds a task a goal
export async function addTaskDb(newTask: CreateTaskInput) {
  newTask.companyId = await getCompanyId();

  return await createApiRequest<CreateTaskMutation>(
    createTask,
    newTask,
    "createTask"
  );
}

// Updateds a given task
export async function updateTaskDb(updatedTask: UpdateTaskInput) {
  const updateObject: UpdateTaskInput = removeUndefinedAndNullFields({
    id: updatedTask.id,
    title: updatedTask.title,
    description: updatedTask.description,
    startDate: updatedTask.startDate,
    targetDate: updatedTask.targetDate,
    status: updatedTask.status,
    employeeTasksId: updatedTask.employeeTasksId,
  });

  return await createApiRequest<UpdateTaskMutation>(
    updateTask,
    updateObject,
    "updateTask"
  );
}

// Delete a task with given id
export async function deleteTaskDb(taskId: string) {
  return await createApiRequest<DeleteTaskMutation>(
    deleteTask,
    { id: taskId },
    "deleteTask"
  );
}

// Give a readable status string for a given task status
export function getTaskStatusString(intl: IntlShape, status?: string) {
  switch (status) {
    case TaskStatus.NOT_STARTED:
      return intl.formatMessage({ id: "tasks.status.not.started" });
    case TaskStatus.IN_PROGRESS:
      return intl.formatMessage({ id: "tasks.status.in.progress" });
    case TaskStatus.ON_HOLD:
      return intl.formatMessage({ id: "tasks.status.on.hold" });
    case TaskStatus.COMPLETED:
      return intl.formatMessage({ id: "tasks.status.completed" });
    case TaskStatus.CANCELLED:
      return intl.formatMessage({ id: "tasks.status.cancelled" });
    default:
      return "Unknown";
  }
}

export function getTaskStatusColor(status?: string) {
  switch (status) {
    case TaskStatus.NOT_STARTED:
      return "black";
    case TaskStatus.IN_PROGRESS:
      return "green";
    case TaskStatus.ON_HOLD:
      return "orange";
    case TaskStatus.COMPLETED:
      return "grey";
    case TaskStatus.CANCELLED:
      return "grey";
    default:
      return "red";
  }
}

// Default order of the status list is: in progress, on hold, not started, completed, cancelled
export function compareTasksByStatus(a: Task | null, b: Task | null) {
  if (!a || !b) return 0;

  const statusOrder = [
    TaskStatus.IN_PROGRESS,
    TaskStatus.ON_HOLD,
    TaskStatus.NOT_STARTED,
    TaskStatus.COMPLETED,
    TaskStatus.CANCELLED,
  ];
  return (
    statusOrder.indexOf((a.status as TaskStatus) || "") -
    statusOrder.indexOf((b.status as TaskStatus) || "")
  );
}
