import { getAllSubgoals } from "./webSubgoals";
import {
  Goal,
  Event,
  CreateEventInput,
  CreateEventMutation,
  DeleteEventMutation,
  KeyResultUpdate,
  KeyResult,
  Comment,
  UpdateEventInput,
  UpdateEventMutation,
  RedFlag,
} from "@/src/API";
import { createEvent, deleteEvent, updateEvent } from "@/src/graphql/mutations";
import {
  createApiRequest,
  getCompanyId,
  removeUndefinedAndNullFields,
} from "./webHelpers";
import KeyResultFeedDescription from "@/components/KeyResults/KeyResultFeedDescription";
import GoalFeedDescription from "@/components/Goal/GoalFeedDescription";
import RedFlagFeedDescription from "@/components/RedFlags/RedFlagFeedDescription";
import HelpRequestFeedDescription from "@/components/HelpRequests/HelpRequestFeedDescription";
import IdeaFeedDescription from "@/components/Ideas/IdeaFeedDescription";
import StatusFeedDescription from "@/components/Status/StatusFeedDescription";
import { IntlShape } from "react-intl";
import { EmployeeJoinConnection } from "./webEmployee";
import SuccessStoryFeedDescription from "@/components/SuccessStories/SuccessStoryFeedDescription";
import ContributionFeedDescription from "@/components/Contributions/ContributionFeedDescription";
import { getEvent } from "@/src/graphql/queries";
import { log } from "./backend/actions/logger";
import { createNewNotification, NotificationType } from "./webNotifications";
import { EmployeeWithAvatarUrl } from "@/contexts/EmployeesContext";

export enum EventOwner {
  GOAL = "goal",
  SUCCESS_STORY = "successStory",
  KEY_RESULT = "keyResult",
  KEY_RESULT_UPDATE = "keyResultUpdate",
  RED_FLAG = "redFlag",
  STATUS = "status",
  CONTRIBUTION = "contribution",
  IDEA = "idea",
  HELP_REQUEST = "helpRequest",
}

export enum EventType {
  GOAL_ADDED = "GOAL_ADDED",
  GOAL_OPENED = "GOAL_OPENED",
  GOAL_CLOSED = "GOAL_CLOSED",
  SUCCESS_STORY_ADDED = "SUCCESS_STORY_ADDED",
  KEY_RESULT_ADDED = "KEY_RESULT_ADDED",
  KEY_RESULT_UPDATE_ADDED = "KEY_RESULT_UPDATE_ADDED",
  RED_FLAG_ADDED = "RED_FLAG_ADDED",
  RED_FLAG_RESOLVED = "RED_FLAG_RESOLVED",
  RED_FLAG_REOPENED = "RED_FLAG_REOPENED",
  STATUS_ADDED = "STATUS_ADDED",
  CONTRIBUTION_ADDED = "CONTRIBUTION_ADDED",
  IDEA_ADDED = "IDEA_ADDED",
  HELP_REQUEST_ADDED = "HELP_REQUEST_ADDED",
  HELP_REQUEST_RESOLVED = "HELP_REQUEST_RESOLVED",
  HELP_REQUEST_REOPENED = "HELP_REQUEST_REOPENED",
}

export interface EventInfo {
  title: string;
  discussionTitle: string;
  description?: string | JSX.Element;
  employeeEmail?: string | null;
  attachments?: string[];
  comments?: (Comment | null)[];
  likes?: string[];
  employeeJoins?: EmployeeJoinConnection;
}
//edit an event
export async function updateEventDb(event: UpdateEventInput) {
  return await createApiRequest<UpdateEventMutation>(
    updateEvent,
    removeUndefinedAndNullFields(event),
    "updateEvent"
  );
}
// Adds an event to the database
async function addEventDb(newEvent: CreateEventInput) {
  return createApiRequest<CreateEventMutation>(
    createEvent,
    newEvent,
    "createEvent"
  );
}

// Delete given event from the database.
function deleteEventDb(eventId: String) {
  return createApiRequest<DeleteEventMutation>(
    deleteEvent,
    { id: eventId },
    "deleteEvent"
  );
}

// Delete given events from the database.
export async function deleteEventsDb(events: (Event | null)[]) {
  if (!events || events.length === 0) return;
  const eventIds = events.map((event) => event && event.id).filter(Boolean);
  await Promise.all(
    eventIds?.map((eventId) => eventId && deleteEventDb(eventId)) || []
  );
}

export async function addEvent(
  eventType: EventType,
  goalId: string,
  employees: EmployeeWithAvatarUrl[] | undefined,
  taggedEmployees?: (EmployeeWithAvatarUrl | undefined | null)[],
  details?: any
) {
  const companyId = await getCompanyId();
  const newEvent = await addEventDb({
    eventType,
    goalEventsId: goalId,
    type: "Event",
    companyId,
    ...details,
  });

  if (taggedEmployees && taggedEmployees.length > 0) {
    await createNewNotification(
      NotificationType.MENTION,
      taggedEmployees,
      newEvent?.owner,
      newEvent?.id
    );
  }
  //skip the tagged people(so that they dont get double notifications)
  const untaggedEmployees = employees?.filter(
    (employee) => !taggedEmployees?.includes(employee)
  );
  await createNewNotification(
    eventType,
    untaggedEmployees,
    newEvent?.owner,
    newEvent?.id
  );
}

// Websocket messages updates only goals, not events (e.g. comments, likes, etc).
// Thus we use goal's subelement to get event details and don't fetch event subitems in a query.
// These helper functions get the correct subelement from the goal.

const getEventSuccessStory = (event: Event) =>
  event.goal?.successStories?.items?.find(
    (story) => story?.id === event.eventSuccessStoryId
  );

const getEventKeyResult = (event: Event) =>
  event.goal?.keyResults?.items?.find(
    (keyResult) => keyResult?.id === event.keyResultEventsId
  );

const getEventKeyResultUpdate = (
  event: Event
): [KeyResult | null | undefined, KeyResultUpdate | null | undefined] => {
  let keyResultUpdate: KeyResultUpdate | null | undefined = null;
  let keyResult: KeyResult | null | undefined = null;

  for (let keyresult of event.goal?.keyResults?.items || []) {
    keyResultUpdate = keyresult?.updates?.items?.find(
      (kru) => kru?.id === event.eventKeyResultUpdateId
    );
    if (keyResultUpdate) {
      keyResult = keyresult;
      break;
    }
  }
  return [keyResult, keyResultUpdate];
};

const getEventRedFlag = (event: Event): RedFlag | null | undefined =>
  event.goal?.redFlags?.items?.find(
    (redFlag) => redFlag?.id === event.redFlagEventsId
  );

const getEventStatus = (event: Event) =>
  event.goal?.status?.items?.find(
    (status) => status?.id === event.eventStatusId
  );

const getEventContribution = (event: Event) =>
  event.goal?.contributions?.items?.find(
    (contribution) => contribution?.id === event.eventContributionId
  );

const getEventIdea = (event: Event) =>
  event.goal?.ideas?.items?.find((idea) => idea?.id === event.eventIdeaId);

const getEventHelpRequest = (event: Event) =>
  event.goal?.helpRequests?.items?.find(
    (helpRequest) => helpRequest?.id === event.eventHelpRequestId
  );

// Get all events for the given goal and its subgoals.
export function getAllEventsForGoal(
  goalId: string,
  events?: Event[],
  goals?: Goal[]
): Event[] {
  if (!events || events.length === 0 || !goals) return [];

  let goalIds = new Set();
  goalIds.add(goalId);
  const subgoals = getAllSubgoals(goalId, goals);
  subgoals.forEach((g) => goalIds.add(g.id));

  return events.filter((e) => goalIds.has(e.goalEventsId));
}

export async function getEventById(eventId: string) {
  try {
    const event = await createApiRequest(
      getEvent,
      {
        id: eventId,
      },
      "event"
    );

    return event;
  } catch (error: any) {
    log("Error getting event: " + error.message);
    return null;
  }
}

// Get all the events for organization goals and hydrate them with the goal.
export function getOrganizationEvents(
  organizationGoals: (Goal | null)[],
  goals?: Goal[],
  events?: Event[]
) {
  if (
    !organizationGoals ||
    organizationGoals.length === 0 ||
    !goals ||
    !events
  ) {
    return [];
  }

  const goalIds = new Set(organizationGoals.map((goal) => goal?.id)) as Set<
    string | null | undefined
  >;
  return events.filter((e) => goalIds.has(e.goalEventsId));
}

// Create eventinfo object from the event.
export function getEventInfo(intl: IntlShape, event: Event): EventInfo {
  switch (event.eventType) {
    case EventType.GOAL_ADDED:
      return {
        title: intl.formatMessage({ id: "feeds.new.goal.caption" }),
        discussionTitle: intl.formatMessage({
          id: "feeds.goal.discussion.caption",
        }),
        description: <GoalFeedDescription goal={event.goal} />,
        employeeEmail: event.goal?.creatorEmail,
        attachments: event.goal?.attachments || [],
        comments: event.goal?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: undefined,
      };
    case EventType.GOAL_CLOSED:
      return {
        title: intl.formatMessage({ id: "feeds.close.goal.caption" }),
        discussionTitle: intl.formatMessage({
          id: "feeds.goal.discussion.caption",
        }),
        description: <GoalFeedDescription goal={event.goal} />,
        employeeEmail: event.goal?.creatorEmail,
        attachments: event.goal?.attachments || [],
        comments: event.goal?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: undefined,
      };
    case EventType.GOAL_OPENED:
      return {
        title: intl.formatMessage({ id: "feeds.open.goal.caption" }),
        discussionTitle: intl.formatMessage({
          id: "feeds.goal.discussion.caption",
        }),
        description: <GoalFeedDescription goal={event.goal} />,
        employeeEmail: event.goal?.creatorEmail,
        attachments: event.goal?.attachments || [],
        comments: event.goal?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: undefined,
      };
    case EventType.SUCCESS_STORY_ADDED:
      const successStory = getEventSuccessStory(event);
      return {
        title: intl.formatMessage({ id: "feeds.new.success.story.caption" }),
        discussionTitle: intl.formatMessage({
          id: "feeds.success.story.discussion.caption",
        }),
        description: <SuccessStoryFeedDescription story={successStory} />,
        employeeEmail: successStory?.creatorEmail,
        attachments: successStory?.attachments || [],
        comments: successStory?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: successStory?.employeeJoins,
      };
    case EventType.KEY_RESULT_ADDED:
      const keyResult = getEventKeyResult(event);
      return {
        title: intl.formatMessage({ id: "feeds.new.key.result.caption" }),
        discussionTitle: intl.formatMessage({
          id: "feeds.key.result.discussion.caption",
        }),
        description: (
          <KeyResultFeedDescription
            keyResult={keyResult}
            keyResultUpdate={null}
          />
        ),
        employeeEmail: keyResult?.creatorEmail,
        attachments: keyResult?.attachments || [],
        comments: keyResult?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: undefined,
      };
    case EventType.KEY_RESULT_UPDATE_ADDED:
      const [keyResultForUpdate, keyResultUpdate] =
        getEventKeyResultUpdate(event);
      return {
        title: intl.formatMessage({
          id: "feeds.new.key.result.update.caption",
        }),
        discussionTitle: intl.formatMessage({
          id: "feeds.key.result.update.discussion.caption",
        }),
        description: (
          <KeyResultFeedDescription
            keyResult={keyResultForUpdate}
            keyResultUpdate={keyResultUpdate}
          />
        ),
        employeeEmail: keyResultUpdate?.creatorEmail,
        attachments: keyResultForUpdate?.attachments || [],
        comments: keyResultUpdate?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: undefined,
      };
    case EventType.RED_FLAG_ADDED:
      const redFlagAdded = getEventRedFlag(event);
      return {
        title: intl.formatMessage({ id: "feeds.new.red.flag.caption" }),
        discussionTitle: intl.formatMessage({
          id: "feeds.red.flag.discussion.caption",
        }),
        description: (
          <RedFlagFeedDescription
            redFlag={redFlagAdded}
            resolvedEvent={false}
            reopenedEvent={false}
          />
        ),
        employeeEmail: redFlagAdded?.creatorEmail,
        attachments: redFlagAdded?.attachments || [],
        comments: redFlagAdded?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: undefined,
      };
    case EventType.RED_FLAG_RESOLVED:
      const redFlagResolved = getEventRedFlag(event);
      return {
        title: intl.formatMessage({ id: "feeds.red.flag.resolved.caption" }),
        discussionTitle: intl.formatMessage({
          id: "feeds.red.flag.discussion.caption",
        }),
        description: (
          <RedFlagFeedDescription
            redFlag={redFlagResolved}
            resolvedEvent={true}
            reopenedEvent={false}
          />
        ),
        employeeEmail: redFlagResolved?.resolvedBy,
        attachments: redFlagResolved?.attachments || [],
        comments: redFlagResolved?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: undefined,
      };
    case EventType.RED_FLAG_REOPENED:
      const redFlagReopened = getEventRedFlag(event);
      return {
        title: intl.formatMessage({ id: "feeds.red.flag.reopened.caption" }),
        discussionTitle: intl.formatMessage({
          id: "feeds.red.flag.discussion.caption",
        }),
        description: (
          <RedFlagFeedDescription
            redFlag={redFlagReopened}
            resolvedEvent={false}
            reopenedEvent={true}
          />
        ),
        employeeEmail: redFlagReopened?.reopenedBy,
        attachments: redFlagReopened?.attachments || [],
        comments: redFlagReopened?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: undefined,
      };
    case EventType.STATUS_ADDED:
      const status = getEventStatus(event);
      return {
        title: intl.formatMessage({ id: "feeds.new.status.caption" }),
        discussionTitle: intl.formatMessage({
          id: "feeds.status.discussion.caption",
        }),
        description: <StatusFeedDescription status={status} />,
        employeeEmail: status?.creatorEmail,
        attachments: status?.attachments || [],
        comments: status?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: undefined,
      };
    case EventType.CONTRIBUTION_ADDED:
      const contribution = getEventContribution(event);
      return {
        title: intl.formatMessage({ id: "feeds.new.contribution.caption" }),
        discussionTitle: intl.formatMessage({
          id: "feeds.contribution.discussion.caption",
        }),
        description: (
          <ContributionFeedDescription contribution={contribution} />
        ),
        employeeEmail: contribution?.creatorEmail,
        attachments: contribution?.attachments || [],
        comments: contribution?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: contribution?.employeeJoins,
      };
    case EventType.IDEA_ADDED:
      const idea = getEventIdea(event);
      return {
        title: intl.formatMessage({ id: "feeds.new.idea.caption" }),
        discussionTitle: intl.formatMessage({
          id: "feeds.idea.discussion.caption",
        }),
        description: <IdeaFeedDescription idea={idea} />,
        employeeEmail: idea?.creatorEmail,
        attachments: idea?.attachments || [],
        comments: idea?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: idea?.employeeJoins,
      };
    case EventType.HELP_REQUEST_ADDED:
      const helpRequest = getEventHelpRequest(event);
      return {
        title: intl.formatMessage({ id: "feeds.new.help.request.caption" }),
        discussionTitle: intl.formatMessage({
          id: "feeds.help.request.discussion.caption",
        }),
        description: (
          <HelpRequestFeedDescription
            helpRequest={helpRequest}
            resolvedEvent={false}
            reopenedEvent={false}
          />
        ),
        employeeEmail: helpRequest?.creatorEmail,
        attachments: helpRequest?.attachments || [],
        comments: helpRequest?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: helpRequest?.employeeJoins,
      };
    case EventType.HELP_REQUEST_RESOLVED:
      const helpRequestResolved = getEventHelpRequest(event);
      return {
        title: intl.formatMessage({
          id: "feeds.help.request.resolved.caption",
        }),
        discussionTitle: intl.formatMessage({
          id: "feeds.help.request.discussion.caption",
        }),
        description: (
          <HelpRequestFeedDescription
            helpRequest={helpRequestResolved}
            resolvedEvent={true}
            reopenedEvent={false}
          />
        ),
        employeeEmail: helpRequestResolved?.resolvedBy,
        attachments: helpRequestResolved?.attachments || [],
        comments: helpRequestResolved?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: helpRequestResolved?.employeeJoins,
      };
    case EventType.HELP_REQUEST_REOPENED:
      const helpRequestReopened = getEventHelpRequest(event);
      return {
        title: intl.formatMessage({
          id: "feeds.help.request.reopened.caption",
        }),
        discussionTitle: intl.formatMessage({
          id: "feeds.help.request.discussion.caption",
        }),
        description: (
          <HelpRequestFeedDescription
            helpRequest={helpRequestReopened}
            resolvedEvent={false}
            reopenedEvent={true}
          />
        ),
        employeeEmail: helpRequestReopened?.reopenedBy,
        attachments: helpRequestReopened?.attachments || [],
        comments: helpRequestReopened?.comments?.items || [],
        likes: event.likes || [],
        employeeJoins: helpRequestReopened?.employeeJoins,
      };
    default:
      return {
        title: intl.formatMessage({ id: "feeds.unknown.event" }),
        discussionTitle: "",
        description: "",
      };
  }
}

// Gets the id field for the employee join from given event.
export function getEventEmployeeJoinIdField(event: Event) {
  switch (event.eventType) {
    case EventType.GOAL_ADDED:
    case EventType.GOAL_CLOSED:
    case EventType.GOAL_OPENED:
      return undefined;
    case EventType.SUCCESS_STORY_ADDED:
      return "employeeSuccessStoryEmployeeJoinsId";
    case EventType.KEY_RESULT_ADDED:
    case EventType.KEY_RESULT_UPDATE_ADDED:
      return undefined;
    case EventType.RED_FLAG_ADDED:
    case EventType.RED_FLAG_RESOLVED:
    case EventType.RED_FLAG_REOPENED:
      return undefined;
    case EventType.STATUS_ADDED:
      return undefined;
    case EventType.CONTRIBUTION_ADDED:
      return "employeeContributionEmployeeJoinsId";
    case EventType.IDEA_ADDED:
      return "employeeIdeaEmployeeJoinsId";
    case EventType.HELP_REQUEST_ADDED:
    case EventType.HELP_REQUEST_RESOLVED:
    case EventType.HELP_REQUEST_REOPENED:
      return "employeeHelpRequestEmployeeJoinsId";
    default:
      return undefined;
  }
}

// Get the title for the employee join from given event.
export function getEventEmployeesTitle(intl: IntlShape, eventType: string) {
  switch (eventType) {
    case EventType.GOAL_ADDED:
    case EventType.GOAL_CLOSED:
    case EventType.GOAL_OPENED:
      return undefined;
    case EventType.SUCCESS_STORY_ADDED:
      return intl.formatMessage({ id: "successstories.employees.caption" });
    case EventType.KEY_RESULT_ADDED:
    case EventType.KEY_RESULT_UPDATE_ADDED:
      return undefined;
    case EventType.RED_FLAG_ADDED:
    case EventType.RED_FLAG_RESOLVED:
    case EventType.RED_FLAG_REOPENED:
      return undefined;
    case EventType.STATUS_ADDED:
      return undefined;
    case EventType.CONTRIBUTION_ADDED:
      return intl.formatMessage({ id: "contributions.employees.caption" });
    case EventType.IDEA_ADDED:
      return intl.formatMessage({ id: "ideas.employees.caption" });
    case EventType.HELP_REQUEST_ADDED:
    case EventType.HELP_REQUEST_RESOLVED:
    case EventType.HELP_REQUEST_REOPENED:
      return intl.formatMessage({ id: "helprequests.employees.caption" });
    default:
      return undefined;
  }
}

// Add a parent goal for each event.
export function hydrateEvents(events: Event[], goals?: Goal[]) {
  if (!goals) return events;

  return events.map((event) => {
    const goal = goals.find((goal) => goal.id === event.goalEventsId)!;
    return { ...event, goal };
  });
}
export function hydrateEvent(event: Event, goals?: Goal[]) {
  if (!goals) return event;

  const goal = goals.find((goal) => goal.id === event.goalEventsId)!;
  return { ...event, goal };
}

// Get the owner and owner id for the given event.
export function getEventOwner(
  currentGoalId?: string,
  successStoryId?: string,
  keyResultId?: string,
  redFlagId?: string,
  statusId?: string,
  contributionId?: string,
  ideaId?: string,
  helpRequestId?: string,
  keyResultUpdateId?: string
): {
  owner: EventOwner;
  ownerId: string;
} {
  if (successStoryId) {
    return { owner: EventOwner.SUCCESS_STORY, ownerId: successStoryId };
  } else if (keyResultId) {
    return { owner: EventOwner.KEY_RESULT, ownerId: keyResultId };
  } else if (redFlagId) {
    return { owner: EventOwner.RED_FLAG, ownerId: redFlagId };
  } else if (statusId) {
    return { owner: EventOwner.STATUS, ownerId: statusId };
  } else if (contributionId) {
    return { owner: EventOwner.CONTRIBUTION, ownerId: contributionId };
  } else if (ideaId) {
    return { owner: EventOwner.IDEA, ownerId: ideaId };
  } else if (helpRequestId) {
    return { owner: EventOwner.HELP_REQUEST, ownerId: helpRequestId };
  } else if (keyResultUpdateId) {
    return { owner: EventOwner.KEY_RESULT_UPDATE, ownerId: keyResultUpdateId };
  }

  return { owner: EventOwner.GOAL, ownerId: currentGoalId || "" };
}

export enum DeleteEventType {
  GOAL = "goalEventsId",
  SUCCESS_STORY = "eventSuccessStoryId",
  KEY_RESULT = "keyResultEventsId",
  KEY_RESULT_UPDATE = "eventKeyResultUpdateId",
  RED_FLAG = "redFlagEventsId",
  STATUS = "eventStatusId",
  CONTRIBUTION = "eventContributionId",
  IDEA = "eventIdeaId",
  HELP_REQUEST = "eventHelpRequestId",
}

export function getDeleteEvents(
  events: Event[] | undefined,
  eventRefProperty: DeleteEventType,
  value: any
) {
  if (!events || events.length === 0) return [];
  return events.filter(
    (event) => event[eventRefProperty] && event[eventRefProperty] === value
  );
}
