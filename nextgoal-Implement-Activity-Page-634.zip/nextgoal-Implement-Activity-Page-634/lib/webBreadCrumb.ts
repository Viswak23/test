import { Goal } from "@/src/API";
import { OrganizationUnit } from "@/src/API";

export interface BcLinkElement {
  title: string;
  link: string;
  closed?: boolean;
}

export interface BcIdElement {
  title: string;
  organizationUnit?: {
    id?: string;
  };
}

export function buildOrganizationPath(
  organization: OrganizationUnit[],
  currentOrganizationUnitId: string,
  parentOrganizationUnitId?: string
) {
  if (
    parentOrganizationUnitId &&
    parentOrganizationUnitId === currentOrganizationUnitId
  ) {
    return [];
  }

  // Find current organization unit
  const organizationRoute = [
    organization.find((org) => org.id === currentOrganizationUnitId),
  ];
  // Get all the ancestors of the current organization unit
  let tempOrg = organizationRoute[0];
  while (
    tempOrg?.organizationUnitChildOrzganizationUnitsId &&
    (!parentOrganizationUnitId ||
      tempOrg?.organizationUnitChildOrzganizationUnitsId !==
        parentOrganizationUnitId)
  ) {
    organizationRoute.unshift(
      organization.find(
        (org) => org.id === tempOrg?.organizationUnitChildOrzganizationUnitsId
      )
    );
    tempOrg = organizationRoute[0];
  }

  return organizationRoute;
}

export function getOrganizationLinkPath(
  organization: OrganizationUnit[],
  currentOrganizationUnitId?: string
): BcLinkElement[] {
  if (!currentOrganizationUnitId) return [];

  const organizationRoute = buildOrganizationPath(
    organization,
    currentOrganizationUnitId
  );

  return organizationRoute.map((org) => ({
    title: org?.name || "",
    link: `/organization/${org?.id}`,
  }));
}

export function getOrganizationIdPath(
  organization: OrganizationUnit[],
  topLevelCaption: string,
  currentOrganizationId: string,
  parentOrganizationId?: string
): BcIdElement[] {
  const organizationRoute = buildOrganizationPath(
    organization,
    currentOrganizationId,
    parentOrganizationId
  );

  const path = organizationRoute.map((org) => ({
    title: org?.name || "",
    organizationUnit: {
      id: org?.id,
    },
  }));

  if (organizationRoute.length > 0) {
    path.unshift({
      title: topLevelCaption,
      organizationUnit: {
        id: parentOrganizationId,
      },
    });
  }

  return path;
}

export function getGoalLinkPath(
  goals: Goal[],
  archivedGoals: Goal[],
  currentGoalId?: string
): BcLinkElement[] {
  if (!currentGoalId) return [];

  let currentGoal = goals.find((goal) => goal.id === currentGoalId);
  if (!currentGoal) {
    currentGoal = archivedGoals.find((goal) => goal.id === currentGoalId);
  }
  const goalRoute = [currentGoal];

  let tempGoal = goalRoute[0];
  while (tempGoal?.goalChildGoalsId) {
    let nextGoal = goals.find((goal) => goal.id === tempGoal?.goalChildGoalsId);
    if (!nextGoal) {
      nextGoal = archivedGoals.find(
        (goal) => goal.id === tempGoal?.goalChildGoalsId
      );
    }

    goalRoute.unshift(nextGoal);
    tempGoal = goalRoute[0];
  }

  return goalRoute.map((goal) => ({
    title: goal?.title || "",
    closed: goal?.isClosed || false,
    link: `/goals/${goal?.id}`,
  }));
}
