"use server";

import OpenAI from "openai";
export interface Message {
  role: "user" | "assistant" | "system";
  content: string;
}

const openAI = new OpenAI({
  apiKey: process.env.NEXT_PUBLIC_OPENAI_API_KEY,
});

export async function getMessage(backgroundInfo: string, messages: Message[]) {
  const response = await openAI.chat.completions.create({
    model: process.env.NEXT_PUBLIC_OPENAI_API_MODEL!,
    messages: [
      {
        role: "system",
        content: backgroundInfo,
      },
      ...messages.map((message) => ({
        role: message.role,
        content: message.content.trim(),
      })),
    ],
  });

  return response.choices[0].message.content;
}