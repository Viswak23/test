import { useMemo } from "react";
import {
  CreateEmployeeInput,
  CreateEmployeeMutation,
  UpdateEmployeeInput,
  UpdateEmployeeMutation,
  CreateOrganizationUnitEmployeeJoinMutation,
  Employee,
  ModelIdeaEmployeeJoinConnection,
  DeleteIdeaEmployeeJoinMutation,
  CreateIdeaEmployeeJoinMutation,
  ModelSuccessStoryEmployeeJoinConnection,
  IdeaEmployeeJoin,
  SuccessStoryEmployeeJoin,
  CreateSuccessStoryEmployeeJoinMutation,
  ContributionEmployeeJoin,
  ModelContributionEmployeeJoinConnection,
  DeleteSuccessStoryEmployeeJoinMutation,
  DeleteContributionEmployeeJoinMutation,
  CreateContributionEmployeeJoinMutation,
  ModelHelpRequestEmployeeJoinConnection,
  HelpRequestEmployeeJoin,
  CreateHelpRequestEmployeeJoinMutation,
  DeleteHelpRequestEmployeeJoinMutation,
  Goal,
  RedFlag,
  HelpRequest,
  Idea,
  SuccessStory,
  Contribution,
  DeleteEmployeeMutation,
  OrganizationUnitEmployeeJoin,
  DeleteOrganizationUnitEmployeeJoinMutation,
  AddUserToCognitoMutation,
  RemoveUserFromCognitoMutation,
  EnableUserLoginMutation,
  DisableUserLoginMutation,
  Event,
  ListEmployeesQuery,
} from "@/src/API";
import { API, graphqlOperation, Storage } from "aws-amplify";
import { GraphQLQuery } from "@aws-amplify/api";
import {
  addUserToCognito,
  createContributionEmployeeJoin,
  createEmployee,
  createHelpRequestEmployeeJoin,
  createIdeaEmployeeJoin,
  createOrganizationUnitEmployeeJoin,
  createSuccessStoryEmployeeJoin,
  deleteContributionEmployeeJoin,
  deleteEmployee,
  deleteHelpRequestEmployeeJoin,
  deleteIdeaEmployeeJoin,
  deleteOrganizationUnitEmployeeJoin,
  deleteSuccessStoryEmployeeJoin,
  DisableUserLogin,
  EnableUserLogin,
  removeUserFromCognito,
  ToggleAdminRole,
  updateEmployee,
} from "@/src/graphql/mutations";
import {
  createApiRequest,
  getCompanyId,
  removeUndefinedAndNullFields,
} from "./webHelpers";
import { EmployeeWithAvatarUrl } from "@/contexts/EmployeesContext";
import { AttachmentOwner, saveAttachment } from "./webAttachment";
import { getHelpRequests } from "./webHelpRequests";
import { deleteGoalWithChildrenDb } from "./webGoals";
import { IntlShape } from "react-intl";
import { SupportedLanguages } from "./localisation";
import { aws_user_pools_id } from "./amplifyConfig";
import { log } from "./backend/actions/logger";

export function getLanguageString(language: SupportedLanguages): string {
  switch (language) {
    case SupportedLanguages.EN: {
      return "en";
    }
    case SupportedLanguages.FI: {
      return "fi";
    }
    default: {
      // This should not be a possible outcome...
      console.error("Unknown language: " + language);
      return "";
    }
  }
}

export function getLanguageEnum(language: string): SupportedLanguages | null {
  switch (language) {
    case "en": {
      return SupportedLanguages.EN;
    }
    case "fi": {
      return SupportedLanguages.FI;
    }
    default: {
      return null;
    }
  }
}

export type EmployeeJoinConnection =
  | ModelIdeaEmployeeJoinConnection
  | ModelSuccessStoryEmployeeJoinConnection
  | ModelContributionEmployeeJoinConnection
  | ModelHelpRequestEmployeeJoinConnection
  | null;
export type EmployeeJoin =
  | IdeaEmployeeJoin
  | SuccessStoryEmployeeJoin
  | ContributionEmployeeJoin
  | HelpRequestEmployeeJoin
  | null;

// Get the employees from the join. Use memo to avoid unnecessary re-renders.
export function useTaggedEmployeesFromJoin(
  employees: EmployeeWithAvatarUrl[] | undefined,
  employeeJoins: EmployeeJoinConnection | undefined,
  employeeIdField: string
) {
  return useMemo(() => {
    if (!employeeJoins?.items || !employees || !employeeIdField) {
      return null;
    }
    const owners = employeeJoins?.items.map((join: any) => {
      const id = join[employeeIdField] as any;
      const employee = getEmployeeById(employees, id);
      if (employee) {
        return employee;
      }
      return null;
    });
    owners.filter((owner: any) => owner != null);
    return (owners as EmployeeWithAvatarUrl[]) || [];
  }, [employeeJoins?.items, employees, employeeIdField]);
}

// Add employee to database.
export async function addEmployeeDb(newEmployee: CreateEmployeeInput) {
  newEmployee.companyId = await getCompanyId();

  // Generate random temporary password
  const tempPassword = Math.random().toString(36).slice(-8);
  // Add user to cognito.
  let cognito_result = await API.graphql<
    GraphQLQuery<AddUserToCognitoMutation>
  >(
    graphqlOperation(addUserToCognito, {
      userPoolId: aws_user_pools_id,
      email: newEmployee.email,
      password: tempPassword,
    })
  );

  let data = JSON.parse(cognito_result.data!.addUserToCognito!);
  if (data.statusCode != 200) {
    throw new Error(data.body);
  }
  newEmployee.owner = newEmployee.email;

  const resultEmployee = await createApiRequest<CreateEmployeeMutation>(
    createEmployee,
    newEmployee,
    "createEmployee"
  );

  return resultEmployee;
}

export async function updateEmployeeDb(updatedEmployee: UpdateEmployeeInput) {
  const updateObject = removeUndefinedAndNullFields({
    id: updatedEmployee.id,
    name: updatedEmployee.name,
    email: updatedEmployee.email,
    avatarUrl: updatedEmployee.avatarUrl,
    notRelevantParentGoals: "updatedEmployee.notRelevantParentGoals",
    disabled: updatedEmployee.disabled,
    language: updatedEmployee.language,
    locale: updatedEmployee.locale,
    owner: updatedEmployee.owner,
    isAdmin: updatedEmployee.isAdmin,
    career: updatedEmployee.career,
    interest: updatedEmployee.interest,
  });
  return await createApiRequest<UpdateEmployeeMutation>(
    updateEmployee,
    updateObject,
    "updateEmployee"
  );
}

export async function toggleAdminRole(
  employee: Employee,
  isAddingUser: boolean
) {
  try {
    await API.graphql({
      query: ToggleAdminRole,
      variables: {
        userPoolId: aws_user_pools_id,
        email: employee.email,
        isAdmin: isAddingUser ? employee.isAdmin : !employee.isAdmin,
      },
    });

    if (!isAddingUser) {
      await updateEmployeeDb({ ...employee, isAdmin: !employee.isAdmin });
    }
  } catch (error: any) {
    log(`Toggle Admin Role: ${error.message}`);
  }
  return;
}

export async function toggleEmployeeDb(employee: Employee) {
  if (employee.disabled) {
    await API.graphql<GraphQLQuery<EnableUserLoginMutation>>(
      graphqlOperation(EnableUserLogin, {
        email: employee.email,
        userPoolId: aws_user_pools_id,
      })
    );
  } else {
    await API.graphql<GraphQLQuery<DisableUserLoginMutation>>(
      graphqlOperation(DisableUserLogin, {
        email: employee.email,
        userPoolId: aws_user_pools_id,
      })
    );
  }

  const updatedEmployee = {
    id: employee.id,
    disabled: !employee.disabled,
  };
  return await updateEmployeeDb(updatedEmployee);
}

// Delete given employee, personal goals, possible avatarurl and all the joins (organization, help requests, ideas, ...).
export async function deleteEmployeeDb(
  intl: IntlShape,
  employee: Employee | null | undefined,
  goals?: Goal[],
  events?: Event[],
  organizationJoins?: OrganizationUnitEmployeeJoin[]
) {
  if (!employee) {
    return;
  }

  try {
    // Remove user from cognito.
    await API.graphql<GraphQLQuery<RemoveUserFromCognitoMutation>>(
      graphqlOperation(removeUserFromCognito, {
        userPoolId: aws_user_pools_id,
        email: employee.email,
      })
    );
  } catch (error: any) {
    log(`Delete EmployeeDb: ${error.message}`);
    throw new Error("Error removing user from cognito");
  }

  // Delete personal goals.
  if (goals) {
    const personalGoals = goals.filter(
      (goal) =>
        goal.employeeGoalsId === employee?.id && goal.goalChildGoalsId == null
    );
    await Promise.all(
      personalGoals.map(async (goal) =>
        deleteGoalWithChildrenDb(intl, goal, events)
      )
    );
  }

  // Delete organization unit joins.
  if (organizationJoins) {
    const joins = organizationJoins.filter(
      (join) => join.employeeId === employee.id
    );
    await Promise.all(
      joins.map(async (join) => removeEmployeeFromOrganizationUnit(join))
    );
  }

  // Delete all the other employee joins.
  if (goals) {
    await deleteAllEmployeeJoins(employee, goals);
  }

  // Delete avatarUrl from S3.
  if (employee.avatarUrl) {
    try {
      await Storage.remove(employee.avatarUrl);
    } catch (error: any) {
      log(`DeleteEmployeeDb: ${error.message}`);
      throw new Error("Error deleting attachment");
    }
  }

  return await createApiRequest<DeleteEmployeeMutation>(
    deleteEmployee,
    { id: employee.id },
    "deleteEmployee"
  );
}

// Add employee to organization unit.
export async function addEmployeeToOrganizationUnit(
  employeeId: string,
  organizationUnitId: string
) {
  const companyId = await getCompanyId();
  const joinObject = {
    organizationUnitId,
    employeeId,
    companyId,
  };
  const result = await API.graphql<
    GraphQLQuery<CreateOrganizationUnitEmployeeJoinMutation>
  >(
    graphqlOperation(createOrganizationUnitEmployeeJoin, { input: joinObject })
  );

  if (result.errors || !result.data) {
    throw new Error("Error adding employee to organization unit");
  } else {
    return result.data.createOrganizationUnitEmployeeJoin;
  }
}

// Remove employee from organization unit.
export async function removeEmployeeFromOrganizationUnit(
  existingJoin: OrganizationUnitEmployeeJoin
) {
  const result = await API.graphql<
    GraphQLQuery<DeleteOrganizationUnitEmployeeJoinMutation>
  >(
    graphqlOperation(deleteOrganizationUnitEmployeeJoin, {
      input: { id: existingJoin.id },
    })
  );
  return result;
}

// Save avatar image to S3 and return url.
export async function saveAvatarImage(file: File, employeeId: string) {
  try {
    const extension = file.name.split(".")[1];
    const filename = `${employeeId}-profile.${extension}`;
    return await saveAttachment(file, AttachmentOwner.Avatar, filename);
  } catch (error: any) {
    log(`Save Avatar Image: ${error.message}`);
    throw new Error("Error saving avatar image");
  }
}

// Get avatar image url from S3.
export async function getEmployeeAvatarUrl(avatarUrl?: string | null) {
  if (avatarUrl) {
    return Storage.get(avatarUrl, { download: false });
  }
  return undefined;
}

// Get avatar url by email.
export function getAvatarUrlByEmail(
  employees?: EmployeeWithAvatarUrl[],
  email?: string
) {
  if (!employees || !email) return undefined;

  const creator = employees.find((employee) => employee.email === email);
  if (creator) {
    return creator.resolvedAvatarUrl;
  }
  return undefined;
}

// Get employee by email.
export function getEmployeeByEmail(
  employees?: EmployeeWithAvatarUrl[],
  email?: string | null
) {
  if (!employees || !email) return undefined;

  const employee = employees.find((employee) => employee.email === email);
  if (employee) {
    return employee;
  }
  return undefined;
}

// Get employee by id.
export function getEmployeeById(
  employees?: EmployeeWithAvatarUrl[],
  id?: string | null
) {
  if (!employees || !id) return undefined;

  const employee = employees.find((employee) => employee.id === id);
  if (employee) {
    return employee;
  }
  return undefined;
}

export enum EmployeeJoinType {
  Idea = "Idea",
  SuccessStory = "SuccessStory",
  Contribution = "Contribution",
  HelpRequest = "HelpRequest",
}

function getEmployeeIdFromJoin(join: EmployeeJoin, type: EmployeeJoinType) {
  if (type === EmployeeJoinType.Idea) {
    return (join as IdeaEmployeeJoin)?.employeeIdeaEmployeeJoinsId || "";
  } else if (type === EmployeeJoinType.SuccessStory) {
    return (
      (join as SuccessStoryEmployeeJoin)?.employeeSuccessStoryEmployeeJoinsId ||
      ""
    );
  } else if (type === EmployeeJoinType.Contribution) {
    return (
      (join as ContributionEmployeeJoin)?.employeeContributionEmployeeJoinsId ||
      ""
    );
  } else if (type === EmployeeJoinType.HelpRequest) {
    return (
      (join as HelpRequestEmployeeJoin)?.employeeHelpRequestEmployeeJoinsId ||
      ""
    );
  }

  return "";
}

// Remove employeeJoins that are not anymore in the list of employees.
export async function deleteRemovedEmployeeJoins<T>(
  employeeJoins: EmployeeJoinConnection | undefined,
  employees: (EmployeeWithAvatarUrl | null)[],
  type: EmployeeJoinType
) {
  // Delete removed employeeJoins
  const removed = ((employeeJoins?.items || []) as any[]).filter(
    (item) =>
      !employees?.find(
        (employee) => employee?.id === getEmployeeIdFromJoin(item, type)
      )
  );

  if (removed && removed.length > 0) {
    const resultSet = await Promise.all(
      removed.map((item) => {
        if (type === EmployeeJoinType.Idea) {
          return API.graphql<GraphQLQuery<DeleteIdeaEmployeeJoinMutation>>(
            graphqlOperation(deleteIdeaEmployeeJoin, {
              input: { id: item?.id },
            })
          );
        } else if (type === EmployeeJoinType.SuccessStory) {
          return API.graphql<
            GraphQLQuery<DeleteSuccessStoryEmployeeJoinMutation>
          >(
            graphqlOperation(deleteSuccessStoryEmployeeJoin, {
              input: { id: item?.id },
            })
          );
        } else if (type === EmployeeJoinType.Contribution) {
          return API.graphql<
            GraphQLQuery<DeleteContributionEmployeeJoinMutation>
          >(
            graphqlOperation(deleteContributionEmployeeJoin, {
              input: { id: item?.id },
            })
          );
        } else if (type === EmployeeJoinType.HelpRequest) {
          return API.graphql<
            GraphQLQuery<DeleteHelpRequestEmployeeJoinMutation>
          >(
            graphqlOperation(deleteHelpRequestEmployeeJoin, {
              input: { id: item?.id },
            })
          );
        }
      })
    );

    if (
      resultSet?.find((result) => result && (result.errors || !result.data))
    ) {
      throw new Error("Error removing tagged employees");
    }
  }
}

// Add employeeJoins that are not in the list of employeeJoins.
export async function addEmployeeJoins(
  employees: (EmployeeWithAvatarUrl | null)[],
  joinInfo: any,
  type: EmployeeJoinType
) {
  const companyId = await getCompanyId();
  const joinObject = {
    ...joinInfo,
    companyId,
  };

  const resultSet = await Promise.all(
    employees.map((employee) => {
      // Call the correct mutation based on the joinInfo.
      if (type === EmployeeJoinType.Idea) {
        return API.graphql<GraphQLQuery<CreateIdeaEmployeeJoinMutation>>(
          graphqlOperation(createIdeaEmployeeJoin, {
            input: { ...joinObject, employeeIdeaEmployeeJoinsId: employee?.id },
          })
        );
      } else if (type === EmployeeJoinType.SuccessStory) {
        return API.graphql<
          GraphQLQuery<CreateSuccessStoryEmployeeJoinMutation>
        >(
          graphqlOperation(createSuccessStoryEmployeeJoin, {
            input: {
              ...joinObject,
              employeeSuccessStoryEmployeeJoinsId: employee?.id,
            },
          })
        );
      } else if (type === EmployeeJoinType.Contribution) {
        return API.graphql<
          GraphQLQuery<CreateContributionEmployeeJoinMutation>
        >(
          graphqlOperation(createContributionEmployeeJoin, {
            input: {
              ...joinObject,
              employeeContributionEmployeeJoinsId: employee?.id,
            },
          })
        );
      } else if (type === EmployeeJoinType.HelpRequest) {
        return API.graphql<GraphQLQuery<CreateHelpRequestEmployeeJoinMutation>>(
          graphqlOperation(createHelpRequestEmployeeJoin, {
            input: {
              ...joinObject,
              employeeHelpRequestEmployeeJoinsId: employee?.id,
            },
          })
        );
      }
    })
  );

  if (resultSet.find((result) => result && (result.errors || !result.data))) {
    throw new Error("Error adding tagged employees");
  }

  return resultSet;
}

// Add employeeJoins that are not in the list of employeeJoins.
export async function addNewEmployeeJoins(
  employeeJoins: EmployeeJoinConnection | undefined,
  employees: (EmployeeWithAvatarUrl | null)[],
  joinInfo: any,
  type: EmployeeJoinType
) {
  // Add new employeeJoins.
  const added = employees?.filter(
    (employee) =>
      !((employeeJoins?.items || []) as any).find(
        (item: EmployeeJoin) =>
          getEmployeeIdFromJoin(item, type) === employee?.id
      )
  );

  if (added && (added?.length || 0) > 0) {
    return await addEmployeeJoins(added, joinInfo, type);
  }
}

// Get all the employee's subitems from the goals list.
export function getEmployeeSubItems(
  employee?: Employee | null,
  goals?: Goal[]
) {
  const result = {
    redFlags: [] as RedFlag[],
    offersForHelp: [] as HelpRequest[],
    ideas: [] as Idea[],
    successStories: [] as SuccessStory[],
    contributions: [] as Contribution[],
  };

  if (!goals || !employee) {
    return result;
  }

  const email = employee.email || "";
  const id = employee.id || "";

  goals.forEach((goal) => {
    goal.redFlags?.items?.forEach((redFlag) => {
      if (
        redFlag?.creatorEmail === email ||
        redFlag?.resolvedBy === email ||
        redFlag?.reopenedBy === email
      ) {
        result.redFlags.push(redFlag);
      }
    });
    goal.helpRequests?.items?.forEach((helpRequest) => {
      if (
        helpRequest?.employeeJoins?.items?.find(
          (join) => join?.employeeHelpRequestEmployeeJoinsId === id
        )
      ) {
        result.offersForHelp.push(helpRequest);
      }
    });
    goal.ideas?.items?.forEach((idea) => {
      if (
        idea?.employeeJoins?.items?.find(
          (join) => join?.employeeIdeaEmployeeJoinsId === id
        )
      ) {
        result.ideas.push(idea);
      }
    });
    goal.successStories?.items?.forEach((successStory) => {
      if (
        successStory?.employeeJoins?.items?.find(
          (join) => join?.employeeSuccessStoryEmployeeJoinsId === id
        )
      ) {
        result.successStories.push(successStory);
      }
    });
    goal.contributions?.items?.forEach((contribution) => {
      if (
        contribution?.employeeJoins?.items?.find(
          (join) => join?.employeeContributionEmployeeJoinsId === id
        )
      ) {
        result.contributions.push(contribution);
      }
    });
  });

  return result;
}

// Get open help requests where employee is not already in the employeeJoins and the request
// has not been hidden by employee.
export function getOpenHelpRequestsForEmployee(
  employee?: Employee | null,
  goals?: Goal[]
) {
  const result = {
    openHelpRequests: [] as HelpRequest[],
    notRelevantHelpRequests: [] as HelpRequest[],
  };

  if (!employee || !goals) {
    return result;
  }

  const requests = getHelpRequests(goals, false);
  requests.forEach((request) => {
    if (!request) {
      return;
    }

    // Check if the employee is already in the employeeJoins.
    if (
      request.employeeJoins?.items?.find(
        (join) => join?.employeeHelpRequestEmployeeJoinsId === employee.id
      )
    ) {
      return;
    } else if (request.notRelevantForEmployees?.includes(employee.email)) {
      result.notRelevantHelpRequests.push(request);
      return;
    }
    result.openHelpRequests.push(request);
  });
  return result;
}

// Delete all the employee joins.
async function deleteAllEmployeeJoins(employee: Employee, goals: Goal[]) {
  const joins = {
    ideas: [] as (IdeaEmployeeJoin | null)[],
    successStories: [] as (SuccessStoryEmployeeJoin | null)[],
    contributions: [] as (ContributionEmployeeJoin | null)[],
    helpRequests: [] as (HelpRequestEmployeeJoin | null)[],
  };
  goals.forEach((goal) => {
    goal.ideas?.items?.forEach((idea) => {
      joins.ideas.push(
        ...(idea?.employeeJoins?.items?.filter(
          (join) => join?.employeeIdeaEmployeeJoinsId === employee.id
        ) || [])
      );
    });
    goal.successStories?.items?.forEach((story) => {
      joins.successStories.push(
        ...(story?.employeeJoins?.items?.filter(
          (join) => join?.employeeSuccessStoryEmployeeJoinsId === employee.id
        ) || [])
      );
    });
    goal.contributions?.items?.forEach((contribution) => {
      joins.contributions.push(
        ...(contribution?.employeeJoins?.items?.filter(
          (join) => join?.employeeContributionEmployeeJoinsId === employee.id
        ) || [])
      );
    });
    goal.helpRequests?.items?.forEach((request) => {
      joins.helpRequests.push(
        ...(request?.employeeJoins?.items?.filter(
          (join) => join?.employeeHelpRequestEmployeeJoinsId === employee.id
        ) || [])
      );
    });
  });
  await Promise.all(
    joins.ideas.map(async (join) =>
      API.graphql<GraphQLQuery<DeleteIdeaEmployeeJoinMutation>>(
        graphqlOperation(deleteIdeaEmployeeJoin, { input: { id: join?.id } })
      )
    )
  );
  await Promise.all(
    joins.successStories.map(async (join) =>
      API.graphql<GraphQLQuery<DeleteSuccessStoryEmployeeJoinMutation>>(
        graphqlOperation(deleteSuccessStoryEmployeeJoin, {
          input: { id: join?.id },
        })
      )
    )
  );
  await Promise.all(
    joins.contributions.map(async (join) =>
      API.graphql<GraphQLQuery<DeleteContributionEmployeeJoinMutation>>(
        graphqlOperation(deleteContributionEmployeeJoin, {
          input: { id: join?.id },
        })
      )
    )
  );
  await Promise.all(
    joins.helpRequests.map(async (join) =>
      API.graphql<GraphQLQuery<DeleteHelpRequestEmployeeJoinMutation>>(
        graphqlOperation(deleteHelpRequestEmployeeJoin, {
          input: { id: join?.id },
        })
      )
    )
  );
}

// Check if given goal is an employee goal.
export function isEmployeeGoal(goals: Goal[], goalId?: string | null) {
  if (!goalId) {
    return false;
  }

  const goal = goals.find((goal) => goal.id === goalId);
  return goal?.employeeGoalsId != null;
}
