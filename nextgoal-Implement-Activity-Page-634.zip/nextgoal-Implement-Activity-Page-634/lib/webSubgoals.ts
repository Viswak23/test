import { Goal } from "@/src/API";

// Get all subgoals of a goal
export function getAllSubgoals(goalId: string, goals?: Goal[]): Goal[] {
  if (!goals) return [];

  let subgoals: Goal[] = goals.filter((g) => g.goalChildGoalsId === goalId);
  subgoals.forEach(
    (g) => (subgoals = subgoals.concat(getAllSubgoals(g.id, goals)))
  );
  return subgoals;
}
