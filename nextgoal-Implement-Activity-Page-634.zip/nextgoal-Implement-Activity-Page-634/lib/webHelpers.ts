import { API, Amplify, graphqlOperation, withSSRContext } from "aws-amplify";
import { GraphQLQuery } from "@aws-amplify/api";
import * as _ from "lodash";
import { log } from "./backend/actions/logger";
import {
  SNSClient,
  PublishCommand,
  PublishCommandInput,
} from "@aws-sdk/client-sns";
import { ReqInterface } from "./backend/getData";

// Get companyid from cognito groups
export async function getCompanyId(req?: ReqInterface) {
  const { accessToken } =
    req != null
      ? await withSSRContext({ req }).Auth.currentSession()
      : await Amplify.Auth.currentSession();
  const cognitogroups = accessToken.payload["cognito:groups"];
  if (cognitogroups[0] === "admin") {
    return cognitogroups[1];
  }
  return cognitogroups[0];
}

export function isAdmin(): boolean {
  return Amplify.Auth.user.signInUserSession.idToken.payload[
    "cognito:groups"
  ].includes("admin");
}

export function isOwner(owner?: string | null): boolean {
  if (!owner) {
    return false;
  }

  return owner === Amplify.Auth.user.attributes.email;
}

export function canDeleteDbItem(obj: any): boolean {
  const isOwner = obj.owner === Amplify.Auth.user.attributes.email;
  const isAdmin =
    Amplify.Auth.user.signInUserSession.idToken.payload[
      "cognito:groups"
    ].includes("admin");
  return isOwner || isAdmin;
}

// A function that removes undefined values from an object
export function removeUndefinedValuesFromObject(obj: any): object {
  Object.keys(obj).forEach((key) => obj[key] === undefined && delete obj[key]);
  return obj;
}

// Amplify has changed behaviour. It doesn't return the related objects anymore, but instead throws an error.
export async function createApiRequest<T>(
  operation: any,
  inputObject: any,
  outputName: string,
  inputIndexField?: any
) {
  let data;
  const variables = inputIndexField ?? { input: inputObject, limit: 10000 };
  try {
    const result = await API.graphql<GraphQLQuery<T>>(
      graphqlOperation(operation, variables)
    );
    // Not a beautiful solution, but it works.
    data = (result as any).data;
  } catch (error: any) {
    // We have an amplify problem. Amplify is giving goal has null fields errors even the goal is null in subitems.
    // If the item was created, ignore the error.
    if (!error.data || !error.data[outputName]) {
      log(`Remove Undefiened Values: ${error.message}`);
      throw error;
    }
    // Otherwise, continue with the error.
    data = error.data;
  }

  if (!data) {
    throw new Error(`Error creating a request: ${outputName}`);
  }

  return data[outputName];
}

const snsClient = new SNSClient({
  region: process.env.NEXT_PUBLIC_AWS_REGION,
  credentials: {
    accessKeyId: process.env.NEXT_PUBLIC_AWS_ACCESS_KEY_ID!,
    secretAccessKey: process.env.NEXT_PUBLIC_AWS_SECRET_ACCESS_KEY!,
  },
});

export async function pushNotificationToSNS(params: PublishCommandInput) {
  try {
    const command = new PublishCommand(params);
    const result = await snsClient.send(command);
    return result;
  } catch (error: any) {
    log(
      `Error pushing notification to SNS helpers: ${JSON.stringify(
        error
      )} ${JSON.stringify(params)}`
    );
    throw new Error(
      `Failed to push notification to SNS: ${JSON.stringify(error)}`
    );
  }
}

const numericFields: string[] = [
  "initialValue",
  "targetValue",
  "currentValue",
  "currentValueBefore",
  "currentValueAfter",
];

const isNullAndNotNumber = (value: any, key: string): boolean => {
  return (
    (value === null || value === undefined) && !numericFields.includes(key)
  );
};

// The function omit the null and undefined fields out of the object
// This prevents writing null value with mutation and cause unauthorized error
// https://github.com/graphql/graphql-js/issues/133

export function removeUndefinedAndNullFields<T extends object>(inputObject: T) {
  return _.omitBy(inputObject, isNullAndNotNumber) as T;
}
