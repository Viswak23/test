import awsExports from "../src/aws-exports";

export const aws_user_pools_id =
  process.env.NEXT_PUBLIC_USER_POOLS_ID == "null" ||
  !process.env.NEXT_PUBLIC_USER_POOLS_ID
    ? awsExports.aws_user_pools_id
    : process.env.NEXT_PUBLIC_USER_POOLS_ID;
export const aws_user_pools_web_client_id =
  process.env.NEXT_PUBLIC_USER_POOLS_WEB_CLIENT_ID == "null" ||
  !process.env.NEXT_PUBLIC_USER_POOLS_WEB_CLIENT_ID
    ? awsExports.aws_user_pools_web_client_id
    : process.env.NEXT_PUBLIC_USER_POOLS_WEB_CLIENT_ID;
export const aws_cognito_identity_pool_id =
  process.env.NEXT_PUBLIC_COGNITO_IDENTITY_POOL_ID == "null" ||
  !process.env.NEXT_PUBLIC_COGNITO_IDENTITY_POOL_ID
    ? awsExports.aws_cognito_identity_pool_id
    : process.env.NEXT_PUBLIC_COGNITO_IDENTITY_POOL_ID;
awsExports.aws_cognito_identity_pool_id;
export const customAwsExports = {
  ...awsExports,
  aws_user_pools_id,
  aws_user_pools_web_client_id,
  aws_cognito_identity_pool_id,
};

export enum LogLevel {
  error = "error",
  warn = "warn",
  info = "info",
  debug = "debug",
}
