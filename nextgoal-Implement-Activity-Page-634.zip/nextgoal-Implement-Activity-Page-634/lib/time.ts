import { Employee } from "@/src/API";
import dayjs from "dayjs";
import { IntlShape } from "react-intl";
import { SupportedLocales } from "./localisation";

export function timeToTarget(intl: IntlShape, timestamp?: string | null) {
  if (!timestamp) return intl.formatMessage({ id: "goals.no.target.date" });

  const diff = daysAgoDayjs(timestamp);
  if (diff <= 0) {
    return intl.formatMessage(
      { id: "time.days.to.target" },
      { count: Math.abs(diff) }
    );
  } else {
    return intl.formatMessage({ id: "time.days.ago" }, { count: diff });
  }
}
export function NotificationTimeAgo(dateString: string, intl: IntlShape) {
  const now = new Date(); // Current date and time
  const timestamp = new Date(dateString); // Given date and time
  const differenceInSeconds = Math.floor(
    (now.getTime() - timestamp.getTime()) / 1000
  ); // Difference in seconds

  const minutes = Math.floor(differenceInSeconds / 60);
  const hours = Math.floor(differenceInSeconds / 3600);
  const days = Math.floor(differenceInSeconds / 86400);

  if (differenceInSeconds < 60) {
    return intl.formatMessage(
      { id: "notifications.time.sec" },
      { time: differenceInSeconds }
    );
  } else if (minutes < 60) {
    return intl.formatMessage(
      { id: "notifications.time.min" },
      { time: minutes }
    );
  } else if (hours < 24) {
    return intl.formatMessage(
      { id: "notifications.time.hour" },
      { time: hours }
    );
  } else {
    return intl.formatMessage({ id: "notifications.time.day" }, { time: days });
  }
}

export function showDate(
  timestamp?: string | null,
  currentUser?: Employee | null
) {
  if (!timestamp) {
    return "";
  }

  const locale = currentUser?.locale || "en-US";
  const date = dayjs(timestamp).toDate();

  switch (locale) {
    case SupportedLocales.FI:
      return new Intl.DateTimeFormat("fi-FI").format(date);
    case SupportedLocales.ENGB:
      return new Intl.DateTimeFormat("en-GB").format(date);
    case SupportedLocales.ENUS:
    default:
      return new Intl.DateTimeFormat("en-US").format(date);
  }
}

export function daysAgoDayjs(timestamp: string) {
  return dayjs().diff(dayjs(timestamp), "day");
}

export function diffInDays(start: string, end: string) {
  return dayjs(end).diff(dayjs(start), "day");
}

// Show days to target date, or days since target date if it has passed
export function timeToTargetDate(intl: IntlShape, timestamp?: string | null) {
  if (!timestamp) return "";

  const diff = daysAgoDayjs(timestamp);
  if (diff <= 0) {
    return intl.formatMessage(
      { id: "time.days.left" },
      { count: Math.abs(diff) }
    );
  } else {
    return intl.formatMessage({ id: "time.days.ago" }, { count: diff });
  }
}

export function getTimeFromDbEntry(dbEntry: string) {
  return dayjs(dbEntry);
}

export function calculateDaysOfStatus(
  intl: IntlShape,
  timestamp?: string | null
) {
  if (!timestamp) return "-";

  const diff = daysAgoDayjs(timestamp);
  return intl.formatMessage({ id: "time.days.ago" }, { count: Math.abs(diff) });
}

interface UpdateSortObject {
  dateOfUpdate: string;
}
type Direction = "asc" | "des";
export function sortUpdateDate(
  a: UpdateSortObject | null,
  b: UpdateSortObject | null,
  direction: Direction = "asc"
) {
  if (b == null) {
    return -1;
  }
  if (a == null) {
    return 1;
  }
  if (direction === "asc") {
    return dayjs(a.dateOfUpdate).isBefore(dayjs(b.dateOfUpdate)) ? -1 : 1;
  } else {
    return dayjs(a.dateOfUpdate).isBefore(dayjs(b.dateOfUpdate)) ? 1 : -1;
  }
}

interface SortObject {
  createdAt: string;
}

export function sortCreatedAtAscending(
  a: SortObject | null,
  b: SortObject | null
) {
  if (b == null) {
    return -1;
  }
  if (a == null) {
    return 1;
  }

  return dayjs(a.createdAt).isBefore(dayjs(b.createdAt)) ? -1 : 1;
}

export function sortCreatedAtDescending(
  a: SortObject | null,
  b: SortObject | null
) {
  if (b == null) {
    return 1;
  }
  if (a == null) {
    return -1;
  }

  return dayjs(a.createdAt).isBefore(dayjs(b.createdAt)) ? 1 : -1;
}

// Get a integer timestamp from a date string for graphs
export function getTimestamp(date: string) {
  return dayjs(date).valueOf();
}

// Get only a date part of a date string
export function getTimeStampForGraph(date: string) {
  const newDate = dayjs(date).startOf("day");
  return newDate.valueOf();
}

// Check if the first date is before the second date
export function isBefore(date1: string, date2: string) {
  return dayjs(date1).isBefore(dayjs(date2));
}

// Get the current timestamp in UTC time
export function getCurrentTimestamp() {
  return dayjs().toISOString();
}

export function getGreetingText(intl: IntlShape) {
  const currentHour = dayjs().hour();

  if (currentHour >= 5 && currentHour < 12) {
    return intl.formatMessage({ id: "greeting.morning" });
  } else if (currentHour >= 12 && currentHour < 18) {
    return intl.formatMessage({ id: "greeting.afternoon" });
  } else {
    return intl.formatMessage({ id: "greeting.evening" });
  }
}
