import {
  CreateCommentInput,
  CreateCommentMutation,
  UpdateCommentInput,
  UpdateCommentMutation,
  Comment,
  DeleteCommentInput,
  GetCommentQuery,
} from "@/src/API";
import { GraphQLQuery } from "@aws-amplify/api";

import {
  createComment,
  updateComment,
  deleteComment,
} from "@/src/graphql/mutations";
import {
  createApiRequest,
  getCompanyId,
  removeUndefinedAndNullFields,
} from "./webHelpers";
import { log } from "./backend/actions/logger";
import { getComment } from "@/src/graphql/queries";
import { API, graphqlOperation } from "aws-amplify";

// Adds an comment to a goal and returns updated goal and event
export async function addCommentDb(
  newComment: CreateCommentInput,
  goalId: string
) {
  try {
    newComment.companyId = await getCompanyId();
    newComment.hostGoalId = goalId;

    return await createApiRequest<CreateCommentMutation>(
      createComment,
      newComment,
      "createComment"
    );
  } catch (error: any) {
    log("Error adding comment: " + error.message);
  }
}

// Updateds a given comment to a goal and returns updated goal
export async function updateCommentDb(updatedComment: UpdateCommentInput) {
  const updateItem = removeUndefinedAndNullFields({
    id: updatedComment.id,
    companyId: updatedComment.companyId,
    text: updatedComment.text,
  });
  return await createApiRequest<UpdateCommentMutation>(
    updateComment,
    updateItem,
    "updateComment"
  );
}

// Delete a comment from the database
export async function deleteCommentDb(commentId: string) {
  return await createApiRequest<DeleteCommentInput>(
    deleteComment,
    { id: commentId },
    "deleteComment"
  );
}

// Delete given comments with their replies from the database.
export async function deleteCommentsWithReplies(comments?: (Comment | null)[]) {
  if (!comments || comments.length === 0) return;
  const replies = comments.flatMap((comment) => comment?.replies?.items || []);
  let commentIds = comments
    .map((comment) => comment && comment.id)
    .filter(Boolean);
  commentIds = commentIds?.concat(
    replies?.map((reply) => reply && reply.id).filter(Boolean) || []
  );
  await Promise.all(
    commentIds?.map((commentId) => commentId && deleteCommentDb(commentId)) ||
      []
  );
}

export async function getCommentById(commentId: string) {
  try {
    const response = await API.graphql<GraphQLQuery<GetCommentQuery>>(
      graphqlOperation(getComment, { id: commentId })
    );
    return response.data?.getComment;
  } catch (error: any) {
    log("Error getting comment by id" + error.message);
  }
}
