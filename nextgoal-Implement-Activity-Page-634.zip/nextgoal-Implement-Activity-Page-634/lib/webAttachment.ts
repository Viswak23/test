import { useState, useEffect } from "react";
import { Storage } from "aws-amplify";
import { getCompanyId } from "./webHelpers";
import { log } from "./backend/actions/logger";

export enum AttachmentOwner {
  Avatar = "Avatar",
  Status = "Status",
  RedFlag = "RedFlag",
  Idea = "Idea",
  SuccessStory = "SuccessStory",
  Contribution = "Contribution",
  KeyResult = "KeyResult",
  KeyResultUpdate = "KeyResultUpdate",
  HelpRequest = "HelpRequest",
  Goal = "Goal",
}

export interface AttachmentFile {
  type?: string;
  url?: string;
  file?: File;
  originalFilename?: string;
  base64?: string;
}

function getPathForAttachment(attachmentOwner: AttachmentOwner) {
  switch (attachmentOwner) {
    case AttachmentOwner.Avatar:
      return "profiles";
    case AttachmentOwner.Status:
      return "status";
    case AttachmentOwner.RedFlag:
      return "redflags";
    case AttachmentOwner.Idea:
      return "ideas";
    case AttachmentOwner.SuccessStory:
      return "successstories";
    case AttachmentOwner.Contribution:
      return "contributions";
    case AttachmentOwner.KeyResult:
      return "keyresults";
    case AttachmentOwner.KeyResultUpdate:
      return "keyresultupdates";
    case AttachmentOwner.HelpRequest:
      return "helprequests";
    case AttachmentOwner.Goal:
      return "goals";
    default:
      return "unknown-attachments";
  }
}

// Save mediafile to S3 and return url.
export async function saveAttachment(
  file: File,
  attachmentOwner: AttachmentOwner,
  filename?: string
) {
  try {
    const fn = filename ? filename : file.name;
    const companyId = await getCompanyId();
    const filenameWithPath = `${companyId}/${getPathForAttachment(
      attachmentOwner
    )}/${fn}`;
    const result = await Storage.put(filenameWithPath, file, {
      contentType: file.type,
      level: "public",
    });
    return result.key;
  } catch (error: any) {
    log(`Save Attachments: ${error.message}`);
    throw new Error("Error saving media file");
  }
}

// Save attachment files to S3 and return urls.
export async function saveAttachments(
  attachments: AttachmentFile[],
  owner: AttachmentOwner
) {
  const urls = await Promise.all(
    attachments.map(async (attachment) => {
      if (attachment.file) {
        // Use timestamp so that two files with the same name can be uploaded. We don't yet have new status id.
        const fileName = `${Date.now()}-${attachment.file.name}`;
        return saveAttachment(attachment.file, owner, fileName);
      }
      return null;
    })
  );

  return urls.filter((url) => url != null) as string[];
}

// Delete removed media file from S3.
export async function deleteAttachment(attachmentUrl?: string) {
  if (attachmentUrl) {
    try {
      return Storage.remove(attachmentUrl);
    } catch (error: any) {
      log(`Delete Attachments: ${error.message}`);
      throw new Error("Error deleting attachment");
    }
  }
  return Promise.resolve();
}

// Remove deleted accahment files from S3.
export async function deleteAttachments(
  removed: AttachmentFile[],
  existing: AttachmentFile[]
) {
  await Promise.all(
    removed.map(async (attachment) => {
      return deleteAttachment(attachment.originalFilename);
    })
  );
  return existing
    .filter((attachment) => !removed.includes(attachment))
    .map((attachment) => attachment.originalFilename)
    .filter((attachment) => attachment != null) as string[];
}

// Get media file url from S3. Returns promise so await must be done when calling.
export function getAttachmentUrl(attachmentUrl?: string | null) {
  if (attachmentUrl) {
    return Storage.get(attachmentUrl, { download: false });
  }
  return undefined;
}

export async function getAttachmentFile(attachment: string) {
  let type = "image";
  if (
    attachment.includes(".mpeg") ||
    attachment.includes(".mp4") ||
    attachment.includes(".mov")
  ) {
    type = "video";
  } else if (attachment.includes(".pdf")) {
    type = "pdf";
  }
  return {
    url: await getAttachmentUrl(attachment),
    type,
    originalFilename: attachment,
  };
}

// Use custom hook to get the attachments urls.
export function useAttachmentUrls(attachmentList?: string[]) {
  const [attachments, setAttachment] = useState<AttachmentFile[]>([]);

  useEffect(() => {
    async function getAttachments() {
      let result: AttachmentFile[] = [];
      if (attachmentList) {
        result = await Promise.all(
          attachmentList.map(async (mf) => await getAttachmentFile(mf))
        );
      }
      setAttachment(result);
    }

    getAttachments();
  }, [attachmentList]);

  return attachments;
}
