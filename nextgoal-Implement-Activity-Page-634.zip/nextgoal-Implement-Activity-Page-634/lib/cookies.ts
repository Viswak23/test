'use server'

import { cookies } from 'next/headers'

export async function setPreferredLanguage(language: string) {
  cookies().set('language', language)
}

export async function getPreferredLanguage(): Promise<string | null> {
  return cookies().get('language')?.value || null
}