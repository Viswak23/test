import {
  CreateIdeaInput,
  CreateIdeaMutation,
  DeleteIdeaMutation,
  Idea,
  UpdateIdeaInput,
  UpdateIdeaMutation,
  Event,
} from "@/src/API";
import { createIdea, updateIdea, deleteIdea } from "@/src/graphql/mutations";
import {
  DeleteEventType,
  EventType,
  addEvent,
  deleteEventsDb,
  getDeleteEvents,
} from "./webEvents";
import {
  createApiRequest,
  getCompanyId,
  removeUndefinedAndNullFields,
} from "./webHelpers";
import { deleteCommentsWithReplies } from "./webComments";
import { EmployeeWithAvatarUrl } from "@/contexts/EmployeesContext";
import {
  EmployeeJoinType,
  addEmployeeJoins,
  addNewEmployeeJoins,
  deleteRemovedEmployeeJoins,
} from "./webEmployee";
import { AttachmentFile, deleteAttachments } from "./webAttachment";
import { log } from "./backend/actions/logger";

// Adds a new idea to the goal
export async function addIdeaDb(
  newIdea: CreateIdeaInput,
  employees: (EmployeeWithAvatarUrl | null)[],
  allEmployees: EmployeeWithAvatarUrl[] | undefined,
  employeeGoal: boolean
) {
  newIdea.companyId = await getCompanyId();
  const resultIdea = await createApiRequest<CreateIdeaMutation>(
    createIdea,
    newIdea,
    "createIdea"
  );

  if (resultIdea) {
    // Add join table entries for the employees
    if (employees.length > 0) {
      const joinInfo = {
        goalId: resultIdea.goalIdeasId,
        ideaEmployeeJoinsId: resultIdea.id,
      };
      await addEmployeeJoins(employees, joinInfo, EmployeeJoinType.Idea);
    }

    // Don't create an event for employees' own goals
    if (resultIdea && !employeeGoal) {
      // Add event to the event table
      addEvent(
        EventType.IDEA_ADDED,
        resultIdea.goalIdeasId,
        allEmployees,
        employees,
        {
          eventIdeaId: resultIdea.id,
        }
      ).catch((error: any) => {
        log(`AddIdeaDb: ${error.message}`);
        throw new Error(error.message);
      });
    }
  }
  return resultIdea;
}

// Updates existing idea
export async function updateIdeaDb(
  updatedIdea: UpdateIdeaInput,
  originalIdea?: Idea,
  employees?: (EmployeeWithAvatarUrl | null)[]
) {
  // UpdatedStatus contains fields from the original status, so we create a new updateobject.
  const updateObject: UpdateIdeaInput = removeUndefinedAndNullFields({
    id: updatedIdea.id,
    title: updatedIdea.title,
    description: updatedIdea.description,
    attachments: updatedIdea.attachments,
  });
  const resultIdea = await createApiRequest<UpdateIdeaMutation>(
    updateIdea,
    updateObject,
    "updateIdea"
  );

  // If the employee joins are given, update them.
  if (employees && originalIdea) {
    // Delete removed employeeJoins
    await deleteRemovedEmployeeJoins(
      originalIdea.employeeJoins,
      employees,
      EmployeeJoinType.Idea
    );

    // Add new employeeJoins.
    const joinInfo = {
      goalId: originalIdea.goalIdeasId,
      ideaEmployeeJoinsId: originalIdea.id,
    };
    await addNewEmployeeJoins(
      originalIdea.employeeJoins,
      employees,
      joinInfo,
      EmployeeJoinType.Idea
    );
  }
  return resultIdea;
}

// Delete given idea including comments and replies from the database.
export async function deleteIdeaDb(
  idea: Idea,
  attachments: AttachmentFile[],
  events?: Event[]
) {
  // Delete all the comments
  await deleteCommentsWithReplies(idea.comments?.items || []);
  // Delete all the employeeJoins
  await deleteRemovedEmployeeJoins(
    idea.employeeJoins,
    [],
    EmployeeJoinType.Idea
  );
  // Remove all the attachments
  await deleteAttachments(attachments, []);
  // Delete the event
  await deleteEventsDb(getDeleteEvents(events, DeleteEventType.IDEA, idea.id));
  // Delete the idea
  return await createApiRequest<DeleteIdeaMutation>(
    deleteIdea,
    { id: idea.id },
    "deleteIdea"
  );
}
