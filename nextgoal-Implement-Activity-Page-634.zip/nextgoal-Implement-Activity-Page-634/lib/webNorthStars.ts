import {
  CreateNorthStarInput,
  CreateNorthStarMutation,
  DeleteNorthStarMutation,
  UpdateNorthStarInput,
  UpdateNorthStarMutation,
} from "@/src/API";
import {
  createNorthStar,
  deleteNorthStar,
  updateNorthStar,
} from "@/src/graphql/mutations";
import { createApiRequest, getCompanyId, removeUndefinedAndNullFields } from "./webHelpers";

// Adds a new north star
export async function addNorthStarDb(newNorthStar: CreateNorthStarInput) {
  newNorthStar.companyId = await getCompanyId();
  return await createApiRequest<CreateNorthStarMutation>(
    createNorthStar,
    newNorthStar,
    "createNorthStar"
  );
}

// Updates existing north star
export async function updateNorthStarDb(
  updatedNorthStar: UpdateNorthStarInput
) {
  // updatedNorthStar contains fields from the original north star, so we create a new updateobject to remove links, createdAt etc.
  const updateObject: UpdateNorthStarInput = removeUndefinedAndNullFields({
    id: updatedNorthStar.id,
    title: updatedNorthStar.title,
    description: updatedNorthStar.description,
  });

  return await createApiRequest<UpdateNorthStarMutation>(
    updateNorthStar,
    updateObject,
    "updateNorthStar"
  );
}

export async function deleteNorthStarDb(id: string) {
  return await createApiRequest<DeleteNorthStarMutation>(
    deleteNorthStar,
    { id },
    "deleteNorthStar"
  );
}
