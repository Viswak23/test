import {
  Company,
  CreateCompanyInput,
  ListCompaniesQuery,
  UpdateCompanyInput,
  UpdateCompanyMutation,
} from "@/src/API";
import { API } from "aws-amplify";
import { GraphQLQuery } from "@aws-amplify/api";
import { createCompany, updateCompany } from "@/src/graphql/mutations";
import {
  createApiRequest,
  getCompanyId,
  removeUndefinedAndNullFields,
} from "./webHelpers";
import { GRAPHQL_AUTH_MODE } from "@aws-amplify/api";
import { listCompanies } from "@/src/graphql/queries";

// Add company information to db
export async function addCompanyDb(
  newCompany: CreateCompanyInput,
  isAuth = true
) {
  if (isAuth) {
    newCompany.companyId = await getCompanyId();
  }
  const result: any = await API.graphql({
    query: createCompany,
    variables: {
      input: newCompany,
    },
    authMode: GRAPHQL_AUTH_MODE.API_KEY,
  });

  if (result.errors || !result.data) {
    throw new Error("Error creating company information");
  } else {
    return result?.data?.createCompany;
  }
}

// Updates company information
export async function updateCompanyDb(updatedCompany: UpdateCompanyInput) {
  const updateObject = {
    id: updatedCompany.id,
    owner: updatedCompany.owner,
    companyId: updatedCompany.companyId,
    name: updatedCompany.name,
    creatorEmail: updatedCompany.creatorEmail,
    isSubscribed: updatedCompany.isSubscribed,
    subscriptionId: updatedCompany.subscriptionId,
    customerId: updatedCompany.customerId,
    subscriptionExpireDate: updatedCompany.subscriptionExpireDate,
    description: updatedCompany.description,
  };
  return await createApiRequest<UpdateCompanyMutation>(
    updateCompany,
    removeUndefinedAndNullFields(updateObject),
    "updateCompany"
  );
}

// get company by companyId
export async function getCompanyDb() {
  const companyId = await getCompanyId();
  const result = await createApiRequest<ListCompaniesQuery>(
    listCompanies,
    undefined,
    "listCompanies"
  );
  const company = result?.items?.find(
    (company: Company) => company?.companyId === companyId
  );

  if (result.errors || !company) {
    throw new Error("Error getting company information");
  } else {
    return company;
  }
}
