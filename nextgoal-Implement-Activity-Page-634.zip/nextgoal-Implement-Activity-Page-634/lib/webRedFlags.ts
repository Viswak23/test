import { getAllSubgoals } from "./webSubgoals";
import {
  CreateRedFlagInput,
  CreateRedFlagMutation,
  DeleteRedFlagMutation,
  Goal,
  Event,
  RedFlag,
  UpdateRedFlagInput,
  UpdateRedFlagMutation,
} from "@/src/API";
import {
  createRedFlag,
  deleteRedFlag,
  updateRedFlag,
} from "@/src/graphql/mutations";
import {
  DeleteEventType,
  EventType,
  addEvent,
  deleteEventsDb,
  getDeleteEvents,
} from "./webEvents";
import {
  createApiRequest,
  getCompanyId,
  removeUndefinedAndNullFields,
} from "./webHelpers";
import { deleteCommentsWithReplies } from "./webComments";
import { sortCreatedAtDescending } from "./time";
import { AttachmentFile, deleteAttachments } from "./webAttachment";
import { EmployeeWithAvatarUrl } from "@/contexts/EmployeesContext";

// Adds an red flag to a goal and returns updated goal
export async function addRedFlagDb(
  newRedFlag: CreateRedFlagInput,
  employeeGoal: boolean,
  allEmployees: EmployeeWithAvatarUrl[] | undefined
) {
  newRedFlag.companyId = await getCompanyId();
  const resultRf = await createApiRequest<CreateRedFlagMutation>(
    createRedFlag,
    removeUndefinedAndNullFields(newRedFlag),
    "createRedFlag"
  );

  // Add an event if it's not a employee's own goal
  if (resultRf && !employeeGoal) {
    addEvent(
      EventType.RED_FLAG_ADDED,
      resultRf.goalRedFlagsId,
      allEmployees,
      undefined,
      {
        redFlagEventsId: resultRf.id,
      }
    );
  }

  return resultRf;
}

// Updateds a given red flag to a goal and returns updated goal
export async function updateRedFlagDb(
  updatedRedFlag: UpdateRedFlagInput,
  originalRedFlag: RedFlag | null,
  employeeGoal: boolean,
  allEmployees: EmployeeWithAvatarUrl[] | undefined
) {
  const updateObject: UpdateRedFlagInput = removeUndefinedAndNullFields({
    id: updatedRedFlag.id,
    text: updatedRedFlag.text,
    resolved: updatedRedFlag.resolved,
    resolvedTime: updatedRedFlag.resolvedTime,
    resolvedBy: updatedRedFlag.resolvedBy,
    resolvedComment: updatedRedFlag.resolvedComment,
    reopenedTime: updatedRedFlag.reopenedTime,
    reopenedBy: updatedRedFlag.reopenedBy,
    reopenedComment: updatedRedFlag.reopenedComment,
    attachments: updatedRedFlag.attachments,
  });

  const resultRf = await createApiRequest<UpdateRedFlagMutation>(
    updateRedFlag,
    updateObject,
    "updateRedFlag"
  );

  if (resultRf && !employeeGoal) {
    if (
      originalRedFlag &&
      !originalRedFlag.resolved &&
      updatedRedFlag.resolved
    ) {
      addEvent(
        EventType.RED_FLAG_RESOLVED,
        resultRf.goalRedFlagsId,
        allEmployees,
        undefined,
        {
          redFlagEventsId: resultRf.id,
        }
      );
    }
    if (
      originalRedFlag &&
      originalRedFlag.resolved &&
      !updatedRedFlag.resolved
    ) {
      addEvent(
        EventType.RED_FLAG_REOPENED,
        resultRf.goalRedFlagsId,
        allEmployees,
        undefined,
        {
          redFlagEventsId: resultRf.id,
        }
      );
    }
  }
  return resultRf;
}

// Delete given red flag including comments and replies from the database.
export async function deleteRedFlagDb(
  redFlag: RedFlag,
  attachments: AttachmentFile[],
  events?: Event[]
) {
  // Delete all the comments
  await deleteCommentsWithReplies(redFlag.comments?.items || []);
  // Remove all the attachments
  await deleteAttachments(attachments, []);
  // Delete the event
  await deleteEventsDb(
    getDeleteEvents(events, DeleteEventType.RED_FLAG, redFlag.id)
  );

  // Delete the red flag
  return await createApiRequest<DeleteRedFlagMutation>(
    deleteRedFlag,
    { id: redFlag.id },
    "deleteRedFlag"
  );
}

// Return an array of goals that contains a goal and all the subgoals which has redflags in resolved state.
export function getRedFlags(
  goals?: Goal[],
  resolved?: boolean
): (RedFlag | null)[] {
  if (goals == null || resolved == null) {
    return [];
  }

  return goals
    .reduce((acc, goal) => {
      return acc.concat(
        goal.redFlags?.items?.filter((rf) => !!rf?.resolved === resolved) ?? []
      );
    }, [] as (RedFlag | null)[])
    .sort(sortCreatedAtDescending);
}

// Return an array of goals that contains a goal and all the subgoals which has redflags in resolved state.
export function getGoalsWithRedFlags(
  goalId?: string,
  goals?: Goal[],
  resolved?: boolean
): Goal[] {
  if (!goalId || !goals || resolved === undefined) {
    return [];
  }

  const goal = goals.find(
    (g) =>
      g.id === goalId &&
      g.redFlags?.items &&
      g.redFlags?.items.find((r) => r && r.resolved === resolved)
  );
  const result = goal ? [goal] : [];
  const subgoalsWithRedFlags = getAllSubgoals(goalId, goals).filter((g) =>
    g.redFlags?.items?.find((r) => r && r.resolved === resolved)
  );

  return result.concat(subgoalsWithRedFlags);
}

// Get a list of all the redflags of the goal and all the subgoals which has redflags in resolved state.
export function getAllRedFlagsOfGoal(
  goalId?: string,
  goals?: Goal[],
  resolved?: boolean
): (RedFlag | null)[] {
  if (!goalId || !goals || resolved === undefined) {
    return [];
  }

  const goalsWithRedFlags = getGoalsWithRedFlags(goalId, goals, resolved);
  return getRedFlags(goalsWithRedFlags, resolved);
}
