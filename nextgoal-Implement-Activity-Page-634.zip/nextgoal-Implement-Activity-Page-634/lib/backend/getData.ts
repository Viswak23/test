import { getGoals } from "@/lib/backend/goals";
import { getOrganization } from "@/lib/backend/organization";
import { getEvents } from "@/lib/backend/events";
import { withSSRContext } from "aws-amplify";
import {
  getEmployees,
  getOrganizationUnitEmployeeJoins,
} from "@/lib/backend/employee";
import { headers } from "next/headers";
import { getNorthStars } from "./northstars";
import { log } from "./actions/logger";
import { getNotifications } from "./notifications";

export interface ReqInterface {
  headers: {
    cookie: string | null;
  };
}

// during migration i relized that we are writing the same function in different places, couldn't it be done better?
export async function getData() {
  try {
    const req = {
      headers: {
        cookie: headers().get("cookie"),
      },
    };

    const { Auth } = withSSRContext({ req });
    await Auth.currentAuthenticatedUser();
    const session = await Auth.currentSession();
    const userEmail = session?.accessToken?.payload?.email;

    //only get the open goals
    const goalsData = getGoals(req, { isClosed: { eq: false } });
    const archiveData = getGoals(req, { isClosed: { eq: true } });
    const organizationData = getOrganization(req);
    const employeesData = getEmployees(req);
    const eventsData = getEvents(req);
    const organizationUnitEmployeeJoinsData =
      getOrganizationUnitEmployeeJoins(req);
    const northStarsData = getNorthStars(req);
    const notificationsData = getNotifications(req, userEmail);

    const [
      goals,
      archive,
      organization,
      employees,
      events,
      organizationUnitEmployeeJoins,
      northStars,
      notifications,
    ] = await Promise.all([
      goalsData,
      archiveData,
      organizationData,
      employeesData,
      eventsData,
      organizationUnitEmployeeJoinsData,
      northStarsData,
      notificationsData,
    ]);

    return {
      goals,
      archive,
      organization,
      employees,
      events,
      organizationUnitEmployeeJoins,
      northStars,
      notifications,
    };
  } catch (error: any) {
    log(`getData: ${error.message}`);
    console.error(error);
    return {
      goals: [],
      archive: [],
      organization: [],
      employees: [],
      events: [],
      organizationUnitEmployeeJoins: [],
      northStars: [],
      notifications: [],
    };
  }
}
