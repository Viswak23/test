import { Goal } from "@/src/API";
import { withSSRContext } from "aws-amplify";
import { GRAPHQL_AUTH_MODE } from "@aws-amplify/api";
import { listGoalsWithListInfo } from "@/src/graphql/custom-queries";
import { ReqInterface } from "./getData";
import { log } from "./actions/logger";
import { getCompanyId } from "../webHelpers";

export async function getGoals(
  req: ReqInterface,
  filter: any
): Promise<Goal[]> {
  const SSR = withSSRContext({ req });

  try {
    const response = await SSR.API.graphql({
      variables: {
        filter,
        companyId: await getCompanyId(req),
      },
      query: listGoalsWithListInfo,
      authMode: GRAPHQL_AUTH_MODE.AMAZON_COGNITO_USER_POOLS,
    });
    return response.data.goalsByCompany.items;
  } catch (error: any) {
    log(`getGoals: ${error.message}`);
    console.error("Error while fetching goal list: ", error);
    return [];
  }
}
