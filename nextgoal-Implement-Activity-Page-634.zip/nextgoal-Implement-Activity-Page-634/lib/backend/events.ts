import { Event, ModelSortDirection } from "@/src/API";
import { graphqlOperation, withSSRContext } from "aws-amplify";
import { eventsByCompanyId, getEvent } from "@/src/graphql/queries";
import { ReqInterface } from "./getData";
import { log } from "./actions/logger";
import { getCompanyId } from "../webHelpers";

export async function getEvents(req: ReqInterface): Promise<Event[]> {
  const SSR = withSSRContext({ req });
  const params = {
    sortDirection: ModelSortDirection.DESC,
    limit: 10000,
    companyId: await getCompanyId(req),
  };

  try {
    const response = await SSR.API.graphql(
      graphqlOperation(eventsByCompanyId, params)
    );
    return response.data.eventsByCompanyId.items;
  } catch (error: any) {
    log(`getEvents: ${error.message}`);
    console.error("Error while fetching event list: ", error);
    return [];
  }
}

export async function getEventById(req: ReqInterface, eventId: string) {
  const SSR = withSSRContext({ req });
  try {
    const response = await SSR.API.graphql(
      graphqlOperation(getEvent, { id: eventId })
    );
    return response.data.getEvent;
  } catch (error: any) {
    log(`getEvent: ${error.message}`);
    console.error("Error while fetching event by id: ", error);
    return null;
  }
}
