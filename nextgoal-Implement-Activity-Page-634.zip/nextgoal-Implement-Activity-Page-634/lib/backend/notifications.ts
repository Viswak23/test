import { graphqlOperation, withSSRContext } from "aws-amplify";
import {
  ModelSortDirection,
  Notification,
  NotificationsByEmployeeEmailQueryVariables,
} from "@/src/API";
import { notificationsByEmployeeEmail } from "@/src/graphql/queries";
import { ReqInterface } from "./getData";
import { log } from "./actions/logger";

export async function getNotifications(
  req: ReqInterface,
  email: string
): Promise<Notification[]> {
  const SSR = withSSRContext({ req });
  const params: NotificationsByEmployeeEmailQueryVariables = {
    sortDirection: ModelSortDirection.DESC,
    toEmployeeEmail: email,
    limit: 10000,
  };
  try {
    const response = await SSR.API.graphql(
      graphqlOperation(notificationsByEmployeeEmail, params)
    );
    return response.data.notificationsByEmployeeEmail.items;
  } catch (error: any) {
    log(`getNotifications: ${error.message}`);
    console.error("Error while fetching notifications: ", error);
    return [];
  }
}
