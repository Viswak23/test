"use server";

import { log } from "./logger";

//this should stay on the server side to avoid the user manipulate the payment intent
export async function createStripeSubscription(customerId: string) {
  const priceId = process.env.NEXT_PUBLIC_STRIPE_PRICEID!;
  const stripe = require("stripe")(process.env.NEXT_PUBLIC_STRIPE_API_SECRET);
  try {
    const subscription = await stripe.subscriptions.create({
      customer: customerId,
      items: [
        {
          price: priceId,
        },
      ],
      payment_behavior: "default_incomplete",
      payment_settings: { save_default_payment_method: "on_subscription" },
      expand: ["latest_invoice.payment_intent", "pending_setup_intent"],
    });

    return {
      id: subscription.id,
      customer: subscription.customer,
      currentPeriodEnd: subscription.current_period_end,
      clientSecret: subscription.latest_invoice.payment_intent.client_secret,
    };
  } catch (error: any) {
    log(`createStripeSubscription: ${error.message}`);
    throw new Error(`Error creating Stripe subscription: ${error.message}`);
  }
}
