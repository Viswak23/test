"use server";
import { createLogger, format } from "winston";
import WinstonCloudWatch from "winston-cloudwatch";
import { customAwsExports, LogLevel } from "../../amplifyConfig";

//extract the amplify environment name so that I can group the logs for each env
const envName =
  customAwsExports.aws_cloud_logic_custom[0].endpoint.split("/")[3];
const logger = createLogger({
  level: "error",
  format: format.json(),
  transports: [
    new WinstonCloudWatch({
      level: `error`,
      logGroupName: `workzep-${envName}`,
      logStreamName: `${new Date().toISOString().split("T")[0]}-error`,
      awsRegion: customAwsExports.aws_project_region,
      awsOptions: {
        credentials: {
          accessKeyId: process.env.NEXT_PUBLIC_AWS_ACCESS_KEY_ID!,
          secretAccessKey: process.env.NEXT_PUBLIC_AWS_SECRET_ACCESS_KEY!,
        },
        region: customAwsExports.aws_project_region,
      },
    }),
  ],
});
export async function log(message: any, level: LogLevel = LogLevel.error) {
  switch (level) {
    case LogLevel.warn:
      logger.warn(message);
      break;
    case LogLevel.info:
      logger.info(message);
      break;
    case LogLevel.debug:
      logger.debug(message);
      break;
    case LogLevel.error:
    default:
      logger.error(message);
      break;
  }
}
