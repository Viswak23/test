import { NorthStar } from "@/src/API";
import { withSSRContext } from "aws-amplify";
import { GRAPHQL_AUTH_MODE } from "@aws-amplify/api";
import { listNorthStars, northStarByCompany } from "@/src/graphql/queries";
import { ReqInterface } from "./getData";
import { log } from "./actions/logger";
import { getCompanyId } from "../webHelpers";

export async function getNorthStars(req: ReqInterface): Promise<NorthStar[]> {
  const SSR = withSSRContext({ req });

  try {
    const response = await SSR.API.graphql({
      variables: {
        companyId: await getCompanyId(req),
      },
      query: northStarByCompany,
      authMode: GRAPHQL_AUTH_MODE.AMAZON_COGNITO_USER_POOLS,
    });
    return response.data.northStarByCompany.items;
  } catch (error: any) {
    log(`getNorthStars: ${error.message}`);
    console.error("Error while fetching north stars: ", error);
    return [];
  }
}
