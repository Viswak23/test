import { Employee, OrganizationUnitEmployeeJoin } from "@/src/API";
import { withSSRContext } from "aws-amplify";
import { GRAPHQL_AUTH_MODE } from "@aws-amplify/api";
import {
  employeeByCompany,
  getEmployee,
  listEmployees,
  listOrganizationUnitEmployeeJoins,
  organizationUnitEmployeeJoinByCompany,
} from "@/src/graphql/queries";
import { ReqInterface } from "./getData";
import { log } from "./actions/logger";
import { getCompanyId } from "../webHelpers";

export async function getEmployeeById(
  id: string,
  req: ReqInterface
): Promise<Employee | undefined> {
  const SSR = withSSRContext({ req });

  try {
    const response = await SSR.API.graphql({
      query: getEmployee,
      variables: { id },
      authMode: GRAPHQL_AUTH_MODE.AMAZON_COGNITO_USER_POOLS,
    });
    return response.data.getEmployee;
  } catch (error: any) {
    log(`GetEmployeeById: ${error.message}`);
    console.error("Error while fetching employee: ", error);
    return undefined;
  }
}

export async function getEmployeeByEmail(
  email: string,
  req: ReqInterface
): Promise<Employee | undefined> {
  const SSR = withSSRContext({ req });

  try {
    const response = await SSR.API.graphql({
      query: listEmployees,
      variables: { filter: { email: { eq: email } } },
      authMode: GRAPHQL_AUTH_MODE.AMAZON_COGNITO_USER_POOLS,
    });

    if (response.data.listEmployees.items.length === 0) {
      return undefined;
    }

    return response.data.listEmployees.items[0];
  } catch (error: any) {
    log(`GetEmployeeByEmail: ${error.message}`);
    console.error("Error while fetching employee: ", error);
    return undefined;
  }
}

export async function getEmployees(req: ReqInterface): Promise<Employee[]> {
  const SSR = withSSRContext({ req });

  try {
    const response = await SSR.API.graphql({
      variables: {
        companyId: await getCompanyId(req),
      },
      query: employeeByCompany,
      authMode: GRAPHQL_AUTH_MODE.AMAZON_COGNITO_USER_POOLS,
    });
    return response.data.employeeByCompany.items;
  } catch (error: any) {
    log(`GetEmployees: ${error.message}`);
    console.error("Error while fetching employees: ", error);
    return [];
  }
}

export async function getOrganizationUnitEmployeeJoins(
  req: ReqInterface
): Promise<OrganizationUnitEmployeeJoin[]> {
  const SSR = withSSRContext({ req });

  try {
    const response = await SSR.API.graphql({
      variables: {
        companyId: await getCompanyId(req),
      },
      query: organizationUnitEmployeeJoinByCompany,
      authMode: GRAPHQL_AUTH_MODE.AMAZON_COGNITO_USER_POOLS,
    });

    return response.data.organizationUnitEmployeeJoinByCompany.items;
  } catch (error: any) {
    log(`getOrganizationUnitEmployeeJoins: ${error.message}`);
    console.error(
      "Error while fetching Organization unit employee joins: ",
      error
    );
    return [];
  }
}
