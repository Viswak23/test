import { withSSRContext } from "aws-amplify";
import { GRAPHQL_AUTH_MODE } from "@aws-amplify/api";
import {
  listOrganizationUnitsWithEmployees,
} from "@/src/graphql/custom-queries";
import { OrganizationUnit } from "@/src/API";
import { ReqInterface } from "./getData";
import { log } from "./actions/logger";
import { getCompanyId } from "../webHelpers";

export async function getOrganization(
  req: ReqInterface
): Promise<OrganizationUnit[]> {
  const SSR = withSSRContext({ req });

  try {
    const response = await SSR.API.graphql({
      variables: {
        companyId: await getCompanyId(req),
      },
      query: listOrganizationUnitsWithEmployees,
      authMode: GRAPHQL_AUTH_MODE.AMAZON_COGNITO_USER_POOLS,
    });
    return response.data.organizationUnitByCompany.items;
  } catch (error: any) {
    log(`getOrganization: ${error.message}`);
    console.error("Error while fetching organization list: ", error);
    return [];
  }
}
