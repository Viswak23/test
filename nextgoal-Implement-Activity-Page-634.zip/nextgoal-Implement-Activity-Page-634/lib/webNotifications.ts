import {
  CreateNotificationInput,
  CreateNotificationMutation,
  Employee,
  UpdateNotificationInput,
} from "@/src/API";
import { EventType } from "./webEvents";
import {
  createApiRequest,
  getCompanyId,
  pushNotificationToSNS,
} from "./webHelpers";
import {
  createNotification,
  updateNotification,
} from "@/src/graphql/mutations";
import { log } from "./backend/actions/logger";
import { EmployeeWithAvatarUrl } from "@/contexts/EmployeesContext";
import { PublishCommandInput } from "@aws-sdk/client-sns";
import TranslationService from "./services/TranslationService";
import { getPlatformIntegrationData } from "./webPlatformIntegration";
import { SupportedLanguages } from "./localisation";

export enum NotificationType {
  COMMENT = "COMMENT",
  REPLY = "REPLY",
  LIKE = "LIKE",
  MENTION = "MENTION",
  NORTHSTAR_ADDED = "NORTHSTAR_ADDED",
}

async function createNotificationDb(
  notificationObject: CreateNotificationInput
) {
  try {
    return createApiRequest<CreateNotificationMutation>(
      createNotification,
      notificationObject,
      "createNotification"
    );
  } catch (error: any) {
    log("Error creating notification DB" + error.message);
  }
}
export async function updateReadStatusDb(
  notification: UpdateNotificationInput
) {
  try {
    await createApiRequest(
      updateNotification,
      notification,
      "onUpdateNotification"
    );
  } catch (error: any) {
    log("Error updating notification read status" + error.message);
  }
}
export async function createNewNotification(
  notificationType: NotificationType | EventType,
  employees?: (EmployeeWithAvatarUrl | undefined | null)[],
  currentEmployeeEmail?: string,
  eventId?: string | null,
  goalId?: string | null
) {
  const notificationExpire = 604800; //7 days in ms
  try {
    const companyId = await getCompanyId();
    //if reply, only create one notification for the comment owner
    if (employees && employees.length == 0) return;
    employees?.map(async (employee) => {
      //don't create a notification to the person who made it.

      if (employee?.email !== currentEmployeeEmail) {
        const newNotification: CreateNotificationInput = {
          type: "Notification",
          notificationType: notificationType,
          companyId: companyId,
          toEmployeeEmail: employee?.email,
          isRead: false,
          eventId: eventId || null,
          goalId: goalId || null,
          expireAt:
            Math.floor(new Date().getTime() / 1000.0) + notificationExpire, // current time plus 7 days in unix format
        };
        await createNotificationDb(newNotification);
      }
    });

    const currentEmployee = employees?.find(
      (employee) => employee?.email === currentEmployeeEmail
    );

    if (currentEmployee) {
      const notiLanguage = currentEmployee.language ?? SupportedLanguages.EN;

      const { title, description } = getNotificationInfo(
        notificationType,
        currentEmployee,
        notiLanguage
      );
      const integrations = await getPlatformIntegrationData(companyId);
      if (!integrations || integrations.length === 0) {
        return;
      }

      const link = eventId
        ? `${process.env.NEXT_PUBLIC_URL}/${notiLanguage}/feeds/${eventId}`
        : goalId
        ? `${process.env.NEXT_PUBLIC_URL}/${notiLanguage}/goal/${goalId}`
        : process.env.NEXT_PUBLIC_URL;
      for (const integration of integrations) {
        await publishNotification(
          companyId,
          `${title}\n${description}\n${TranslationService.getInstance(
            notiLanguage
          ).formatMessage({ id: "integration.further.info" })}`,
          encodeURIComponent(link!),
          integration.platform
        );
      }
    }
  } catch (error: any) {
    log("Error creating notification" + error.message);
  }
}

export function getNotificationInfo(
  notificationType: NotificationType | EventType,
  fromEmployee: Employee,
  locale: string
) {
  const intl = TranslationService.getInstance(locale);
  switch (notificationType) {
    case NotificationType.COMMENT:
      return {
        title: intl.formatMessage({ id: "notifications.comment.title" }),
        description: intl.formatMessage(
          { id: "notifications.comment.body" },
          { name: fromEmployee.name }
        ),
      };
    case NotificationType.LIKE:
      return {
        title: intl.formatMessage({ id: "notifications.like.title" }),
        description: intl.formatMessage(
          { id: "notifications.like.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.CONTRIBUTION_ADDED:
      return {
        title: intl.formatMessage({ id: "notifications.contribution.title" }),
        description: intl.formatMessage(
          { id: "notifications.contribution.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.GOAL_ADDED:
      return {
        title: intl.formatMessage({ id: "notifications.goal.added.title" }),
        description: intl.formatMessage(
          { id: "notifications.goal.added.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.GOAL_CLOSED:
      return {
        title: intl.formatMessage({ id: "notifications.goal.closed.title" }),
        description: intl.formatMessage(
          { id: "notifications.goal.closed.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.GOAL_OPENED:
      return {
        title: intl.formatMessage({ id: "notifications.goal.reopen.title" }),
        description: intl.formatMessage(
          { id: "notifications.goal.reopen.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.HELP_REQUEST_ADDED:
      return {
        title: intl.formatMessage({
          id: "notifications.helprequest.added.title",
        }),
        description: intl.formatMessage(
          { id: "notifications.helprequest.added.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.HELP_REQUEST_REOPENED:
      return {
        title: intl.formatMessage({
          id: "notifications.helprequest.reopened.title",
        }),
        description: intl.formatMessage(
          { id: "notifications.helprequest.reopened.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.HELP_REQUEST_RESOLVED:
      return {
        title: intl.formatMessage({
          id: "notifications.helprequest.resolved.title",
        }),
        description: intl.formatMessage(
          { id: "notifications.helprequest.resolved.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.IDEA_ADDED:
      return {
        title: intl.formatMessage({
          id: "notifications.idea.added.title",
        }),
        description: intl.formatMessage(
          { id: "notifications.idea.added.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.KEY_RESULT_ADDED:
      return {
        title: intl.formatMessage({
          id: "notifications.keyresult.added.title",
        }),
        description: intl.formatMessage(
          { id: "notifications.keyresult.added.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.KEY_RESULT_UPDATE_ADDED:
      return {
        title: intl.formatMessage({
          id: "notifications.keyresult.update.added.title",
        }),
        description: intl.formatMessage(
          { id: "notifications.keyresult.update.added.body" },
          { name: fromEmployee.name }
        ),
      };
    case NotificationType.MENTION:
      return {
        title: intl.formatMessage({
          id: "notifications.mention.title",
        }),
        description: intl.formatMessage(
          { id: "notifications.mention.body" },
          { name: fromEmployee.name }
        ),
      };
    case NotificationType.REPLY:
      return {
        title: intl.formatMessage({
          id: "notifications.reply.title",
        }),
        description: intl.formatMessage(
          { id: "notifications.reply.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.RED_FLAG_ADDED:
      return {
        title: intl.formatMessage({
          id: "notifications.redflag.added.title",
        }),
        description: intl.formatMessage(
          { id: "notifications.redflag.added.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.RED_FLAG_REOPENED:
      return {
        title: intl.formatMessage({
          id: "notifications.redflag.reopened.title",
        }),
        description: intl.formatMessage(
          { id: "notifications.redflag.reopened.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.RED_FLAG_RESOLVED:
      return {
        title: intl.formatMessage({
          id: "notifications.redflag.resolved.title",
        }),
        description: intl.formatMessage(
          { id: "notifications.redflag.resolved.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.STATUS_ADDED:
      return {
        title: intl.formatMessage({
          id: "notifications.status.added.title",
        }),
        description: intl.formatMessage(
          { id: "notifications.status.added.body" },
          { name: fromEmployee.name }
        ),
      };
    case EventType.SUCCESS_STORY_ADDED:
      return {
        title: intl.formatMessage({
          id: "notifications.success.story.added.title",
        }),
        description: intl.formatMessage(
          { id: "notifications.success.story.body" },
          { name: fromEmployee.name }
        ),
      };
    case NotificationType.NORTHSTAR_ADDED:
      return {
        title: intl.formatMessage({
          id: "notifications.northstar.added.title",
        }),
        description: intl.formatMessage(
          { id: "notifications.northstar.added.body" },
          { name: fromEmployee.name }
        ),
      };
    default:
      throw new Error(`Unhandled action type: ${notificationType}`);
  }
}

async function publishNotification(
  companyId: string,
  content: string,
  link: string,
  platform: string
) {
  const params: PublishCommandInput = {
    Message: content,
    TopicArn: process.env.NEXT_PUBLIC_PLATFORM_NOTIFICATION_ARN,
    MessageAttributes: {
      platform: {
        DataType: "String",
        StringValue: platform,
      },
      companyId: {
        DataType: "String",
        StringValue: companyId,
      },
      link: {
        DataType: "String",
        StringValue: link,
      },
    },
  };
  try {
    await pushNotificationToSNS(params);
  } catch (error: any) {
    log(
      `Failed to push notification to SNS webNotification: ${JSON.stringify(
        error
      )} ${JSON.stringify(params)} `
    );
    throw new Error(
      `Failed to push notification to SNS webNotification: ${error} ${JSON.stringify(
        params
      )}`
    );
  }
}
