import { createIntl, createIntlCache } from "react-intl";
import en from "@/languages/en.json";
import fi from "@/languages/fi.json";
import es from "@/languages/es.json";

// Cache is optional but recommended for performance
const cache = createIntlCache();

class TranslationService {
  private static instance: TranslationService;
  private intl: any;

  private constructor(locale: string) {
    const messages = { en, fi, es };
    this.intl = createIntl({
      locale: locale,
      messages: (messages as any)[locale],
    }, cache);
  }

  public static getInstance(locale: string): TranslationService {
    if (!TranslationService.instance || TranslationService.instance.intl != locale) {
      TranslationService.instance = new TranslationService(locale);
    }
    return TranslationService.instance;
  }

  public formatMessage(descriptor: { id: string }, values: any = {}) {
    return this.intl.formatMessage(descriptor, values);
  }
}

export default TranslationService;
