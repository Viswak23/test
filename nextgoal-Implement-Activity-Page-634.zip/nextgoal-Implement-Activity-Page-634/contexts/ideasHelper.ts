import {
  useEffect,
  Dispatch,
} from "react";
import { GraphQLSubscription } from "@aws-amplify/api";
import { OnCreateIdeaEmployeeJoinSubscription, OnCreateIdeaSubscription, OnDeleteIdeaEmployeeJoinSubscription, OnDeleteIdeaSubscription, OnUpdateIdeaSubscription } from "@/src/API";
import * as subscriptions from "@/src/graphql/subscriptions";
import { API, graphqlOperation } from "aws-amplify";

// Subscribe Idea updates
export const useIdeasUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnCreateIdeaSubscription>>(
      graphqlOperation(subscriptions.onCreateIdea)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "ideaAdded", newIdea: value.data?.onCreateIdea });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateIdeaSubscription>>(
      graphqlOperation(subscriptions.onUpdateIdea)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "ideaUpdated", updatedIdea: value.data?.onUpdateIdea });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnDeleteIdeaSubscription>>(
      graphqlOperation(subscriptions.onDeleteIdea)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "ideaDeleted", deletedIdea: value.data?.onDeleteIdea });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  // We need to listen the joins as well. They are modified separately from the idea.
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnCreateIdeaEmployeeJoinSubscription>>(
      graphqlOperation(subscriptions.onCreateIdeaEmployeeJoin)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "ideaEmployeeJoinAdded", newEmployeeJoin: value.data?.onCreateIdeaEmployeeJoin });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnDeleteIdeaEmployeeJoinSubscription>>(
      graphqlOperation(subscriptions.onDeleteIdeaEmployeeJoin)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "ideaEmployeeJoinDeleted", deletedEmployeeJoin: value.data?.onDeleteIdeaEmployeeJoin });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
}
