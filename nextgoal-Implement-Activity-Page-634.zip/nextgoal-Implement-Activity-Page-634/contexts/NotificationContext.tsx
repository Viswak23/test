"use client";

import { createContext, useContext, Dispatch, useEffect } from "react";
import { useImmerReducer } from "use-immer";
import {
  Notification,
  OnCreateNotificationSubscription,
  OnUpdateNotificationSubscription,
} from "@/src/API";
import { GraphQLSubscription } from "@aws-amplify/api";
import * as subscriptions from "@/src/graphql/subscriptions";
import { API, graphqlOperation } from "aws-amplify";
import { useAuthStatus } from "@/lib/customHooks";

const NotificationsContext = createContext<NotificationsState | null>(null);
const NotificationsDispatchContext = createContext<React.Dispatch<any> | null>(
  null
);

interface NotificationsState {
  notifications: Notification[];
}

interface NotificationsProviderProps {
  children: React.ReactNode;
  initialState: NotificationsState;
}

// Use subscriptions to update the notifications list.
const useNotificationUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  const currentUserEmail = useAuthStatus().attributes.email;
  useEffect(() => {
    const sub = API.graphql<
      GraphQLSubscription<OnCreateNotificationSubscription>
    >(graphqlOperation(subscriptions.onCreateNotification)).subscribe({
      next: ({ value }) => {
        if (currentUserEmail != value.data?.onCreateNotification?.owner)
          //dont update the state when the creator of the notification is the same user.
          dispatch({
            type: "addNotification",
            newNotification: value.data?.onCreateNotification,
          });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch, currentUserEmail]);
  useEffect(() => {
    const sub = API.graphql<
      GraphQLSubscription<OnUpdateNotificationSubscription>
    >(graphqlOperation(subscriptions.onUpdateNotification)).subscribe({
      next: ({ value }) => {
        if (currentUserEmail != value.data?.onUpdateNotification?.owner)
          dispatch({
            type: "updateNotification",
            updatedNotification: value.data?.onUpdateNotification,
          });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch, currentUserEmail]);
};

export function NotificationsProvider({
  children,
  initialState,
}: NotificationsProviderProps) {
  const [notifications, dispatch] = useImmerReducer(
    NotificationsReducer,
    initialState
  );
  useNotificationUpdatesSubscriptions(dispatch);

  return (
    <NotificationsContext.Provider value={notifications}>
      <NotificationsDispatchContext.Provider value={dispatch}>
        {children}
      </NotificationsDispatchContext.Provider>
    </NotificationsContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationsContext);
  if (context === undefined) {
    throw new Error(
      "useNotifications must be used within a NotificationsProvider"
    );
  }
  return context;
}

export function useNotificationsDispatch() {
  const context = useContext(NotificationsDispatchContext);
  if (context === undefined) {
    throw new Error(
      "useNotificationsDispatch must be used within a NotificationsProvider"
    );
  }
  return context;
}

function NotificationsReducer(draft: NotificationsState, action: any) {
  switch (action.type) {
    case "addNotification":
      draft.notifications.unshift(action.newNotification);
      break;
    case "updateNotification":
      draft.notifications = draft.notifications.map((notification) =>
        notification.id === action.updatedNotification.id
          ? action.updatedNotification
          : notification
      );
      break;
    default:
      throw new Error(`Unhandled action type: ${action.type}`);
  }
}
