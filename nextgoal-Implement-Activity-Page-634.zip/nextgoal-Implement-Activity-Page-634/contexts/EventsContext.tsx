"use client";

import { createContext, useContext, Dispatch, useEffect } from "react";
import { useImmerReducer } from "use-immer";
import {
  Event,
  OnCreateEventSubscription,
  OnDeleteEventSubscription,
  OnUpdateEventSubscription,
} from "@/src/API";
import { GraphQLSubscription } from "@aws-amplify/api";
import * as subscriptions from "@/src/graphql/subscriptions";
import { API, graphqlOperation } from "aws-amplify";

const EventsContext = createContext<EventsState | null>(null);
const EventsDispatchContext = createContext<React.Dispatch<any> | null>(null);

interface EventsState {
  events: Event[];
  currentEvent: Event | null;
}

interface EventsProviderProps {
  children: React.ReactNode;
  initialState: EventsState;
}

// Use subscriptions to update the events list.
const useEventUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnCreateEventSubscription>>(
      graphqlOperation(subscriptions.onCreateEvent)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "addEvent", newEvent: value.data?.onCreateEvent });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateEventSubscription>>(
      graphqlOperation(subscriptions.onUpdateEvent)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "updateEvent",
          updatedEvent: value.data?.onUpdateEvent,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnDeleteEventSubscription>>(
      graphqlOperation(subscriptions.onDeleteEvent)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "deleteEvent",
          deletedEvent: value.data?.onDeleteEvent,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
};

export function EventsProvider({
  children,
  initialState,
}: EventsProviderProps) {
  const [events, dispatch] = useImmerReducer(eventsReducer, initialState);
  useEventUpdatesSubscriptions(dispatch);

  return (
    <EventsContext.Provider value={events}>
      <EventsDispatchContext.Provider value={dispatch}>
        {children}
      </EventsDispatchContext.Provider>
    </EventsContext.Provider>
  );
}

export function useEvents() {
  const context = useContext(EventsContext);
  if (context === undefined) {
    throw new Error("useEvents must be used within a EventsProvider");
  }
  return context;
}

export function useEventsDispatch() {
  const context = useContext(EventsDispatchContext);
  if (context === undefined) {
    throw new Error("useEventsDispatch must be used within a EventsProvider");
  }
  return context;
}

function eventsReducer(draft: EventsState, action: any) {
  switch (action.type) {
    case "addEvent":
      draft.events.unshift(action.newEvent);
      break;
    case "addCurrentEvent":
      draft.currentEvent = action.currentEvent;
      break;
    case "updateEvent":
      if (draft.currentEvent?.id === action.updatedEvent.id) {
        draft.currentEvent = action.updatedEvent;
      }
      draft.events = draft.events.map((event) => {
        if (event.id === action.updatedEvent.id) {
          return action.updatedEvent;
        }
        return event;
      });
      break;
    case "deleteEvent":
      draft.events = draft.events.filter(
        (event) => event.id !== action.deletedEvent.id
      );
      break;
    default:
      throw new Error(`Unhandled action type: ${action.type}`);
  }
}
