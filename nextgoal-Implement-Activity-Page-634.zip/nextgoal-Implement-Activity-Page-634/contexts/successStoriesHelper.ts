import {
  useEffect,
  Dispatch,
} from "react";
import { GraphQLSubscription } from "@aws-amplify/api";
import { OnCreateSuccessStoryEmployeeJoinSubscription, OnCreateSuccessStorySubscription, OnDeleteSuccessStoryEmployeeJoinSubscription, OnDeleteSuccessStorySubscription, OnUpdateSuccessStorySubscription } from "@/src/API";
import * as subscriptions from "@/src/graphql/subscriptions";
import { API, graphqlOperation } from "aws-amplify";

// Subscribe success story updates
export const useSuccessStoryUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  useEffect(() => {
    const sub = API.graphql<
      GraphQLSubscription<OnCreateSuccessStorySubscription>
    >(graphqlOperation(subscriptions.onCreateSuccessStory)).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "successStoryAdded",
          newSuccessStory: value.data?.onCreateSuccessStory,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<
      GraphQLSubscription<OnUpdateSuccessStorySubscription>
    >(graphqlOperation(subscriptions.onUpdateSuccessStory)).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "successStoryUpdated",
          updatedSuccessStory: value.data?.onUpdateSuccessStory,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<
      GraphQLSubscription<OnDeleteSuccessStorySubscription>
    >(graphqlOperation(subscriptions.onDeleteSuccessStory)).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "successStoryDeleted",
          deletedSuccessStory: value.data?.onDeleteSuccessStory,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  // We need to listen the joins as well. They are modified separately from the success story.
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnCreateSuccessStoryEmployeeJoinSubscription>>(
      graphqlOperation(subscriptions.onCreateSuccessStoryEmployeeJoin)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "successStoryEmployeeAdded", newEmployeeJoin: value.data?.onCreateSuccessStoryEmployeeJoin });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnDeleteSuccessStoryEmployeeJoinSubscription>>(
      graphqlOperation(subscriptions.onDeleteSuccessStoryEmployeeJoin)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "successStoryEmployeeDeleted", deletedEmployeeJoin: value.data?.onDeleteSuccessStoryEmployeeJoin });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
}
