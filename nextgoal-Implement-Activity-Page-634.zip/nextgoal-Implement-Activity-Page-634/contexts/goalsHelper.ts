import { useEffect, Dispatch } from "react";
import {
  Goal,
  Comment,
  Status,
  RedFlag,
  SuccessStory,
  KeyResult,
  Task,
  Contribution,
  OnDeleteGoalSubscription,
  Idea,
  HelpRequest,
} from "@/src/API";
import * as _ from "lodash";
import { OnCreateGoalSubscription, OnUpdateGoalSubscription } from "@/src/API";
import { GraphQLSubscription } from "@aws-amplify/api";
import * as subscriptions from "@/src/graphql/subscriptions";
import { API, graphqlOperation } from "aws-amplify";
import { EmployeeJoin } from "@/lib/webEmployee";

export interface GoalsState {
  goals: Goal[];
  archivedGoals: Goal[];
}

export enum subItemFields {
  comments = "comments",
  status = "status",
  redFlags = "redFlags",
  successStories = "successStories",
  keyResults = "keyResults",
  tasks = "tasks",
  contributions = "contributions",
  ideas = "ideas",
  helpRequests = "helpRequests",
}

export enum subItemFieldsWithEmployeeJoins {
  ideas = "ideas",
  successStories = "successStories",
  contributions = "contributions",
  helpRequests = "helpRequests",
}

export type SubItemType =
  | Comment
  | Status
  | RedFlag
  | SuccessStory
  | KeyResult
  | Task
  | Contribution
  | HelpRequest
  | Idea
  | null;
export type SubItemTypeWithEmployeeJoins =
  | Idea
  | SuccessStory
  | Contribution
  | HelpRequest
  | null;

// Use subscriptions to update the goals state after a goal is created or updated,
export const useGoalUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnCreateGoalSubscription>>(
      graphqlOperation(subscriptions.onCreateGoal)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "add", newGoal: value.data?.onCreateGoal });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateGoalSubscription>>(
      graphqlOperation(subscriptions.onUpdateGoal)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "update", updatedGoal: value.data?.onUpdateGoal });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnDeleteGoalSubscription>>(
      graphqlOperation(subscriptions.onDeleteGoal)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "delete", deletedGoal: value.data?.onDeleteGoal });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
};

export function getGoalFromState(draft: GoalsState, goalId: string): Goal {
  const goal = [...draft.archivedGoals, ...draft.goals].find(
    (goal) => goal.id === goalId
  );
  return goal!;
}

// Filter subitem away from the result set
function filterItem<T extends SubItemType>(
  items: (T | null)[],
  id?: string
): (T | null)[] | undefined {
  return items.filter((item) => item!.id !== id);
}

// Add a new subitem to the goal and returns a new deep copy goal object.
export function addSubitemToGoal(
  goal: Goal,
  subItemField: subItemFields,
  subItem: SubItemType
) {
  (goal[subItemField]!.items as (SubItemType | null)[]) = [
    subItem,
    ...(goal[subItemField]?.items || []),
  ];
}

// Update a subitem to the goal and returns a new deep copy goal object.
export function updateSubitemToGoal<T extends SubItemType>(
  goal: Goal,
  subItemField: subItemFields,
  subItem: T
) {
  goal[subItemField]!.items = goal[subItemField]!.items.map((item) => {
    let tempSubItem = { ...subItem };
    if (item!.id! === (subItem as any).id) {
      // Restore replies for comments
      if ((item as any).replies != null) {
        (tempSubItem as Comment)!.replies = (item as Comment).replies;
      }
      // Restore comments for subitem
      if ((item as any).comments != null) {
        (tempSubItem as any).comments = (item as any).comments;
      }
      // Restore updates for key results
      if ((item as any).updates != null) {
        (tempSubItem as any).updates = (item as any).updates;
      }
      // Restore employee joins for subitem
      if ((item as any).employeeJoins != null) {
        (tempSubItem as any).employeeJoins = (item as any).employeeJoins;
      }
      return tempSubItem as any;
    }
    return item;
  });
}

// Delete a subitem from the goal and return a new deep copy of the goal object.
export function deleteSubitemFromGoal<T extends SubItemType>(
  goal: Goal,
  subItemField: subItemFields,
  subItem: T
) {
  if (!goal || !goal[subItemField] || !goal[subItemField]?.items || !subItem) {
    return;
  }

  const result = filterItem<T>(
    goal[subItemField]!.items as (T | null)[],
    subItem.id
  );
  goal[subItemField]!.items = result as any;
}

// Add a subitem both to the current goal and to the goals list.
export function addSubitemToCurrentGoalAndToGoalsList(
  state: GoalsState,
  subItemField: subItemFields,
  subItem: SubItemType,
  goalId: string
) {
  const goal = getGoalFromState(state, goalId);
  addSubitemToGoal(goal, subItemField, subItem);
}

// Update subitem to both the current goal and to the goals list.
export function updateSubitemToCurrentGoalAndToGoalsList(
  state: GoalsState,
  subItemField: subItemFields,
  subItem: SubItemType,
  goalId: string
) {
  const goal = getGoalFromState(state, goalId);
  updateSubitemToGoal(goal, subItemField, subItem);
}

// Delete a subitem from both the current goal and to the goals list.
export function deleteSubitemFromCurrentGoalAndFromGoalsList(
  state: GoalsState,
  subItemField: subItemFields,
  subItem: SubItemType,
  goalId: string
) {
  const goal = getGoalFromState(state, goalId);
  deleteSubitemFromGoal(goal, subItemField, subItem);
}

// Apply updates to the goal.
// XXX: This is a bit tricky while you have to remember to update this when ever making the changes to the goal.
// But the goal does have properties that are not coming through the websockets (deeply nested properties, like comments, replies, etc.).
export function updateGoal(goal: Goal, updatedGoal: any) {
  const newGoal = _.cloneDeep(goal);
  return {
    ...newGoal,
    title: updatedGoal.title,
    description: updatedGoal.description,
    useTasks: updatedGoal.useTasks,
    reward: updatedGoal.reward,
    startDate: updatedGoal.startDate,
    targetDate: updatedGoal.targetDate,
    updatedAt: updatedGoal.updatedAt,
    isClosed: updatedGoal.isClosed,
    statusFlag: updatedGoal.statusFlag,
    closingNotes: updatedGoal.closingNotes,
  };
}

// Add a employeeJoin to the subitem (idea, contribution, ...)
export function addEmployeeJoinToCurrentGoalAndToGoalsList(
  state: GoalsState,
  subItemField: subItemFieldsWithEmployeeJoins,
  subItem: EmployeeJoin,
  goalId: string
) {
  const goal = getGoalFromState(state, goalId);
  addEmployeeJoinToGoal(goal, subItemField, subItem);
}

// Add a EmployeeJoin to the given goal's given subitem.
// Add a new subitem to the goal and returns a new deep copy goal object.
export function addEmployeeJoinToGoal<T extends EmployeeJoin>(
  goal: Goal,
  subItemField: subItemFieldsWithEmployeeJoins,
  subItem: T
) {
  if (!goal[subItemField] || !subItem || !goal[subItemField]!.items) {
    return;
  }

  const idField = getJoinSubitemIdField(subItemField);
  if (idField === "Unknown field") {
    return;
  }

  // Find the subitem from the goal
  // XXX: any casts are made because could not find in reasonable time how to make the types work
  const subItems = goal[subItemField]!.items as any[];
  const oldSub = subItems.find(
    (item) => item?.id === (subItem as any)[idField]
  );
  const sub = _.cloneDeep(oldSub);

  if (!sub) {
    return;
  }
  // Check that the join is not already there
  if (sub.employeeJoins?.items?.find((join: any) => join?.id === subItem?.id)) {
    return;
  }

  // Add the join to the subitem
  sub.employeeJoins = {
    ...sub.employeeJoins!,
    items: [subItem as any, ...(sub.employeeJoins?.items || [])],
  };

  goal[subItemField]!.items = goal[subItemField]?.items.map((item) => {
    if (item?.id === sub?.id) {
      return sub;
    }
    return item;
  }) as any;
}

function getJoinSubitemIdField(subItemField: subItemFieldsWithEmployeeJoins) {
  switch (subItemField) {
    case subItemFieldsWithEmployeeJoins.ideas:
      return "ideaEmployeeJoinsId";
    case subItemFieldsWithEmployeeJoins.contributions:
      return "contributionEmployeeJoinsId";
    case subItemFieldsWithEmployeeJoins.successStories:
      return "successStoryEmployeeJoinsId";
    case subItemFieldsWithEmployeeJoins.helpRequests:
      return "helpRequestEmployeeJoinsId";
    default:
      return "Unknown field";
  }
}

// Delete a employeeJoin from the subitem (idea, contribution, ...)
export default function deleteEmployeeJoinFromCurrentGoalAndFromGoalsList(
  state: GoalsState,
  subItemField: subItemFieldsWithEmployeeJoins,
  subItem: EmployeeJoin,
  goalId: string
) {
  const goal = getGoalFromState(state, goalId);
  deleteEmployeeJoinFromGoal(goal, subItemField, subItem);
}

// Filter subitem away from the result set
function filterEmployeeJoinItem<T extends EmployeeJoin>(
  items: (T | null)[],
  id?: string
): (T | null)[] | undefined {
  return items.filter((item) => item!.id !== id);
}

// Deletes an employee join from a given goal's given subitem.
function deleteEmployeeJoinFromGoal<T extends EmployeeJoin>(
  goal: Goal,
  subItemField: subItemFieldsWithEmployeeJoins,
  subItem: T
) {
  if (!goal[subItemField] || !subItem) {
    return;
  }

  const idField = getJoinSubitemIdField(subItemField);
  if (idField === "Unknown field") {
    return;
  }

  // Find the subitem from the goal
  // XXX: any casts are made because could not find in reasonable time how to make the types work
  const subItems = goal[subItemField]!.items as SubItemTypeWithEmployeeJoins[];
  const oldSub = subItems.find(
    (item) => item?.id === (subItem as any)[idField]
  );
  const sub = _.cloneDeep(oldSub);

  if (!sub) {
    return;
  }

  // Delete the join from the subitem
  sub.employeeJoins = {
    ...sub.employeeJoins!,
    items: filterEmployeeJoinItem<T>(
      sub.employeeJoins?.items as (T | null)[],
      subItem.id
    ) as any,
  };
  goal[subItemField]!.items = goal[subItemField]?.items.map((item) => {
    if (item?.id === sub?.id) {
      return sub;
    }
    return item;
  }) as any;
}
