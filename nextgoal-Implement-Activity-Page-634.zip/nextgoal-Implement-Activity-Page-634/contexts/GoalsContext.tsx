"use client";

import { createContext, useContext } from "react";
import { useImmerReducer } from "use-immer";
import * as _ from "lodash";
import deleteEmployeeJoinFromCurrentGoalAndFromGoalsList, {
  GoalsState,
  subItemFields,
  addSubitemToCurrentGoalAndToGoalsList,
  updateSubitemToCurrentGoalAndToGoalsList,
  deleteSubitemFromCurrentGoalAndFromGoalsList,
  updateGoal,
  useGoalUpdatesSubscriptions,
  addEmployeeJoinToCurrentGoalAndToGoalsList,
  subItemFieldsWithEmployeeJoins,
} from "./goalsHelper";
import {
  addCommentToGoal,
  deleteCommentFromGoal,
  updateCommentToGoal,
  useCommentsUpdatesSubscriptions,
} from "./commentsHelper";
import {
  addKeyResultUpdateToState,
  deleteKeyResultUpdateFromState,
  updateKeyResultUpdateToState,
} from "./keyResultHelper";
import { useTasksUpdatesSubscriptions } from "./tasksHelper";
import { useKeyresultsUpdatesSubscriptions } from "./keyResultHelper";
import { useContributionsUpdatesSubscriptions } from "./contributionsHelper";
import { useRedFlagsUpdatesSubscriptions } from "./redFlagsHelper";
import { useStatusUpdatesSubscriptions } from "./statusesHelper";
import { useSuccessStoryUpdatesSubscriptions } from "./successStoriesHelper";
import { useIdeasUpdatesSubscriptions } from "./ideasHelper";
import { useHelpRequestsUpdatesSubscriptions } from "./helpRequestsHelper";

const GoalsContext = createContext<GoalsState | null>(null);
const GoalsDispatchContext = createContext<React.Dispatch<any> | null>(null);

interface GoalsProviderProps {
  children: React.ReactNode;
  initialState: GoalsState;
}

export function GoalsProvider({ children, initialState }: GoalsProviderProps) {
  const [goals, dispatch] = useImmerReducer(goalsReducer, initialState);
  useGoalUpdatesSubscriptions(dispatch);
  useTasksUpdatesSubscriptions(dispatch);
  useKeyresultsUpdatesSubscriptions(dispatch);
  useCommentsUpdatesSubscriptions(dispatch);
  useContributionsUpdatesSubscriptions(dispatch);
  useRedFlagsUpdatesSubscriptions(dispatch);
  useStatusUpdatesSubscriptions(dispatch);
  useSuccessStoryUpdatesSubscriptions(dispatch);
  useIdeasUpdatesSubscriptions(dispatch);
  useHelpRequestsUpdatesSubscriptions(dispatch);

  return (
    <GoalsContext.Provider value={goals}>
      <GoalsDispatchContext.Provider value={dispatch}>
        {children}
      </GoalsDispatchContext.Provider>
    </GoalsContext.Provider>
  );
}
export function useGoals() {
  const context = useContext(GoalsContext);
  if (context === undefined) {
    throw new Error("useGoal must be used within a GoalProvider");
  }
  return context;
}
export function useGoalsDispatch() {
  const context = useContext(GoalsDispatchContext);
  if (context === undefined) {
    throw new Error("useGoalDispatch must be used within a GoalProvider");
  }
  return context;
}
// Updates are coming through the sockets. In that way we will get also the updates triggered by the other users.
function goalsReducer(draft: GoalsState, action: any) {
  switch (action.type) {
    case "add":
      draft.goals.push(action.newGoal);
      break;
    case "update":
      // We can't use updated goal received through socket while it does not contain comments, statuces etc.
      let updatedGoals = draft.goals.map((goal) => {
        if (goal.id === action.updatedGoal.id) {
          return updateGoal(goal, action.updatedGoal);
        }
        return goal;
      });
      let updatedArchive = draft.archivedGoals.map((goal) => {
        if (goal.id === action.updatedGoal.id) {
          return updateGoal(goal, action.updatedGoal);
        }
        return goal;
      });

      updatedGoals = updatedGoals.filter((goal) => {
        if (goal.isClosed) {
          updatedArchive.push(goal);
          return false;
        }
        return true;
      });
      updatedArchive = updatedArchive.filter((goal) => {
        if (!goal.isClosed) {
          updatedGoals.push(goal);
          return false;
        }
        return true;
      });
      draft.goals = updatedGoals;
      draft.archivedGoals = updatedArchive;

      break;
    case "updateArchive":
      draft.archivedGoals = action.archivedGoals;
      break;
    case "delete":
      draft.goals = draft.goals.filter(
        (goal) => goal.id !== action.deletedGoal.id
      );
      break;
    // Comments
    // added brackets to down-scope the isArchive variable
    case "commentAdded":
      addCommentToGoal(draft, {
        ...action.newComment,
      });
      break;

    case "commentUpdated":
      updateCommentToGoal(draft, {
        ...action.updatedComment,
      });
      break;

    case "commentDeleted":
      deleteCommentFromGoal(draft, { ...action.deletedComment });
      break;

    case "statusAdded":
      return addSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.status,
        action.newStatus,
        action.newStatus.goalStatusId
      );
    case "statusUpdated":
      return updateSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.status,
        action.updatedStatus,
        action.updatedStatus.goalStatusId
      );
    case "statusDeleted":
      return deleteSubitemFromCurrentGoalAndFromGoalsList(
        draft,
        subItemFields.status,
        action.deletedStatus,
        action.deletedStatus.goalStatusId
      );
    case "redFlagAdded":
      return addSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.redFlags,
        action.newRedFlag,
        action.newRedFlag.goalRedFlagsId
      );
    case "redFlagUpdated":
      return updateSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.redFlags,
        action.updatedRedFlag,
        action.updatedRedFlag.goalRedFlagsId
      );
    case "redFlagDeleted":
      return deleteSubitemFromCurrentGoalAndFromGoalsList(
        draft,
        subItemFields.redFlags,
        action.deletedRedFlag,
        action.deletedRedFlag.goalRedFlagsId
      );
    case "successStoryAdded":
      return addSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.successStories,
        action.newSuccessStory,
        action.newSuccessStory.goalSuccessStoriesId
      );
    case "successStoryUpdated":
      return updateSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.successStories,
        action.updatedSuccessStory,
        action.updatedSuccessStory.goalSuccessStoriesId
      );
    case "successStoryDeleted":
      return deleteSubitemFromCurrentGoalAndFromGoalsList(
        draft,
        subItemFields.successStories,
        action.deletedSuccessStory,
        action.deletedSuccessStory.goalSuccessStoriesId
      );
    case "successStoryEmployeeAdded":
      return addEmployeeJoinToCurrentGoalAndToGoalsList(
        draft,
        subItemFieldsWithEmployeeJoins.successStories,
        action.newEmployeeJoin,
        action.newEmployeeJoin.goalId
      );
    case "successStoryEmployeeDeleted":
      return deleteEmployeeJoinFromCurrentGoalAndFromGoalsList(
        draft,
        subItemFieldsWithEmployeeJoins.successStories,
        action.deletedEmployeeJoin,
        action.deletedEmployeeJoin.goalId
      );
    case "keyResultAdded":
      return addSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.keyResults,
        action.newKeyResult,
        action.newKeyResult.goalKeyResultsId
      );
    case "keyResultUpdated":
      return updateSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.keyResults,
        action.updatedKeyResult,
        action.updatedKeyResult.goalKeyResultsId
      );
    case "keyResultDeleted":
      return deleteSubitemFromCurrentGoalAndFromGoalsList(
        draft,
        subItemFields.keyResults,
        action.deletedKeyResult,
        action.deletedKeyResult.goalKeyResultsId
      );
    case "keyResultUpdateAdded":
      return addKeyResultUpdateToState(draft, action.newKeyResultUpdate);
    case "keyResultUpdateUpdated":
      return updateKeyResultUpdateToState(draft, action.updatedKeyResultUpdate);
    case "keyResultUpdateDeleted":
      return deleteKeyResultUpdateFromState(
        draft,
        action.deletedKeyResultUpdate
      );
    case "taskAdded":
      return addSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.tasks,
        action.newTask,
        action.newTask.goalTasksId
      );
    case "taskUpdated":
      return updateSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.tasks,
        action.updatedTask,
        action.updatedTask.goalTasksId
      );
    case "taskDeleted":
      return deleteSubitemFromCurrentGoalAndFromGoalsList(
        draft,
        subItemFields.tasks,
        action.deletedTask,
        action.deletedTask.goalTasksId
      );
    case "contributionAdded":
      return addSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.contributions,
        action.newContribution,
        action.newContribution.goalContributionsId
      );
    case "contributionUpdated":
      return updateSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.contributions,
        action.updatedContribution,
        action.updatedContribution.goalContributionsId
      );
    case "contributionDeleted":
      return deleteSubitemFromCurrentGoalAndFromGoalsList(
        draft,
        subItemFields.contributions,
        action.deletedContribution,
        action.deletedContribution.goalContributionsId
      );
    case "contributionEmployeeJoinAdded":
      return addEmployeeJoinToCurrentGoalAndToGoalsList(
        draft,
        subItemFieldsWithEmployeeJoins.contributions,
        action.newEmployeeJoin,
        action.newEmployeeJoin.goalId
      );
    case "contributionEmployeeJoinDeleted":
      return deleteEmployeeJoinFromCurrentGoalAndFromGoalsList(
        draft,
        subItemFieldsWithEmployeeJoins.contributions,
        action.deletedEmployeeJoin,
        action.deletedEmployeeJoin.goalId
      );
    case "ideaAdded":
      return addSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.ideas,
        action.newIdea,
        action.newIdea.goalIdeasId
      );
    case "ideaUpdated":
      return updateSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.ideas,
        action.updatedIdea,
        action.updatedIdea.goalIdeasId
      );
    case "ideaDeleted":
      return deleteSubitemFromCurrentGoalAndFromGoalsList(
        draft,
        subItemFields.ideas,
        action.deletedIdea,
        action.deletedIdea.goalIdeasId
      );
    case "ideaEmployeeJoinAdded":
      return addEmployeeJoinToCurrentGoalAndToGoalsList(
        draft,
        subItemFieldsWithEmployeeJoins.ideas,
        action.newEmployeeJoin,
        action.newEmployeeJoin.goalId
      );
    case "ideaEmployeeJoinDeleted":
      return deleteEmployeeJoinFromCurrentGoalAndFromGoalsList(
        draft,
        subItemFieldsWithEmployeeJoins.ideas,
        action.deletedEmployeeJoin,
        action.deletedEmployeeJoin.goalId
      );
    case "helpRequestAdded":
      return addSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.helpRequests,
        action.newHelpRequest,
        action.newHelpRequest.goalHelpRequestsId
      );
    case "helpRequestUpdated":
      return updateSubitemToCurrentGoalAndToGoalsList(
        draft,
        subItemFields.helpRequests,
        action.updatedHelpRequest,
        action.updatedHelpRequest.goalHelpRequestsId
      );
    case "helpRequestDeleted":
      return deleteSubitemFromCurrentGoalAndFromGoalsList(
        draft,
        subItemFields.helpRequests,
        action.deletedHelpRequest,
        action.deletedHelpRequest.goalHelpRequestsId
      );
    case "helpRequestEmployeeJoinAdded":
      return addEmployeeJoinToCurrentGoalAndToGoalsList(
        draft,
        subItemFieldsWithEmployeeJoins.helpRequests,
        action.newEmployeeJoin,
        action.newEmployeeJoin.goalId
      );
    case "helpRequestEmployeeJoinDeleted":
      return deleteEmployeeJoinFromCurrentGoalAndFromGoalsList(
        draft,
        subItemFieldsWithEmployeeJoins.helpRequests,
        action.deletedEmployeeJoin,
        action.deletedEmployeeJoin.goalId
      );
    default:
      throw new Error(`Unhandled action type: ${action.type}`);
  }
}
