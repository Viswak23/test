"use client";

import {
  Dispatch,
  createContext,
  useContext,
  useEffect,
} from "react";
import { useImmerReducer } from "use-immer";
import { API, graphqlOperation } from "aws-amplify";
import { GraphQLSubscription } from "@aws-amplify/api";
import {
  NorthStar,
  OnCreateNorthStarSubscription,
  OnDeleteNorthStarSubscription,
  OnUpdateNorthStarSubscription,
} from "@/src/API";
import * as subscriptions from "@/src/graphql/subscriptions";

const NorthStarsContext = createContext<NorthStarsState | null>(null);
const NorthStarsDispatchContext = createContext<React.Dispatch<any> | null>(
  null
);

export interface NorthStarsState {
  northStars: NorthStar[];
}

interface NorthStarsProviderProps {
  children: React.ReactNode;
  initialState: NorthStarsState;
}
// Use subscriptions to update north stars state after a north star is created, updated, or deleted.
const useNorthStarsUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnCreateNorthStarSubscription>>(
      graphqlOperation(subscriptions.onCreateNorthStar)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "addNorthStar",
          newNorthStar: value.data?.onCreateNorthStar,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateNorthStarSubscription>>(
      graphqlOperation(subscriptions.onUpdateNorthStar)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "updateNorthStar",
          updatedNorthStar: value.data?.onUpdateNorthStar,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnDeleteNorthStarSubscription>>(
      graphqlOperation(subscriptions.onDeleteNorthStar)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "deleteNorthStar",
          deletedNorthStar: value.data?.onDeleteNorthStar,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
};

export function NorthStarsProvider({
  children,
  initialState,
}: NorthStarsProviderProps) {
  const [northStars, dispatch] = useImmerReducer(northStarsReducer, initialState);
  useNorthStarsUpdatesSubscriptions(dispatch);

  return (
    <NorthStarsContext.Provider value={northStars}>
      <NorthStarsDispatchContext.Provider value={dispatch}>
        {children}
      </NorthStarsDispatchContext.Provider>
    </NorthStarsContext.Provider>
  );
}

export function useNorthStars() {
  const context = useContext(NorthStarsContext);
  if (context === undefined) {
    throw new Error("useNorthStars must be used within a NorthStarsProvider");
  }
  return context;
}

export function useNorthStarsDispatch() {
  const context = useContext(NorthStarsDispatchContext);
  if (context === undefined) {
    throw new Error(
      "useNorthStarsDispatch must be used within a NorthStarsProvider"
    );
  }
  return context;
}

function northStarsReducer(draft: NorthStarsState, action: any) {
  switch (action.type) {
    case "addNorthStar":
      draft.northStars.push(action.newNorthStar);
      break;
    case "updateNorthStar":
      const index = draft.northStars.findIndex(e => e.id === action.updatedNorthStar.id);
      if (index !== -1) {
        draft.northStars[index] = action.updatedNorthStar;
      }
      break;
    case "deleteNorthStar":
      draft.northStars = draft.northStars.filter(e => e.id !== action.deletedNorthStar.id);
      break;
    default:
      throw new Error(`Unhandled action type: ${action.type}`);
  }
}