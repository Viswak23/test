"use client";

import { createContext, useContext, useEffect, Dispatch } from "react";
import {
  OnCreateOrganizationUnitSubscription,
  OrganizationUnit,
} from "@/src/API";
import { GraphQLSubscription } from "@aws-amplify/api";
import * as subscriptions from "@/src/graphql/subscriptions";
import { OnUpdateOrganizationUnitSubscription } from "@/src/API";
import { API, graphqlOperation } from "aws-amplify";
import _ from "lodash";
import { useImmerReducer } from "use-immer";

interface OrganizationState {
  organization: OrganizationUnit[];
}

const OrganizationContext = createContext<OrganizationState | null>(null);
const OrganizationDispatchContext = createContext<React.Dispatch<any> | null>(
  null
);

interface OrganizationProviderProps {
  children: React.ReactNode;
  initialState: OrganizationState;
}

// Use subscriptions to update the goals state after a goal is created or updated,
// comments are added or updated, etc.
const useOrganizationUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  useEffect(() => {
    const sub = API.graphql<
      GraphQLSubscription<OnCreateOrganizationUnitSubscription>
    >(graphqlOperation(subscriptions.onCreateOrganizationUnit)).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "add",
          newOrganizationUnit: value.data?.onCreateOrganizationUnit,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<
      GraphQLSubscription<OnUpdateOrganizationUnitSubscription>
    >(graphqlOperation(subscriptions.onUpdateOrganizationUnit)).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "update",
          updatedOrganizationUnit: value.data?.onUpdateOrganizationUnit,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
};

export function OrganizationProvider({
  children,
  initialState,
}: OrganizationProviderProps) {
  const [goals, dispatch] = useImmerReducer(organizationReducer, initialState);
  useOrganizationUpdatesSubscriptions(dispatch);

  return (
    <OrganizationContext.Provider value={goals}>
      <OrganizationDispatchContext.Provider value={dispatch}>
        {children}
      </OrganizationDispatchContext.Provider>
    </OrganizationContext.Provider>
  );
}

export function useOrganization() {
  const context = useContext(OrganizationContext);
  if (context === undefined) {
    throw new Error(
      "useOrganization must be used within a OrganizationProvider"
    );
  }
  return context;
}

export function useOrganizationDispatch() {
  const context = useContext(OrganizationDispatchContext);
  if (context === undefined) {
    throw new Error(
      "useOrganizationDispatch must be used within a OrganizationProvider"
    );
  }
  return context;
}

function organizationReducer(draft: OrganizationState, action: any) {
  switch (action.type) {
    case "add":
      draft.organization.push(action.newOrganizationUnit);
      break;
    case "update":
      const index = draft.organization.findIndex(
        (org) => org.id === action.updatedOrganizationUnit.id
      );
      if (index !== -1) {
        draft.organization[index] = action.updatedOrganizationUnit;
      }
      break;
    case "delete":
      draft.organization = draft.organization.filter(
        (org) => org.id !== action.deletedOrganizationUnitId
      );
      break;
    default:
      throw new Error(`Unhandled action type: ${action.type}`);
  }
}
