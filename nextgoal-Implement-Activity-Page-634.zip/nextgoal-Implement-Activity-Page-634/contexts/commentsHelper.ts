import {
  Comment,
  Contribution,
  Goal,
  HelpRequest,
  Idea,
  KeyResult,
  OnDeleteCommentSubscription,
  RedFlag,
  Status,
  SuccessStory,
  Task,
} from "@/src/API";
import {
  GoalsState,
  addSubitemToGoal,
  deleteSubitemFromGoal,
  getGoalFromState,
  subItemFields,
  updateSubitemToGoal,
} from "./goalsHelper";
import * as _ from "lodash";
import { useEffect, Dispatch } from "react";
import { GraphQLSubscription } from "@aws-amplify/api";
import {
  OnCreateCommentSubscription,
  OnUpdateCommentSubscription,
} from "@/src/API";
import * as subscriptions from "@/src/graphql/subscriptions";
import { API, graphqlOperation } from "aws-amplify";
import {
  addCommentToKeyResultUpdate,
  checkIfKeyResultUpdateReplyAndAddReply,
  checkIfKeyResultUpdateReplyAndDeleteReply,
  checkIfKeyResultUpdateReplyAndUpdateReply,
  deleteCommentFromKeyResultUpdate,
  updateCommentToKeyResultUpdate,
} from "./keyResultHelper";
import { current } from "immer";

export enum commentParentSubelements {
  status = "statusCommentsId",
  redFlag = "redFlagCommentsId",
  successStory = "successStoryCommentsId",
  task = "taskCommentsId",
  keyResult = "keyResultCommentsId",
  contribution = "contributionCommentsId",
  idea = "ideaCommentsId",
  helpRequest = "helpRequestCommentsId",
}

export enum subItemFieldsWithComments {
  status = "status",
  redFlags = "redFlags",
  successStories = "successStories",
  tasks = "tasks",
  keyResults = "keyResults",
  contribution = "contributions",
  ideas = "ideas",
  helpRequests = "helpRequests",
}

type SubelementsWithComment =
  | Status
  | RedFlag
  | SuccessStory
  | Task
  | KeyResult
  | Contribution
  | HelpRequest
  | Idea;
type FindElementsWithComment = Comment | SubelementsWithComment;

// Task susbscriptions for updated (add, update and delete)
export const useCommentsUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  // Subscribe comment updates
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnCreateCommentSubscription>>(
      graphqlOperation(subscriptions.onCreateComment)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "commentAdded",
          newComment: value.data?.onCreateComment,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateCommentSubscription>>(
      graphqlOperation(subscriptions.onUpdateComment)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "commentUpdated",
          updatedComment: value.data?.onUpdateComment,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnDeleteCommentSubscription>>(
      graphqlOperation(subscriptions.onDeleteComment)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "commentDeleted",
          deletedComment: value.data?.onDeleteComment,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
};

/*********************
 *
 * Add comment section
 *
 ********************/

// Update a comment also for goal list if it's of an interesting subitem.
// XXX: If we get rid of currentgoal, then refactor
export function addCommentToGoal(draft: GoalsState, newComment: Comment) {
  const goal = getGoalFromState(draft, newComment.hostGoalId);
  // Check if it's a reply to a comment.
  if (newComment.commentRepliesId != null) {
    addReplyToGoalOrSubitemComment(goal, newComment);
  } else {
    addCommentToGoalOrSubitem(goal, newComment);
  }
}

// Add a reply to goal comment, or it's subitem comments.
// XXX: After amplify change, we don't get the parent comment in the new comment, so we need check all the goal comments.
function addReplyToGoalOrSubitemComment(goal: Goal, newComment: Comment) {
  // We need to run through all the items due the Amplify change.
  // XXX: In the future we can save some additional information to prevent this.

  if (checkIfGoalCommentsReplyAndAddReply(goal, newComment)) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndAddReply<RedFlag>(
      goal,
      newComment,
      subItemFieldsWithComments.redFlags
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndAddReply<Task>(
      goal,
      newComment,
      subItemFieldsWithComments.tasks
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndAddReply<KeyResult>(
      goal,
      newComment,
      subItemFieldsWithComments.keyResults
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndAddReply<Status>(
      goal,
      newComment,
      subItemFieldsWithComments.status
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndAddReply<Contribution>(
      goal,
      newComment,
      subItemFieldsWithComments.contribution
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndAddReply<SuccessStory>(
      goal,
      newComment,
      subItemFieldsWithComments.successStories
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndAddReply<Idea>(
      goal,
      newComment,
      subItemFieldsWithComments.ideas
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndAddReply<HelpRequest>(
      goal,
      newComment,
      subItemFieldsWithComments.helpRequests
    )
  ) {
    return goal;
  }
  if (checkIfKeyResultUpdateReplyAndAddReply(goal, newComment)) {
    return goal;
  }
  return goal;
}

// Goal has been found. Add a comment either to the goal or to the subitem.
function addCommentToGoalOrSubitem(goal: Goal, newComment: Comment) {
  if (newComment.goalCommentsId) {
    return addSubitemToGoal(goal, subItemFields.comments, newComment);
  } else if (newComment.redFlagCommentsId) {
    return addCommentToGoalSubitem<RedFlag>(
      goal,
      newComment,
      subItemFieldsWithComments.redFlags,
      commentParentSubelements.redFlag
    );
  } else if (newComment.taskCommentsId) {
    return addCommentToGoalSubitem<Task>(
      goal,
      newComment,
      subItemFieldsWithComments.tasks,
      commentParentSubelements.task
    );
  } else if (newComment.keyResultCommentsId) {
    return addCommentToGoalSubitem<KeyResult>(
      goal,
      newComment,
      subItemFieldsWithComments.keyResults,
      commentParentSubelements.keyResult
    );
  } else if (newComment.statusCommentsId) {
    return addCommentToGoalSubitem<Status>(
      goal,
      newComment,
      subItemFieldsWithComments.status,
      commentParentSubelements.status
    );
  } else if (newComment.contributionCommentsId) {
    return addCommentToGoalSubitem<Contribution>(
      goal,
      newComment,
      subItemFieldsWithComments.contribution,
      commentParentSubelements.contribution
    );
  } else if (newComment.successStoryCommentsId) {
    return addCommentToGoalSubitem<SuccessStory>(
      goal,
      newComment,
      subItemFieldsWithComments.successStories,
      commentParentSubelements.successStory
    );
  } else if (newComment.ideaCommentsId) {
    return addCommentToGoalSubitem<Idea>(
      goal,
      newComment,
      subItemFieldsWithComments.ideas,
      commentParentSubelements.idea
    );
  } else if (newComment.helpRequestCommentsId) {
    return addCommentToGoalSubitem<HelpRequest>(
      goal,
      newComment,
      subItemFieldsWithComments.helpRequests,
      commentParentSubelements.helpRequest
    );
  } else if (newComment.keyResultUpdateCommentsId) {
    return addCommentToKeyResultUpdate(goal, newComment);
  }

  return goal;
}

// Add a comment to goal's subitem.
function addCommentToGoalSubitem<T extends SubelementsWithComment>(
  goal: Goal,
  newComment: Comment,
  field: subItemFieldsWithComments,
  commentParentIdField: commentParentSubelements
) {
  const subItem = findItem<T>(
    goal[field]!.items as (T | null)[],
    newComment[commentParentIdField]
  );
  if (!subItem) {
    return undefined;
  }

  subItem.comments = {
    ...(subItem.comments || {
      nextToken: null,
      __typename: "ModelCommentConnection",
    }),
    items: [...(subItem.comments?.items || []), newComment],
  };

  return goal;
}

// Check if the comment is a reply to goal comments.
// If it is, add a reply and return true, otherwise return false.
function checkIfGoalCommentsReplyAndAddReply(goal: Goal, newComment: Comment) {
  if (goal?.comments?.items) {
    const found = goal.comments?.items?.some(
      (comment) => comment && comment.id === newComment.commentRepliesId
    );

    if (found) {
      goal.comments.items = addReplyToComments(
        goal?.comments.items,
        newComment
      );
      return true;
    }

    return false;
  }
  return false;
}
function checkIfGoalCommentsReplyAndUpdateReply(
  goal: Goal,
  newComment: Comment
) {
  if (goal?.comments?.items) {
    const found = goal.comments?.items?.some(
      (comment) => comment && comment.id === newComment.commentRepliesId
    );

    if (found) {
      goal.comments.items = updateReplyToComments(
        goal?.comments.items,
        newComment
      );
      return true;
    }

    return false;
  }
  return false;
}

// Check if the comment is a reply to goal subitems comments.
// If it is, add a reply and return true, otherwise return false. Reply to a thread is added as a last reply.
function checkIfGoalSubitemReplyAndAddReply<T extends SubelementsWithComment>(
  goal: Goal,
  newComment: Comment,
  field: subItemFieldsWithComments
) {
  // We know that the goal is right. We need to iterate through all the subitems and their comments.
  const subItems = goal![field]!.items as (T | null)[];
  if (!subItems) {
    return false;
  }

  const item = subItems.find((subItem) => {
    return subItem?.comments?.items?.some(
      (comment) => comment && comment.id === newComment.commentRepliesId
    );
  });

  if (item) {
    item.comments!.items = addReplyToComments(item.comments!.items, newComment);
    return true;
  }

  return false;
}

// Add a reply to comments.
export function addReplyToComments(
  comments: (Comment | null)[],
  newComment?: Comment
) {
  return comments?.map((comment) => {
    if (comment && comment?.id === newComment?.commentRepliesId) {
      return {
        ...comment,
        replies: {
          ...(comment?.replies || {
            nextToken: null,
            __typename: "ModelCommentConnection",
          }),
          items: [...(comment?.replies?.items || []), newComment],
        },
      };
    }
    return comment;
  });
}

/*********************
 *
 * Update comment section
 *
 ********************/

// Update a comment for goal list if it is "interesting" comment.
// XXX: Design is going to direction where everything is interesting -> thus think if this is really needed.
export function updateCommentToGoal(
  draft: GoalsState,
  updatedComment: Comment
) {
  const goal = getGoalFromState(draft, updatedComment.hostGoalId);
  // Check if it's a reply to a comment.
  if (updatedComment.commentRepliesId != null) {
    updateReplyToGoalOrSubitemComment(goal, updatedComment);
  } else {
    updateCommentToGoalOrSubitem(goal, updatedComment);
  }
}

// Update a reply to current goal comment, or it's subitem comments.
// XXX: After amplify change, we don't get the parent comment in the new comment, so we need check all the goal comments.
function updateReplyToGoalOrSubitemComment(
  goal: Goal,
  updatedComment: Comment
) {
  // We need to run through all the items due the Amplify change.
  // XXX: In the future we can save some additional information to prevent this.

  if (
    checkIfGoalSubitemReplyAndUpdateReply<RedFlag>(
      goal,
      updatedComment,
      subItemFieldsWithComments.redFlags
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndUpdateReply<Task>(
      goal,
      updatedComment,
      subItemFieldsWithComments.tasks
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndUpdateReply<KeyResult>(
      goal,
      updatedComment,
      subItemFieldsWithComments.keyResults
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndUpdateReply<Status>(
      goal,
      updatedComment,
      subItemFieldsWithComments.status
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndUpdateReply<Contribution>(
      goal,
      updatedComment,
      subItemFieldsWithComments.contribution
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndUpdateReply<SuccessStory>(
      goal,
      updatedComment,
      subItemFieldsWithComments.successStories
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndUpdateReply<Idea>(
      goal,
      updatedComment,
      subItemFieldsWithComments.ideas
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndUpdateReply<HelpRequest>(
      goal,
      updatedComment,
      subItemFieldsWithComments.helpRequests
    )
  ) {
    return goal;
  }
  if (checkIfKeyResultUpdateReplyAndUpdateReply(goal, updatedComment)) {
    return goal;
  }
  if (checkIfGoalCommentsReplyAndUpdateReply(goal, updatedComment)) {
    return goal;
  }
  return goal;
}

// Add a reply to goal or it's subitem comments.
function updateCommentToGoalOrSubitem(goal: Goal, updatedComment: Comment) {
  if (updatedComment.redFlagCommentsId) {
    return updateCommentToGoalSubitem<RedFlag>(
      goal,
      updatedComment,
      subItemFieldsWithComments.redFlags,
      commentParentSubelements.redFlag
    );
  } else if (updatedComment.taskCommentsId) {
    return updateCommentToGoalSubitem<Task>(
      goal,
      updatedComment,
      subItemFieldsWithComments.tasks,
      commentParentSubelements.task
    );
  } else if (updatedComment.keyResultCommentsId) {
    return updateCommentToGoalSubitem<KeyResult>(
      goal,
      updatedComment,
      subItemFieldsWithComments.keyResults,
      commentParentSubelements.keyResult
    );
  } else if (updatedComment.goalCommentsId) {
    return updateSubitemToGoal(goal, subItemFields.comments, updatedComment);
  } else if (updatedComment.statusCommentsId) {
    return updateCommentToGoalSubitem<Status>(
      goal,
      updatedComment,
      subItemFieldsWithComments.status,
      commentParentSubelements.status
    );
  } else if (updatedComment.contributionCommentsId) {
    return updateCommentToGoalSubitem<Contribution>(
      goal,
      updatedComment,
      subItemFieldsWithComments.contribution,
      commentParentSubelements.contribution
    );
  } else if (updatedComment.successStoryCommentsId) {
    return updateCommentToGoalSubitem<SuccessStory>(
      goal,
      updatedComment,
      subItemFieldsWithComments.successStories,
      commentParentSubelements.successStory
    );
  } else if (updatedComment.ideaCommentsId) {
    return updateCommentToGoalSubitem<Idea>(
      goal,
      updatedComment,
      subItemFieldsWithComments.ideas,
      commentParentSubelements.idea
    );
  } else if (updatedComment.helpRequestCommentsId) {
    return updateCommentToGoalSubitem<HelpRequest>(
      goal,
      updatedComment,
      subItemFieldsWithComments.helpRequests,
      commentParentSubelements.helpRequest
    );
  } else if (updatedComment.keyResultUpdateCommentsId) {
    return updateCommentToKeyResultUpdate(goal, updatedComment);
  }
  return goal;
}

// Update a comment to current goal's subitem.
function updateCommentToGoalSubitem<T extends SubelementsWithComment>(
  goal: Goal,
  updatedComment: Comment,
  field: subItemFieldsWithComments,
  commentParentField: commentParentSubelements
) {
  if (!goal || !goal[field]?.items || !updatedComment[commentParentField]) {
    return undefined;
  }

  const subItem = findItem<T>(
    goal![field]!.items as (T | null)[],
    updatedComment[commentParentField]
  );
  if (!subItem || !subItem.comments?.items) {
    return undefined;
  }
  subItem.comments.items = subItem.comments.items.map((comment) => {
    if (comment?.id === updatedComment.id) {
      // Restore replies for comments
      if (comment?.replies != null) {
        updatedComment.replies = comment?.replies;
      }
      return updatedComment;
    }
    return comment;
  });
}

// Check if the comment is a reply to current goal subitems comments.
// If it is, update a reply and return a new state, otherwise return undefined.
function checkIfGoalSubitemReplyAndUpdateReply<
  T extends SubelementsWithComment
>(goal: Goal, updatedComment: Comment, field: subItemFieldsWithComments) {
  // We know that the goal is right. We need to iterate through all the subitems and their comments.
  const subItems = goal![field]!.items as (T | null)[];
  if (!subItems) {
    return false;
  }

  const item = subItems.find((subItem) => {
    return subItem?.comments?.items?.some(
      (comment) => comment && comment.id === updatedComment.commentRepliesId
    );
  });

  if (item) {
    item.comments!.items = updateReplyToComments(
      item.comments!.items,
      updatedComment
    );
    return true;
  }

  return false;
}

// Update a reply to comments.
export function updateReplyToComments(
  comments: (Comment | null)[],
  updatedComment: Comment
) {
  return comments.map((comment) => {
    if (
      comment &&
      comment?.id === updatedComment.commentRepliesId &&
      comment?.replies?.items
    ) {
      const newReplies = comment.replies?.items.map((reply) =>
        reply?.id === updatedComment.id ? updatedComment : reply
      );
      return {
        ...comment!,
        replies: { ...comment.replies, items: newReplies },
      };
    }
    return comment;
  });
}

// Find a subitem from the list of subitems.
function findItem<T extends FindElementsWithComment>(
  items: (T | null)[],
  id?: string | null
): T | null | undefined {
  return items.find((item) => item?.id === id);
}

/*********************
 *
 * Delete comment section
 *
 ********************/

export function deleteCommentFromGoal(
  draft: GoalsState,
  deletedComment: Comment
) {
  const goal = getGoalFromState(draft, deletedComment.hostGoalId);
  // Check if it's a reply to a comment.
  if (deletedComment.commentRepliesId != null) {
    deleteReplyToGoalOrSubitemComment(goal, deletedComment);
  } else {
    deleteCommentToGoalOrSubitem(goal, deletedComment);
  }
}

export function deleteReplyToGoalOrSubitemComment(
  goal: Goal,
  deletedComment: Comment
) {
  if (
    checkIfGoalSubitemReplyAndDeleteReply<RedFlag>(
      goal,
      deletedComment,
      subItemFieldsWithComments.redFlags
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndDeleteReply<Task>(
      goal,
      deletedComment,
      subItemFieldsWithComments.tasks
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndDeleteReply<KeyResult>(
      goal,
      deletedComment,
      subItemFieldsWithComments.keyResults
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndDeleteReply<Status>(
      goal,
      deletedComment,
      subItemFieldsWithComments.status
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndDeleteReply<Contribution>(
      goal,
      deletedComment,
      subItemFieldsWithComments.contribution
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndDeleteReply<SuccessStory>(
      goal,
      deletedComment,
      subItemFieldsWithComments.successStories
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndDeleteReply<Idea>(
      goal,
      deletedComment,
      subItemFieldsWithComments.ideas
    )
  ) {
    return goal;
  }
  if (
    checkIfGoalSubitemReplyAndDeleteReply<HelpRequest>(
      goal,
      deletedComment,
      subItemFieldsWithComments.helpRequests
    )
  ) {
    return goal;
  }
  if (checkIfKeyResultUpdateReplyAndDeleteReply(goal, deletedComment)) {
    return goal;
  }
  if (checkIfGoalCommentsReplyAndDeleteReply(goal, deletedComment)) {
    return goal;
  }
  return goal;
}

function checkIfGoalSubitemReplyAndDeleteReply<
  T extends SubelementsWithComment
>(goal: Goal, deletedComment: Comment, field: subItemFieldsWithComments) {
  // We know that the goal is right. We need to iterate through all the subitems and their comments.
  const subItems = goal![field]!.items as (T | null)[];
  if (!subItems) {
    return false;
  }

  const item = subItems.find((subItem) => {
    return subItem?.comments?.items?.some(
      (comment) => comment && comment.id === deletedComment.commentRepliesId
    );
  });

  if (item) {
    // Filter out the comment reply
    item.comments!.items = deleteReplyFromComments(
      item.comments!.items,
      deletedComment
    );
    return true;
  }

  return false;
}

export function deleteReplyFromComments(
  comments: (Comment | null)[],
  deletedComment: Comment
) {
  return comments.map((comment) => {
    if (
      comment &&
      comment?.id === deletedComment.commentRepliesId &&
      comment?.replies?.items
    ) {
      const newReplies = comment.replies?.items.filter(
        (reply) => reply?.id !== deletedComment.id
      );
      return {
        ...comment!,
        replies: { ...comment.replies, items: newReplies },
      };
    }
    return comment;
  });
}

export function deleteCommentToGoalOrSubitem(
  goal: Goal,
  deletedComment: Comment
) {
  if (deletedComment.redFlagCommentsId) {
    return deleteCommentFromGoalSubitem<RedFlag>(
      goal,
      deletedComment,
      subItemFieldsWithComments.redFlags,
      commentParentSubelements.redFlag
    );
  } else if (deletedComment.taskCommentsId) {
    return deleteCommentFromGoalSubitem<Task>(
      goal,
      deletedComment,
      subItemFieldsWithComments.tasks,
      commentParentSubelements.task
    );
  } else if (deletedComment.keyResultCommentsId) {
    return deleteCommentFromGoalSubitem<KeyResult>(
      goal,
      deletedComment,
      subItemFieldsWithComments.keyResults,
      commentParentSubelements.keyResult
    );
  } else if (deletedComment.goalCommentsId) {
    return deleteSubitemFromGoal(goal, subItemFields.comments, deletedComment);
  } else if (deletedComment.statusCommentsId) {
    return deleteCommentFromGoalSubitem<Status>(
      goal,
      deletedComment,
      subItemFieldsWithComments.status,
      commentParentSubelements.status
    );
  } else if (deletedComment.contributionCommentsId) {
    return deleteCommentFromGoalSubitem<Contribution>(
      goal,
      deletedComment,
      subItemFieldsWithComments.contribution,
      commentParentSubelements.contribution
    );
  } else if (deletedComment.successStoryCommentsId) {
    return deleteCommentFromGoalSubitem<SuccessStory>(
      goal,
      deletedComment,
      subItemFieldsWithComments.successStories,
      commentParentSubelements.successStory
    );
  } else if (deletedComment.ideaCommentsId) {
    return deleteCommentFromGoalSubitem<Idea>(
      goal,
      deletedComment,
      subItemFieldsWithComments.ideas,
      commentParentSubelements.idea
    );
  } else if (deletedComment.helpRequestCommentsId) {
    return deleteCommentFromGoalSubitem<HelpRequest>(
      goal,
      deletedComment,
      subItemFieldsWithComments.helpRequests,
      commentParentSubelements.helpRequest
    );
  } else if (deletedComment.keyResultUpdateCommentsId) {
    return deleteCommentFromKeyResultUpdate(goal, deletedComment);
  }
  return goal;
}

function deleteCommentFromGoalSubitem<T extends SubelementsWithComment>(
  goal: Goal,
  deletedComment: Comment,
  field: subItemFieldsWithComments,
  commentParentField: commentParentSubelements
) {
  if (!goal || !goal[field]?.items || !deletedComment[commentParentField]) {
    return undefined;
  }

  const subItem = findItem<T>(
    goal![field]!.items as (T | null)[],
    deletedComment[commentParentField]
  );
  if (!subItem || !subItem.comments?.items) {
    return undefined;
  }
  subItem.comments.items = subItem.comments.items.filter(
    (comment) => comment?.id != deletedComment.id
  );
  return goal;
}

function checkIfGoalCommentsReplyAndDeleteReply(
  goal: Goal,
  deletedComment: Comment
) {
  if (goal?.comments?.items) {
    const found = goal.comments?.items?.some(
      (comment) => comment && comment.id === deletedComment.commentRepliesId
    );

    if (found) {
      goal.comments.items = deleteReplyFromComments(
        goal?.comments.items,
        deletedComment
      );
      return true;
    }

    return false;
  }
  return false;
}
