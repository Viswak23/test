import {
  useEffect,
  Dispatch,
} from "react";
import { GraphQLSubscription } from "@aws-amplify/api";
import { OnCreateHelpRequestEmployeeJoinSubscription, OnCreateHelpRequestSubscription, OnDeleteHelpRequestEmployeeJoinSubscription, OnDeleteHelpRequestSubscription, OnUpdateHelpRequestSubscription } from "@/src/API";
import * as subscriptions from "@/src/graphql/subscriptions";
import { API, graphqlOperation } from "aws-amplify";

// Subscribe HelpRequest updates
export const useHelpRequestsUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnCreateHelpRequestSubscription>>(
      graphqlOperation(subscriptions.onCreateHelpRequest)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "helpRequestAdded", newHelpRequest: value.data?.onCreateHelpRequest });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateHelpRequestSubscription>>(
      graphqlOperation(subscriptions.onUpdateHelpRequest)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "helpRequestUpdated", updatedHelpRequest: value.data?.onUpdateHelpRequest });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnDeleteHelpRequestSubscription>>(
      graphqlOperation(subscriptions.onDeleteHelpRequest)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "helpRequestDeleted", deletedHelpRequest: value.data?.onDeleteHelpRequest });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  // We need to listen the joins as well. They are modified separately from the helpRequest.
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnCreateHelpRequestEmployeeJoinSubscription>>(
      graphqlOperation(subscriptions.onCreateHelpRequestEmployeeJoin)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "helpRequestEmployeeJoinAdded", newEmployeeJoin: value.data?.onCreateHelpRequestEmployeeJoin });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnDeleteHelpRequestEmployeeJoinSubscription>>(
      graphqlOperation(subscriptions.onDeleteHelpRequestEmployeeJoin)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "helpRequestEmployeeJoinDeleted", deletedEmployeeJoin: value.data?.onDeleteHelpRequestEmployeeJoin });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
}
