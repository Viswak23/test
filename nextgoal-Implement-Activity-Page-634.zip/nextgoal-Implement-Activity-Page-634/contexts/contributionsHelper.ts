import {
  useEffect,
  Dispatch,
} from "react";
import { GraphQLSubscription } from "@aws-amplify/api";
import { OnCreateContributionEmployeeJoinSubscription, OnCreateContributionSubscription, OnDeleteContributionEmployeeJoinSubscription, OnDeleteContributionSubscription, OnUpdateContributionSubscription } from "@/src/API";
import * as subscriptions from "@/src/graphql/subscriptions";
import { API, graphqlOperation } from "aws-amplify";

// Subscribe contribution updates
export const useContributionsUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnCreateContributionSubscription>>(
      graphqlOperation(subscriptions.onCreateContribution)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "contributionAdded", newContribution: value.data?.onCreateContribution });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateContributionSubscription>>(
      graphqlOperation(subscriptions.onUpdateContribution)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "contributionUpdated", updatedContribution: value.data?.onUpdateContribution });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnDeleteContributionSubscription>>(
      graphqlOperation(subscriptions.onDeleteContribution)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "contributionDeleted", deletedContribution: value.data?.onDeleteContribution });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

    // We need to listen the joins as well. They are modified separately from the contribution.
    useEffect(() => {
      const sub = API.graphql<GraphQLSubscription<OnCreateContributionEmployeeJoinSubscription>>(
        graphqlOperation(subscriptions.onCreateContributionEmployeeJoin)
      ).subscribe({
        next: ({ value }) => {
          dispatch({ type: "contributionEmployeeJoinAdded", newEmployeeJoin: value.data?.onCreateContributionEmployeeJoin });
        },
        error: (error) => console.warn(error),
      });
  
      return () => sub.unsubscribe();
    }, [dispatch]);
  
    useEffect(() => {
      const sub = API.graphql<GraphQLSubscription<OnDeleteContributionEmployeeJoinSubscription>>(
        graphqlOperation(subscriptions.onDeleteContributionEmployeeJoin)
      ).subscribe({
        next: ({ value }) => {
          dispatch({ type: "contributionEmployeeJoinDeleted", deletedEmployeeJoin: value.data?.onDeleteContributionEmployeeJoin });
        },
        error: (error) => console.warn(error),
      });

    return () => sub.unsubscribe();
  }, [dispatch]);
}
