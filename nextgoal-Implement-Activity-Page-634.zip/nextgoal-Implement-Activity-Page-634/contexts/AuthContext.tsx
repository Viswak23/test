"use client";

import { useContext, createContext } from "react";

interface AuthState {
  currentUser: any | undefined;
  setCurrentUser: (value: any | undefined) => void;
}

export const AuthContext = createContext<AuthState | null>(null);

export function useAuthContext() {
  return useContext(AuthContext);
}
