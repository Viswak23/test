import {
  useEffect,
  Dispatch,
} from "react";
import { GraphQLSubscription } from "@aws-amplify/api";
import { OnCreateStatusSubscription, OnDeleteStatusSubscription, OnUpdateStatusSubscription } from "@/src/API";
import * as subscriptions from "@/src/graphql/subscriptions";
import { API, graphqlOperation } from "aws-amplify";

// Subscribe status updates
export const useStatusUpdatesSubscriptions = (dispatch: Dispatch<any>) => {   
    useEffect(() => {
      const sub = API.graphql<GraphQLSubscription<OnCreateStatusSubscription>>(
        graphqlOperation(subscriptions.onCreateStatus)
      ).subscribe({
        next: ({ value }) => {
          dispatch({
            type: "statusAdded",
            newStatus: value.data?.onCreateStatus,
          });
        },
        error: (error) => console.warn(error),
      });
  
      return () => sub.unsubscribe();
    }, [dispatch]);
  
    useEffect(() => {
      const sub = API.graphql<GraphQLSubscription<OnUpdateStatusSubscription>>(
        graphqlOperation(subscriptions.onUpdateStatus)
      ).subscribe({
        next: ({ value }) => {
          dispatch({
            type: "statusUpdated",
            updatedStatus: value.data?.onUpdateStatus,
          });
        },
        error: (error) => console.warn(error),
      });
  
      return () => sub.unsubscribe();
    }, [dispatch]);

    useEffect(() => {
      const sub = API.graphql<GraphQLSubscription<OnDeleteStatusSubscription>>(
        graphqlOperation(subscriptions.onDeleteStatus)
      ).subscribe({
        next: ({ value }) => {
          dispatch({
            type: "statusDeleted",
            deletedStatus: value.data?.onDeleteStatus,
          });
        },
        error: (error) => console.warn(error),
      });
  
      return () => sub.unsubscribe();
    }, [dispatch]);
}
