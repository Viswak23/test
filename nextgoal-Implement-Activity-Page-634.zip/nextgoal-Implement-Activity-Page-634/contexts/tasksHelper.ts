import {
  useEffect,
  Dispatch,
} from "react";
import { GraphQLSubscription } from "@aws-amplify/api";
import { OnCreateTaskSubscription, OnDeleteTaskSubscription, OnUpdateTaskSubscription, Task } from "@/src/API";
import * as subscriptions from "@/src/graphql/subscriptions";
import { API, graphqlOperation } from "aws-amplify";

// Task susbscriptions for updated (add, update and delete)
export const useTasksUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnCreateTaskSubscription>>(
      graphqlOperation(subscriptions.onCreateTask)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "taskAdded", newTask: value.data?.onCreateTask });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateTaskSubscription>>(
      graphqlOperation(subscriptions.onUpdateTask)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "taskUpdated", updatedTask: value.data?.onUpdateTask });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnDeleteTaskSubscription>>(
      graphqlOperation(subscriptions.onDeleteTask)
    ).subscribe({
      next: ({ value }) => {
        dispatch({ type: "taskDeleted", deletedTask: value.data?.onDeleteTask });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
}
