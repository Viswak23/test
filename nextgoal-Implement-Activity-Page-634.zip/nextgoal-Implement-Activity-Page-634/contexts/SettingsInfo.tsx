"use client";
import { Company, Employee, UpdateCompanyInput } from "@/src/API";
import { update } from "lodash";
import { createContext, useContext } from "react";
import { useImmerReducer } from "use-immer";
import { useSettingsUpdatesSubscriptions } from "./settingsHelpers";
import { useEmployees } from "./EmployeesContext";

const SettingsContext = createContext<SettingsState | null>(null);
const SettingsDispatchContext = createContext<React.Dispatch<any> | null>(null);

export type SubscriptionDetails = {
  status: string;
  nextBilling: string;
  amount: number;
  quantity: string;
  subscriptionId: string;
  customerId: string;
  currency: string;
};
export type BillingDetails = {
  name: string;
  number: number;
  expire: string;
};

interface SettingsState {
  subscriptionDetails: SubscriptionDetails | null;
  billingDetails: BillingDetails | null;
  companyDetails: Company | null;
  dbUser?: Employee | null;
}

interface SettingsProviderProps {
  children: React.ReactNode;
  initialState: SettingsState;
}

export function SettingsProvider({
  children,
  initialState,
}: SettingsProviderProps) {
  const [settings, dispatch] = useImmerReducer(settingsReducer, initialState);
  useSettingsUpdatesSubscriptions(dispatch);
  return (
    <SettingsContext.Provider value={settings}>
      <SettingsDispatchContext.Provider value={dispatch}>
        {children}
      </SettingsDispatchContext.Provider>
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error("useSettings must be used within a SettingsProvider");
  }
  return context;
}

export function useSettingsDispatch() {
  const context = useContext(SettingsDispatchContext);
  if (context === undefined) {
    throw new Error(
      "useSettings Dispatch must be used within a SettingsProvider"
    );
  }
  return context;
}

function settingsReducer(draft: SettingsState, action: any) {
  switch (action.type) {
    case "set_subscription_details":
      draft.subscriptionDetails = action.payload;
      break;
    case "set_billing_details":
      draft.billingDetails = action.payload;
      break;
    case "set_dbUser":
      draft.dbUser = action.payload;
      break;
    case "set_company_details":
      draft.companyDetails = action.payload;
      break;
    default:
      throw new Error(`Unhandled action type: ${action.type}`);
  }
}
