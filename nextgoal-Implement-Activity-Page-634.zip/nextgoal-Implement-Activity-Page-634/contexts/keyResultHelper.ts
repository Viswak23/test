import {
  Goal,
  KeyResultUpdate,
  OnUpdateKeyResultUpdateSubscription,
  Comment,
  OnDeleteKeyResultUpdateSubscription,
} from "@/src/API";
import { useEffect, Dispatch } from "react";
import { GraphQLSubscription } from "@aws-amplify/api";
import {
  OnCreateKeyResultSubscription,
  OnUpdateKeyResultSubscription,
  OnDeleteKeyResultSubscription,
  OnCreateKeyResultUpdateSubscription,
} from "@/src/API";
import * as subscriptions from "@/src/graphql/subscriptions";
import { API, graphqlOperation } from "aws-amplify";
import {  GoalsState } from "./goalsHelper";
import { addReplyToComments, deleteReplyFromComments, updateReplyToComments } from "./commentsHelper";

// Task susbscriptions for updated (add, update and delete)
export const useKeyresultsUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  // Subscribe key results modifications
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnCreateKeyResultSubscription>>(
      graphqlOperation(subscriptions.onCreateKeyResult)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "keyResultAdded",
          newKeyResult: value.data?.onCreateKeyResult,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateKeyResultSubscription>>(
      graphqlOperation(subscriptions.onUpdateKeyResult)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "keyResultUpdated",
          updatedKeyResult: value.data?.onUpdateKeyResult,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnDeleteKeyResultSubscription>>(
      graphqlOperation(subscriptions.onDeleteKeyResult)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "keyResultDeleted",
          deletedKeyResult: value.data?.onDeleteKeyResult,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  // Subscribe key results updates
  useEffect(() => {
    const sub = API.graphql<
      GraphQLSubscription<OnCreateKeyResultUpdateSubscription>
    >(graphqlOperation(subscriptions.onCreateKeyResultUpdate)).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "keyResultUpdateAdded",
          newKeyResultUpdate: value.data?.onCreateKeyResultUpdate,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<
      GraphQLSubscription<OnUpdateKeyResultUpdateSubscription>
    >(graphqlOperation(subscriptions.onUpdateKeyResultUpdate)).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "keyResultUpdateUpdated",
          updatedKeyResultUpdate: value.data?.onUpdateKeyResultUpdate,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<
      GraphQLSubscription<OnDeleteKeyResultUpdateSubscription>
    >(graphqlOperation(subscriptions.onDeleteKeyResultUpdate)).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "keyResultUpdateDeleted",
          deletedKeyResultUpdate: value.data?.onDeleteKeyResultUpdate,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
};

// Add a key result update to current goal key result and return a new state.
export function addKeyResultUpdateToGoal(
  goal: Goal,
  newKeyResultUpdate: KeyResultUpdate
) {
  const keyResult = goal.keyResults!.items.find(
    (keyResult) => keyResult?.id === newKeyResultUpdate.keyResultUpdatesId
  );
  if (keyResult) {
    keyResult.updates = {
      ...(keyResult.updates || {
        nextToken: null,
        __typename: "ModelKeyResultUpdateConnection",
      }),
      items: [newKeyResultUpdate, ...(keyResult.updates?.items || [])],
    };
  }
}

// Adds a keyresult update both to the current goal and to the goal list
export function addKeyResultUpdateToState(
  state: GoalsState,
  newKeyResultUpdate: KeyResultUpdate
) {
  // Updates added togoal list
  const goal = [...state.archivedGoals, ...state.goals].find((goal) => {
    if (
      goal.keyResults?.items.find(
        (kr) => kr?.id === newKeyResultUpdate.keyResultUpdatesId
      )
    )
      return goal;
  });
  if (!goal) return;
  addKeyResultUpdateToGoal(goal, newKeyResultUpdate);
}

// Update a key result update to a given goal.
export function updateKeyResultUpdateToGoal(
  goal: Goal,
  updatedKeyResultUpdate: KeyResultUpdate
) {
  const keyResult = goal.keyResults!.items.find(
    (keyResult) => keyResult?.id === updatedKeyResultUpdate.keyResultUpdatesId
  );
  if (keyResult) {
    keyResult.updates = {
      ...(keyResult.updates || {
        nextToken: null,
        __typename: "ModelKeyResultUpdateConnection",
      }),
      items:
        keyResult.updates?.items?.map((keyResultUpdate) => {
          if (keyResultUpdate?.id === updatedKeyResultUpdate.id) {
            // Restore comments for keyresultupdate if exists
            if (keyResultUpdate.comments != null) {
              updatedKeyResultUpdate = {
                ...updatedKeyResultUpdate,
                comments: keyResultUpdate.comments,
              };
            }
            return updatedKeyResultUpdate;
          }
          return keyResultUpdate;
        }) || [],
    };
  }
}

// Updates a keyresult update both to the current goal and to the goal list
export function updateKeyResultUpdateToState(
  state: GoalsState,
  updatedKeyResultUpdate: KeyResultUpdate
) {
  // Updates added to goal list
  const goal = [...state.archivedGoals, ...state.goals].find((goal) => {
    if (
      goal.keyResults?.items.find(
        (kr) => kr?.id === updatedKeyResultUpdate.keyResultUpdatesId
      )
    )
      return goal;
  });
  if (!goal) return;
  return updateKeyResultUpdateToGoal(goal, updatedKeyResultUpdate);
}

// Delete a key result update from a given goal
export function deleteKeyResultUpdateFromGoal(
  goal: Goal,
  deletedKeyResultUpdate: KeyResultUpdate
) {
  const keyResult = goal.keyResults!.items.find(
    (keyResult) => keyResult?.id === deletedKeyResultUpdate.keyResultUpdatesId
  );
  if (keyResult) {
    keyResult.updates = {
      ...(keyResult.updates || {
        nextToken: null,
        __typename: "ModelKeyResultUpdateConnection",
      }),
      items:
        keyResult.updates?.items?.filter(
          (keyResultUpdate) => keyResultUpdate?.id !== deletedKeyResultUpdate.id
        ) || [],
    };
  }
}

// Deleted a keyresult update both to the current goal and to the goal list
export function deleteKeyResultUpdateFromState(
  state: GoalsState,
  deletedKeyResultUpdate: KeyResultUpdate
) {
  // Deleted from the goal list

  const goal = [...state.archivedGoals, ...state.goals].find((goal) => {
    if (
      goal.keyResults?.items.find(
        (kr) => kr?.id === deletedKeyResultUpdate.keyResultUpdatesId
      )
    )
      return goal;
  });
  if (!goal) return;
  return deleteKeyResultUpdateFromGoal(goal, deletedKeyResultUpdate);
}

// Add a comment to the key result update for a given goal
export function addCommentToKeyResultUpdate(goal: Goal, comment: Comment) {
  let keyResultUpdate = findKeyResultUpdateBasedOnComment(
    goal,
    comment.keyResultUpdateCommentsId!
  );

  if (keyResultUpdate) {
    keyResultUpdate.comments = {
      ...(keyResultUpdate.comments || {
        nextToken: null,
        __typename: "ModelCommentConnection",
      }),
      items: [comment, ...(keyResultUpdate.comments?.items || [])],
    };
  }
}

// Update a comment to the key result update for a given goal
export function updateCommentToKeyResultUpdate(goal: Goal, comment: Comment) {
  let keyResultUpdate = findKeyResultUpdateBasedOnComment(
    goal,
    comment.keyResultUpdateCommentsId!
  );

  if (keyResultUpdate) {
    keyResultUpdate.comments = {
      ...(keyResultUpdate.comments || {
        nextToken: null,
        __typename: "ModelCommentConnection",
      }),
      items: (keyResultUpdate.comments?.items?.map((c) => {
        if (c?.id === comment.id) {
          return comment;
        }
        return c;
      }) || []) as Comment[],
    };
  }
}

// Delete a comment from the key result update for a given goal
export function deleteCommentFromKeyResultUpdate(goal: Goal, comment: Comment) {
  let keyResultUpdate = findKeyResultUpdateBasedOnComment(
    goal,
    comment.keyResultUpdateCommentsId!
  );

  if (keyResultUpdate) {
    // Filter out the comment with the specified commentId
    keyResultUpdate.comments = {
      ...(keyResultUpdate.comments || {
        nextToken: null,
        __typename: "ModelCommentConnection",
      }),
      items: (keyResultUpdate.comments?.items?.filter(
        (c) => c?.id !== comment.id
      ) || []) as Comment[],
    };
  }
}

function findKeyResultUpdateBasedOnComment(
  goal: Goal,
  keyResultUpdateId: string
) {
  for (let keyResult of goal?.keyResults?.items || []) {
    const keyResultUpdate = keyResult?.updates?.items?.find(
      (kru) => kru?.id === keyResultUpdateId
    );
    if (keyResultUpdate) {
      return keyResultUpdate;
    }
  }
  return null;
}

// Add a reply to key result update comments
export function checkIfKeyResultUpdateReplyAndAddReply(
  goal: Goal,
  comment: Comment
) {
  let keyResultUpdate: KeyResultUpdate | null | undefined = null;
  for (let keyresult of goal?.keyResults?.items || []) {
    keyResultUpdate = keyresult?.updates?.items?.find((kru) =>
      kru?.comments?.items.some((c) => c?.id === comment.commentRepliesId)
    );
    if (keyResultUpdate) {
      break;
    }
  }

  if (keyResultUpdate) {
    keyResultUpdate.comments!.items = addReplyToComments(
      keyResultUpdate.comments!.items,
      comment
    );
    return true;
  }

  return false;
}

export function checkIfKeyResultUpdateReplyAndUpdateReply(
  goal: Goal,
  comment: Comment
) {
  let keyResultUpdate: KeyResultUpdate | null | undefined = null;
  for (let keyresult of goal?.keyResults?.items || []) {
    keyResultUpdate = keyresult?.updates?.items?.find((kru) =>
      kru?.comments?.items.some((c) => c?.id === comment.commentRepliesId)
    );
    if (keyResultUpdate) {
      break;
    }
  }

  if (keyResultUpdate) {
    keyResultUpdate.comments!.items = updateReplyToComments(
      keyResultUpdate.comments!.items,
      comment
    );
    return true;
  }

  return false;
}

export function checkIfKeyResultUpdateReplyAndDeleteReply(
  goal: Goal,
  comment: Comment
) {
  let keyResultUpdate: KeyResultUpdate | null | undefined = null;
  for (let keyresult of goal?.keyResults?.items || []) {
    keyResultUpdate = keyresult?.updates?.items?.find((kru) =>
      kru?.comments?.items.some((c) => c?.id === comment.commentRepliesId)
    );
    if (keyResultUpdate) {
      break;
    }
  }

  if (keyResultUpdate) {
    keyResultUpdate.comments!.items = deleteReplyFromComments(
      keyResultUpdate.comments!.items,
      comment
    );
    return true;
  }

  return false;
}
