"use client";

import React, { createContext, Dispatch, useContext, useEffect } from "react";
import { useImmerReducer } from "use-immer";
import {
  Employee,
  OnCreateOrganizationUnitEmployeeJoinSubscription,
  OnDeleteEmployeeSubscription,
  OnDeleteOrganizationUnitEmployeeJoinSubscription,
} from "@/src/API";
import { GraphQLSubscription } from "@aws-amplify/api";
import * as subscriptions from "@/src/graphql/subscriptions";
import * as modSubscriptions from "@/src/graphql/custom-subscriptions";
import { API, graphqlOperation } from "aws-amplify";
import {
  OnCreateEmployeeSubscription,
  OnUpdateEmployeeSubscription,
  OrganizationUnitEmployeeJoin,
} from "@/src/API";
import _ from "lodash";
import { getAttachmentUrl } from "@/lib/webAttachment";

export interface EmployeeWithAvatarUrl extends Employee {
  resolvedAvatarUrl?: string;
}

interface EmployeesState {
  employees?: EmployeeWithAvatarUrl[];
  organizationUnitEmployeeJoins?: OrganizationUnitEmployeeJoin[];
}

const EmployeesContext = createContext<EmployeesState | null>(null);
const EmployeesDispatchContext = createContext<Dispatch<any> | null>(null);

interface EmployeesProviderProps {
  children: React.ReactNode;
  initialState: EmployeesState;
}

// Use subscriptions to update the Employee state after a Employee is created or updated, or a OrganizationUnitEmployeeJoin is created.
const useEmployeesUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnCreateEmployeeSubscription>>(
      graphqlOperation(modSubscriptions.onCreateEmployeeWithoutOwner)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "addEmployee",
          newEmployee: value.data?.onCreateEmployee,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateEmployeeSubscription>>(
      graphqlOperation(modSubscriptions.onUpdateEmployeeWithoutOwner)
    ).subscribe({
      next: ({ value }) => {
        // Check if we need to update avatarUrl
        async function getResolvedAvaraUrl() {
          const updatedAvatarUrl = await getAttachmentUrl(
            value.data?.onUpdateEmployee?.avatarUrl
          );
          dispatch({
            type: "updateEmployee",
            updatedEmployee: {
              ...value.data?.onUpdateEmployee,
              resolvedAvatarUrl: updatedAvatarUrl,
            },
          });
        }
        getResolvedAvaraUrl();
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnDeleteEmployeeSubscription>>(
      graphqlOperation(modSubscriptions.onDeleteEmployeeWithoutOwner)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "deleteEmployee",
          deletedEmployee: {
            ...value.data?.onDeleteEmployee,
          },
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<
      GraphQLSubscription<OnCreateOrganizationUnitEmployeeJoinSubscription>
    >(
      graphqlOperation(subscriptions.onCreateOrganizationUnitEmployeeJoin)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "addOrganizationUnitEmployeeJoin",
          addedOrganizationUnitEmployeeJoin:
            value.data?.onCreateOrganizationUnitEmployeeJoin,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<
      GraphQLSubscription<OnDeleteOrganizationUnitEmployeeJoinSubscription>
    >(
      graphqlOperation(subscriptions.onDeleteOrganizationUnitEmployeeJoin)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "deleteOrganizationUnitEmployeeJoin",
          deletedOrganizationUnitEmployeeJoin:
            value.data?.onDeleteOrganizationUnitEmployeeJoin,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
};

export function EmployeesProvider({
  children,
  initialState,
}: EmployeesProviderProps) {
  const [goals, dispatch] = useImmerReducer(employeesReducer, initialState);
  useEmployeesUpdatesSubscriptions(dispatch);
  // Get the employee urls
  useEffect(() => {
    async function getResolvedAvaraUrls() {
      if (initialState.employees) {
        const employeesWithAvatarUrls = await Promise.all(
          initialState.employees.map(async (employee: Employee) => {
            return {
              ...employee,
              resolvedAvatarUrl: await getAttachmentUrl(employee.avatarUrl),
            };
          })
        );

        // Do something with employeesWithAvatarUrls
        dispatch({
          type: "updateEmployeesWithAvatarUrls",
          updatedEmployees: employeesWithAvatarUrls,
        });
      }
    }

    getResolvedAvaraUrls();
  }, [initialState.employees, dispatch]);

  return (
    <EmployeesContext.Provider value={goals}>
      <EmployeesDispatchContext.Provider value={dispatch}>
        {children}
      </EmployeesDispatchContext.Provider>
    </EmployeesContext.Provider>
  );
}

export function useEmployees() {
  const context = useContext(EmployeesContext);
  if (context === undefined) {
    throw new Error("useEmployee must be used within a EmployeeProvider");
  }
  return context;
}

export function useEmployeesDispatch() {
  const context = useContext(EmployeesDispatchContext);
  if (context === undefined) {
    throw new Error(
      "useEmployeeDispatch must be used within a EmployeeProvider"
    );
  }
  return context;
}

function employeesReducer(draft: EmployeesState, action: any) {
  switch (action.type) {
    case "addEmployee":
      if (
        draft.employees &&
        action.newEmployee &&
        !_.find(
          draft.employees,
          (employee) => employee?.id === action.newEmployee?.id
        )
      ) {
        draft.employees?.push(action.newEmployee);
      }
      break;
    case "updateEmployee":
      draft.employees = draft.employees?.map((employee) => {
        if (employee?.id === action.updatedEmployee?.id) {
          return action.updatedEmployee;
        }
        return employee;
      });
      break;
    case "deleteEmployee":
      draft.employees = draft.employees?.filter(
        (e) => e.id !== action.deletedEmployee.id
      );
      break;
    case "addOrganizationUnitEmployeeJoin":
      // Todo: Maybe check should be added to other places as well.
      if (
        draft.organizationUnitEmployeeJoins &&
        action.addedOrganizationUnitEmployeeJoin &&
        !_.find(
          draft.organizationUnitEmployeeJoins,
          (oue) => oue?.id === action.addedOrganizationUnitEmployeeJoin?.id
        )
      ) {
        draft.organizationUnitEmployeeJoins?.push(
          action.addedOrganizationUnitEmployeeJoin
        );
      }
      break;
    case "deleteOrganizationUnitEmployeeJoin":
      draft.organizationUnitEmployeeJoins =
        draft.organizationUnitEmployeeJoins?.filter(
          (oue) => oue.id !== action.deletedOrganizationUnitEmployeeJoin.id
        );
      break;
    case "updateEmployeesWithAvatarUrls":
      draft.employees = action.updatedEmployees;
      break;
    default:
      throw new Error(`Unhandled action type: ${action.type}`);
  }
}
