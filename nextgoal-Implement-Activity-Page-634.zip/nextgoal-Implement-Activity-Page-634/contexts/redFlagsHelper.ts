import { useEffect, Dispatch } from "react";
import { GraphQLSubscription } from "@aws-amplify/api";
import {
  OnCreateRedFlagSubscription,
  OnDeleteRedFlagSubscription,
  OnUpdateRedFlagSubscription,
} from "@/src/API";
import * as subscriptions from "@/src/graphql/subscriptions";
import { API, graphqlOperation } from "aws-amplify";

// Subscribe red flag updates
export const useRedFlagsUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnCreateRedFlagSubscription>>(
      graphqlOperation(subscriptions.onCreateRedFlag)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "redFlagAdded",
          newRedFlag: value.data?.onCreateRedFlag,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateRedFlagSubscription>>(
      graphqlOperation(subscriptions.onUpdateRedFlag)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "redFlagUpdated",
          updatedRedFlag: value.data?.onUpdateRedFlag,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);

  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnDeleteRedFlagSubscription>>(
      graphqlOperation(subscriptions.onDeleteRedFlag)
    ).subscribe({
      next: ({ value }) => {
        dispatch({
          type: "redFlagDeleted",
          deletedRedFlag: value.data?.onDeleteRedFlag,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
};
