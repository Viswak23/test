import {
  OnUpdateCompanySubscription,
  OnUpdateEmployeeSubscription,
} from "@/src/API";
import * as _ from "lodash";
import { GraphQLSubscription } from "@aws-amplify/api";
import * as subscriptions from "@/src/graphql/subscriptions";
import { API, graphqlOperation } from "aws-amplify";
import { Dispatch, useEffect } from "react";

export const useSettingsUpdatesSubscriptions = (dispatch: Dispatch<any>) => {
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateCompanySubscription>>(
      graphqlOperation(subscriptions.onUpdateCompany)
    ).subscribe({
      next: ({ value }) => {
        const updatedCompany = value.data?.onUpdateCompany;
        dispatch({
          type: "set_company_details",
          payload: updatedCompany,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateEmployeeSubscription>>(
      graphqlOperation(subscriptions.onUpdateEmployee)
    ).subscribe({
      next: ({ value }) => {
        const updatedEmployee = value.data?.onUpdateEmployee;
        dispatch({
          type: "set_dbUser",
          payload: updatedEmployee,
        });
      },
      error: (error) => console.warn(error),
    });

    return () => sub.unsubscribe();
  }, [dispatch]);
};
