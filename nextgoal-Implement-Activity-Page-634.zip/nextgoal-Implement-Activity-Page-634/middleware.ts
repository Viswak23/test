// https://nextjs.org/docs/pages/building-your-application/routing/middleware

import { NextRequest, NextResponse } from "next/server";
import awsExports from "@/src/aws-exports";
import { decodeProtectedHeader, importJWK, JWK, jwtVerify } from "jose";
import { match } from "@formatjs/intl-localematcher";
import Negotiator from "negotiator";
import {
  aws_user_pools_id,
  aws_user_pools_web_client_id,
} from "./lib/amplifyConfig";

// Supported locales
const locales = ["en", "es", "fi"];
// Routes that do not require authentication
const publicRoutes = [
  "/login",
  "/logout",
  "/register",
  "/",
  "/contact",
  "/product",
  "/blog",
  "/pricing",
  "/privacy-policy",
  "/terms-of-service",
  "/documentations/slack-integration",
  "/en",
  "/es",
  "/fi",
];

const enum AuthStatus {
  NOT_AUTHENTICATED,
  AUTHENTICATED,
  TOKEN_EXPIRED,
}

export async function middleware(request: NextRequest) {
  // Check if there is any supported locale in the request
  const { pathname } = request.nextUrl;

  if (pathname.includes("/integration")) {
    return NextResponse.next();
  }

  const locale = locales.find(
    (locale) => pathname.startsWith(`/${locale}/`) || pathname === `/${locale}`
  );
  const localeNeeded = isLocaleNeeded(pathname) && locale == null;

  if (localeNeeded) {
    // If there is no locale, redirect to the default locale
    const defaultLocale = getLocale(request);
    request.nextUrl.pathname = `/${defaultLocale}${pathname}`;
    return NextResponse.redirect(request.nextUrl);
  }

  // Check if the user is authenticated (if required)
  let authenticated = AuthStatus.AUTHENTICATED;
  if (isAuthNeeded(pathname, locale)) {
    authenticated = await isAuth(request);
  }

  // If the user is not authenticated, redirect to the login page
  if (authenticated !== AuthStatus.AUTHENTICATED) {
    const parsedURL = new URL(request.url);
    const path = parsedURL.pathname;

    // If the token has expired, redirect to the login page with the expired flag
    if (authenticated === AuthStatus.TOKEN_EXPIRED) {
      return NextResponse.redirect(
        new URL(`/${locale}/login?origin=${path}&expired=true`, request.url)
      );
    }

    return NextResponse.redirect(
      new URL(`/${locale}/login?origin=${path}`, request.url)
    );
  }

  // Everything is fine, continue
  return NextResponse.next();
}

// Get the preferred locale from the browser
function getLocale(request: NextRequest) {
  // Check if user has a preferred language set in the cookies.
  const preferredLanguage = request.cookies.get("language");
  if (preferredLanguage) {
    return preferredLanguage.value;
  } else {
    const headerLanguages = request.headers.get("accept-language") || "en";
    let headers = { "accept-language": headerLanguages };
    let languages = new Negotiator({ headers }).languages();
    let defaultLocale = "en";
    return match(languages, locales, defaultLocale);
  }
}

// Check if the authentication is needed for the route
function isAuthNeeded(pathname: string, locale?: string) {
  let path = pathname;
  if (locale && pathname.startsWith(`/${locale}/`)) {
    path = pathname.replace(`/${locale}/`, "/");
  }

  return (
    !publicRoutes.includes(path) &&
    !path.includes(".png") &&
    !path.includes(".ico") &&
    !path.includes(".webp")
  );
}

// Check if the locale is required for the route
function isLocaleNeeded(pathname: string) {
  return (
    !pathname.includes(".png") &&
    !pathname.includes(".ico") &&
    !pathname.includes(".webp")
  );
}

//this function will take the JWT from the nextRequest and verify it using jose library. this is the only way :(
async function isAuth(req: NextRequest) {
  const region = awsExports.aws_cognito_region ?? "";
  const userPoolId = aws_user_pools_id ?? "";
  const userPoolWebClientId = aws_user_pools_web_client_id ?? "";

  // Find the auth token from the cookie
  const tokenKey = [...req.cookies.getAll().map((item) => item.name)].find(
    (key) =>
      new RegExp(
        `CognitoIdentityServiceProvider\\.${userPoolWebClientId}\\..+\\.idToken`
      ).test(key)
  );

  if (!tokenKey) return AuthStatus.NOT_AUTHENTICATED;
  //getting the value of that token
  const token = req.cookies.get(tokenKey);

  if (!token) return AuthStatus.NOT_AUTHENTICATED;

  //getting a list of keys from aws cognito to compare ours with
  const { keys }: { keys: JWK[] } = await fetch(
    `https://cognito-idp.${region}.amazonaws.com/${userPoolId}/.well-known/jwks.json`
  ).then((res) => res.json());

  const { kid } = decodeProtectedHeader(token.value);
  const jwk = keys.find((key) => key.kid === kid);
  if (!jwk) return AuthStatus.NOT_AUTHENTICATED;

  return jwtVerify(token.value, await importJWK(jwk))
    .then((res) => {
      return AuthStatus.AUTHENTICATED;
    })
    .catch((error) => {
      //not allowed to use the log function in here.
      console.error(error);
      // If ERR_JWT_EXPIRED, the token has expired. Try to refresh the page first.
      if (error.code === "ERR_JWT_EXPIRED") {
        return AuthStatus.TOKEN_EXPIRED;
      }
      return AuthStatus.NOT_AUTHENTICATED;
    });
}

export const config = {
  matcher: [
    // Skip all internal paths (_next)
    "/((?!_next/static|_next/image|favicon.png|favicon_workzep.png|view-main.png|workzep-logo.png|screen-mainpage.jpg|screen-keyresults.jpg|screen-dashboard.jpg).*)",
  ],
};
