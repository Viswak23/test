import { useState, useEffect } from "react";

export function useMobileView() {
  const [mobileView, setMobileView] = useState(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia("(max-width: 768px)");
    const handleMediaQueryChange = (e: any) => setMobileView(e.matches);

    // Initial check
    setMobileView(mediaQuery.matches);

    // Add listener
    mediaQuery.addEventListener("change", handleMediaQueryChange);

    // Clean up listener on unmount
    return () =>
      mediaQuery.removeEventListener("change", handleMediaQueryChange);
  }, []);

  return mobileView;
}
