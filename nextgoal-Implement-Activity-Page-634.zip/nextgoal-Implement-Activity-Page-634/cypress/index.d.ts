/// <reference types="cypress" />

declare global {
  namespace Cypress {
    interface Chainable {
      /**
       * Custom command to select DOM element by data-cy attribute.
       * @example cy.dataCy('greeting')
       */
      getCy(dataCyAttribute: string): Chainable<JQuery<HTMLElement>>;
      login(): Chainable<void>;
      createGoalWithChildElements(goal: any): Chainable<void>;


      createGoal(goal: any): Chainable<void>;

      createRedFlag(redFlag: any): Chainable<void>;

      createKeyResults(keyResults: any): Chainable<void>;

    }
  }
}

export {};
