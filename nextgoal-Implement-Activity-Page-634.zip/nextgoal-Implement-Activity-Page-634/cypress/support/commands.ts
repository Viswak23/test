/// <reference types="cypress" />

import "./cognito";

Cypress.Commands.add("getCy", (selector) => {
  return cy.get(`[data-cy="${selector}"]`);
});

Cypress.Commands.add("createGoalWithChildElements", (goal: any) => {
  cy.getCy("add-goal-button").click();
  cy.getCy("edit-goal-title-input").type(goal.title);
  if (goal.description) {
    cy.getCy("edit-goal-description-input").type(goal.description);
  }
  cy.getCy("dialog-button-save").click();
  cy.getCy(`goal-card-${goal.title}`).find('[data-cy="expand-more"]').click();
  cy.getCy(`goal-card-${goal.title}`)
    .find('[data-cy="key-results-tab"]')
    .click();
  cy.getCy(`goal-card-${goal.title}`)
    .find('[data-cy="add-subitem-button"]')
    .click();
  cy.getCy("edit-keyresult-title").type(goal.keyResults[0].title);
  cy.getCy("dialog-button-save").click();
  cy.getCy(`goal-card-${goal.title}`).find('[data-cy="red-flags-tab"]').click();
  cy.getCy(`goal-card-${goal.title}`)
    .find('[data-cy="add-subitem-button"]')
    .click();
  cy.getCy("edit-redflag-description").type(goal.redFlags[0].comment);
  cy.getCy("dialog-button-save").click();
  cy.getCy(`goal-card-${goal.title}`).find('[data-cy="ideas-tab"]').click();
  cy.getCy(`goal-card-${goal.title}`)
    .find('[data-cy="add-subitem-button"]')
    .click();
  cy.getCy("edit-idea-title").type(goal.ideas[0].title);
  cy.getCy("dialog-button-save").click();
  cy.getCy(`goal-card-${goal.title}`)
    .find('[data-cy="contributions-tab"]')
    .click();
  cy.getCy(`goal-card-${goal.title}`)
    .find('[data-cy="add-subitem-button"]')
    .click();
  cy.getCy("edit-contribution-description").type(
    goal.contributions[0].description
  );
  cy.getCy("dialog-button-save").click();
  cy.getCy("edit-contribution-dialog").should("not.exist");
});

Cypress.Commands.add("createGoal", (goal) => {
  cy.getCy("add-goal-button").click();
  if (goal.title) {
    cy.getCy("edit-goal-title-input").type(goal.title);
  }
  if (goal.description) {
    cy.getCy("edit-goal-description-input").type(goal.description);
  }
  if (goal.reward) {
    cy.getCy("edit-goal-reward-input").type(goal.reward);
  }
  if (goal.startDate) {
    cy.getCy("edit-goal-start-date-container")
      .find("input")
      .type(goal.startDate);
  }
  if (goal.targetDate) {
    cy.getCy("edit-goal-target-date-container")
      .find("input")
      .type(goal.targetDate);
  }
  cy.getCy("dialog-button-save").click();
  cy.getCy(`goal-card-${goal.title}`).log("Goal successfully created");
});

Cypress.Commands.add("createRedFlag", (redFlag) => {
  cy.getCy("red-flags-tab").click();
  cy.getCy("add-subitem-button").click();
  cy.getCy("edit-redflag-description").type(redFlag);
  cy.getCy("dialog-button-save").click();
  cy.getCy("feed-item").contains(redFlag);
  cy.log("Red Flag successfully created");
});

Cypress.Commands.add("createKeyResults", (keyResults) => {
  cy.getCy("key-results-tab").click();
  cy.getCy("add-subitem-button").click();
  cy.getCy("edit-keyresult-title").type(keyResults.description);
  cy.getCy("keyresult-status-dropdown").click();
  cy.get('[data-value="UNKNOWN"]').click();
  cy.getCy("keyresult-initial-value-field").type(`${keyResults.initial}`);
  cy.getCy("keyresult-target-value-field").type(`${keyResults.target}`);
  cy.getCy("dialog-button-save").click();
  cy.getCy(`key-result-${keyResults.description}`).should("exist");
  cy.log("Key Results successfully created");
});

// ***********************************************
// This example commands.ts shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
//
// declare global {
//   namespace Cypress {
//     interface Chainable {
//       login(email: string, password: string): Chainable<void>
//       drag(subject: string, options?: Partial<TypeOptions>): Chainable<Element>
//       dismiss(subject: string, options?: Partial<TypeOptions>): Chainable<Element>
//       visit(originalFn: CommandOriginalFn, url: string, options: Partial<VisitOptions>): Chainable<Element>
//     }
//   }
// }

export {};
