import { Amplify } from "aws-amplify";

Amplify.configure(Cypress.env("awsConfig"));

Cypress.Commands.add("login", () => {
  const username = Cypress.env("cognito_username");
  cy.session(
    `cognito-${username}-session`,
    () => {
      cy.visit("/main");
      cy.get('[id="amplify-id-:r1:"]').type(username);
      cy.get('[id="amplify-id-:r4:"]').type(Cypress.env("cognito_password"));
      try {
        cy.get("button").contains("Sign in").click();
        cy.getCy("add-goal-button");
      } catch (e) {
        console.error(e);
      }
    },
    {
      validate() {
        cy.visit("/main");
        // revalidate our session to make sure we are logged in
        cy.getCy("add-goal-button");
      },
      cacheAcrossSpecs: true,
    }
  );
});
