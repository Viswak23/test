// ***********************************************************
// This example support/e2e.ts is processed and
// loaded automatically before your test files.
//
// This is a great place to put global configuration and
// behavior that modifies Cypress.
//
// You can change the location of this file or turn off
// automatically serving support files with the
// 'supportFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/configuration
// ***********************************************************

// Import commands.js using ES2015 syntax:
import "./commands";
import { clearData } from "./database";

// Alternatively you can use CommonJS syntax:
// require('./commands')

before(() => {
  cy.login();
  cy.wrap(null).then(() => {
    cy.log("Clearing test data");
    return clearData().then(() => {
      cy.log("Test data deleted");
    });
  });
});

Cypress.on("uncaught:exception", (err, runnable) => {
  // Don't fail the test if the error is a NEXT_REDIRECT
  if (err.message.includes("NEXT_REDIRECT")) {
    return false;
  }

  // returning false here prevents Cypress from
  // failing the test
  return true;
});

export {};
