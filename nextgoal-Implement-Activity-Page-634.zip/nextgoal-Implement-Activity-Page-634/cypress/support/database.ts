import { API, graphqlOperation } from "aws-amplify";
import {
  DeleteGoalMutation,
  DeleteOrganizationUnitMutation,
  Goal,
  ListGoalsQuery,
  ListOrganizationUnitsQuery,
  OrganizationUnit,
  Employee,
  ListEmployeesQuery,
  OrganizationUnitEmployeeJoin,
  ListOrganizationUnitEmployeeJoinsQuery,
  DeleteOrganizationUnitEmployeeJoinMutation,
  DeleteEmployeeMutation,
  ListRedFlagsQuery,
  RedFlag,
  ListKeyResultsQuery,
  KeyResult,
  ListIdeasQuery,
  Idea,
  Contribution,
  ListContributionsQuery,
  NorthStar,
  ListNorthStarsQuery,
  DeleteNorthStarMutation,
  Status,
  ListStatusesQuery,
  DeleteStatusMutation,
  KeyResultUpdate,
  ListKeyResultUpdatesQuery,
  DeleteKeyResultUpdateMutation,
  SuccessStory,
  ListSuccessStoriesQuery,
  ListHelpRequestsQuery,
  HelpRequest,
  DeleteHelpRequestMutation,
  ListCommentsQuery,
  DeleteCommentMutation,
  DeleteEventMutation,
  ListEventsQuery,
  ContributionEmployeeJoin,
  DeleteContributionEmployeeJoinMutation,
  DeleteHelpRequestEmployeeJoinMutation,
  DeleteIdeaEmployeeJoinMutation,
  DeleteSuccessStoryEmployeeJoinMutation,
  HelpRequestEmployeeJoin,
  IdeaEmployeeJoin,
  ListContributionEmployeeJoinsQuery,
  ListHelpRequestEmployeeJoinsQuery,
  ListIdeaEmployeeJoinsQuery,
  ListSuccessStoryEmployeeJoinsQuery,
  SuccessStoryEmployeeJoin,
  DeleteRedFlagMutation,
  DeleteKeyResultMutation,
  DeleteIdeaMutation,
  DeleteContributionMutation,
  DeleteSuccessStoryMutation,
  Comment,
  Event,
  EventsByCompanyIdQuery,
} from "../../src/API";
import {
  deleteComment,
  deleteContribution,
  deleteContributionEmployeeJoin,
  deleteEmployee,
  deleteEvent,
  deleteGoal,
  deleteHelpRequest,
  deleteHelpRequestEmployeeJoin,
  deleteIdea,
  deleteIdeaEmployeeJoin,
  deleteKeyResult,
  deleteKeyResultUpdate,
  deleteNorthStar,
  deleteOrganizationUnit,
  deleteOrganizationUnitEmployeeJoin,
  deleteRedFlag,
  deleteStatus,
  deleteSuccessStory,
  deleteSuccessStoryEmployeeJoin,
} from "../../src/graphql/mutations";
import {
  eventsByCompanyId,
  listComments,
  listContributionEmployeeJoins,
  listContributions,
  listEmployees,
  listEvents,
  listGoals,
  listHelpRequestEmployeeJoins,
  listHelpRequests,
  listIdeaEmployeeJoins,
  listIdeas,
  listKeyResults,
  listKeyResultUpdates,
  listNorthStars,
  listOrganizationUnitEmployeeJoins,
  listOrganizationUnits,
  listRedFlags,
  listStatuses,
  listSuccessStories,
  listSuccessStoryEmployeeJoins,
} from "../../src/graphql/queries";
import { createApiRequest } from "@/lib/webHelpers";
import { GraphQLQuery } from "@aws-amplify/api";

// Get organization
async function getOrganization(): Promise<(OrganizationUnit | null)[]> {
  try {
    const response = await createApiRequest<ListOrganizationUnitsQuery>(
      listOrganizationUnits,
      {},
      "listOrganizationUnits"
    );
    return response?.items || [];
  } catch (error) {
    console.error("Error while fetching organization list: ", error);
    return [];
  }
}

// Delete an organization unit from the database
function deleteOrganizationUnitDb(organizationId: string) {
  return createApiRequest<DeleteOrganizationUnitMutation>(
    deleteOrganizationUnit,
    { id: organizationId },
    "deleteOrganizationUnit"
  );
}

// Get north stars
async function getNorthStars(): Promise<(NorthStar | null)[]> {
  try {
    const response = await createApiRequest<ListNorthStarsQuery>(
      listNorthStars,
      {},
      "listNorthStars"
    );
    return response?.items || [];
  } catch (error) {
    console.error("Error while fetching north star list: ", error);
    return [];
  }
}

// Delete a north star from the database
function deleteNorthStarDb(northStarId: string) {
  return createApiRequest<DeleteNorthStarMutation>(
    deleteNorthStar,
    { id: northStarId },
    "deleteNorthStar"
  );
}

// Get all goals
async function getGoals(): Promise<(Goal | null)[]> {
  try {
    const response = await createApiRequest<ListGoalsQuery>(
      listGoals,
      {},
      "listGoals"
    );
    return response?.items || [];
  } catch (error) {
    console.error("Error while fetching goal list: ", error);
    return [];
  }
}

// Delete a goal from the database
function deleteGoalDb(goalId: string) {
  return createApiRequest<DeleteGoalMutation>(
    deleteGoal,
    { id: goalId },
    "deleteGoal"
  );
}

// Get all the employees
async function getEmployees(): Promise<(Employee | null)[]> {
  try {
    const response = await createApiRequest<ListEmployeesQuery>(
      listEmployees,
      {},
      "listEmployees"
    );
    return response?.items || [];
  } catch (error) {
    console.error("Error while fetching employee list: ", error);
    return [];
  }
}

// Delete an employee from the database
function deleteEmployeeDb(employeeId: string) {
  return createApiRequest<DeleteEmployeeMutation>(
    deleteEmployee,
    { id: employeeId },
    "deleteEmployee"
  );
}

// List all the organizationunitemployeejoins
async function getOrganizationUnitEmployeeJoins(): Promise<
  (OrganizationUnitEmployeeJoin | null)[]
> {
  try {
    const response =
      await createApiRequest<ListOrganizationUnitEmployeeJoinsQuery>(
        listOrganizationUnitEmployeeJoins,
        {},
        "listOrganizationUnitEmployeeJoins"
      );
    return response?.items || [];
  } catch (error) {
    console.error(
      "Error while fetching organizationUnitEmployees joins: ",
      error
    );
    return [];
  }
}

// Delete an organizationUnitEmployeeJoin from the database
function deleteOrganizationUnitEmployeeJoinDb(
  organizationUnitEmployeeJoinId: string
) {
  return createApiRequest<DeleteOrganizationUnitEmployeeJoinMutation>(
    deleteOrganizationUnitEmployeeJoin,
    { id: organizationUnitEmployeeJoinId },
    "deleteOrganizationUnitEmployeeJoin"
  );
}

// List all the red flags
export async function getRedFlags(): Promise<(RedFlag | null)[]> {
  try {
    const response = await createApiRequest<ListRedFlagsQuery>(
      listRedFlags,
      {},
      "listRedFlags"
    );
    return response?.items || [];
  } catch (error) {
    console.error("Error while fetching red flag list: ", error);
    return [];
  }
}

// Delete a red flag from the database
function deleteRedFlagDb(redFlagId: string) {
  return createApiRequest<DeleteRedFlagMutation>(
    deleteRedFlag,
    { id: redFlagId },
    "deleteRedFlag"
  );
}

// List all the key results
export async function getKeyResults(): Promise<(KeyResult | null)[]> {
  try {
    const response = await createApiRequest<ListKeyResultsQuery>(
      listKeyResults,
      {},
      "listKeyResults"
    );
    return response?.items || [];
  } catch (error) {
    console.error("Error while fetching key result list: ", error);
    return [];
  }
}

// Delete a key result from the database
function deleteKeyResultDb(keyResultId: string) {
  return createApiRequest<DeleteKeyResultMutation>(
    deleteKeyResult,
    { id: keyResultId },
    "deleteKeyResult"
  );
}

// List all the ideas
export async function getIdeas(): Promise<(Idea | null)[]> {
  try {
    const response = await createApiRequest<ListIdeasQuery>(
      listIdeas,
      {},
      "listIdeas"
    );
    return response?.items || [];
  } catch (error) {
    console.error("Error while fetching idea list: ", error);
    return [];
  }
}

// Delete an idea from the database
function deleteIdeaDb(ideaId: string) {
  return createApiRequest<DeleteIdeaMutation>(
    deleteIdea,
    { id: ideaId },
    "deleteIdea"
  );
}

// List all the contributions
export async function getContributions(): Promise<(Contribution | null)[]> {
  try {
    const response = await createApiRequest<ListContributionsQuery>(
      listContributions,
      {},
      "listContributions"
    );
    return response?.items || [];
  } catch (error) {
    console.error("Error while fetching contribution list: ", error);
    return [];
  }
}

// Delete a contribution from the database
function deleteContributionDb(contributionId: string) {
  return createApiRequest<DeleteContributionMutation>(
    deleteContribution,
    { id: contributionId },
    "deleteContribution"
  );
}

// Get all the statuses
export async function getStatuses(): Promise<(Status | null)[]> {
  try {
    const response = await createApiRequest<ListStatusesQuery>(
      listStatuses,
      {},
      "listStatuses"
    );
    return response?.items || [];
  } catch (error) {
    console.error("Error while fetching status list: ", error);
    return [];
  }
}

// Delete a status from the database
function deleteStatusDb(statusId: string) {
  return createApiRequest<DeleteStatusMutation>(
    deleteStatus,
    { id: statusId },
    "deleteStatus"
  );
}

// Get all the key result updates
export async function getKeyResultUpdates(): Promise<
  (KeyResultUpdate | null)[]
> {
  try {
    const response = await createApiRequest<ListKeyResultUpdatesQuery>(
      listKeyResultUpdates,
      {},
      "listKeyResultUpdates"
    );
    return response?.items || [];
  } catch (error) {
    console.error("Error while fetching key result updates list: ", error);
    return [];
  }
}

// Delete a key result update from the database
function deleteKeyResultUpdateDb(keyResultUpdateId: string) {
  return createApiRequest<DeleteKeyResultUpdateMutation>(
    deleteKeyResultUpdate,
    { id: keyResultUpdateId },
    "deleteKeyResultUpdate"
  );
}

// Get all the success stories
export async function getSuccessStories(): Promise<(SuccessStory | null)[]> {
  try {
    const response = await createApiRequest<ListSuccessStoriesQuery>(
      listSuccessStories,
      {},
      "listSuccessStories"
    );
    return response?.items || [];
  } catch (error) {
    console.error("Error while fetching success story list: ", error);
    return [];
  }
}

// Delete a success story from the database
function deleteSuccessStoryDb(successStoryId: string) {
  return createApiRequest<DeleteSuccessStoryMutation>(
    deleteSuccessStory,
    { id: successStoryId },
    "deleteSuccessStory"
  );
}

// Get all the help requests
export async function getHelpRequests(): Promise<(HelpRequest | null)[]> {
  try {
    const response = await createApiRequest<ListHelpRequestsQuery>(
      listHelpRequests,
      {},
      "listHelpRequests"
    );
    return response?.items || [];
  } catch (error) {
    console.error("Error while fetching help request list: ", error);
    return [];
  }
}

// Delete a help request from the database
function deleteHelpRequestDb(helpRequestId: string) {
  return createApiRequest<DeleteHelpRequestMutation>(
    deleteHelpRequest,
    { id: helpRequestId },
    "deleteHelpRequest"
  );
}

// Get all the comments
export async function getComments(): Promise<(Comment | null)[]> {
  try {
    const response = await createApiRequest<ListCommentsQuery>(
      listComments,
      {},
      "listComments"
    );
    return response?.items || [];
  } catch (error) {
    console.error("Error while fetching comment list: ", error);
    return [];
  }
}

// Delete a comment from the database
function deleteCommentDb(commentId: string) {
  return createApiRequest<DeleteCommentMutation>(
    deleteComment,
    { id: commentId },
    "deleteComment"
  );
}

// Get all the events
export async function getEvents(): Promise<(Event | null)[]> {
  try {
    const params = {
      sortDirection: "DESC",
      limit: 1000,
      companyId: "CypressTest-DoNotDelete"
    };

    const result = await API.graphql<GraphQLQuery<EventsByCompanyIdQuery>>(
      graphqlOperation(eventsByCompanyId, params)
    );

    return result.data?.eventsByCompanyId?.items || [];
    /*
    
    const response = await createApiRequest<EventsByCompanyIdQuery>(
      eventsByCompanyId,
      params,
      "eventsByCompanyId"
    );
    return response?.items || [];
    */
  } catch (error) {
    console.error("Error while fetching event list: ", error);
    return [];
  }
}

// Delete an event from the database
function deleteEventDb(eventId: string) {
  return createApiRequest<DeleteEventMutation>(
    deleteEvent,
    { id: eventId },
    "deleteEvent"
  );
}

// Get all the ideaemployeejoins
export async function getIdeaEmployeeJoins(): Promise<
  (IdeaEmployeeJoin | null)[]
> {
  try {
    const response = await createApiRequest<ListIdeaEmployeeJoinsQuery>(
      listIdeaEmployeeJoins,
      {},
      "listIdeaEmployeeJoins"
    );
    return response?.items || [];
  } catch (error) {
    console.error("Error while fetching idea employee joins list: ", error);
    return [];
  }
}

// Delete an ideaemployeejoin from the database
function deleteIdeaEmployeeJoinDb(ideaEmployeeJoinId: string) {
  return createApiRequest<DeleteIdeaEmployeeJoinMutation>(
    deleteIdeaEmployeeJoin,
    { id: ideaEmployeeJoinId },
    "deleteIdeaEmployeeJoin"
  );
}

// Get all the successstoryemployeejoins
export async function getSuccessStoryEmployeeJoins(): Promise<
  (SuccessStoryEmployeeJoin | null)[]
> {
  try {
    const response = await createApiRequest<ListSuccessStoryEmployeeJoinsQuery>(
      listSuccessStoryEmployeeJoins,
      {},
      "listSuccessStoryEmployeeJoins"
    );
    return response?.items || [];
  } catch (error) {
    console.error(
      "Error while fetching success story employee joins list: ",
      error
    );
    return [];
  }
}

// Delete a successstoryemployeejoin from the database
function deleteSuccessStoryEmployeeJoinDb(successStoryEmployeeJoinId: string) {
  return createApiRequest<DeleteSuccessStoryEmployeeJoinMutation>(
    deleteSuccessStoryEmployeeJoin,
    { id: successStoryEmployeeJoinId },
    "deleteSuccessStoryEmployeeJoin"
  );
}

// Get all the contributionemployeejoins
export async function getContributionEmployeeJoins(): Promise<
  (ContributionEmployeeJoin | null)[]
> {
  try {
    const response = await createApiRequest<ListContributionEmployeeJoinsQuery>(
      listContributionEmployeeJoins,
      {},
      "listContributionEmployeeJoins"
    );
    return response?.items || [];
  } catch (error) {
    console.error(
      "Error while fetching contribution employee joins list: ",
      error
    );
    return [];
  }
}

// Delete a contributionemployeejoin from the database
function deleteContributionEmployeeJoinDb(contributionEmployeeJoinId: string) {
  return createApiRequest<DeleteContributionEmployeeJoinMutation>(
    deleteContributionEmployeeJoin,
    { id: contributionEmployeeJoinId },
    "deleteContributionEmployeeJoin"
  );
}

// Get all the helprequestemployeejoins
export async function getHelpRequestEmployeeJoins(): Promise<
  (HelpRequestEmployeeJoin | null)[]
> {
  try {
    const response = await createApiRequest<ListHelpRequestEmployeeJoinsQuery>(
      listHelpRequestEmployeeJoins,
      {},
      "listHelpRequestEmployeeJoins"
    );
    return response?.items || [];
  } catch (error) {
    console.error(
      "Error while fetching help request employee joins list: ",
      error
    );
    return [];
  }
}

// Delete a helprequestemployeejoin from the database
function deleteHelpRequestEmployeeJoinDb(helpRequestEmployeeJoinId: string) {
  return createApiRequest<DeleteHelpRequestEmployeeJoinMutation>(
    deleteHelpRequestEmployeeJoin,
    { id: helpRequestEmployeeJoinId },
    "deleteHelpRequestEmployeeJoin"
  );
}

// Get all the data from database
async function getData() {
  return new Cypress.Promise(async (resolve, reject) => {
    const organization = await getOrganization();
    const northStars = await getNorthStars();
    const employees = await getEmployees();
    const organizationUnitEmployeeJoins =
      await getOrganizationUnitEmployeeJoins();
    const goals = await getGoals();
    const statuses = await getStatuses();
    const redFlags = await getRedFlags();
    const keyResults = await getKeyResults();
    const keyResultUpdates = await getKeyResultUpdates();
    const successStories = await getSuccessStories();
    const contributions = await getContributions();
    const ideas = await getIdeas();
    const helpRequests = await getHelpRequests();
    const comments = await getComments();
    const events = await getEvents();
    const ideaEmployeeJoins = await getIdeaEmployeeJoins();
    const successStoryEmployeeJoins = await getSuccessStoryEmployeeJoins();
    const contributionEmployeeJoins = await getContributionEmployeeJoins();
    const helpRequestEmployeeJoins = await getHelpRequestEmployeeJoins();

    resolve({
      organization,
      northStars,
      employees,
      organizationUnitEmployeeJoins,
      goals,
      statuses,
      redFlags,
      keyResults,
      keyResultUpdates,
      successStories,
      contributions,
      ideas,
      helpRequests,
      comments,
      events,
      ideaEmployeeJoins,
      successStoryEmployeeJoins,
      contributionEmployeeJoins,
      helpRequestEmployeeJoins,
    });
  });
}

/* Clear the database:
 * Clear OrganizationUnit
 * Clear NorthStar
 * DO NOT CLEAR: Company
 * Clear Employee, EXCEPT the user for the tests
 * Clear OrganizationUnitEmployeeJoin
 * Clear Goal
 * Clear Status
 * Clear RedFlag
 * Clear KeyResult
 * Clear KeyResultUpdate
 * Clear SuccessStory
 * Clear Contribution
 * Clear Idea
 * Clear HelpRequest
 * Clear Comment
 * Clear Event
 * Clear IdeaEmployeeJoin
 * Clear SuccessStoryEmployeeJoin
 * Clear ContributionEmployeeJoin
 * Clear HelpRequestEmployeeJoin
 * TODO: Clear Notification
 */
export function clearData() {
  return new Cypress.Promise(async (resolve, reject) => {
    cy.log("Fetch the data from the database");
    const data = (await getData()) as any;

    cy.log("Deleting data");
    const deleteOrganizationUnits = data.organization.map(
      (organizationUnit: { id: string }) =>
        organizationUnit && deleteOrganizationUnitDb(organizationUnit?.id)
    );
    const deleteNorthStars = data.northStars.map(
      (northStar: { id: string }) =>
        northStar && deleteNorthStarDb(northStar?.id)
    );
    const testUserEmail = Cypress.env("cognito_username");
    const deleteEmployeesList = data.employees.filter(
      (e: { email: string }) => e && e.email !== testUserEmail
    );

    const deleteEmployees = deleteEmployeesList.map(
      (employee: { id: string }) => employee && deleteEmployeeDb(employee?.id)
    );

    const deleteOrganizationUnitEmployeeJoins =
      data.organizationUnitEmployeeJoins.map(
        (organizationUnitEmployeeJoin: { id: string }) =>
          organizationUnitEmployeeJoin &&
          deleteOrganizationUnitEmployeeJoinDb(organizationUnitEmployeeJoin?.id)
      );

    const deleteGoals = data.goals.map(
      (goal: { id: string }) => goal && deleteGoalDb(goal?.id)
    );

    cy.log("Goals count:" + deleteGoals.length);

    const responsesGoals = await Promise.all(deleteGoals);
    cy.log("Goals deleted");
    cy.log("Responses: " + responsesGoals.join(","));

    const deleteStatuses = data.statuses.map(
      (status: { id: string }) => status && deleteStatusDb(status?.id)
    );

    const deleteRedFlags = data.redFlags.map(
      (redFlag: { id: string }) => redFlag && deleteRedFlagDb(redFlag?.id)
    );

    const deleteKeyResults = data.keyResults.map(
      (keyResult: { id: string }) =>
        keyResult && deleteKeyResultDb(keyResult?.id)
    );

    const deleteKeyResultUpdates = data.keyResultUpdates.map(
      (keyResultUpdate: { id: string }) =>
        keyResultUpdate && deleteKeyResultUpdateDb(keyResultUpdate?.id)
    );

    const deleteSuccessStories = data.successStories.map(
      (successStory: { id: string }) =>
        successStory && deleteSuccessStoryDb(successStory?.id)
    );

    const deleteContributions = data.contributions.map(
      (contribution: { id: string }) =>
        contribution && deleteContributionDb(contribution?.id)
    );

    const deleteIdeas = data.ideas.map(
      (idea: { id: string }) => idea && deleteIdeaDb(idea?.id)
    );

    const deleteHelpRequests = data.helpRequests.map(
      (helpRequest: { id: string }) =>
        helpRequest && deleteHelpRequestDb(helpRequest?.id)
    );

    const deleteComments = data.comments.map(
      (comment: { id: string }) => comment && deleteCommentDb(comment?.id)
    );

    cy.log("Comments count:" + deleteComment.length);
    const responses = await Promise.all(deleteComments);
    cy.log("Comments deleted");
    cy.log("Responses: " + responses.join(","));

    const deleteEvents = data.events.map(
      (event: { id: string }) => event && deleteEventDb(event?.id)
    );

    const deleteIdeaEmployeeJoins = data.ideaEmployeeJoins.map(
      (ideaEmployeeJoin: { id: string }) =>
        ideaEmployeeJoin && deleteIdeaEmployeeJoinDb(ideaEmployeeJoin?.id)
    );

    const deleteSuccessStoryEmployeeJoins = data.successStoryEmployeeJoins.map(
      (successStoryEmployeeJoin: { id: string }) =>
        successStoryEmployeeJoin &&
        deleteSuccessStoryEmployeeJoinDb(successStoryEmployeeJoin?.id)
    );

    const deleteContributionEmployeeJoins = data.contributionEmployeeJoins.map(
      (contributionEmployeeJoin: { id: string }) =>
        contributionEmployeeJoin &&
        deleteContributionEmployeeJoinDb(contributionEmployeeJoin?.id)
    );

    const deleteHelpRequestEmployeeJoins = data.helpRequestEmployeeJoins.map(
      (helpRequestEmployeeJoin: { id: string }) =>
        helpRequestEmployeeJoin &&
        deleteHelpRequestEmployeeJoinDb(helpRequestEmployeeJoin?.id)
    );

    await Promise.all([
      deleteOrganizationUnits,
      deleteNorthStars,
      deleteEmployees,
      deleteOrganizationUnitEmployeeJoins,
      deleteGoals,
      deleteStatuses,
      deleteRedFlags,
      deleteKeyResults,
      deleteKeyResultUpdates,
      deleteSuccessStories,
      deleteContributions,
      deleteIdeas,
      deleteHelpRequests,
      deleteComments,
      deleteEvents,
      deleteIdeaEmployeeJoins,
      deleteSuccessStoryEmployeeJoins,
      deleteContributionEmployeeJoins,
      deleteHelpRequestEmployeeJoins,
    ]);

    cy.log("Data deleted");
    resolve();
  });
}
