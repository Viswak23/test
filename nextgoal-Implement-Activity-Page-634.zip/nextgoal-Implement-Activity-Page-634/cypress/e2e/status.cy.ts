/// <reference types="cypress" />

describe('Status in main page', () => {
  const goalTitle = 'Status goal';

  before(() => {
    cy.login();
    cy.visit('/main');
    // Add a goal so we can add the status
    cy.getCy('add-goal-button').click();
    cy.getCy('edit-goal-title-input').type(goalTitle);
    cy.getCy('dialog-button-save').click();
    cy.getCy(`goal-card-${goalTitle}`).find('[data-cy="expand-more"]').click();
  });

  beforeEach(() => {
    cy.login();
    cy.visit('/main');
    cy.getCy(`goal-card-${goalTitle}`).find('[data-cy="expand-more"]').click();
  });

  it('Create a status with an title only', () => {
    const statusTitle = 'Test status';

    cy.getCy('add-status-button').click();
    cy.getCy('edit-status-title-input').type(statusTitle);
    cy.getCy('dialog-button-save').click();
    // Check that the status is created
    cy.getCy('status-feed-item').contains(statusTitle);
  });

  it('Create a status with all the information', () => {
    const status = {
      title: 'All information',
      goingWell: 'This is going well',
      challenges: 'This is a challenge',
      toImprove: 'This could be improved',
    };

    cy.getCy('add-status-button').click();
    cy.getCy('edit-status-title-input').type(status.title);
    cy.getCy('edit-status-going-well-input').type(status.goingWell);
    cy.getCy('edit-status-challenges-input').type(status.challenges);
    cy.getCy('edit-status-room-to-improve-input').type(status.toImprove);
    cy.getCy('dialog-button-save').click();
    // Check that the status is created
    cy.getCy('status-feed-item').contains(status.title);
    cy.getCy('status-feed-item').contains(status.goingWell);
    cy.getCy('status-feed-item').contains(status.challenges);
    cy.getCy('status-feed-item').contains(status.toImprove);
  });

  it('Try to create a status without a title', () => {
    const status = {
      title: 'All information',
      goingWell: 'This is going well',
      challenges: 'This is a challenge',
      toImprove: 'This could be improved',
    };

    cy.getCy('add-status-button').click();
    cy.getCy('edit-status-going-well-input').type(status.goingWell);
    cy.getCy('edit-status-challenges-input').type(status.challenges);
    cy.getCy('edit-status-room-to-improve-input').type(status.toImprove);
    cy.getCy('dialog-button-save').click();
    // Check that the error message is shown
    cy.get('#status-helper-text').contains("Status cannot be empty");
  });

  it('Cancel creating a new status', () => {
    const statusTitle = 'Cancelled status';

    cy.getCy('add-status-button').click();
    cy.getCy('edit-status-title-input').type(statusTitle);
    cy.getCy('dialog-button-cancel').click();
    // Check that the status is not created
    cy.getCy('latest-status-container').should('not.contain', statusTitle);
  });

  it('Edit status', () => {
    const statusOriginal = {
      title: 'All information',
      goingWell: 'This is going well',
      challenges: 'This is a challenge',
      toImprove: 'This could be improved',
    };

    const statusEdited = {
      title: 'Edited information',
      goingWell: 'Not is going well',
      challenges: 'Not a challenge',
      toImprove: 'This could not be improved',
    };

    cy.getCy('add-status-button').click();
    cy.getCy('edit-status-title-input').type(statusOriginal.title);
    cy.getCy('edit-status-going-well-input').type(statusOriginal.goingWell);
    cy.getCy('edit-status-challenges-input').type(statusOriginal.challenges);
    cy.getCy('edit-status-room-to-improve-input').type(statusOriginal.toImprove);
    cy.getCy('dialog-button-save').click();
    cy.getCy('status-feed-item').contains(statusOriginal.title);
    cy.getCy('status-feed-item').contains(statusOriginal.goingWell);
    cy.getCy('status-feed-item').contains(statusOriginal.challenges);
    cy.getCy('status-feed-item').contains(statusOriginal.toImprove);
    // Edit the status
    cy.getCy('latest-status-container').getCy('feed-item-edit').click();
    cy.getCy('edit-status-title-input').clear().type(statusEdited.title);
    cy.getCy('edit-status-going-well-input').clear().type(statusEdited.goingWell);
    cy.getCy('edit-status-challenges-input').clear().type(statusEdited.challenges);
    cy.getCy('edit-status-room-to-improve-input').clear().type(statusEdited.toImprove);
    cy.getCy('dialog-button-save').click();
    // Check that the status is edited
    // XXX: More should be shown and then checked.
    cy.getCy('status-feed-item').contains(statusEdited.title);
    cy.getCy('status-feed-item').contains(statusEdited.goingWell);
    cy.getCy('status-feed-item').contains(statusEdited.challenges);
    cy.getCy('status-feed-item').contains(statusEdited.toImprove);
  });

  it('Cancel editing status', () => {
    const statusOriginal = {
      title: 'All information',
      goingWell: 'This is going well',
      challenges: 'This is a challenge',
      toImprove: 'This could be improved',
    };

    const statusEdited = {
      title: 'Edited information',
      goingWell: 'Not is going well',
      challenges: 'Not a challenge',
      toImprove: 'This could not be improved',
    };

    cy.getCy('add-status-button').click();
    cy.getCy('edit-status-title-input').type(statusOriginal.title);
    cy.getCy('edit-status-going-well-input').type(statusOriginal.goingWell);
    cy.getCy('edit-status-challenges-input').type(statusOriginal.challenges);
    cy.getCy('edit-status-room-to-improve-input').type(statusOriginal.toImprove);
    cy.getCy('dialog-button-save').click();
    cy.getCy('status-feed-item').contains(statusOriginal.title);
    cy.getCy('status-feed-item').contains(statusOriginal.goingWell);
    cy.getCy('status-feed-item').contains(statusOriginal.challenges);
    cy.getCy('status-feed-item').contains(statusOriginal.toImprove);
    // Edit the status
    cy.getCy('latest-status-container').getCy('feed-item-edit').click();
    cy.getCy('edit-status-title-input').find('input').clear().type(statusEdited.title);
    cy.getCy('edit-status-going-well-input').clear().type(statusEdited.goingWell);
    cy.getCy('edit-status-challenges-input').clear().type(statusEdited.challenges);
    cy.getCy('edit-status-room-to-improve-input').clear().type(statusEdited.toImprove);
    cy.getCy('dialog-button-cancel').click();
    // Check that the status is edited
    cy.getCy('status-feed-item').contains(statusOriginal.title);
    cy.getCy('status-feed-item').contains(statusOriginal.goingWell);
    cy.getCy('status-feed-item').contains(statusOriginal.challenges);
    cy.getCy('status-feed-item').contains(statusOriginal.toImprove);
  });

  it('Show status updates', () => {
    const updatesStatus = {
      title: 'Updates title',
      goingWell: 'Updates is going well',
      challenges: 'Updates is a challenge',
      toImprove: 'Updates could be improved',
    };

    cy.getCy('add-status-button').click();
    cy.getCy('edit-status-title-input').type(updatesStatus.title);
    cy.getCy('edit-status-going-well-input').type(updatesStatus.goingWell);
    cy.getCy('edit-status-challenges-input').type(updatesStatus.challenges);
    cy.getCy('edit-status-room-to-improve-input').type(updatesStatus.toImprove);
    cy.getCy('dialog-button-save').click();

    cy.getCy('show-status-updates-button').click();
    cy.getCy('status-updates').get('[data-cy="feed-item"]').first().contains(updatesStatus.title);
  });

  it('Add comment and reply to status and check that they are also shown in feeds', () => {
    const status = {
      title: 'Comment status',
    };

    const comment = 'This is a comment';
    const reply = 'This is a reply';

    cy.getCy('add-status-button').click();
    cy.getCy('edit-status-title-input').type(status.title);
    cy.getCy('dialog-button-save').click();
    // Add comment
    cy.getCy('latest-status-container').find('[data-cy="feed-item-add-comment"]').click();
    cy.getCy('edit-comment-textfield').type(comment);
    cy.getCy('comment-save').click();

    // XXX: With within command the custom commands are not found :-(
    cy.get('[data-cy="latest-status-container"]').within(() => {
      // Check that the comment is shown
      cy.get('[data-cy="comment-item"]').contains(comment);
      // Add reply
      cy.get('[data-cy="comment-reply-button"]').click();
      cy.get('[data-cy="edit-comment-textfield"]').type(reply);
      cy.get('[data-cy="comment-save"]').click();  
      // Check that the reply is shown
      cy.get('[data-cy="comment-item"]').contains(reply);
    });

    // Check that the comment and reply are shown in feeds
    cy.getCy('nav-link-Feeds').click();
    cy.getCy('feeds-page');

    // getCy does not work with within command
    cy.contains(status.title).parents('[data-cy="feed-item"]').within(() => {
      cy.get('[data-cy="feed-item-expand-comments"]').click();
      cy.get('[data-cy="comment-item"]').contains(comment);
      cy.get('[data-cy="comment-show-replies-button"]').click();
      cy.get('[data-cy="comment-item"]').contains(reply);
    });
  });
});

describe('Status in goal and feeds page', () => {
  const goalTitle = 'Status goal 2';

  before(() => {
    cy.login();
    cy.visit('/main');
    // Add a goal so we can add the status
    cy.getCy('add-goal-button').click();
    cy.getCy('edit-goal-title-input').type(goalTitle);
    cy.getCy('dialog-button-save').click();
    cy.getCy(`goal-card-${goalTitle}`).find('[data-cy="expand-more"]').click();
  });

  beforeEach(() => {
    cy.login();
    cy.visit('/main');
    cy.getCy(`goal-card-${goalTitle}`).find('[data-cy="expand-more"]').click();
  });

  it('Show status in the feeds', () => {
    const status = {
      title: 'All information',
      goingWell: 'This is going well',
      challenges: 'This is a challenge',
      toImprove: 'This could be improved',
    };

    cy.getCy(`goal-card-${goalTitle}`).find('[data-cy="add-status-button"]').click();
    cy.getCy('edit-status-title-input').type(status.title);
    cy.getCy('edit-status-going-well-input').type(status.goingWell);
    cy.getCy('edit-status-challenges-input').type(status.challenges);
    cy.getCy('edit-status-room-to-improve-input').type(status.toImprove);
    cy.getCy('dialog-button-save').click();
    
    cy.getCy('nav-link-Feeds').click();
    cy.getCy('feeds-page');
    cy.getCy('status-feed-item').contains(status.title);
    cy.getCy('status-feed-item').contains(status.goingWell);
    cy.getCy('status-feed-item').contains(status.challenges);
    cy.getCy('status-feed-item').contains(status.toImprove);
  });

  it('Add comment and reply to status and check that they are also shown in main page', () => {
    const status = {
      title: 'Feeds comment status',
    };
    const comment = "Feed comment";
    const reply = "Feed reply";

    cy.getCy(`goal-card-${goalTitle}`).find('[data-cy="add-status-button"]').click();
    cy.getCy('edit-status-title-input').type(status.title);
    cy.getCy('dialog-button-save').click();
    
    cy.getCy('nav-link-Feeds').click();
    cy.getCy('feeds-page');

    // Add comment
    cy.contains(status.title).parents('[data-cy="feed-item"]').within(() => {
      cy.get('[data-cy="feed-item-add-comment"]').click();
      cy.get('[data-cy="edit-comment-textfield"]').type(comment);
      cy.get('[data-cy="comment-save"]').click();
      cy.get('[data-cy="comment-item"]').contains(comment);
      // Add reply
      cy.get('[data-cy="comment-reply-button"]').click();
      cy.get('[data-cy="edit-comment-textfield"]').type(reply);
      cy.get('[data-cy="comment-save"]').click();  
      // Check that the reply is shown
      cy.get('[data-cy="comment-item"]').contains(reply);
    });

    // Check that the comment and reply are shown in main page
    cy.getCy('nav-link-Goals').click();
    cy.getCy(`goal-card-${goalTitle}`).find('[data-cy="expand-more"]').click();
    cy.getCy('latest-status-container').find('[data-cy="feed-item-expand-comments"]').click();
    cy.getCy('latest-status-container').contains(comment);
    cy.getCy('latest-status-container').find('[data-cy="comment-show-replies-button"]').click();
    cy.getCy('latest-status-container').contains(reply);
  });

  it('Add status from the goals page', () => {
    const status = {
      title: 'Goal page status',
      goingWell: 'This is going well in goal page',
      challenges: 'This is a challenge in goal page',
      toImprove: 'This could be improved in goal page',
    };

    cy.getCy(`goal-card-${goalTitle}`).find('[data-cy="link-to-goal-details"]').click();
    cy.getCy('goal-page');
    cy.getCy('add-status-button').click();
    cy.getCy('edit-status-title-input').type(status.title);
    cy.getCy('edit-status-going-well-input').type(status.goingWell);
    cy.getCy('edit-status-challenges-input').type(status.challenges);
    cy.getCy('edit-status-room-to-improve-input').type(status.toImprove);
    cy.getCy('dialog-button-save').click();
    cy.getCy('status-feed-item').contains(status.title);
    cy.getCy('status-feed-item').contains(status.goingWell);
    cy.getCy('status-feed-item').contains(status.challenges);
    cy.getCy('status-feed-item').contains(status.toImprove);
  });

  it('Show status updates in goals page', () => {
    const updatesStatus = {
      title: 'Updates title',
      goingWell: 'Updates is going well',
      challenges: 'Updates is a challenge',
      toImprove: 'Updates could be improved',
    };

    cy.getCy(`goal-card-${goalTitle}`).find('[data-cy="link-to-goal-details"]').click();
    cy.getCy('goal-page');
    cy.getCy('add-status-button').click();
    cy.getCy('edit-status-title-input').type(updatesStatus.title);
    cy.getCy('edit-status-going-well-input').type(updatesStatus.goingWell);
    cy.getCy('edit-status-challenges-input').type(updatesStatus.challenges);
    cy.getCy('edit-status-room-to-improve-input').type(updatesStatus.toImprove);
    cy.getCy('dialog-button-save').click();

    cy.getCy('show-status-updates-button').click();
    cy.getCy('status-updates').find('[data-cy="feed-item"]').first().contains(updatesStatus.title);
  });
});


export {};