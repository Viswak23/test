/// <reference types="cypress" />

describe("Creating a goal in main page", () => {
  beforeEach(() => {
    cy.login();
  });

  it("Create a goal with only title", () => {
    const title = "Test goal";

    cy.visit("/main");
    cy.getCy("add-goal-button").click();
    cy.getCy("edit-goal-title-input").type(title);
    cy.getCy("dialog-button-save").click();
    // Check that the goal is created
    cy.getCy(`goal-card-${title}`);
    // Check that pressing update opens the dialog with existing information
    cy.getCy(`goal-card-${title}`)
      .find('[data-cy="goal-list-item-edit"]')
      .click();
    cy.getCy("edit-goal-title-input").find("input").should("have.value", title);
    cy.getCy("dialog-button-cancel").click();
  });

  it("Create a goal with all the information", () => {
    const goal = {
      title: "All information",
      description: "This is a description",
      reward: "This is a reward",
      startDate: "06062024",
      startDateRead: "06/06/2024",
      targetDate: "07072024",
      targetDateRead: "07/07/2024",
      useTasks: true,
    };

    cy.visit("/main");
    cy.getCy("add-goal-button").click();
    cy.getCy("edit-goal-title-input").type(goal.title);
    cy.getCy("edit-goal-description-input").type(goal.description);
    cy.getCy("edit-goal-reward-input").type(goal.reward);
    cy.getCy("edit-goal-start-date-container")
      .find("input")
      .type(goal.startDate);
    cy.getCy("edit-goal-target-date-container")
      .find("input")
      .type(goal.targetDate);
    cy.getCy("dialog-button-save").click();
    // Check that the goal is created
    cy.getCy(`goal-card-${goal.title}`);
    // Check that pressing update opens the dialog with existing information
    cy.getCy(`goal-card-${goal.title}`)
      .find('[data-cy="goal-list-item-edit"]')
      .click();
    cy.getCy("edit-goal-title-input")
      .find("input")
      .should("have.value", goal.title);
    cy.getCy("edit-goal-description-input")
      .find("textarea")
      .should("have.value", goal.description);
    cy.getCy("edit-goal-reward-input")
      .find("textarea")
      .should("have.value", goal.reward);
    cy.getCy("edit-goal-start-date-container")
      .find("input")
      .should("have.value", goal.startDateRead);
    cy.getCy("edit-goal-target-date-container")
      .find("input")
      .should("have.value", goal.targetDateRead);
    cy.getCy("dialog-button-cancel").click();
  });

  it("Cancel creating a goal does not create a goal", () => {
    cy.visit("/main");
    cy.getCy("add-goal-button").click();
    cy.getCy("edit-goal-title-input").type("Cancelled goal");
    cy.getCy("dialog-button-cancel").click();
    // Check that the goal is not created
    cy.getCy("goal-card-Cancelled goal").should("not.exist");
  });

  it("Creating a goal without title gives an error", () => {
    cy.visit("/main");
    cy.getCy("add-goal-button").click();
    cy.getCy("edit-goal-description-input").type("We give an description");
    cy.getCy("dialog-button-save").click();
    cy.getCy("edit-goal-title-input").should("contain", "Title is required");
    cy.getCy("dialog-button-cancel").click();
  });
});

describe("Updating a goal in main page", () => {
  const originalGoal = {
    title: "Update goal",
    description: "Update goal description",
    reward: "Update goal reward",
    startDate: "06062024",
    startDateRead: "06/06/2024",
    targetDate: "07072024",
    targetDateRead: "07/07/2024",
  };

  const cancelUpdateGoalTitle = "Cancel update";

  // Create a goals for the tests
  before(() => {
    cy.login();
    cy.visit("/main");
    cy.getCy("add-goal-button").click();
    cy.getCy("edit-goal-title-input").type(originalGoal.title);
    cy.getCy("edit-goal-description-input").type(originalGoal.description);
    cy.getCy("edit-goal-reward-input").type(originalGoal.reward);
    cy.getCy("edit-goal-start-date-container")
      .find("input")
      .type(originalGoal.startDate);
    cy.getCy("edit-goal-target-date-container")
      .find("input")
      .type(originalGoal.targetDate);
    cy.getCy("dialog-button-save").click();
    cy.getCy(`goal-card-${originalGoal.title}`);
    cy.getCy("add-goal-button").click();
    cy.getCy("edit-goal-title-input").type(cancelUpdateGoalTitle);
    cy.getCy("dialog-button-save").click();
    cy.getCy(`goal-card-${cancelUpdateGoalTitle}`);
  });

  beforeEach(() => {
    cy.login();
  });

  it("Update all the goal information", () => {
    const updatedGoal = {
      title: "Updated information",
      description: "Updated description",
      reward: "Updated reward",
      startDate: "05052024",
      startDateRead: "05/05/2024",
      targetDate: "08082024",
      targetDateRead: "08/08/2024",
    };

    cy.visit("/main");
    cy.getCy(`goal-card-${originalGoal.title}`)
      .find('[data-cy="goal-list-item-edit"]')
      .click();
    cy.getCy("edit-goal-title-input")
      .find("input")
      .clear()
      .type(updatedGoal.title);
    cy.getCy("edit-goal-description-input")
      .clear()
      .type(updatedGoal.description);
    cy.getCy("edit-goal-reward-input").clear().type(updatedGoal.reward);
    cy.getCy("edit-goal-start-date-container")
      .find("input")
      .type(updatedGoal.startDate);
    cy.getCy("edit-goal-target-date-container")
      .find("input")
      .type(updatedGoal.targetDate);
    cy.getCy("dialog-button-save").click();
    // Check that the goal is created
    cy.getCy(`goal-card-${updatedGoal.title}`);
    // Check that pressing update opens the dialog with existing information
    cy.getCy(`goal-card-${updatedGoal.title}`)
      .find('[data-cy="goal-list-item-edit"]')
      .click();
    cy.getCy("edit-goal-title-input")
      .find("input")
      .should("have.value", updatedGoal.title);
    cy.getCy("edit-goal-description-input")
      .find("textarea")
      .should("have.value", updatedGoal.description);
    cy.getCy("edit-goal-reward-input")
      .find("textarea")
      .should("have.value", updatedGoal.reward);
    cy.getCy("edit-goal-start-date-container")
      .find("input")
      .should("have.value", updatedGoal.startDateRead);
    cy.getCy("edit-goal-target-date-container")
      .find("input")
      .should("have.value", updatedGoal.targetDateRead);
    cy.getCy("dialog-button-cancel").click();
  });

  it("Cancel updating a goal does not change information", () => {
    const updatedTitle = "We are cancelling";

    cy.visit("/main");
    cy.getCy(`goal-card-${cancelUpdateGoalTitle}`)
      .find('[data-cy="goal-list-item-edit"]')
      .click();
    cy.getCy("edit-goal-title-input").type(updatedTitle);
    cy.getCy("dialog-button-cancel").click();
    // Check that the goal is not updated
    cy.getCy(`goal-card-${cancelUpdateGoalTitle}`);
    cy.getCy(`goal-card-${updatedTitle}`).should("not.exist");
  });

  it("Trying to clear the goal title gives an error", () => {
    cy.visit("/main");
    cy.getCy(`goal-card-${cancelUpdateGoalTitle}`)
      .find('[data-cy="goal-list-item-edit"]')
      .click();
    cy.getCy("edit-goal-title-input").find("input").clear();
    cy.getCy("dialog-button-save").click();
    cy.getCy("edit-goal-title-input").should("contain", "Title is required");
    cy.getCy("dialog-button-cancel").click();
  });
});

export {};
