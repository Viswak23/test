describe("Organization units main page", () => {
  const organization = {
    main1: {
      name: "Main 1",
      children: [
        {
          name: "Sub 1",
          children: [],
          employees: [{ name: "SubEmployee 1", email: "test2@test.test" }],
        },
        {
          name: "Sub 2",
          children: [],
          employees: [{ name: "SubEmployee 2", email: "test3@test.test" }],
        },
      ],
      employees: [{ name: "Employee 1", email: "test@test.test" }],
    },
    main2: {
      name: "Main 2",
      updatedName: "Updated Main 2",
      children: [],
    },
  };

  beforeEach(() => {
    cy.login();
  });

  it("Create organization units and show them in main page", () => {
    cy.visit("/main");
    cy.getCy("add-organization-unit-button").click();
    cy.getCy("edit-organization-name-input").type(organization.main1.name);
    cy.getCy("dialog-button-save").click();
    // Check that the organization unit is created
    cy.getCy(`organization-unit-card-${organization.main1.name}`).contains(
      organization.main1.name
    );
    // Check that pressing edit opens the dialog with existing information
    cy.getCy(`organization-unit-card-${organization.main1.name}`)
      .find('[data-cy="edit-organization-unit-button"]')
      .click();
    cy.getCy("edit-organization-name-input")
      .find("input")
      .should("have.value", organization.main1.name);
    cy.getCy("dialog-button-cancel").click();
  });

  it("Empty name shows error", () => {
    cy.visit("/main");
    cy.getCy("add-organization-unit-button").click();
    cy.getCy("dialog-button-save").click();
    cy.getCy("edit-organization-name-input").should(
      "contain",
      "Organization unit name is required"
    );
    cy.getCy("dialog-button-cancel").click();
  });

  it("Cancel creating organization unit does not create it", () => {
    cy.visit("/main");
    cy.getCy("add-organization-unit-button").click();
    cy.getCy("edit-organization-name-input").type("Foobar");
    cy.getCy("dialog-button-cancel").click();
    cy.getCy(`organization-unit-card-Foobar`).should("not.exist");
  });

  it("Create suborganization units and show them in main page", () => {
    cy.visit("/main");
    cy.getCy(`organization-unit-card-${organization.main1.name}`)
      .find('[data-cy="expand-organization-unit-button"]')
      .click();
    cy.getCy("add-organization-unit-button").click();
    cy.getCy("edit-organization-name-input").type(
      organization.main1.children[0].name
    );
    cy.getCy("dialog-button-save").click();
    cy.getCy("add-organization-unit-button").click();
    cy.getCy("edit-organization-name-input").type(
      organization.main1.children[1].name
    );
    cy.getCy("dialog-button-save").click();
    cy.getCy(`organization-unit-card-${organization.main1.children[0].name}`);
    cy.getCy(`organization-unit-card-${organization.main1.children[1].name}`);
  });

  it("Update organization unit name", () => {
    cy.visit("/main");
    cy.getCy("add-organization-unit-button").click();
    cy.getCy("edit-organization-name-input")
      .find("input")
      .clear()
      .type(organization.main2.name);
    cy.getCy("dialog-button-save").click();
    cy.getCy(`organization-unit-card-${organization.main2.name}`).contains(
      organization.main2.name
    );
    cy.getCy(`organization-unit-card-${organization.main2.name}`)
      .find('[data-cy="edit-organization-unit-button"]')
      .click();
    cy.getCy("edit-organization-name-input")
      .find("input")
      .clear()
      .type(organization.main2.updatedName);
    cy.getCy("dialog-button-save").click();
    cy.getCy(
      `organization-unit-card-${organization.main2.updatedName}`
    ).contains(organization.main2.updatedName);
  });

  it("Clear organization unit name shows error", () => {
    cy.visit("/main");
    cy.getCy(`organization-unit-card-${organization.main1.name}`)
      .find('[data-cy="edit-organization-unit-button"]')
      .click();
    cy.getCy("edit-organization-name-input").find("input").clear();
    cy.getCy("dialog-button-save").click();
    cy.getCy("edit-organization-name-input").should(
      "contain",
      "Organization unit name is required"
    );
    cy.getCy("dialog-button-cancel").click();
  });

  it("Cancel organization unit update does not update it", () => {
    cy.visit("/main");
    cy.getCy(`organization-unit-card-${organization.main1.name}`)
      .find('[data-cy="edit-organization-unit-button"]')
      .click();
    cy.getCy("edit-organization-name-input").type("Cancel update");
    cy.getCy("dialog-button-cancel").click();
    cy.getCy(`organization-unit-card-Cancel update`).should("not.exist");
    cy.getCy(`organization-unit-card-${organization.main1.name}`).contains(
      organization.main1.name
    );
  });
});

export {};
