/// <reference types="cypress" />

const remainingGoal = {
  title: "Remaining goal",
  description: "This goal remains",
  keyResults: [
    {
      title: "This key result remains",
    },
  ],
  ideas: [
    {
      title: "This idea remains",
    },
  ],
  redFlags: [
    {
      comment: "This red flag remains",
    },
  ],
  successStories: [
    {
      text: "This success story remains",
    },
  ],
  contributions: [
    {
      description: "This contribution remains",
    },
  ],
};

const deletedGoal = {
  title: "Deleted goal",
  keyResults: [
    {
      title: "This key result is deleted",
    },
  ],
  ideas: [
    {
      title: "This idea is deleted",
    },
  ],
  redFlags: [
    {
      comment: "This red flag is deleted",
    },
  ],
  successStories: [
    {
      text: "This success story is deleted",
    },
  ],
  contributions: [
    {
      description: "This contribution is deleted",
    },
  ],
};

describe("Delete goal", () => {
  before(() => {
    cy.visit("/main");
    // Create a goal that is not deleted.
    cy.createGoalWithChildElements(remainingGoal);
    // Create a goal that is deleted.
    cy.createGoalWithChildElements(deletedGoal);
  });

  beforeEach(() => {
    cy.login();
  });

  it("Delete a goal succees and removes all the children", () => {
    cy.visit("/main");
    // Check that after delete returns to main page and deleted goal is not there and remaining goal is there
    cy.getCy(`goal-card-${deletedGoal.title}`)
      .find('[data-cy="link-to-goal-details"]')
      .click();
    cy.getCy("delete-goal-button").click();
    cy.getCy("dialog-button-save").click();
    cy.getCy("main-page").should("be.visible");
    cy.getCy(`goal-card-${deletedGoal.title}`).should("not.exist");
    cy.getCy(`goal-card-${remainingGoal.title}`).should("be.visible");
  });

  it("Cancel dont delete a goal", () => {
    cy.visit("/main");
    cy.getCy(`goal-card-${remainingGoal.title}`)
      .find('[data-cy="link-to-goal-details"]')
      .click();
    cy.getCy("delete-goal-button").click();
    cy.getCy("dialog-button-cancel").click();
    cy.getCy("goal-detail-heading-container").contains(remainingGoal.title);
  });

  it("Cannot delete a goal with a subgoal", () => {
    const goalName = "Test goal";
    const subgoalName = "Subgoal";

    cy.visit("/main");
    cy.getCy("add-goal-button").click();
    cy.getCy("edit-goal-title-input").type(goalName);
    cy.getCy("dialog-button-save").click();
    cy.getCy("add-organization-unit-button").click();
    cy.getCy("edit-organization-name-input").type("Organization");
    cy.getCy("dialog-button-save").click();
    cy.getCy(`organization-unit-card-Organization`)
      .find('[data-cy="link-to-organization-details"]')
      .click();
    cy.getCy(`organization-unit-add-goal-button-${goalName}`).click();
    cy.getCy("edit-goal-title-input").type("Subgoal");
    cy.getCy("dialog-button-save").click();
    cy.getCy("goal-card-Subgoal").contains(subgoalName);
    cy.getCy(`parentgoal-link-${goalName}`).contains(goalName).click();
    cy.getCy("goal-detail-heading-container").contains(goalName);
    cy.getCy("delete-goal-button").click();
    cy.getCy("information-dialog").contains("Cannot delete goal");
  });
});

export {};
