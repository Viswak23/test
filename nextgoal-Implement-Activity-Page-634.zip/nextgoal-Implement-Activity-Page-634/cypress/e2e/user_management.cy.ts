/// <reference types="cypress" />

describe("Testing usermanagement.", () => {
  beforeEach(() => {
    cy.login();
  });

  it("Create a user", () => {
    cy.visit("/users");
    cy.getCy("add-employee-button").click();
    cy.getCy("edit-employee-name-input").type("Test Tim");
    cy.getCy("edit-employee-email-input").type("testdummy@taigoa.fi");
    cy.getCy("dialog-button-save").click();
    // Check that the user is created
    cy.getCy("employee-card").contains("Test Tim");
  });
  it("Disable user login", () => {
    cy.visit("/users");
    cy.getCy("disable-employee").click();
    cy.getCy("dialog-button-save").click();
    // Check that the user is disabled
    cy.getCy("enable-employee");
  });
  it("Enable user login", () => {
    cy.visit("/users");
    cy.getCy("enable-employee").click();
    cy.getCy("dialog-button-save").click();
    // Check that the user is enabled
    cy.getCy("disable-employee");
  });
  it("Delete user", () => {
    cy.visit("/users");
    cy.getCy("delete-employee-button").click();
    cy.getCy("dialog-button-save").click();
    // Check that the user is deleted
    cy.contains("Test Tim").should("not.exist");
  });
});

export {};
