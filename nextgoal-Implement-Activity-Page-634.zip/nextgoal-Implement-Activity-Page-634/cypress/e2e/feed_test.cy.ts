/// <reference types="cypress" />

describe("Feed test setup", () => {
  const newComment = "Nice Work";
  const editComment = "Nice Work - edit";
  const cancelComment = "Nice Work - cancel";
  const replyText = "Nice Work-Reply";
  const replyEditText = "Nice Work-Reply-Edit";
  const replyEditCancel = "Nice Work-Reply-Edit-Cancel";
  const replyCancel = "Nice Work-Reply-Cancel";

  const Replies = {
    positive: [
      "Great job on this project!",
      "Well done, I'm really impressed with your work.",
      "This is exactly what we needed. Fantastic!",
      "You’ve outdone yourself this time. Amazing!",
    ],
    negative: [
      "This needs a lot of improvement.",
      "I’m not sure this meets our standards.",
      "This has unfortunately missed the mark.",
      "We might need to start over on this one.",
    ],
  };

  before(() => {
    cy.login().then(() => {
      cy.visit("/main");
      cy.createGoal({
        title: "Write test",
        description: "Write test description",
        reward: "no bug is reward",
        startDate: "07072024",
        targetDate: "10102025",
      });
    });
  });
  beforeEach(() => {
    cy.login();
    cy.visit("/feeds");
  });

  it("should display the feed with items", () => {
    cy.get('[data-cy="feeds-page"]').should(
      "be.visible",
      "Feeds page did not load or is not visible within the expected time."
    );
    cy.get("body").then(($body) => {
      $body.find('[data-cy="feed-item"]');

      cy.get('[data-cy="feed-item-actions"]').each(($item, index) => {
        cy.wrap($item).within(() => {
          cy.get('[data-cy="feed-item-likes"]').should("be.visible");
          cy.get('[data-cy="feed-item-add-comment"]').should("be.visible");
          cy.get('[data-cy="feed-item-expand-comments"]').should("be.visible");
        });
      });
    });
  });

  it("Verify functionality of like button", () => {
    cy.getCy("feed-item-likes").click();
    cy.getCy("likes-count").should("contain", "1 like");
  });

  context("Comment", () => {
    it("allows a user to add and save a comment", () => {
      cy.getCy("feed-item-add-comment").click();
      cy.getCy("edit-comment-textfield")
        .find("textArea")
        .first()
        .type(newComment);
      cy.getCy("comment-save").click();
      cy.getCy("comment-item").should("contain", newComment);
    });

    it("allows a user to cancel adding a comment", () => {
      cy.getCy("feed-item-add-comment").click();
      cy.getCy("edit-comment-textfield")
        .find("textArea")
        .first()
        .type(cancelComment);
      cy.getCy("comment-cancel").click();
      cy.getCy("comment-item").should("not.contain", cancelComment);
    });

    it("allows a user to edit and save an existing comment", () => {
      cy.getCy("feed-item-add-comment").click();
      cy.getCy("edit-comment-textfield")
        .find("textarea")
        .first()
        .type(editComment);
      cy.getCy("comment-save").click();
      cy.getCy("comment-item").should("contain", editComment);
      //edit comment
      cy.getCy("comment-item")
        .contains(editComment)
        .parents('[data-cy="comment-item"]')
        .within(() => {
          cy.getCy("comment-edit-button").click();
        });

      cy.getCy("edit-comment-textfield")
        .find("textarea")
        .first()
        .clear()
        .type(Replies.positive[0]);
      cy.getCy("comment-save").click();

      cy.getCy("comment-item").should("contain", Replies.positive[0]);
    });

    it("allows a user to cancel updating an existing comment", () => {
      cy.getCy("feed-item-add-comment").click();
      cy.getCy("edit-comment-textfield")
        .find("textarea")
        .first()
        .type(cancelComment);
      cy.getCy("comment-save").click();
      cy.getCy("comment-item").should("contain", cancelComment);
      //edit comment
      cy.getCy("comment-item")
        .contains(cancelComment)
        .parents('[data-cy="comment-item"]')
        .within(() => {
          cy.getCy("comment-edit-button").click();
        });

      cy.getCy("edit-comment-textfield")
        .find("textarea")
        .first()
        .clear()
        .type(Replies.negative[0]);
      cy.getCy("comment-cancel").click();

      cy.getCy("comment-item").should("not.contain", Replies.negative[0]);
    });
  });

  context("Reply Functionality", () => {
    it("Successfully creates and displays a reply to a comment", () => {
      cy.getCy("feed-item-add-comment").click();
      cy.getCy("edit-comment-textfield")
        .find("textarea")
        .first()
        .type(replyText);
      cy.getCy("comment-save").click();
      cy.getCy("comment-item").should("contain", replyText);
      //add reply
      cy.getCy("comment-item")
        .contains(replyText)
        .parents('[data-cy="comment-item"]')
        .within(() => {
          cy.getCy("comment-reply-button").click();
        });
      cy.getCy("edit-comment-textfield")
        .find("textarea")
        .first()
        .type(Replies.positive[1]);
      cy.getCy("comment-save").click();

      cy.contains('[data-cy="comment-item"]', replyText);
      cy.getCy("comment-item").should("contain", Replies.positive[1]);
    });

    it("Successfully edits a reply and reflects changes", () => {
      cy.getCy("feed-item-add-comment").click();
      cy.getCy("edit-comment-textfield")
        .find("textarea")
        .first()
        .type(replyEditText);
      cy.getCy("comment-save").click();
      cy.getCy("comment-item").should("contain", replyEditText);
      //add reply
      cy.getCy("comment-item")
        .contains(replyEditText)
        .parents('[data-cy="comment-item"]')
        .within(() => {
          cy.getCy("comment-reply-button").click();
        });
      cy.getCy("edit-comment-textfield")
        .find("textarea")
        .first()
        .type(Replies.positive[1]);
      cy.getCy("comment-save").click();

      cy.contains('[data-cy="comment-item"]', replyEditText);
      cy.getCy("comment-item").should("contain", Replies.positive[1]);

      //EDIT REPLY
      cy.contains('[data-cy="comment-item"]', Replies.positive[1])
        .find('[data-cy="comment-edit-button"]')
        .click();
      cy.getCy("edit-comment-textfield")
        .find("textarea")
        .first()
        .clear()
        .type(Replies.positive[2]);
      cy.getCy("comment-save").click();

      cy.contains('[data-cy="comment-item"]', replyEditText);
      cy.getCy("comment-item").should("contain", Replies.positive[2]);
    });

    it("Allows canceling during reply creation without adding a reply", () => {
      cy.getCy("feed-item-add-comment").click();
      cy.getCy("edit-comment-textfield")
        .find("textarea")
        .first()
        .type(replyCancel);
      cy.getCy("comment-save").click();
      cy.getCy("comment-item").should("contain", replyCancel);
      //add reply /cancel add reply
      cy.getCy("comment-item")
        .contains(replyCancel)
        .parents('[data-cy="comment-item"]')
        .within(() => {
          cy.getCy("comment-reply-button").click();
        });
      cy.getCy("edit-comment-textfield")
        .find("textarea")
        .first()
        .type(Replies.negative[1]);
      cy.getCy("comment-cancel").click();

      cy.contains('[data-cy="comment-item"]', replyCancel);
      cy.getCy("comment-item").should("not.contain", Replies.negative[1]);
    });

    it("Cancels and discards changes during reply editing", () => {
      cy.getCy("feed-item-add-comment").click();
      cy.getCy("edit-comment-textfield")
        .find("textarea")
        .first()
        .type(replyEditCancel);
      cy.getCy("comment-save").click();
      cy.getCy("comment-item").should("contain", replyEditCancel);

      cy.getCy("comment-item")
        .contains(replyEditCancel)
        .parents('[data-cy="comment-item"]')
        .within(() => {
          cy.getCy("comment-reply-button").click();
        });
      cy.getCy("edit-comment-textfield")
        .find("textarea")
        .first()
        .type(Replies.positive[3]);
      cy.getCy("comment-save").click();
      cy.contains('[data-cy="comment-item"]', replyEditCancel);
      cy.getCy("comment-item").should("contain", Replies.positive[3]);
      //EDIT REPLY /cancel functionality
      cy.contains('[data-cy="comment-item"]', replyEditCancel);
      cy.contains('[data-cy="comment-item"]', Replies.positive[3])
        .find('[data-cy="comment-edit-button"]')
        .click();
      cy.getCy("edit-comment-textfield")
        .find("textarea")
        .first()
        .clear()
        .type(Replies.negative[3]);
      cy.getCy("comment-cancel").click();

      cy.contains('[data-cy="comment-item"]', replyEditCancel);
      cy.getCy("comment-item").should("not.contain", Replies.negative[3]);
    });
  });
});

export {};
