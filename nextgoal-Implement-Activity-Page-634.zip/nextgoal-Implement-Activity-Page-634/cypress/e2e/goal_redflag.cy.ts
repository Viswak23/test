/// <reference types="cypress" />

const goal = {
  title: "Complete Project",
  description: "Finish the project by the end of Q4.",
  reward: "Bonus",
};

const flags = {
  Initial: "Beginning Test Red Flag",
  NotAdded: "Not Test Red Flag",
  Edit: "Editable Test Red Flag",
  Comment: "Comment Test Red Flag",
  CommentReply: "Comment/Reply Test Red Flag",
  Delete: "Deletion Test Red Flag",
  DeleteCancel: "Cancel Deletion Test Red Flag",
};

const resolvedFlags = {
  Initial: "Resolved Red Flag",
  Edit: "Edit Resolved Red Flag",
  Comment: "RESOLVED Comment Test",
  CommentReply: "RESOLVED Comment/Reply Test",
  Delete: "Delete Resolved Test Red Flag",
  CancelDelete: "Cancel Deletion Resolved Test Red Flag",
};

describe("Testing Red Flag Functionality", () => {
  before(() => {
    cy.login();
    cy.visit("/main");
    cy.createGoal(goal);
  });

  beforeEach(() => {
    cy.login();
    cy.visit("/main");
    cy.getCy(`goal-card-${goal.title}`).find('[data-cy="expand-more"]').click();
    cy.viewport(1400, 1100);
  });

  it("Creates a Red Flag with title", () => {
    cy.createRedFlag(flags.Initial);
  });

  it("Cancel Creating a Red Flag with title", () => {
    cy.getCy("red-flags-tab").click();
    cy.getCy("add-subitem-button").click();
    cy.getCy("edit-redflag-description").type(flags.NotAdded);
    cy.getCy("dialog-button-cancel").click();
    cy.contains('[data-cy="feed-item"]', flags.NotAdded).should("not.exist");
  });

  it("Allows to edit a Red Flag", () => {
    cy.createRedFlag(flags.Edit);
    cy.contains('[data-cy="feed-item"]', flags.Edit)
      .find('[data-cy="feed-item-edit"]')
      .click();
    cy.getCy("edit-redflag-description")
      .find("input")
      .clear()
      .type("Editted Test Red Flag");
    cy.getCy("dialog-button-save").click();
    cy.contains('[data-cy="feed-item"]', flags.Edit).should("exist");
  });

  context("Comment Functionality", () => {
    const comment = { initial: "Comment", edit: "Edited Comment" };

    it("Allows to add a comment and edit a comment", () => {
      cy.createRedFlag(flags.Comment);

      cy.contains('[data-cy="feed-item"]', flags.Comment)
        .find('[data-cy="feed-item-actions"] [data-testid="AddCommentIcon"]')
        .click();
      cy.getCy("edit-comment-textfield").type(comment.initial);
      cy.getCy("comment-save").click();
      cy.contains('[data-cy="comment-item"]', comment.initial).should("exist");

      //add edit comment code
      cy.contains('[data-cy="comment-item"]', comment.initial)
        .find('[data-cy="comment-edit-button"]')
        .click();
      cy.getCy("edit-comment-textfield")
        .contains("textArea", comment.initial)
        .clear()
        .type(comment.edit);
      cy.getCy("comment-save").click();
      cy.contains('[data-cy="comment-item"]', comment.edit).should("exist");
    });

    it("Allows adding a comment reply and editing a reply", () => {
      const comment = "Comment Test";
      const reply = { initial: "Reply", edit: "Edited Reply" };
      cy.createRedFlag(flags.CommentReply);

      cy.contains('[data-cy="feed-item"]', flags.CommentReply)
        .find('[data-cy="feed-item-actions"] [data-testid="AddCommentIcon"]')
        .click();
      cy.getCy("edit-comment-textfield").type(comment);
      cy.getCy("comment-save").click();
      cy.contains('[data-cy="comment-item"]', comment).should("exist");

      cy.getCy("comment-item").find('[data-cy="comment-reply-button"]').click();
      cy.getCy("edit-comment-textfield").type(reply.initial);
      cy.getCy("comment-save").click();

      //add reply edit code here or in another test
      cy.contains('[data-cy="comment-item"]', reply.initial)
        .find('[data-cy="comment-edit-button"]')
        .click();
      cy.getCy("edit-comment-textfield")
        .contains("textArea", reply.initial)
        .clear()
        .type(reply.edit);
      cy.getCy("comment-save").click();
      cy.contains('[data-cy="comment-item"]', reply.edit).should("exist");
    });
  });

  context("Delete functionality", () => {
    it("Delete Red Flag", () => {
      cy.createRedFlag(flags.Delete);

      cy.getCy(`goal-card-${goal.title}`)
        .contains('[data-cy="feed-item"]', flags.Delete)
        .find('[data-testid="DeleteIcon"]')
        .click();

      cy.get('[role="dialog"]').find('[data-cy="dialog-button-save"]').click();

      cy.getCy("red-flags-tab").click();
      cy.getCy(`goal-card-${goal.title}`)
        .contains("[data-cy='feed-item']", flags.Delete)
        .should("not.exist");
    });

    it("Canceling Delete Red Flag", () => {
      cy.createRedFlag(flags.DeleteCancel);

      cy.getCy(`goal-card-${goal.title}`)
        .contains('[data-cy="feed-item"]', flags.DeleteCancel)
        .find('[data-testid="DeleteIcon"]')
        .click();

      cy.get('[role="dialog"]')
        .find('[data-cy="dialog-button-cancel"]')
        .click();

      cy.getCy("red-flags-tab").click();
      cy.getCy(`goal-card-${goal.title}`)
        .contains('[data-cy="feed-item"]', flags.DeleteCancel)
        .should("exist");
    });
  });

  context("Resolved Test Add and Edit", () => {
    it("Resolves A Red Flag and adds resolve comment.", () => {
      const resolvedComment = "Resolved Test";
      cy.createRedFlag(resolvedFlags.Initial);
      cy.contains('[data-cy="feed-item"]', resolvedFlags.Initial)
        .find('[data-cy="feed-item-edit"]')
        .click();
      cy.getCy("resolved-checkbox").find('[type="checkbox"]').check();
      cy.get("#resolvedComment").type(resolvedComment);
      cy.getCy("dialog-button-save").click();

      cy.getCy("resolved-flags").within(() => {
        cy.get('[data-cy="expand-more"]').click();
        cy.contains('[data-cy="feed-item"]', resolvedFlags.Initial).should(
          "contain",
          resolvedComment
        );
      });
    });

    it("Edit Resolved Red Flag", () => {
      const resolvedComment = {
        initial: "Resolved Test - edit",
        reOpened: "Not Resolved Flag",
      };
      const edit = { description: "Check the Red Flag" };
      cy.createRedFlag(resolvedFlags.Edit);
      cy.contains('[data-cy="feed-item"]', resolvedFlags.Edit)
        .find('[data-cy="feed-item-edit"]')
        .click();
      cy.getCy("resolved-checkbox").find('[type="checkbox"]').check();
      cy.get("#resolvedComment").type(resolvedComment.initial);
      cy.getCy("dialog-button-save").click();

      cy.getCy("resolved-flags").find('[data-cy="expand-more"]').click();
      cy.contains('[data-cy="feed-item"]', resolvedComment.initial)
        .find('[data-cy="feed-item-edit"]')
        .click();

      cy.getCy("edit-redflag-description")
        .find("#description")
        .clear()
        .type(edit.description);
      cy.getCy("resolved-checkbox").find('[type="checkbox"]').uncheck();
      cy.get("#reopenedComment").type(resolvedComment.reOpened);
      cy.getCy("dialog-button-save").click();

      cy.getCy(`goal-card-${goal.title}`)
        .contains('[data-cy="feed-item"]', edit.description)
        .should("contain", resolvedComment.reOpened);
    });
  });

  context("RESOLVED Test Comment-Reply functionality", () => {
    const comments = [
      "Comment for RESOLVED flag",
      "Comment/reply for RESOLVEDflag",
      "Reply for RESOLVED flag",
    ];
    const editComments = [
      "Editted comment for RESOLVED flag",
      "editted reply for RESOLVED flag",
    ];
    it("Allows to add a comment and edit the comment", () => {
      const resolvedComment = "RESOLVED Comment";
      cy.createRedFlag(resolvedFlags.Comment);
      //resolving flags
      cy.contains('[data-cy="feed-item"]', resolvedFlags.Comment)
        .find('[data-cy="feed-item-edit"]')
        .click();
      cy.getCy("resolved-checkbox").find('[type="checkbox"]').check();
      cy.get("#resolvedComment").type(resolvedComment);
      cy.getCy("dialog-button-save").click();

      //adding comment
      cy.getCy("resolved-flags").find('[data-cy="expand-more"]').click();
      cy.contains('[data-cy="feed-item"]', resolvedComment)
        .find('[data-cy="feed-item-actions"] [data-testid="AddCommentIcon"]')
        .click();
      cy.getCy("edit-comment-textfield").type(comments[0]);
      cy.getCy("comment-save").click();
      cy.contains('[data-cy="comment-item"]', comments[0]).should("exist");
      //editting comment
      cy.contains('[data-cy="comment-item"]', comments[0])
        .find('[data-cy="comment-edit-button"]')
        .click();
      cy.getCy("edit-comment-textfield")
        .contains("textarea", comments[0])
        .clear()
        .type(editComments[0]);
      cy.getCy("comment-save").click();
      cy.contains('[data-cy="comment-item"]', editComments[0]).should("exist");
    });

    it("Allows to add a reply and edit the reply", () => {
      const resolvedComment = "RESOLVED Comment/Reply";
      cy.createRedFlag(resolvedFlags.CommentReply);
      cy.contains('[data-cy="feed-item"]', resolvedFlags.CommentReply)
        .find('[data-cy="feed-item-edit"]')
        .click();

      //resolveing red flag
      cy.getCy("resolved-checkbox").find('[type="checkbox"]').check();
      cy.get("#resolvedComment").type(resolvedComment);
      cy.getCy("dialog-button-save").click();

      //commenting resolved flag
      cy.getCy("resolved-flags").find('[data-cy="expand-more"]').click();
      cy.contains('[data-cy="feed-item"]', resolvedComment)
        .find('[data-cy="feed-item-actions"] [data-testid="AddCommentIcon"]')
        .click();
      cy.getCy("edit-comment-textfield").type(comments[1]);
      cy.getCy("comment-save").click();
      cy.contains('[data-cy="comment-item"]', comments[1]).should("exist");

      //adding reply
      cy.contains('[data-cy="comment-item"]', comments[1])
        .find('[data-cy="comment-reply-button"]')
        .click();
      cy.getCy("edit-comment-textfield").type(comments[2]);
      cy.getCy("comment-save").click();
      cy.contains('[data-cy="comment-item"]', comments[2]).should("exist");

      //editing reply flag
      cy.contains('[data-cy="comment-item"]', comments[2])
        .find('[data-cy="comment-edit-button"]')
        .click();
      cy.getCy("edit-comment-textfield")
        .contains("textarea", comments[2])
        .clear()
        .type(editComments[1]);
      cy.getCy("comment-save").click();
      cy.contains('[data-cy="comment-item"]', editComments[1]).should("exist");
    });
  });

  context("Resolved Test Delete Funtionality", () => {
    const resolvedComment = "Resolved Test";
    it("Allows to Delete Resolved Red Flag", () => {
      cy.createRedFlag(resolvedFlags.Delete);

      cy.getCy(`goal-card-${goal.title}`)
        .contains('[data-cy="feed-item"]', resolvedFlags.Delete)
        .find('[data-cy="feed-item-edit"]')
        .click();
      cy.getCy("resolved-checkbox").find('[type="checkbox"]').check();
      cy.get("#resolvedComment").type(resolvedComment);
      cy.getCy("dialog-button-save").click();

      cy.getCy("resolved-flags").find('[data-cy="expand-more"]').click();
      cy.getCy("feed-item").contains(resolvedComment);
      cy.contains('[data-cy="feed-item"]', resolvedFlags.Delete)
        .find('[data-testid="DeleteIcon"]')
        .click();
      cy.get('[role="dialog"]').find('[data-cy="dialog-button-save"]').click();
      cy.getCy("red-flags-tab").click();
      cy.contains('[data-cy="feed-item"]', resolvedFlags.Delete).should(
        "not.exist"
      );
    });

    it("Allows to Cancel Deletion of a Resolved Flag", () => {
      const resolvedComment = "Resolved Test";
      cy.createRedFlag(resolvedFlags.CancelDelete);

      cy.getCy(`goal-card-${goal.title}`)
        .contains('[data-cy="feed-item"]', resolvedFlags.CancelDelete)
        .find('[data-cy="feed-item-edit"]')
        .click();
      cy.getCy("resolved-checkbox").find('[type="checkbox"]').check();
      cy.get("#resolvedComment").type(resolvedComment);
      cy.getCy("dialog-button-save").click();

      cy.getCy("resolved-flags").find('[data-cy="expand-more"]').click();
      cy.getCy("feed-item").contains(resolvedComment);
      cy.contains('[data-cy="feed-item"]', resolvedFlags.CancelDelete)
        .find('[data-testid="DeleteIcon"]')
        .click();
      cy.get('[role="dialog"]')
        .find('[data-cy="dialog-button-cancel"]')
        .click();
      cy.getCy("red-flags-tab").click();
      cy.contains('[data-cy="feed-item"]', resolvedFlags.CancelDelete).should(
        "exist"
      );
    });
  });
});

export {};
