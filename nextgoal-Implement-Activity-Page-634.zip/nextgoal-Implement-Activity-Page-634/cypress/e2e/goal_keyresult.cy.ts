/// <reference types="cypress" />
const goal = {
  title: "Complete Project",
};
const textContent = {
  initialComment: "this is test comment.",
  editedComment: "Editted Comment",
  replyText: "Reply to comment",
  editedReply: "Editted Reply",
};

describe("Testing Key Result Functionality", () => {
  before(() => {
    cy.login().then(() => {
      cy.visit("/main");
      cy.createGoal(goal);
    });
  });

  beforeEach(() => {
    cy.login();
    cy.visit("/main");
    cy.getCy(`goal-card-${goal.title}`).find('[data-cy="expand-more"]').click();
  });

  it("Creates A New Key Result", () => {
    //Define the intital values
    const keyResults = {
      description: "Test Key Results Beginning",
      initial: 1,
      target: 100,
    };
    cy.createKeyResults(keyResults);
    cy.contains(
      `[data-cy='key-result-${keyResults.description}']`,
      keyResults.description
    )
      .should("contain", keyResults.initial.toString())
      .and("contain", keyResults.target.toString());
  });

  it("Edits KeyResult item with given data", () => {
    //Define the intital values
    const keyResults = {
      description: "Test Key Results Edit",
      initial: 1,
      target: 100,
    };
    // Define the new details for editing the key results
    const editKeyResults = {
      description: "Updated Key",
      initial: 50,
      target: 200,
    };

    cy.createKeyResults(keyResults);

    cy.contains(
      `[data-cy='key-result-${keyResults.description}']`,
      keyResults.description
    )
      .find('[data-testid="EditIcon"]')
      .click();
    //Edit the key result with new details
    cy.getCy("edit-keyresult-title")
      .find("input")
      .clear()
      .type(editKeyResults.description);
    cy.getCy("keyresult-status-dropdown").click();
    cy.get('[data-value="COMPLETED"]').click();
    cy.getCy("keyresult-initial-value-field")
      .clear()
      .type(`${editKeyResults.initial}`);
    cy.getCy("keyresult-target-value-field")
      .clear()
      .type(`${editKeyResults.target}`);
    cy.getCy("dialog-button-save").click();

    cy.contains(
      `[data-cy='key-result-${editKeyResults.description}']`,
      editKeyResults.description
    )
      .should("contain", editKeyResults.initial.toString())
      .and("contain", editKeyResults.target.toString())
      .and("contain", "Completed");
  });

  it("Deletes keyresult", () => {
    //Define the intital values
    const keyResults = {
      description: "Test Key Results Delete",
      initial: 1,
      target: 100,
    };

    cy.createKeyResults(keyResults);

    cy.contains(
      `[data-cy='key-result-${keyResults.description}']`,
      keyResults.description
    )
      .find("[data-testid='DeleteIcon']")
      .click();
    cy.getCy("dialog-button-save").click();
    cy.contains(`[data-cy='key-result-${keyResults.description}']`).should(
      "not.exist"
    );
  });

  context("Comment functions and Show comments", () => {
    const keyResults = {
      description: "Test Key Results Comment",
      initial: 1,
      target: 100,
    };

    it("Comments the key result and edits comment", () => {
      cy.createKeyResults(keyResults);
      cy.contains(
        `[data-cy='key-result-${keyResults.description}']`,
        keyResults.description
      )
        .find('[data-testid="AddCommentIcon"]')
        .click();
      cy.getCy("edit-comment-textfield").type(textContent.initialComment);
      cy.getCy("comment-save").click();
      cy.contains(
        '[data-cy="comment-item"]',
        textContent.initialComment
      ).should("exist");
      //Edit comment
      cy.contains(
        `[data-cy='key-result-${keyResults.description}']`,
        keyResults.description
      )
        .find('[data-cy="comment-edit-button"]')
        .click();
      cy.getCy("edit-comment-textfield")
        .contains("textArea", textContent.initialComment)
        .clear()
        .type(textContent.editedComment);
      cy.getCy("comment-save").click();
      cy.contains('[data-cy="comment-item"]', textContent.editedComment).should(
        "exist"
      );
    });

    it("Reply and Edit Reply", () => {
      cy.contains(
        `[data-cy='key-result-${keyResults.description}']`,
        keyResults.description
      )
        .find('[data-testid="AddCommentIcon"]')
        .click();
      cy.getCy("edit-comment-textfield").type(textContent.initialComment);
      cy.getCy("comment-save").click();
      // Ensure the comment is added and then reply to it
      cy.contains(
        `[data-cy='comment-item']`,
        textContent.initialComment
      ).within(() => {
        cy.getCy("comment-reply-button").click();
      });
      // Type the reply and save it
      cy.getCy("edit-comment-textfield").type(textContent.replyText);
      cy.getCy("comment-save").click();
      // Optionally, verify the reply has been added
      cy.contains(`[data-cy='comment-item']`, textContent.replyText).should(
        "exist"
      );
      cy.contains('[data-cy="comment-item"]', textContent.replyText)
        .find('[data-cy="comment-edit-button"]')
        .click();
      cy.getCy("edit-comment-textfield")
        .contains("textArea", textContent.replyText)
        .clear()
        .type(textContent.editedReply);
      cy.getCy("comment-save").click();
      cy.contains('[data-cy="comment-item"]', textContent.editedReply).should(
        "exist"
      );
    });

    it("Show comments", () => {
      cy.contains(
        `[data-cy='key-result-${keyResults.description}']`,
        keyResults.description
      )
        .find('[data-testid="CommentIcon"]')
        .click();
      cy.getCy("comment-item").should(
        "contain",
        textContent.editedComment,
        textContent.initialComment
      );
    });
  });

  context("Testing Key Result Update and Show Update", () => {
    //Define the intital values
    const keyResults = {
      description: "Test Key Results Update",
      initial: 10,
      target: 100,
    };
    // Define the new details for updating the key result
    const updateKeyResult = {
      description: "Key Result update test 1",
      newInitial: 50,
    };
    const updateKeyResultTwo = {
      description: "Key Result update test 2",
      newInitial: 100,
    };
    it("Updates A key result with data", () => {
      cy.createKeyResults(keyResults);
      // Find the newly created key result and initiate an update
      cy.contains(
        `[data-cy='key-result-${keyResults.description}']`,
        keyResults.description
      )
        .find("[data-testid='UpdateIcon']")
        .click();
      // Clear the current value field and type the new initial values
      cy.getCy("keyresults-update-current-value")
        .find("input")
        .clear()
        .type(`${updateKeyResult.newInitial}`);
      cy.getCy("keyresults-update-status").click();
      cy.get('[data-value="BEHIND"]').click();
      // Enter a new description for the key result
      cy.getCy("keyresults-update-description")
        .find("input")
        .type(updateKeyResult.description);

      cy.getCy("dialog-button-save").click();

      cy.contains(
        `[data-cy='key-result-${keyResults.description}']`,
        keyResults.description
      )
        .should("contain", updateKeyResult.description.toString())
        .and("contain", updateKeyResult.newInitial.toString())
        .and("contain", "Behind");

      // Open the update dialog again to make further changes
      cy.contains(
        `[data-cy='key-result-${keyResults.description}']`,
        keyResults.description
      )
        .find("[data-testid='UpdateIcon']")
        .click();
      // Update the current value to 100
      cy.getCy("keyresults-update-current-value")
        .find("input")
        .clear()
        .type(`${updateKeyResultTwo.newInitial}`);
      // Add another update description
      cy.getCy("keyresults-update-description").type(
        updateKeyResultTwo.description
      );
      //Select new status
      cy.getCy("keyresults-update-status").click();
      cy.get('[data-value="COMPLETED"]').click();
      cy.getCy("dialog-button-save").click({ force: true });
      cy.contains(
        `[data-cy='key-result-${keyResults.description}']`,
        keyResults.description
      )
        .should("contain", updateKeyResultTwo.description.toString())
        .and("contain", updateKeyResultTwo.newInitial.toString())
        .and("contain", "Completed");
    });

    it("Checks for update history", () => {
      cy.contains(
        `[data-cy='key-result-${keyResults.description}']`,
        keyResults.description
      )
        .find('[data-testid="ListIcon"]')
        .click()
        .then(() => {
          cy.log("Showing update history");
        });
      cy.get("tr")
        .should("have.length.gt", 0)
        .then(() => {
          cy.log("Verified update history");
        });
      cy.getCy("key-results-update-close-button").click();
    });
  });
});

export {};
