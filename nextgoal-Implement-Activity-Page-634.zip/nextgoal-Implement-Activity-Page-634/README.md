# Nextgoal

The project's public name is "Workzep", and it can be found at: https://www.workzep.com/

<em>Workzep</em> is a project that enables companies to have truly transparent goals at all levels of their organization.

It helps companies set and communicate their goals to their employees and stakeholders in a clear and organized manner, and employees to see how their actions directly contribute to the the big picture.

Join us to see the forest for the trees and build your trail.

## Pre-requisities

1. **Install AWS CLI**: Follow the instructions [here](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html) to install AWS CLI.

2. **Setup AWS CLI SSO**: Use the default SSO session name when configuring AWS CLI with SSO:

```bash
aws configure sso
```

- You generally won’t need to interact with or reference the "SSO session name" again after providing it during the configuration process.
- **Note:** Do not confuse the SSO region with the default client region; these are two different things.
  - The user is asked the "SSO region" when configuring AWS with SSO, and it refers to the specific region that can be found in your AWS access portal's "Access keys" tab (below the also-asked SSO start URL).
  - "CLI default client Region [None]", in turn, is asking you to specify where you want the CLI to interact with AWS services (e.g., eu-north-1, etc.) by default. While some AWS services are global, others are region- or zone-specific, so this is important!
- The input field for "SSO registration scopes [sso:account:access]" can be left blank ("skipped" via Enter key) for default settings.
- The "CLI default output format [None]" used here is json.

3. **Install Amplify CLI**: Follow the steps outlined [here](https://docs.amplify.aws/react/tools/cli/start/set-up-cli/) in the Amplify documentation to install the Amplify CLI.

4. In the `~/.aws/config` file under the default profile, add this line:

```bash
credential_process = aws configure export-credentials --profile my-sso-profile
```

- You can edit this file by opening it in your preferred text/code editor (e.g., VSC).
- **Note:** You don't need to change the "my-sso-profile" to your own profile name; it can be left as-is.

## Getting Started

1. Clone the repository
2. Install dependencies

```bash
npm install
```

3. Pull the backend of the project from Amplify

```bash
amplify pull --appId d34rxrmjrqu4qs --envName taigoadev
```

4. Environment variables:

- You need to add following variables to the .env.local -file (project root):
- This file should be located in the root of your project (next to next.config.js).

```
AWS_COGNITO_USERNAME="your_username_here"
AWS_COGNITO_PASSWORD="your_password_here"

NEXT_IMAGES_HOSTNAME="your_bucket_name.s3.your_region.amazonaws.com"
NEXT_IMAGES_HOSTNAME_TEMP="your_temp_bucket_name.s3.your_region.amazonaws.com"

NEXT_PUBLIC_EMAILJS_SERVICE_ID="your_emailjs_service_id"
NEXT_PUBLIC_EMAILJS_FEEDBACK_TEMPLATE="your_feedback_template_id"
NEXT_PUBLIC_EMAILJS_TAIGOA_EMAIL="your_email_here"
NEXT_PUBLIC_EMAILJS_PUBLIC_KEY="your_emailjs_public_key"

NEXT_PUBLIC_EMAILJS_CONTACTFORM_SERVICE_ID="your_contact_service_name"
NEXT_PUBLIC_EMAILJS_CONTACTFORM_PUBLIC_KEY="your_emailjs_public_key_for_the_contact_form"
NEXT_PUBLIC_EMAILJS_CONTACTFORM_TEMPLATE_ID="your_contactform_template_name"
NEXT_PUBLIC_EMAILJS_CONTACTFORM_EMAIL="your_emailjs_contactform_email"

NEXT_PUBLIC_STRIPE_PRICEID="your_stripe_price_id"
NEXT_PUBLIC_STRIPE_API_PUBLIC="your_stripe_public_key"
NEXT_PUBLIC_STRIPE_API_SECRET="your_stripe_api_secret"
STRIPE_WEBHOOK_SECRET="your_stripe_webhook_secret"

DYNAMODB_TABLE_NAME="your_dynamodb_table_name"

NEXT_PUBLIC_OPENAI_API_KEY="your_openai_api_key"
NEXT_PUBLIC_OPENAI_API_MODEL="your_openai_model_id"
```

5. Run the development server

```bash
npm run dev
```

6. Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Tech

The project source code is saved into github taigoa-oy account.

### Tech stack

The following tech stack is used:

- Frontend
  - Libraries | NextJS, [MUI](https://mui.com/material-ui/getting-started/)
  - Frameworks | React
  - Languages | TypeScript
- AWS Amplify
  - Cognito
  - DynamoDB
  - GraphQl queries (using AWS Amplify API) for DynamoDB queries

## User management

At the moment, users are manually added to AWS Cognito. Find out the correct user pool through AWS Amplify console.

Create a new company:

1. Create the first user
2. Create a new group using YYYY-MM-CompanyName (the same company can have many instances)

Add a user to an existing company:

1. Create the user and send an email invitation
2. Add the user to the correct company

## For development purposes

Registration:

1. To get the registered, in the url link above insert after "/en" this "/register".

Credit/debit card:

2. Use the "4242 4242 4242 4242" as the example to proceed.

3. The password will be send to the email. After that you will be able set new password.

## DynamoDB backups

Point in time recovery is now under testing. Point in time recovery should be on with every production table.
