const {
  IAMClient,
  CreateRoleCommand,
  PutRolePolicyCommand,
} = require("@aws-sdk/client-iam");
const {
  CognitoIdentityProviderClient,
  UpdateGroupCommand,
} = require("@aws-sdk/client-cognito-identity-provider");

exports.handler = async (event) => {
  const iamClient = new IAMClient();
  const cognitoClient = new CognitoIdentityProviderClient();

  const { userPoolId, identityPoolId, s3BucketId, groupName } = event.arguments;
  const roleName = `${userPoolId}-company-${groupName}`;
  const s3PolicyName = `${userPoolId}-s3-policy-company-${groupName}`;

  try {
    // Create IAM Role with Trusted Policy
    const trustPolicy = {
      Version: "2012-10-17",
      Statement: [
        {
          Effect: "Allow",
          Principal: {
            Federated: "cognito-identity.amazonaws.com",
          },
          Action: "sts:AssumeRoleWithWebIdentity",
          Condition: {
            StringEquals: {
              "cognito-identity.amazonaws.com:aud": identityPoolId,
            },
            "ForAnyValue:StringLike": {
              "cognito-identity.amazonaws.com:amr": "authenticated",
            },
          },
        },
      ],
    };

    const createRoleCommand = new CreateRoleCommand({
      RoleName: roleName,
      AssumeRolePolicyDocument: JSON.stringify(trustPolicy),
    });
    const createRoleResponse = await iamClient.send(createRoleCommand);

    // Create in-line policy for the role
    const policyDocument = {
      Version: "2012-10-17",
      Statement: [
        {
          Effect: "Allow",
          Action: ["s3:PutObject", "s3:GetObject", "s3:DeleteObject"],
          Resource: [`arn:aws:s3:::${s3BucketId}/public/${groupName}/*`],
        },
      ],
    };

    const putRolePolicyCommand = new PutRolePolicyCommand({
      RoleName: roleName,
      PolicyName: s3PolicyName,
      PolicyDocument: JSON.stringify(policyDocument),
    });

    await iamClient.send(putRolePolicyCommand);

    // Assign role to the group
    const updateGroupCommand = new UpdateGroupCommand({
      UserPoolId: userPoolId,
      GroupName: groupName,
      RoleArn: createRoleResponse.Role.Arn,
    });

    await cognitoClient.send(updateGroupCommand);

    return {
      statusCode: 200,
      body: JSON.stringify("Success"),
    };
  } catch (e) {
    console.log(e);
    return {
      statusCode: 500,
      body: JSON.stringify("Error creating and assigning IAM role"),
    };
  }
};
