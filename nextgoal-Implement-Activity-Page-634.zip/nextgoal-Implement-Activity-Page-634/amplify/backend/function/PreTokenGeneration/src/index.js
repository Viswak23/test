export const handler = function (event, context) {
  event.response = {
    claimsAndScopeOverrideDetails: {
      accessTokenGeneration: {
        claimsToAddOrOverride: {
          email: event.request.userAttributes.email,
        },
      },
    },
  };
  // Return to Amazon Cognito
  context.done(null, event);
};
