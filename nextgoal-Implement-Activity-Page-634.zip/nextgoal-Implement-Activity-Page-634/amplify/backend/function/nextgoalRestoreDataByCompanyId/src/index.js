/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */
const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const {
  DynamoDBDocumentClient,
  ScanCommand,
  TransactWriteCommand,
} = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient();
const dynamoDbDocumentClient = DynamoDBDocumentClient.from(client);

const MAX_BATCH_SIZE = 100;
const MAX_RETRIES = 3;

exports.handler = async (event) => {
  const tables = event.tables;
  const companyId = event.companyId;

  try {
    for (const table of tables) {
      const { currentTable, restoredTable } = table;

      const restoredItems = await scanTable(restoredTable, companyId);
      const currentItems = await scanTable(currentTable, companyId);

      try {
        await deleteAndCopyItems(currentTable, currentItems, restoredItems);
      } catch (error) {
        console.error(
          "Batch failed after retries. Restoring from backup.",
          error
        );
        throw new Error(`Transaction failed`);
      }
    }
    return {
      statusCode: 200,
      body: JSON.stringify("OK"),
    };
  } catch (error) {
    console.error("Error during data restoration:", error);
    return {
      statusCode: 500,
      body: JSON.stringify("Data restoration failed."),
    };
  }
};

async function deleteAndCopyItems(tableName, deleteItems, putItems) {
  const deleteBatches = createBatches(deleteItems, "Delete", tableName);
  const putBatches = createBatches(putItems, "Put", tableName);

  for (const batch of deleteBatches) {
    await executeWithRetry(batch);
  }

  for (const batch of putBatches) {
    await executeWithRetry(batch);
  }
}

function createBatches(items, operation, tableName) {
  const batches = [];
  for (let i = 0; i < items.length; i += MAX_BATCH_SIZE) {
    const batch = items.slice(i, i + MAX_BATCH_SIZE).map((item) => {
      if (operation === "Delete") {
        return {
          Delete: {
            TableName: tableName,
            Key: {
              id: item.id,
            },
          },
        };
      } else if (operation === "Put") {
        return {
          Put: {
            TableName: tableName,
            Item: item,
          },
        };
      }
    });
    batches.push(batch);
  }
  return batches;
}

async function executeWithRetry(batch) {
  let retries = 0;
  while (retries < MAX_RETRIES) {
    try {
      await dynamoDbDocumentClient.send(
        new TransactWriteCommand({ TransactItems: batch })
      );
      return;
    } catch (error) {
      retries++;
      console.error(`Batch failed: ${retries} retries`, error);
      if (retries === MAX_RETRIES) {
        throw new Error(
          `Failed after ${MAX_RETRIES} retries: ${error.message}`
        );
      }
    }
  }
}

async function scanTable(tableName, companyId) {
  const params = {
    TableName: tableName,
    FilterExpression: "companyId = :companyId",
    ExpressionAttributeValues: {
      ":companyId": companyId,
    },
  };

  const command = new ScanCommand(params);
  const result = await dynamoDbDocumentClient.send(command);
  return result.Items;
}
