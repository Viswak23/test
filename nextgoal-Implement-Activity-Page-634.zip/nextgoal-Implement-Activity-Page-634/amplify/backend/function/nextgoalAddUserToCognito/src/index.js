const {
  CognitoIdentityProviderClient,
  AdminCreateUserCommand,
  AdminAddUserToGroupCommand,
} = require("@aws-sdk/client-cognito-identity-provider");

const ADMIN_GROUP = "admin";

/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */
exports.handler = async (event) => {
  const cognitoClient = new CognitoIdentityProviderClient();

  const { userPoolId, email, password } = event.arguments;

  const companyGroup = event.identity.claims["cognito:groups"].find(
    (group) => group !== ADMIN_GROUP
  );

  try {
    const create_user_input = {
      UserPoolId: userPoolId,
      Username: email,
      TemporaryPassword: password,
      UserAttributes: [
        {
          Name: "email",
          Value: email,
        },
        {
          Name: "email_verified",
          Value: "true",
        },
      ],
    };

    const create_user_command = new AdminCreateUserCommand(create_user_input);

    let response = await cognitoClient.send(create_user_command);

    let sub = response.User.Attributes.find(
      (attribute) => attribute.Name === "sub"
    ).Value;
    const add_to_group_input = {
      UserPoolId: userPoolId,
      Username: sub,
      GroupName: companyGroup,
    };
    const add_to_group_command = new AdminAddUserToGroupCommand(
      add_to_group_input
    );
    await cognitoClient.send(add_to_group_command);

    return JSON.stringify({
      body: sub,
      statusCode: 200,
    });
  } catch (error) {
    return JSON.stringify({
      body: error.message,
      statusCode: 500,
    });
  }
};
