const {
  CognitoIdentityProviderClient,
  AdminGetUserCommand,
} = require("@aws-sdk/client-cognito-identity-provider");

/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */
exports.handler = async (event) => {
  const cognitoClient = new CognitoIdentityProviderClient();
  const { email, userPoolId } = event.arguments;
  //construct the command input from the arguments
  const getUserCommandInput = {
    UserPoolId: userPoolId,
    Username: email,
  };
  //construct the command itself
  const getUserCommand = new AdminGetUserCommand(getUserCommandInput);

  try {
    // sending the command to cognitoClient
    await cognitoClient.send(getUserCommand);
    return JSON.stringify({
      statusCode: 200,
      body: "User Exists",
    }); //if 200 OK means company exists
  } catch (error) {
    return JSON.stringify({
      body: error.message,
      statusCode: 500, //if 500 means company does not exist
    });
  }
};
