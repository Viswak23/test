const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { RestoreTableFromBackupCommand } = require("@aws-sdk/client-dynamodb");

const dynamodb = new DynamoDBClient({ region: 'eu-north-1' });

exports.handler = async (event) => {
    const tableBackups = event.tableBackups;
    const env = event.env;

    const restorePromises = [];

    for (const tableName in tableBackups) {
        const backupArn = tableBackups[tableName];
        const restoredTableName = `${tableName}-restore-${env}`;

        const params = {
            TargetTableName: restoredTableName,
            BackupArn: backupArn
        };

        console.log(`Restoring table ${tableName} from backup ${backupArn} to new table ${restoredTableName}`);
        restorePromises.push(dynamodb.send(new RestoreTableFromBackupCommand(params)));
    }

    try {
        await Promise.all(restorePromises);
        return {
            statusCode: 200,
            body: JSON.stringify('All tables restore initiated successfully.')
        };
    } catch (error) {
        console.error('Error initiating table restores:', error);
        return {
            statusCode: 500,
            body: JSON.stringify('Error initiating table restores.')
        };
    }
};
