const {
  CognitoIdentityProviderClient,
  AdminAddUserToGroupCommand,
  AdminRemoveUserFromGroupCommand,
  ListUsersCommand,
} = require("@aws-sdk/client-cognito-identity-provider");
const {
  DynamoDBClient,
  UpdateItemCommand,
} = require("@aws-sdk/client-dynamodb");

const cognitoClient = new CognitoIdentityProviderClient();
const dynamoDBClient = new DynamoDBClient();

const ADMIN_GROUP = "admin";

/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */
exports.handler = async (event) => {
  const { email, isAdmin, userPoolId } = event.arguments;

  try {
    // Fetch the userId (Username in Cognito) using the email
    const listUsersCommand = new ListUsersCommand({
      UserPoolId: userPoolId,
      Filter: `email = "${email}"`,
      Limit: 1,
    });

    const userResponse = await cognitoClient.send(listUsersCommand);
    if (!userResponse.Users || userResponse.Users.length === 0) {
      throw new Error(`User with email ${email} not found.`);
    }

    const username = userResponse.Users[0].Username;

    // Determine whether to add or remove the user from the admin group
    const adminGroupCommand = isAdmin
      ? new AdminAddUserToGroupCommand({
          UserPoolId: userPoolId,
          Username: username,
          GroupName: ADMIN_GROUP,
        })
      : new AdminRemoveUserFromGroupCommand({
          UserPoolId: userPoolId,
          Username: username,
          GroupName: ADMIN_GROUP,
        });

    await cognitoClient.send(adminGroupCommand);

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "User role updated successfully" }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ message: error.message }),
    };
  }
};
