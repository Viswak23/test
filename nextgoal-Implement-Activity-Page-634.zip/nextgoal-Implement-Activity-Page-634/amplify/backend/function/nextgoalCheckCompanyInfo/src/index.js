const {
  CognitoIdentityProviderClient,
  GetGroupCommand,
} = require("@aws-sdk/client-cognito-identity-provider");

/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */
exports.handler = async (event) => {
  const cognitoClient = new CognitoIdentityProviderClient();
  const { company, userPoolId } = event.arguments;
  //construct the command input from the arguments
  const getGroupCommandInput = {
    UserPoolId: userPoolId,
    GroupName: company,
  };
  //construct the command itself
  const getGroupCommand = new GetGroupCommand(getGroupCommandInput);

  try {
    // sending the command to cognitoClient
    await cognitoClient.send(getGroupCommand);
    return JSON.stringify({
      statusCode: 200,
      body: "Group Exists",
    }); //if 200 OK means company exists
  } catch (error) {
    return JSON.stringify({
      body: error.message,
      statusCode: 500, //if 500 means company does not exist
    });
  }
};
