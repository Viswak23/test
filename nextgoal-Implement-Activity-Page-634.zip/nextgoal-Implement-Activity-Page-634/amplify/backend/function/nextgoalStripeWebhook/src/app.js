/*
Use the following code to retrieve configured secrets from SSM:

const aws = require('aws-sdk');

const { Parameters } = await (new aws.SSM())
  .getParameters({
    Names: ["STRIPE_WEBHOOK_SECRET","STRIPE_API_SECRET","DYNAMODB_TABLE_NAME"].map(secretName => process.env[secretName]),
    WithDecryption: true,
  })
  .promise();

Parameters will be of the form { Name: 'secretName', Value: 'secretValue', ... }[]
*/
/* Amplify Params - DO NOT EDIT
	ENV
	REGION
	AUTH_NEXTGOALFED886BB_USERPOOLID
	API_NEXTGOAL_COMPANYTABLE_NAME
	API_NEXTGOAL_COMPANYTABLE_ARN
	API_NEXTGOAL_GRAPHQLAPIIDOUTPUT
	STRIPE_API_SECRET
	STRIPE_WEBHOOK_SECRET
  DYNAMODB_TABLE_NAME
Amplify Params - DO NOT EDIT */
const express = require("express");
const bodyParser = require("body-parser");
const awsServerlessExpressMiddleware = require("aws-serverless-express/middleware");
const {
  DynamoDBClient,
  UpdateItemCommand,
  GetItemCommand,
  ScanCommand,
} = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient } = require("@aws-sdk/lib-dynamodb");
const aws = require("aws-sdk");
aws.config.update({ region: "eu-north-1" });

// Use the following code to retrieve configured secrets from SSM:
const getKeys = async () => {
  try {
    console.log("Retrieving Secret Keys...");
    const { Parameters } = await new aws.SSM()
      .getParameters({
        Names: [
          "STRIPE_WEBHOOK_SECRET",
          "STRIPE_API_SECRET",
          "DYNAMODB_TABLE_NAME",
        ].map((secretName) => process.env[secretName]),
        WithDecryption: true,
      })
      .promise();
    //each parameter will come with extra information other than the key and the secret, so we use  reduce to map out only the needed info{name:value}
    // Parameters will be of the form { Name: 'secretName', Value: 'secretValue', ... }[], array of secret values
    //Name will be as follows: ....(alot of texthere)_nextgoalStripeWebhook_STRIPE_API_SECRET
    //Value will be the actual secret value
    //and the reduce will return only the name after the nextgoalStripeWebhook_ and it's value

    return Parameters.reduce((acc, curr) => {
      acc[curr.Name.split("nextgoalStripeWebhook_")[1]] = curr.Value;
      return acc;
    }, {});
  } catch (error) {
    console.error(error);
  }
};

// declare a new express app
const app = express();
app.use(awsServerlessExpressMiddleware.eventContext());

// Enable CORS for all methods
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "*");
  next();
});

const ddbClient = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(ddbClient);

async function getIdByCustomerId(customerId) {
  const { DYNAMODB_TABLE_NAME } = await getKeys();

  try {
    const scanItemCommand = new ScanCommand({
      ExpressionAttributeValues: {
        ":a": {
          S: customerId,
        },
      },
      ProjectionExpression: "id",
      FilterExpression: "customerId = :a",
      TableName: DYNAMODB_TABLE_NAME,
    });
    const id = docClient.send(scanItemCommand).then((res) => {
      if (res.Items.length > 0) {
        return res.Items[0].id.S;
      } else {
        throw new Error("No items found for the given customerId");
      }
    });

    return id;
  } catch (error) {
    console.error(error);
  }
}
async function changeCompanyState(state, customerId) {
  const { DYNAMODB_TABLE_NAME } = await getKeys();
  try {
    //updating an item only possible by using the primary key which is ID.
    const companyId = await getIdByCustomerId(customerId);
    const input = {
      ExpressionAttributeNames: {
        "#isSub": "isSubscribed",
      },
      ExpressionAttributeValues: {
        ":isSub": {
          BOOL: state,
        },
      },
      Key: {
        id: {
          S: companyId,
        },
      },
      ReturnValues: "ALL_NEW",
      TableName: DYNAMODB_TABLE_NAME,
      UpdateExpression: "SET #isSub = :isSub",
    };
    const updateCommand = new UpdateItemCommand(input);
    await docClient.send(updateCommand);
  } catch (error) {
    console.error(error);
  }
}
app.post(
  "/webhook",
  bodyParser.raw({ type: "application/json" }),
  async function (req, res) {
    //these names come from the secret store and we can't change them.
    const {
      STRIPE_WEBHOOK_SECRET: endpointSecret,
      STRIPE_API_SECRET: stripeKey,
    } = await getKeys();

    const stripe = require("stripe")(stripeKey);
    // Retrieve the event by verifying the signature using the raw body and secret.
    let event;
    try {
      event = stripe.webhooks.constructEvent(
        JSON.parse(req.body),
        req.headers["stripe-signature"],
        endpointSecret
      );
    } catch (err) {
      console.log(err);
      console.log(`⚠️  Webhook signature verification failed.`);
      console.log(
        `⚠️  Check the env file and enter the correct webhook secret.`
      );
      return res.sendStatus(400);
    }

    // Extract the object from the event.
    const dataObject = event.data.object;
    console.log(`Recieved event: ${event.type}`);
    switch (event.type) {
      //the next events pass a subscription object which contains a status field indicating whether the subscription is active, past due, or canceled.
      case "customer.subscription.created":
        await changeCompanyState(true, dataObject.customer);
        break;
      case "customer.subscription.updated":
        //Check if subscription is active or not
        if (dataObject.status == "active") {
          await changeCompanyState(true, dataObject.customer);
        } else {
          await changeCompanyState(false, dataObject.customer);
        }
        break;
      case "customer.subscription.deleted": //this will be recieved when we call the server action cancelStripeSubscription.
      case "invoice.payment_failed":
        await changeCompanyState(false, dataObject.customer);
        break;
      default:
      // Unexpected event type
    }
    res.sendStatus(200);
  }
);

app.listen(4242, function () {
  console.log("App started");
});
module.exports = app;
