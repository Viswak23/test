const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const {
  DynamoDBDocumentClient,
  ScanCommand,
  BatchWriteCommand,
} = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient();
const dynamoDbDocumentClient = DynamoDBDocumentClient.from(client);

const MAX_BATCH_SIZE = 25;

exports.handler = async (event) => {
  const tables = event.tables;

  try {
    for (const table of tables) {
      const { currentTable, restoredTable } = table;

      const restoredItems = await scanTable(restoredTable);

      try {
        await copyItems(currentTable, restoredItems);
      } catch (error) {
        console.error(
          "Batch write failed after retries. Error:",
          error
        );
        throw new Error(`Batch write failed`);
      }
    }
    return {
      statusCode: 200,
      body: JSON.stringify("OK"),
    };
  } catch (error) {
    console.error("Error during data restoration:", error);
    return {
      statusCode: 500,
      body: JSON.stringify("Data restoration failed."),
    };
  }
};

async function copyItems(tableName, items) {
  const batches = createBatches(items, tableName);

  for (const batch of batches) {
    await executeWithRetry(batch);
  }
}

function createBatches(items, tableName) {
  const batches = [];
  for (let i = 0; i < items.length; i += MAX_BATCH_SIZE) {
    const batch = items.slice(i, i + MAX_BATCH_SIZE).map((item) => {
      return {
        PutRequest: {
          Item: item,
        },
      };
    });
    batches.push({ RequestItems: { [tableName]: batch } });
  }
  return batches;
}

async function executeWithRetry(batch) {
  let retries = 0;
  const MAX_RETRIES = 3;
  while (retries < MAX_RETRIES) {
    try {
      await dynamoDbDocumentClient.send(new BatchWriteCommand(batch));
      return;
    } catch (error) {
      retries++;
      console.error(`Batch write failed: ${retries} retries`, error);
      if (retries === MAX_RETRIES) {
        throw new Error(
          `Failed after ${MAX_RETRIES} retries: ${error.message}`
        );
      }
    }
  }
}

async function scanTable(tableName) {
  const params = {
    TableName: tableName,
  };

  const command = new ScanCommand(params);
  let items = [];
  let result;

  do {
    result = await dynamoDbDocumentClient.send(command);
    items = items.concat(result.Items);
    command.input.ExclusiveStartKey = result.LastEvaluatedKey;
  } while (result.LastEvaluatedKey);

  return items;
}
