const {
  CognitoIdentityProviderClient,
  AdminCreateUserCommand,
  AdminAddUserToGroupCommand,
  CreateGroupCommand,
  DeleteGroupCommand,
  AdminDeleteUserCommand,
  UpdateGroupCommand,
} = require("@aws-sdk/client-cognito-identity-provider");

const {
  IAMClient,
  CreateRoleCommand,
  PutRolePolicyCommand,
  DeleteRoleCommand,
} = require("@aws-sdk/client-iam");
const ADMIN_GROUP = "admin";

/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */
exports.handler = async (event) => {
  const cognitoClient = new CognitoIdentityProviderClient();

  const { userPoolId, identityPoolId, s3BucketId, email, company } =
    event.arguments;

  let groupCreated = false;
  let userCreated = false;
  let roleCreated = false;
  try {
    //create the group

    const create_group_input = {
      GroupName: company,
      UserPoolId: userPoolId,
    };
    const create_group_command = new CreateGroupCommand(create_group_input);
    const group_response = await cognitoClient.send(create_group_command);
    groupCreated = true;

    // assign role to group block
    try {
      const iamClient = new IAMClient();
      const roleName = `${userPoolId}-company-${company}`;
      const s3PolicyName = `${userPoolId}-s3-policy-company-${company}`;

      // Create IAM Role with Trusted Policy
      const trustPolicy = {
        Version: "2012-10-17",
        Statement: [
          {
            Effect: "Allow",
            Principal: {
              Federated: "cognito-identity.amazonaws.com",
            },
            Action: "sts:AssumeRoleWithWebIdentity",
            Condition: {
              StringEquals: {
                "cognito-identity.amazonaws.com:aud": identityPoolId,
              },
              "ForAnyValue:StringLike": {
                "cognito-identity.amazonaws.com:amr": "authenticated",
              },
            },
          },
        ],
      };

      const createRoleCommand = new CreateRoleCommand({
        RoleName: roleName,
        AssumeRolePolicyDocument: JSON.stringify(trustPolicy),
      });
      const createRoleResponse = await iamClient.send(createRoleCommand);

      // Create in-line policy for the role
      const policyDocument = {
        Version: "2012-10-17",
        Statement: [
          {
            Effect: "Allow",
            Action: ["s3:PutObject", "s3:GetObject", "s3:DeleteObject"],
            Resource: [`arn:aws:s3:::${s3BucketId}/public/${company}/*`],
          },
        ],
      };

      const putRolePolicyCommand = new PutRolePolicyCommand({
        RoleName: roleName,
        PolicyName: s3PolicyName,
        PolicyDocument: JSON.stringify(policyDocument),
      });

      await iamClient.send(putRolePolicyCommand);
      roleCreated = true;

      // Assign role to the group
      const updateGroupCommand = new UpdateGroupCommand({
        UserPoolId: userPoolId,
        GroupName: company,
        RoleArn: createRoleResponse.Role.Arn,
      });

      await cognitoClient.send(updateGroupCommand);
    } catch (error) {
      cleanUp(userCreated, groupCreated, roleCreated);
      return {
        statusCode: 500,
        body: error.message,
      };
    }
    //create the user
    const create_user_input = {
      UserPoolId: userPoolId,
      Username: email,

      UserAttributes: [
        {
          Name: "email",
          Value: email,
        },
        {
          Name: "email_verified",
          Value: "true",
        },
      ],
    };

    const create_user_command = new AdminCreateUserCommand(create_user_input);

    let response = await cognitoClient.send(create_user_command);
    userCreated = true;

    let sub = response.User.Attributes.find(
      (attribute) => attribute.Name === "sub"
    ).Value;

    //add the user to the group
    const add_to_group_input = {
      UserPoolId: userPoolId,
      Username: sub,
      GroupName: group_response.Group.GroupName,
    };
    const add_to_group_command = new AdminAddUserToGroupCommand(
      add_to_group_input
    );
    await cognitoClient.send(add_to_group_command);
    //add to admin group
    const add_to_admin_group_input = {
      UserPoolId: userPoolId,
      Username: sub,
      GroupName: ADMIN_GROUP,
    };
    const add_to_admin_group_command = new AdminAddUserToGroupCommand(
      add_to_admin_group_input
    );
    await cognitoClient.send(add_to_admin_group_command);

    return JSON.stringify({
      body: sub,
      statusCode: 200,
    });
  } catch (error) {
    cleanUp(userCreated, groupCreated, roleCreated);
    return JSON.stringify({
      body: error.message,
      statusCode: 500,
    });
  }

  async function cleanUp(
    userCreated = false,
    groupCreated = false,
    roleCreated = false
  ) {
    if (groupCreated) {
      const delete_group_input = {
        GroupName: company,
        UserPoolId: userPoolId,
      };
      const delete_group_command = new DeleteGroupCommand(delete_group_input);
      await cognitoClient.send(delete_group_command);
    }

    //this will be reached only if the user was created before the error happens.
    if (userCreated) {
      const delete_user_input = {
        UserPoolId: userPoolId,
        Username: email,
      };
      const delete_user_command = new AdminDeleteUserCommand(delete_user_input);
      await cognitoClient.send(delete_user_command);
    }
    if (roleCreated) {
      const iamClient = new IAMClient();
      const roleName = `${userPoolId}-company-${company}`;
      const s3PolicyName = `${userPoolId}-s3-policy-company-${company}`;
      const deleteRoleCommand = new DeleteRoleCommand({ RoleName: roleName });
      await iamClient.send(deleteRoleCommand);
      const deleteS3PolicyCommand = new DeleteRolePolicyCommand({
        RoleName: roleName,
        PolicyName: s3PolicyName,
      });
      await iamClient.send(deleteS3PolicyCommand);
    }
  }
};
