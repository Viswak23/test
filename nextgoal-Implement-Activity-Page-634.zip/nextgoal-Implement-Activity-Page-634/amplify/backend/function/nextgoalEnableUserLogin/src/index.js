const {
  CognitoIdentityProviderClient,
  AdminEnableUserCommand,
  AdminListGroupsForUserCommand,
} = require("@aws-sdk/client-cognito-identity-provider");

const ADMIN_GROUP = "admin";

/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */
exports.handler = async (event) => {
  const cognitoClient = new CognitoIdentityProviderClient();

  const { userPoolId, email } = event.arguments;

  const companyGroup = event.identity.claims["cognito:groups"].find(
    (group) => group !== ADMIN_GROUP
  );

  try {
    const input = {
      UserPoolId: userPoolId,
      Username: email,
    };

    const groupCommand = new AdminListGroupsForUserCommand(input);

    const groupResponse = await cognitoClient.send(groupCommand);

    const userGroup = groupResponse.Groups.map((group) => group.GroupName).find(
      (group) => group !== ADMIN_GROUP
    );

    if (userGroup == companyGroup) {
      const enableCommand = new AdminEnableUserCommand(input);
      await cognitoClient.send(enableCommand);
      return JSON.stringify({
        body: "Succesfully enabled user login.",
        statusCode: 200,
      });
    } else {
      return JSON.stringify({
        body: "Admins can only edit users in their own group.",
        statusCode: 403,
      });
    }
  } catch (error) {
    return JSON.stringify({
      body: error.message,
      statusCode: 500,
    });
  }
};
