/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    container: {
      padding: {
        DEFAULT: "1rem",
        sm: "2rem",
        lg: "4rem",
        xl: "6rem",
        "2xl": "10rem",
      },
    },
    extend: {
      colors: {
        primary: "#A426C7",
        darkprimary: "#7F1ABE",
        violete: "#6C48C5",
        secondary: "#EBD3F8",
        white: "#FFFFFF",
        black: "#263238",
        gray: "#607D8B",
        darkGray: "#4D4D4D",
        cyan: "#41DCFF",
        green: "#2AC37F",
      },
      fontFamily: {
        cabin: ["Cabin", "sans-serif"],
        segoe: ["Segoe", "sans-serif"],
        limelight: ["Lime Light"],
      },
      animation: {
        scroll:
          "scroll var(--animation-duration, 20s) var(--animation-direction, forwards) linear infinite",
      },
      keyframes: {
        scroll: {
          to: {
            transform: "translate(calc(-50% - 0.5rem))",
          },
        },
      },
      transitionProperty: {
        height: "height",
        spacing: "margin, padding",
      },
    },
  },
  plugins: [],
};
