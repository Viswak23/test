use serde_json::Value;

pub async fn add_owner(item_type: &String, id: &String, owner: &String, endpoint: &str, auth: &str) {
  
  // mutation query to update item's owner field
  // Note: The double curly braces {{ }} are used to escape curly braces in the format! macro.
  let request_body = serde_json::json!({
    "query": format!("mutation MyMutation {{
      update{item_type}(input: {{id: \"{id}\", owner: \"{owner}\"}}) {{
        id
        owner
      }}
    }}")
  });

  // Nice to get some output...
  println!("Adding owner attribute {} to item with id: {}", owner, id);

  // send request
  let response = reqwest::Client::new()
    .post(endpoint)
    .header("Authorization", auth)
    .json(&request_body)
    .send()
    .await
    .unwrap();

  // parse response and notify if there are errors otherwise don't do anything
  let response_body: Value = response.json().await.unwrap();
  if response_body["errors"].is_array() {
    println!("Error adding owner to item with id: {}", id);
    println!("{}", response_body);
  }
}