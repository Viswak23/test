use aws_sdk_cognitoidentityprovider::types::{AuthFlowType, ChallengeNameType};
// cool library to handle the SRP auth (It just does all the math for you)
use cognito_srp::SrpClient;

pub async fn get_auth(
  pool_id: &str, 
  app_client_id: &str, 
  username: &str, 
  password: &str) -> String {

  // Create a new SRP client
  let srp_client = SrpClient::new(
      username,
      password,
      pool_id,
      app_client_id,
      None,
  );

  // Load AWS config and create a Cognito client
  let config = aws_config::load_from_env().await;
  let cognito_client = aws_sdk_cognitoidentityprovider::Client::new(&config);

  // Initiate the auth flow
  let auth_init_res = cognito_client
      .initiate_auth()
      .auth_flow(AuthFlowType::UserSrpAuth)
      .client_id(app_client_id)
      .set_auth_parameters(Some(srp_client.get_auth_params().unwrap()))
      .send()
      .await;

  let auth_init_out = auth_init_res.unwrap();

  // Process the auth challenge
  let challenge_params =
      auth_init_out
          .challenge_parameters
          .unwrap();
  let challenge_responses =
      srp_client.process_challenge(challenge_params).unwrap();

  // Respond to the auth challenge
  let password_challenge_result = cognito_client
      .respond_to_auth_challenge()
      .set_challenge_responses(Some(challenge_responses))
      .client_id(app_client_id)
      .challenge_name(ChallengeNameType::PasswordVerifier)
      .send()
      .await;

  // Get the access token
  let password_challenge_response = password_challenge_result.unwrap();
  let result = password_challenge_response.authentication_result().unwrap();
  return result.access_token.as_ref().unwrap().clone();
}
