#![allow(non_snake_case)]
use serde::{Deserialize, Serialize};

// Structs for serde to parse JSON. And to make the code more readable.

#[derive(Debug, Deserialize, Serialize)]
pub struct Secrets <'a> {
  pub graphql_endpoint: &'a str,
  pub user_pool_id: &'a str,
  pub app_client_id: &'a str,
  pub username: &'a str,
  pub password: &'a str,
}

#[derive(Debug, Deserialize, Serialize)]
pub struct Item {
  pub owner: Option<String>,
  pub id: String,
  pub creatorEmail: String,
}

#[derive(Debug, Deserialize, Serialize)]
pub struct ListQuery<T> {
  pub items: Vec<T>,
}

#[derive(Debug, Deserialize, Serialize)]
pub struct MyQuery {
  pub data: Data,
}

#[derive(Debug, Deserialize, Serialize)]
pub struct Data {
  listComments: ListQuery<Item>,
  listCompanies: ListQuery<Item>,
  listContributions: ListQuery<Item>,
  listEmployees: ListQuery<Item>,
  listGoals: ListQuery<Item>,
  listHelpRequests: ListQuery<Item>,
  listIdeas: ListQuery<Item>,
  listKeyResultUpdates: ListQuery<Item>,
  listKeyResults: ListQuery<Item>,
  listNorthStars: ListQuery<Item>,
  listOrganizationUnits: ListQuery<Item>,
  listRedFlags: ListQuery<Item>,
  listStatuses: ListQuery<Item>,
  listSuccessStories: ListQuery<Item>,
  listTasks: ListQuery<Item>,
}

impl IntoIterator for Data {
  type Item = ListQuery<Item>;
  type IntoIter = std::vec::IntoIter<Self::Item>;

  fn into_iter(self) -> Self::IntoIter {
    vec![
      self.listComments,
      self.listCompanies,
      self.listContributions,
      self.listEmployees,
      self.listGoals,
      self.listHelpRequests,
      self.listIdeas,
      self.listKeyResultUpdates,
      self.listKeyResults,
      self.listNorthStars,
      self.listOrganizationUnits,
      self.listRedFlags,
      self.listStatuses,
      self.listSuccessStories,
      self.listTasks,
    ]
    .into_iter()
  }
}