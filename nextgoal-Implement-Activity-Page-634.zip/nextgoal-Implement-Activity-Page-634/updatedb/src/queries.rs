use std::collections::HashMap;
use crate::structs::*;

pub async fn get_items(endpoint: &str, auth: &str) -> Vec<(String, Item)>{
  
  // query for all items that need to be updated
  let request_body =
    serde_json::json!({
    "query": "query MyQuery {
      listComments {
        items {
          owner
          id
          creatorEmail
        }
      }
      listCompanies {
        items {
          creatorEmail
          id
          owner
        }
      }
      listContributions {
        items {
          owner
          creatorEmail
          id
        }
      }
      listEmployees {
        items {
          id
          owner
          creatorEmail
        }
      }
      listGoals {
        items {
          id
          owner
          creatorEmail
        }
      }
      listHelpRequests {
        items {
          creatorEmail
          owner
          id
        }
      }
      listIdeas {
        items {
          id
          owner
          creatorEmail
        }
      }
      listKeyResultUpdates {
        items {
          creatorEmail
          owner
          id
        }
      }
      listKeyResults {
        items {
          id
          owner
          creatorEmail
        }
      }
      listNorthStars {
        items {
          owner
          id
          creatorEmail
        }
      }
      listOrganizationUnits {
        items {
          creatorEmail
          id
          owner
        }
      }
      listRedFlags {
        items {
          creatorEmail
          owner
          id
        }
      }
      listStatuses {
        items {
          creatorEmail
          id
          owner
        }
      }
      listSuccessStories {
        items {
          creatorEmail
          id
          owner
        }
      }
      listTasks {
        items {
          creatorEmail
          id
          owner
        }
      }
    }
    "
  });
  
  // reqwest client
  let client = reqwest::Client::new();

  // send request
  let response = client
      .post(endpoint)
      .header("Content-Type", "application/json")
      .header("Authorization", auth)
      .json(&request_body)
      .send().await
      .unwrap();

  // parse response
  let response_body: MyQuery = response.json().await.unwrap();

  // list for mapping querytype to items
  let querytype = [
    "Comment",
    "Company",
    "Contribution",
    "Employee",
    "Goal",
    "HelpRequest",
    "Idea",
    "KeyResultUpdate",
    "KeyResult",
    "NorthStar",
    "OrganizationUnit",
    "RedFlag",
    "Status",
    "SuccessStory",
    "Task"
  ];

  let mut items = vec![];

  // go through each listquery and add (item_type, item) to item list
  for (i, listquery) in response_body.data.into_iter().enumerate() {
    for item in listquery.items {
      items.push((querytype[i].to_owned(), item));
    }
  }

  return items
}

pub async fn get_users(user_pool_id: &str) -> HashMap<String, String> {
  // load aws config and create a client
  let config = aws_config::load_from_env().await;
  let client = aws_sdk_cognitoidentityprovider::Client::new(&config);

  // send request
  let response = client.list_users()
    .user_pool_id(user_pool_id.to_owned())
    .set_attributes_to_get(Some(vec!["email".to_owned(), "sub".to_owned()]))
    .send().await.unwrap();

  // parse response
  let users = response.users.unwrap(); 

  // get email and sub attributes from users
  let user_attributes = users.iter().map(|user| {
    let attributes = user.attributes.as_ref().unwrap().clone();
    let email = &attributes.iter().find(|attr| attr.name == "email").unwrap().value;
    let sub = &attributes.iter().find(|attr| attr.name == "sub").unwrap().value;
    (email.to_owned().unwrap(), sub.to_owned().unwrap())
  }).collect::<Vec<_>>();

  // return hashmap of email to sub because it was easier to work with in main
  // Vec<(String, String)> would propably be just fine but anyways...
  let return_attributes: HashMap<String, String> = HashMap::from_iter(user_attributes);
  return return_attributes;
}