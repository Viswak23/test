mod queries;
mod mutations;
mod structs;
mod auth;

use queries::*;
use mutations::*;
use auth::*;
use structs::*;

// Asynchronous main function
#[tokio::main]
async fn main() {
  // Read secrets from secrets.json
  let secrets_file = std::fs::read_to_string("secrets.json").expect("Could not read secrets.json");
  let secrets: Secrets = serde_json::from_str(&secrets_file).expect("Could not parse secrets.json");

  // Get auth token
  let auth = get_auth(secrets.user_pool_id, secrets.app_client_id, secrets.username, secrets.password).await;
  
  // Get items and users
  let items = get_items(secrets.graphql_endpoint, &auth).await;
  let users = get_users(secrets.user_pool_id).await;
  
  // Print items and users
  println!("\nItems with no owner:");
  let items_with_no_owner: Vec<_> = items.iter().filter(|(_, item)| item.owner.is_none()).collect();
  for (key, value) in items_with_no_owner.iter() {
    let id  = &value.id;
    let owner = &value.owner.clone().unwrap_or_else(|| "None".to_string());
    let creator_email = &value.creatorEmail;
    println!("{}, {}, {}, {}", id, owner, creator_email, key);
  }

  println!("\nItems with owner:");
  let items_with_owner: Vec<_> = items.iter().filter(|(_, item)| item.owner.is_some()).collect();
  for (key, value) in items_with_owner.iter() {
    let id  = &value.id;
    let owner = &value.owner.clone().unwrap_or_else(|| "None".to_string());
    let creator_email = &value.creatorEmail;
    println!("{}, {}, {}, {}", id, owner, creator_email, key);
  }
  
  println!("\nUsers:");
  for (email, id) in users.iter() {
    println!("{}, {}", id, email);
  } 
  
  // Add owner to items with no owner
  for (item_type, item) in &items {
    if item.owner.is_none() {
      let owner = users.get(&item.creatorEmail).unwrap();
      add_owner(&item_type, &item.id, owner, secrets.graphql_endpoint, &auth).await;
    }
  }

  
}
