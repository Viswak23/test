Maybe this (c/sh)ould be turned into a library for future use?

For now the program gets all the items (Employee joins not included because they don't have a creator email field...) from the users company and fills in the owner fields for all the items that don't have it based on the cognito userpool email - id pairs.

Right now this might work with any user in the company (haven't tested), but it propably should require admin role in the future? (Maybe add field level auth rules to the graphql schema?)

To run you need to have rust installed.
For unix:

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

For Windows [check here](https://forge.rust-lang.org/infra/other-installation-methods.html)

Create a secrets.json file into the same directory as cargo.toml and use the following template.

```JSON
{
  "graphql_endpoint": "GRAPHQL_ENDPOINT",
  "user_pool_id": "USER_POOL_ID",
  "app_client_id": "APP_CLIENT_ID",
  "username": "YOUR_USERNAME",
  "password": "YOUR_PASSWORD"
}
```

Where to find?

Graphql endpoint: AWS Appsync > APIs

Userpool id: Cognito > User pools

App client id: Cognito > User pools > YOUR_POOL > App integration tab

cognito Username: `¯\_(ツ)_/¯`

cognito Password: `¯\_(ツ)_/¯`

Before running, log in to aws with sso or something (It's needed for the cognito user query)

To run:

```bash
cargo run
```
