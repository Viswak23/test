import { useState, useMemo, useRef } from "react";
import RedFlagItem from "./RedFlagItem";
import EditRedFlag from "./EditRedFlag";
import GTabPanel from "../Common/GTabPanel/GTabPanel";
import { RedFlag } from "@/src/API";
import { sortCreatedAtDescending } from "@/lib/time";
import RedFlagsExpanded from "./RedFlagsExpanded";
import { useIntl } from "react-intl";
import { AttachmentFile } from "@/lib/webAttachment";
import { deleteRedFlagDb } from "@/lib/webRedFlags";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import { useEvents } from "@/contexts/EventsContext";

interface RedFlagsProps {
  redFlags?: (RedFlag | null)[];
  goalId?: string;
  canAdd?: boolean;
  showResolved?: boolean;
}

export default function RedFlags({
  redFlags,
  goalId,
  canAdd = false,
  showResolved = true,
}: RedFlagsProps) {
  const [addingRedFlag, setAddingRedFlag] = useState(false);
  const [editRedFlag, setEditRedFlag] = useState<RedFlag | undefined>();
  const [deleteRedFlag, setDeleteRedFlag] = useState<RedFlag | undefined>();
  const [deleteAttachments, setDeleteAttachments] = useState<
    AttachmentFile[] | undefined
  >();
  const [saving, setSaving] = useState(false);
  const topRef = useRef<HTMLDivElement | null>(null);
  const intl = useIntl();
  const events = useEvents()?.events;

  const resetState = () => {
    setAddingRedFlag(false);
    setEditRedFlag(undefined);
    setDeleteRedFlag(undefined);
    setDeleteAttachments(undefined);
    setSaving(false);
  };

  const handleAdd = () => {
    setAddingRedFlag(true);
  };

  const handleEdit = (redFlag: RedFlag) => {
    setEditRedFlag(redFlag);
  };

  const handleCloseEdit = (scrollToTop: Boolean) => {
    resetState();
    if (scrollToTop) {
      topRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleDelete = (redFlag: RedFlag, attachments?: AttachmentFile[]) => {
    setDeleteRedFlag(redFlag);
    setDeleteAttachments(attachments || []);
  };

  const handleDeleteCancel = () => {
    resetState();
  };

  const handleDeleteConfirmed = async () => {
    if (!deleteRedFlag) {
      return;
    }

    setSaving(true);
    await deleteRedFlagDb(deleteRedFlag, deleteAttachments || [], events);
    resetState();
  };

  const resolvedRefFlags = useMemo(
    () =>
      redFlags?.filter((rf) => !!rf?.resolved).sort(sortCreatedAtDescending),
    [redFlags]
  );

  const notResolvedRedFlags = useMemo(
    () =>
      redFlags
        ?.filter((rf) => !!rf?.resolved === false)
        .sort(sortCreatedAtDescending),
    [redFlags]
  );

  return (
    <>
      <div ref={topRef} style={{ paddingTop: "2px" }} />
      <GTabPanel
        onAdd={canAdd ? handleAdd : undefined}
        addDisabled={addingRedFlag}
        addLabel={intl.formatMessage({ id: "general.add" })}
      >
        {notResolvedRedFlags?.map((redFlag) => {
          if (!redFlag) {
            return null; // Should never happen, but automatically generated API has (RedFlag | null)[]
          }

          return (
            <RedFlagItem
              key={redFlag.id}
              redFlag={redFlag}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          );
        })}
      </GTabPanel>
      {showResolved && resolvedRefFlags && resolvedRefFlags.length > 0 && (
        <RedFlagsExpanded
          title={intl.formatMessage({ id: "redflags.resolved.red.flags" })}
          redFlags={resolvedRefFlags}
          onEdit={handleEdit}
          onDelete={handleDelete}
          dataCy="resolved-flags"
        />
      )}
      {(addingRedFlag || !!editRedFlag) && (
        <EditRedFlag
          key={editRedFlag?.id || "newRedFlag"}
          goalId={editRedFlag ? editRedFlag.goalRedFlagsId : goalId}
          open={addingRedFlag || !!editRedFlag}
          redFlag={editRedFlag}
          onClose={handleCloseEdit}
        />
      )}
      {deleteRedFlag && (
        <ConfirmationDialog
          title={intl.formatMessage({ id: "redflags.delete.caption" })}
          message={intl.formatMessage({ id: "redflags.delete.confirmation" })}
          messageItem={deleteRedFlag.text || ""}
          open={!!deleteRedFlag}
          saving={saving}
          onCancel={handleDeleteCancel}
          onConfirm={handleDeleteConfirmed}
        />
      )}
    </>
  );
}
