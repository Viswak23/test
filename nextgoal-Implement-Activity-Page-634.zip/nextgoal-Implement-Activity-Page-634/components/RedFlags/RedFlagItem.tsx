import { useMemo, ReactNode } from "react";
import { calculateDaysOfStatus } from "@/lib/time";
import { RedFlag } from "@/src/API";
import { AttachmentFile, useAttachmentUrls } from "@/lib/webAttachment";
import FeedItem from "../Feeds/FeedItem";
import RedFlagFeedDescription from "./RedFlagFeedDescription";
import { useIntl } from "react-intl";
import { canDeleteDbItem } from "@/lib/webHelpers";

interface RedFlagProps {
  redFlag: RedFlag;
  onEdit?: (redFlag: RedFlag) => void;
  onDelete?: (redFlag: RedFlag, attachments: AttachmentFile[]) => void;
}

export default function RedFlagItem({
  redFlag,
  onEdit,
  onDelete,
}: RedFlagProps) {
  const rawAtachments = useMemo(
    () => (redFlag ? (redFlag?.attachments as string[]) : []),
    [redFlag]
  );
  const attachments = useAttachmentUrls(rawAtachments as string[]);
  const intl = useIntl();

  const handleEdit = () => {
    if (onEdit) {
      onEdit(redFlag);
    }
  };

  const timeSince = redFlag
    ? calculateDaysOfStatus(intl, redFlag.createdAt)
    : "-";
  let description: string | ReactNode = <>{redFlag?.text}</> || "";
  if (redFlag?.resolved) {
    description = (
      <>
        {redFlag?.text}
        <br />
        {`${intl.formatMessage({
          id: "redflags.resolved",
        })}: ${calculateDaysOfStatus(intl, redFlag.resolvedTime)}`}
        <br />
        {redFlag.resolvedComment}
      </>
    );
  }

  const handleDelete = () => {
    if (!onDelete) {
      return;
    }

    onDelete(redFlag, attachments);
  };

  return (
    <FeedItem
      title={intl.formatMessage({ id: "redflags.red.flag" })}
      subheader={timeSince}
      description={<RedFlagFeedDescription redFlag={redFlag} />}
      creatorEmail={redFlag.creatorEmail}
      comments={redFlag.comments?.items}
      attachments={attachments}
      currentGoalId={redFlag.goalRedFlagsId!}
      redFlagId={redFlag.id}
      onEdit={onEdit ? handleEdit : undefined}
      onDelete={onDelete && handleDelete}
      deleteDisabled={!canDeleteDbItem(redFlag)}
      tooltips={{
        editTooltip: intl.formatMessage({ id: "redflags.edit" }),
        deleteTooltip: intl.formatMessage({
          id: "redflags.delete.caption",
        }),
        deleteDisabledTooltip: intl.formatMessage({
          id: "redflags.delete.disabled.tooltip",
        }),
      }}
    />
  );
}
