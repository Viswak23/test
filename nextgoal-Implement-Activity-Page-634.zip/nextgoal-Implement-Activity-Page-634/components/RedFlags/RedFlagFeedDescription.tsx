import { RedFlag } from "@/src/API";
import { Stack } from "@mui/material";
import { DetailsLabel, DetailsText, ListText } from "../Common/Texts/Texts";
import { useEmployees } from "@/contexts/EmployeesContext";
import { getEmployeeByEmail } from "@/lib/webEmployee";
import { calculateDaysOfStatus } from "@/lib/time";
import { FormattedMessage, useIntl } from "react-intl";

interface RedFlagFeedDescriptionProps {
  redFlag?: RedFlag | null;
  resolvedEvent?: boolean;
  reopenedEvent?: boolean;
}

export default function RedFlagFeedDescription({
  redFlag,
  resolvedEvent = false,
  reopenedEvent = false,
}: RedFlagFeedDescriptionProps) {
  const employees = useEmployees()?.employees;
  const intl = useIntl();
  const resolver = getEmployeeByEmail(employees, redFlag?.resolvedBy);
  const reopener = getEmployeeByEmail(employees, redFlag?.reopenedBy);

  return (
    <Stack direction="column" spacing={0}>
      <ListText>{redFlag?.text}</ListText>
      {(resolvedEvent || (!reopenedEvent && redFlag?.resolved)) && (
        <>
          <Stack direction="row" spacing={1} style={{ marginTop: "12px" }}>
            <DetailsLabel>
              <FormattedMessage id="redflags.resolved" />
            </DetailsLabel>
            <DetailsText>
              {calculateDaysOfStatus(intl, redFlag?.resolvedTime)} (
              {resolver?.name || redFlag?.resolvedBy})
            </DetailsText>
          </Stack>
          <Stack direction="row" spacing={1}>
            <DetailsLabel
              sx={{
                wordBreak: "normal",
              }}
            >
              <FormattedMessage id="redflags.resolution.comment" />
            </DetailsLabel>
            <ListText>{redFlag?.resolvedComment}</ListText>
          </Stack>
        </>
      )}
      {(reopenedEvent ||
        (!resolvedEvent && !redFlag?.resolved && redFlag?.reopenedTime)) && (
        <>
          <Stack direction="row" spacing={1} style={{ marginTop: "12px" }}>
            <DetailsLabel>
              <FormattedMessage id="redflags.reopened" />
            </DetailsLabel>
            <DetailsText>
              {calculateDaysOfStatus(intl, redFlag?.reopenedTime)} (
              {reopener?.name || redFlag?.reopenedBy})
            </DetailsText>
          </Stack>
          <Stack direction="row" spacing={1}>
            <DetailsLabel>
              <FormattedMessage id="redflags.reopen.comment" />
            </DetailsLabel>
            <ListText>{redFlag?.reopenedComment}</ListText>
          </Stack>
        </>
      )}
    </Stack>
  );
}
