import { RedFlag } from "@/src/API";
import GExpandList from "../Common/GList/GExpandList";
import RedFlagItem from "./RedFlagItem";
import { AttachmentFile } from "@/lib/webAttachment";

interface RedFlagsExpandedProps {
  redFlags?: (RedFlag | null)[];
  title: string;
  dataCy?: string;
  onEdit?: (redFlag: RedFlag) => void;
  onDelete?: (redFlag: RedFlag, attachments: AttachmentFile[]) => void;
}

export default function RedFlagsExpanded({
  redFlags,
  title,
  onEdit,
  dataCy,
  onDelete,
}: RedFlagsExpandedProps) {
  return (
    <GExpandList title={`${title} (${redFlags?.length})`} dataCy={dataCy}>
      {redFlags?.map((rf) => {
        if (!rf) {
          return null; // Should never happen, but automatically generated API has (RedFlag | null)[]
        }

        return (
          <RedFlagItem
            key={rf.id}
            redFlag={rf}
            onEdit={onEdit}
            onDelete={onDelete}
          />
        );
      })}
    </GExpandList>
  );
}
