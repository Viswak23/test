import { useState, useMemo, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import TextField from "@mui/material/TextField";
import { UpdateRedFlagInput } from "@/src/API";
import { Alert, Checkbox, FormControlLabel } from "@mui/material";
import { useImmer } from "use-immer";
import { RedFlag, CreateRedFlagInput } from "@/src/API";
import { addRedFlagDb, updateRedFlagDb } from "@/lib/webRedFlags";
import { useAuthStatus } from "@/lib/customHooks";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import {
  AttachmentFile,
  AttachmentOwner,
  deleteAttachments,
  saveAttachments,
  useAttachmentUrls,
} from "@/lib/webAttachment";
import HandleAttachments from "../Common/Attachment/HandleAttachments";
import { getCurrentTimestamp } from "@/lib/time";
import { FormattedMessage, useIntl } from "react-intl";
import { useGoals } from "@/contexts/GoalsContext";
import { isEmployeeGoal } from "@/lib/webEmployee";
import { log } from "@/lib/backend/actions/logger";
import HelpCollapse from "../Common/Dialog/HelpCollapse";
import { useEmployees } from "@/contexts/EmployeesContext";
import DialogTabTitle from "../Common/Dialog/DialogTabTitle";
import { useOrganization } from "@/contexts/OrganizationContext";
import { useNorthStars } from "@/contexts/NorthStarsContext";
import {
  ChatDialogState,
  defaultChatDialogState,
} from "../Chat/ChatDialogState";
import { TabPanel } from "../Settings/TabPanel";
import DialogChat from "../Chat/ChatInDialog";
import { getGoalBackgroundInfo } from "@/lib/webGoals";

interface EditRedFlagProps {
  goalId?: string | null;
  redFlag?: RedFlag;
  open: boolean;
  onClose: (scrollToTop: Boolean) => void;
}

export default function EditRedFlag({
  goalId,
  redFlag,
  open,
  onClose,
}: EditRedFlagProps) {
  const defaultRedFlag = {
    resolved: false,
    text: "",
    resolvedComment: "",
    reopenedComment: "",
    companyId: "placeholder",
    creatorEmail: "placeholder",
  };
  const [editRedFlag, setEditRedFlag] = useImmer<
    CreateRedFlagInput | UpdateRedFlagInput
  >(redFlag || { ...defaultRedFlag });
  const [showHelp, setShowHelp] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savingError, setSavingError] = useState("");
  const [previewAttachments, setPreviewAttachments] = useState<
    AttachmentFile[]
  >([]);
  const [removedAttachments, setRemovedAttachments] = useState<
    AttachmentFile[]
  >([]);
  const [error, setError] = useState("");
  const intl = useIntl();
  const { goals: fetchedGoals } = useGoals()!;
  const goals = useMemo(() => fetchedGoals || [], [fetchedGoals]);  const employees = useEmployees();
  const [tabValue, setTabValue] = useState(0);
  const [chatDialogState, setChatDialogState] = useImmer<ChatDialogState>(
    defaultChatDialogState
  );
  const organization = useOrganization()?.organization;
  const northStars = useNorthStars()?.northStars;
  const currentGoal = goals.find((goal) => goal.id === goalId);
  const employee = employees?.employees?.find(
    (employee) => employee?.id === currentGoal?.employeeGoalsId
  );

  const currentUser = useAuthStatus();
  const memoizedAttachments = useMemo(
    () => redFlag?.attachments as string[],
    [redFlag?.attachments]
  );
  const existingAttachments = useAttachmentUrls(memoizedAttachments);

  if (!goalId) {
    throw new Error("goalId is required");
  }

  useEffect(() => {
    (async () => {
      let info = await getGoalBackgroundInfo(
        intl,
        currentGoal?.organizationUnitGoalsId ?? undefined,
        employee ?? undefined,
        goals,
        organization,
        northStars,
        employees?.organizationUnitEmployeeJoins,
        currentGoal
      );
      setChatDialogState((draft) => {
        draft.backgroundInfo = info.info;
        draft.hint = info.hint;
      });
    })();
    if (!redFlag) {
      setChatDialogState((draft) => {
        draft.question = intl.formatMessage({
          id: "chat.prefilled.question.redflag",
        });
      });
    }
  }, [
    currentGoal,
    intl,
    currentGoal?.organizationUnitGoalsId,
    employee,
    goals,
    organization,
    northStars,
    employees?.organizationUnitEmployeeJoins,
    redFlag,
    setChatDialogState
  ]);

  const resetState = () => {
    setEditRedFlag(redFlag || { ...defaultRedFlag });
    setShowHelp(false);
    setSaving(false);
    setPreviewAttachments([]);
    setRemovedAttachments([]);
    setError("");
    setSavingError("");
  };

  const handleCommentChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setError("");
    setEditRedFlag((draft) => {
      draft.text = event.target.value;
    });
  };

  const handleResolvedChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setEditRedFlag((draft) => {
      draft.resolved = event.target.checked;
    });
  };

  const handleResolvedCommentChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditRedFlag((draft) => {
      draft.resolvedComment = event.target.value;
    });
  };

  const handleReopenedCommentChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditRedFlag((draft) => {
      draft.reopenedComment = event.target.value;
    });
  };

  const handleCancel = (event?: object, reason?: string) => {
    if (reason === "backdropClick") {
      // Don't do anything. Accidental click can't delete all the information.
      return;
    }

    resetState();
    onClose(false);
  };

  const handleSave = async () => {
    if (!editRedFlag.text) {
      setError(intl.formatMessage({ id: "redflags.error.comment.required" }));
      return;
    }
    try {
      setSaving(true);
      // Save attachments to S3
      const newAttachments = await saveAttachments(
        previewAttachments,
        AttachmentOwner.RedFlag
      );

      const employeeGoal = isEmployeeGoal(goals, goalId);

      if (!redFlag) {
        await addRedFlagDb(
          {
            ...editRedFlag,
            goalRedFlagsId: goalId,
            creatorEmail: currentUser?.attributes.email,
            attachments: newAttachments,
            resolvedBy: editRedFlag.resolved
              ? currentUser?.attributes.email
              : null,
            resolvedTime: editRedFlag.resolved ? getCurrentTimestamp() : null,
          } as CreateRedFlagInput,
          employeeGoal,
          employees?.employees
        );
      } else {
        // Remove deleted attachments from S3
        const remainingAttachments = await deleteAttachments(
          removedAttachments,
          existingAttachments
        );

        const updateObject = {
          ...editRedFlag,
          attachments: remainingAttachments.concat(newAttachments),
        } as UpdateRedFlagInput;

        // Check if resolved by has been changed and save the resolver or reopener
        if (editRedFlag.resolved && !redFlag.resolved) {
          updateObject.resolvedBy = currentUser?.attributes.email;
          updateObject.resolvedTime = getCurrentTimestamp();
        } else if (!editRedFlag.resolved && redFlag.resolved) {
          updateObject.reopenedBy = currentUser?.attributes.email;
          updateObject.reopenedTime = getCurrentTimestamp();
        }
        await updateRedFlagDb(
          updateObject,
          redFlag,
          employeeGoal,
          employees?.employees
        );
      }

      resetState();
      onClose(redFlag == null);
    } catch (error: any) {
      log(`Add/Edit RedFlag: ${error.message}`);
      setSaving(false);
      setSavingError(intl.formatMessage({ id: "general.save.error" }));
    }
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  const reopenedCommentEnabled =
    !editRedFlag.resolved && editRedFlag?.resolvedTime != null;

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      fullWidth={true}
      maxWidth="lg"
      disableRestoreFocus
      onKeyUp={(e) => {
        if (e.key === "Enter") handleSave();
      }}
    >
      <DialogTabTitle
        tabValue={tabValue}
        setTabValue={setTabValue}
        dialogTitle={intl.formatMessage({
          id: redFlag ? "redflags.edit" : "redflags.add",
        })}
        handleToggleHelp={handleToggleHelp}
      />
      <DialogContent>
        <TabPanel value={tabValue} index={0}>
          <HelpCollapse
            showHelp={showHelp}
            helpText={intl.formatMessage({ id: "redflags.edit.help.text" })}
          />
          <TextField
            autoFocus
            margin="dense"
            id="description"
            data-cy="edit-redflag-description"
            label={<FormattedMessage id="redflags.description" />}
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            helperText={error}
            error={error !== ""}
            value={editRedFlag.text || ""}
            onChange={handleCommentChange}
          />
          {/* Solved label & checkbox */}
          <FormControlLabel
            value={editRedFlag.resolved}
            label={<FormattedMessage id="redflags.resolved" />}
            labelPlacement="start"
            sx={{ marginTop: "6px" }}
            control={
              <Checkbox
                data-cy="resolved-checkbox"
                checked={editRedFlag.resolved === true}
                onChange={handleResolvedChange}
              />
            }
          />
          <TextField
            margin="dense"
            id="resolvedComment"
            label={<FormattedMessage id="redflags.resolution.comment" />}
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            disabled={!editRedFlag.resolved}
            value={editRedFlag.resolvedComment || ""}
            onChange={handleResolvedCommentChange}
          />
          <TextField
            margin="dense"
            id="reopenedComment"
            label={<FormattedMessage id="redflags.reopen.comment" />}
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            disabled={!reopenedCommentEnabled}
            value={editRedFlag.reopenedComment || ""}
            onChange={handleReopenedCommentChange}
          />
          <HandleAttachments
            existingAttachments={existingAttachments}
            previewMedias={previewAttachments}
            setPreviewMedias={setPreviewAttachments}
            removedAttachments={removedAttachments}
            setRemovedAttachments={setRemovedAttachments}
          />
          {savingError && <Alert severity="error">{savingError}</Alert>}
        </TabPanel>
        <TabPanel value={tabValue} index={1}>
          <DialogChat
            chatDialogState={chatDialogState}
            setChatDialogState={setChatDialogState}
          />
        </TabPanel>
      </DialogContent>
      <EditDialogActions
        saving={saving}
        onSave={handleSave}
        onCancel={handleCancel}
      />
    </Dialog>
  );
}
