import React, { useState, useMemo, useRef, useEffect } from "react";
import Stack from "@mui/material/Stack";
import { Goal } from "@/src/API";
import ExpandMore from "@/components/Common/ExpandMore/ExpandMore";
import Link from "next/link";
import Collapse from "@mui/material/Collapse";
import { getAllSubgoals } from "@/lib/webSubgoals";
import OrganizationSubgoals from "./OrganizationSubgoals";
import { useOrganization } from "@/contexts/OrganizationContext";
import { Brightness1, Height } from "@mui/icons-material";
import GoalStatus from "../Goal/GoalStatus";
import { Link as MUILink } from "@mui/material";
import { FormattedMessage, useIntl } from "react-intl";
import { getLinkWithLocale } from "@/lib/localisation";
import theme from "@/config/theme";

interface SubgoalItemProps {
  level: number;
  currentGoal: Goal;
  subGoals: Goal[];
  currentOrganizationUnitId: string;
  addCircleRef: React.RefObject<HTMLDivElement>;
  isLast?: boolean;
  height: number;
}

export default function SubgoalItem({
  level,
  currentGoal,
  subGoals,
  currentOrganizationUnitId,
  addCircleRef,
  isLast,
  height,
}: SubgoalItemProps) {
  const [expanded, setExpanded] = useState(false);
  const organization = useOrganization()?.organization;
  const intl = useIntl();
  const addSubGoalitemLabel = intl.formatMessage({ id: "goals.subgoals.show" });

  const nextLevelOrganization = useMemo(
    () =>
      organization?.filter(
        (o) =>
          o.organizationUnitChildOrzganizationUnitsId ===
          currentOrganizationUnitId
      ),
    [organization, currentOrganizationUnitId]
  );
  const orgSubgoals = useMemo(
    () => getAllSubgoals(currentGoal.id, subGoals),
    [currentGoal, subGoals]
  );

  // Ref for the Brightness1 icon
  const brightnessRef = useRef<HTMLDivElement | null>(null);
  const expandedRef = useRef<HTMLDivElement | null>(null);
  const [lineHeight, setLineHeight] = useState(0);
  const [lineTop, setLineTop] = useState(0);

  useEffect(() => {
    if (brightnessRef.current && addCircleRef.current) {
      const brightnessRect = brightnessRef.current.getBoundingClientRect();
      const addCircleRect = addCircleRef.current.getBoundingClientRect();

      // Calculate vertical line height and top position based on position difference
      setLineHeight(brightnessRect.top - addCircleRect.bottom);
      setLineTop(addCircleRect.bottom - brightnessRect.top);
    }
  }, [brightnessRef, addCircleRef, height]);

  const handleExpand = () => {
    setExpanded((current) => !current);
  };

  return (
    <div ref={expandedRef}>
      <Stack direction="column" spacing={0} sx={{ position: "relative" }}>
        {/* Vertical Line */}
        <div
          style={{
            position: "absolute",
            left: "10px",
            top: lineTop,
            width: "2px",
            height: lineHeight,
            transition: "height 0.3s ease",
            backgroundColor: theme.palette.primary.main, // Same color as the icon
          }}
        />

        <Stack direction="row" spacing={1} sx={{ alignItems: "center" }}>
          <Stack direction="row" spacing={1} alignItems={"center"} flexGrow={1}>
            <div ref={brightnessRef}>
              <Brightness1 sx={{ color: "primary.main" }} />
            </div>
            <MUILink
              component={Link}
              href={getLinkWithLocale(`/goals/${currentGoal.id}`, intl.locale)}
              locale={intl.locale}
              underline="hover"
            >
              {currentGoal.isClosed ? (
                <FormattedMessage
                  id="goals.goal.subgoals.closed"
                  values={{
                    goal: currentGoal.title,
                    count: orgSubgoals.length,
                  }}
                />
              ) : (
                <FormattedMessage
                  id="goals.goal.subgoals"
                  values={{
                    goal: currentGoal.title,
                    count: orgSubgoals.length,
                  }}
                />
              )}
            </MUILink>

            {nextLevelOrganization && nextLevelOrganization.length > 0 && (
              <ExpandMore
                expand={expanded}
                onClick={handleExpand}
                aria-expanded={expanded}
                aria-label={addSubGoalitemLabel}
                sx={{ paddingTop: 0, paddingBottom: 0, paddingRight: 0 }}
                expandedTooltip={<FormattedMessage id="general.show.less" />}
                collapsedTooltip={<FormattedMessage id="general.show.more" />}
              />
            )}
          </Stack>
        </Stack>

        {/* Goal details */}
        <GoalStatus goal={currentGoal} style={{ marginLeft: "32px" }} />
      </Stack>

      {/* Subgoals' subgoals */}
      <Collapse in={expanded} timeout="auto" unmountOnExit>
        {nextLevelOrganization?.map((org) => (
          <OrganizationSubgoals
            key={org?.id || "nostatus"}
            level={level + 1}
            goal={currentGoal}
            subGoals={subGoals}
            organizationUnit={org}
            addCircleRef={addCircleRef} // Pass ref down to next OrganizationSubgoals
          />
        ))}
      </Collapse>
      <br />
    </div>
  );
}
