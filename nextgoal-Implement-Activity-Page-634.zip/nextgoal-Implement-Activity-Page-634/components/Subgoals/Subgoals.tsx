import React, { useMemo } from "react";
import { getAllSubgoals } from "@/lib/webSubgoals";
import OrganizationSubgoals from "./OrganizationSubgoals";
import { useGoals } from "@/contexts/GoalsContext";
import { useOrganization } from "@/contexts/OrganizationContext";
import GTabPanel from "../Common/GTabPanel/GTabPanel";
import { DetailsLabel, DetailsText, TabSubTitle } from "../Common/Texts/Texts";
import { Card, Grid, Stack, Theme, useMediaQuery } from "@mui/material";
import { FormattedMessage } from "react-intl";
import { Goal } from "@/src/API";

interface SubgoalsProps {
  goal: Goal | null;
}

export default function Subgoals({ goal }: SubgoalsProps) {
  const organization = useOrganization()?.organization;
  const goals = useGoals()?.goals;
  const archivedGoals = useGoals()?.archivedGoals;
  const firstLevelOrganization = useMemo(
    () =>
      organization?.filter(
        (org) =>
          (!goal?.organizationUnitGoalsId &&
            org.organizationUnitChildOrzganizationUnitsId == null) ||
          org.organizationUnitChildOrzganizationUnitsId ===
            goal?.organizationUnitGoalsId
      ),
    [organization, goal?.organizationUnitGoalsId]
  );
  const allSubgoals = useMemo(
    () =>
      getAllSubgoals(goal?.id || "", goals).concat(
        getAllSubgoals(goal?.id || "", archivedGoals)
      ),
    [goal, goals, archivedGoals]
  );

  if (!goal || !goals) {
    return (
      <div>
        <FormattedMessage id="goals.subgoals.error" />
      </div>
    );
  }

  return (
    <GTabPanel>
      <Stack
        spacing={0}
        sx={{
          marginLeft: "18px",
          marginBottom: "10px", // space btwn detailstxt & cards
        }}
      >
        <Grid
          container
          style={{ paddingTop: "0px" }}
          spacing={1}
          alignItems="center"
          justifyContent="center"
        >
          {/* Subgoals label */}
          <Grid item>
            <TabSubTitle>
              <FormattedMessage id="goals.number.of.subgoals" />
            </TabSubTitle>
          </Grid>

          {/* Number of subgoals */}
          <Grid item>
            <DetailsText style={{ padding: "15px" }}>
              {allSubgoals.length}
            </DetailsText>
          </Grid>
        </Grid>
      </Stack>

      {/* The subgoal cards */}
      <div style={{ padding: "10px" }}>
        <Stack direction="row">
          <Grid
            container
            rowSpacing={{ xs: 1, sm: 1, md: 2 }} // space vertically
            columnSpacing={{ xs: 1, sm: 2, md: 2 }} // space horizontally
            justifyContent="center"
          >
            {firstLevelOrganization?.map((org) => (
              <Grid
                item
                key={org?.id || "nostatus"}
                xs={12}
                sx={{
                  display: "flex",
                  justifyContent: "center",
                }}
              >
                <Card
                  sx={{
                    padding: "30px 20px 30px 20px",
                    marginBottom: "12px",
                    width: "100%",
                    alignContent: "center",
                    flexWrap: "wrap",
                    boxShadow:
                      "rgba(0, 0, 0, 0.12) 0px 1px 3px, rgba(0, 0, 0, 0.24) 0px 1px 2px",
                  }}
                >
                  <OrganizationSubgoals
                    level={0}
                    key={org?.id || "nostatus"}
                    goal={goal}
                    subGoals={allSubgoals}
                    organizationUnit={org}
                  />
                </Card>
              </Grid>
            ))}
          </Grid>
        </Stack>
      </div>
    </GTabPanel>
  );
}
