import React, { useState, useMemo, useRef, useEffect } from "react";
import Stack from "@mui/material/Stack";
import { IconButton, useTheme } from "@mui/material";
import { Goal } from "@/src/API";
import { OrganizationUnit } from "@/src/API";
import Link from "next/link";
import { Link as MUILink } from "@mui/material";
import EditGoal from "@/components/Goal/EditGoal";
import SubgoalItem from "./SubgoalItem";
import { sortGoals } from "@/lib/webGoals";
import { useIntl } from "react-intl";
import { getLinkWithLocale } from "@/lib/localisation";
import { hoverMainToAdd } from "@/config/styling";
import { TabSubTitle } from "../Common/Texts/Texts";
import { AddCircle } from "@mui/icons-material";

interface OrganizationSubgoalsProps {
  level: number;
  goal: Goal;
  subGoals: Goal[];
  organizationUnit: OrganizationUnit;
  onUpdateGoals?: (updatedGoals: Goal[]) => void;
  addCircleRef?: React.RefObject<HTMLDivElement>;
}

export default function OrganizationSubgoals({
  level,
  goal,
  subGoals,
  organizationUnit,
}: OrganizationSubgoalsProps) {
  const [addingGoal, setAddingGoal] = useState(false);
  const intl = useIntl();
  const theme = useTheme();
  const expandedRef = useRef<HTMLDivElement | null>(null);
  const [currentHeight, setCurrentHeight] = useState(0);

  const addSubgoalLabel = intl.formatMessage({ id: "general.add.subgoal" });

  const orgGoals = useMemo(() => {
    const result = subGoals
      ? subGoals.filter(
          (g) =>
            g.organizationUnitGoalsId === organizationUnit.id &&
            g.goalChildGoalsId === goal.id
        )
      : [];

    return sortGoals(result);
  }, [subGoals, organizationUnit.id, goal.id]);
  const paddingLeft = 16 + level * 24;

  useEffect(() => {
    let resizeObserver: ResizeObserver;

    if (expandedRef.current) {
      setCurrentHeight(expandedRef.current.clientHeight);

      resizeObserver = new ResizeObserver(() => {
        setCurrentHeight(expandedRef.current?.clientHeight || 0);
      });
      resizeObserver.observe(expandedRef.current);
    }
    return () => {
      resizeObserver?.disconnect();
    };
  }, [expandedRef]);

  const handleAddClick = () => {
    setAddingGoal(true);
  };

  const handleAddClose = () => {
    setAddingGoal(false);
  };

  const addCircleRef = useRef<HTMLDivElement | null>(null);

  return (
    <div ref={expandedRef}>
      <Stack
        direction="column"
        spacing={1}
        sx={{ marginTop: "6px", paddingLeft: `${paddingLeft}px` }}
      >
        <Stack direction="row" spacing={1} alignItems="center">
          <div ref={addCircleRef}>
            <IconButton
              aria-label={addSubgoalLabel}
              onClick={handleAddClick}
              sx={{
                paddingTop: 0,
                paddingBottom: 0,
                paddingLeft: 0,
                alignContent: "center",
                ...hoverMainToAdd(theme),
              }}
            >
              <AddCircle />
            </IconButton>
          </div>
          <Stack direction="row">
            <TabSubTitle>
              <MUILink
                component={Link}
                href={getLinkWithLocale(
                  `/organization/${organizationUnit.id}`,
                  intl.locale
                )}
                locale={intl.locale}
                underline="hover"
                color={theme.palette.primary.main}
              >
                {organizationUnit.name}
              </MUILink>
            </TabSubTitle>
          </Stack>
        </Stack>

        {/* Subgoals' subgoals */}
        <Stack spacing={4}>
          {orgGoals.map((g) => (
            <SubgoalItem
              key={g.id}
              level={level}
              currentGoal={g}
              subGoals={subGoals}
              currentOrganizationUnitId={organizationUnit.id}
              addCircleRef={addCircleRef} // Pass ref down to SubgoalItem
              height={currentHeight}
            />
          ))}
        </Stack>
      </Stack>
      <EditGoal
        parentId={goal.id}
        newPosition={orgGoals.length + 1}
        organizationUnitId={organizationUnit.id}
        open={addingGoal}
        onClose={handleAddClose}
      />
    </div>
  );
}
