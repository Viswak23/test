import { Idea } from "@/src/API";
import { Stack } from "@mui/material";
import { FeedTitle, ListText } from "../Common/Texts/Texts";

interface IdeaFeedDescriptionProps {
  idea?: Idea | null;
  showTitle?: boolean;
}

export default function IdeaFeedDescription({
  idea,
  showTitle = true,
}: IdeaFeedDescriptionProps) {
  return (
    <Stack direction="column" spacing={0}>
      {showTitle && (
        <FeedTitle style={{ fontWeight: "bold" }}>{idea?.title}</FeedTitle>
      )}
      <ListText>{idea?.description}</ListText>
    </Stack>
  );
}
