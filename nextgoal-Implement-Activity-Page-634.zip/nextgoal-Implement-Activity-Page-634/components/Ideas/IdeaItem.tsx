import { useMemo } from "react";
import { calculateDaysOfStatus } from "@/lib/time";
import { Idea } from "@/src/API";
import { AttachmentFile, useAttachmentUrls } from "@/lib/webAttachment";
import FeedItem from "../Feeds/FeedItem";
import { EventType, getEventEmployeesTitle } from "@/lib/webEvents";
import { canDeleteDbItem } from "@/lib/webHelpers";
import { useIntl } from "react-intl";
import IdeaFeedDescription from "./IdeaFeedDescription";

interface IdeaItemProps {
  idea?: Idea | null;
  onEdit: (idea: Idea) => void;
  onDelete: (idea: Idea, attachments: AttachmentFile[]) => void;
}

export default function IdeaItem({ idea, onEdit, onDelete }: IdeaItemProps) {
  const rawAtachments = useMemo(
    () => (idea ? (idea?.attachments as string[]) : []),
    [idea]
  );
  const attachments = useAttachmentUrls(rawAtachments as string[]);
  const intl = useIntl();

  if (!idea) {
    return null;
  }

  const handleEdit = () => {
    if (onEdit && idea) {
      onEdit(idea);
    }
  };

  const handleDelete = () => {
    onDelete(idea, attachments);
  };

  if (!idea) {
    return null;
  }

  const timeSince = calculateDaysOfStatus(intl, idea.createdAt);
  return (
    <FeedItem
      title={idea.title || ""}
      subheader={timeSince}
      description={<IdeaFeedDescription idea={idea} />}
      creatorEmail={idea.creatorEmail}
      comments={idea.comments?.items}
      attachments={attachments}
      taggedEmployeeJoins={idea.employeeJoins}
      employeeIdField={"employeeIdeaEmployeeJoinsId"}
      taggedEmployeesTitle={getEventEmployeesTitle(intl, EventType.IDEA_ADDED)}
      currentGoalId={idea.goalIdeasId!}
      ideaId={idea.id}
      onEdit={handleEdit}
      onDelete={handleDelete}
      deleteDisabled={!canDeleteDbItem(idea)}
      tooltips={{
        editTooltip: intl.formatMessage({ id: "ideas.edit" }),
        deleteTooltip: intl.formatMessage({
          id: "ideas.delete.caption",
        }),
        deleteDisabledTooltip: intl.formatMessage({
          id: "ideas.delete.disabled.tooltip",
        }),
      }}
    />
  );
}
