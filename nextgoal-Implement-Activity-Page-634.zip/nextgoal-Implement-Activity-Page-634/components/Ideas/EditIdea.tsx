import { useState, useMemo, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import TextField from "@mui/material/TextField";
import {
  Idea,
  CreateIdeaInput,
  UpdateIdeaInput,
  Goal,
  Employee,
} from "@/src/API";
import { useImmer } from "use-immer";
import { Alert } from "@mui/material";
import { useAuthStatus } from "@/lib/customHooks";
import {
  EmployeeWithAvatarUrl,
  useEmployees,
} from "@/contexts/EmployeesContext";
import { addIdeaDb, updateIdeaDb } from "@/lib/webIdeas";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import HandleAttachments from "../Common/Attachment/HandleAttachments";
import {
  AttachmentFile,
  AttachmentOwner,
  deleteAttachments,
  saveAttachments,
  useAttachmentUrls,
} from "@/lib/webAttachment";
import TaggedEmployees from "../Common/TaggedEmployees/TaggedEmployees";
import { EventType, getEventEmployeesTitle } from "@/lib/webEvents";
import { FormattedMessage, useIntl } from "react-intl";
import { log } from "@/lib/backend/actions/logger";
import HelpCollapse from "../Common/Dialog/HelpCollapse";
import DialogTabTitle from "../Common/Dialog/DialogTabTitle";
import { TabPanel } from "../Settings/TabPanel";
import DialogChat from "../Chat/ChatInDialog";
import { getGoalBackgroundInfo } from "@/lib/webGoals";
import { useGoals } from "@/contexts/GoalsContext";
import { useOrganization } from "@/contexts/OrganizationContext";
import { useNorthStars } from "@/contexts/NorthStarsContext";
import {
  ChatDialogState,
  defaultChatDialogState,
} from "../Chat/ChatDialogState";

interface EditIdeaProps {
  goal: Goal;
  idea?: Idea;
  open: boolean;
  onClose: (scrollToTop: Boolean) => void;
}

const defaultIdea = {
  title: "",
  description: "",
  companyId: "placeholder",
  creatorEmail: "placeholder",
};

export default function EditIdea({ goal, idea, open, onClose }: EditIdeaProps) {
  const [showHelp, setShowHelp] = useState(false);
  const [editIdea, setEditIdea] = useImmer<CreateIdeaInput | UpdateIdeaInput>(
    idea || { ...defaultIdea }
  );
  const [taggedEmployees, setTaggedEmployees] = useState<
    EmployeeWithAvatarUrl[]
  >([]);
  const [saving, setSaving] = useState(false);
  const [savingError, setSavingError] = useState("");
  const [previewAttachments, setPreviewAttachments] = useState<
    AttachmentFile[]
  >([]);
  const [removedAttachments, setRemovedAttachments] = useState<
    AttachmentFile[]
  >([]);
  const [error, setError] = useState("");
  const [tabValue, setTabValue] = useState(0);
  const [chatDialogState, setChatDialogState] = useImmer<ChatDialogState>(
    defaultChatDialogState
  );
  const employeeContext = useEmployees();
  const employee = employeeContext?.employees?.find(
    (employee: Employee) => employee?.id === goal?.employeeGoalsId
  );
  const goals = useGoals()?.goals;
  const organization = useOrganization()?.organization;
  const northStars = useNorthStars()?.northStars;

  const currentUser = useAuthStatus();
  const memoizedAttachments = useMemo(
    () => idea?.attachments as string[],
    [idea?.attachments]
  );
  const existingAttachments = useAttachmentUrls(memoizedAttachments);
  const intl = useIntl();
  const employees = useEmployees()?.employees;

  useEffect(() => {
    (async () => {
      let info = await getGoalBackgroundInfo(
        intl,
        goal?.organizationUnitGoalsId ?? undefined,
        employee ?? undefined,
        goals,
        organization,
        northStars,
        employeeContext?.organizationUnitEmployeeJoins,
        goal
      );
      setChatDialogState((draft) => {
        draft.backgroundInfo = info.info;
        draft.hint = info.hint;
      });
    })();
    if (!idea) {
      setChatDialogState((draft) => {
        draft.question = intl.formatMessage({
          id: "chat.prefilled.question.idea",
        });
      });
    }
  }, [
    goal,
    intl,
    employee,
    goals,
    organization,
    northStars,
    employeeContext?.organizationUnitEmployeeJoins,
    idea,
    setChatDialogState
  ]);

  const resetState = () => {
    setEditIdea(idea || { ...defaultIdea });
    setTaggedEmployees([]);
    setShowHelp(false);
    setSaving(false);
    setRemovedAttachments([]);
    setPreviewAttachments([]);
    setError("");
    setSavingError("");
    setChatDialogState(defaultChatDialogState);
  };

  const handleTitleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setError("");
    setEditIdea((draft) => {
      draft.title = event.target.value;
    });
  };

  const handleDescriptionChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditIdea((draft) => {
      draft.description = event.target.value;
    });
  };

  const handleSave = async () => {
    if (!editIdea.title) {
      setError(intl.formatMessage({ id: "ideas.error.title.is.required" }));
      return;
    }
    try {
      setSaving(true);
      // Save attachments to S3
      const newAttachments = await saveAttachments(
        previewAttachments,
        AttachmentOwner.Idea
      );

      if (!idea) {
        await addIdeaDb(
          {
            ...editIdea,
            goalIdeasId: goal.id,
            creatorEmail: currentUser?.attributes.email,
            attachments: newAttachments,
          } as CreateIdeaInput,
          taggedEmployees,
          employees,
          goal.employeeGoalsId != null
        );
      } else {
        // Remove deleted attachments from S3
        const remainingAttachments = await deleteAttachments(
          removedAttachments,
          existingAttachments
        );

        await updateIdeaDb(
          {
            ...editIdea,
            attachments: remainingAttachments.concat(newAttachments),
          } as UpdateIdeaInput,
          idea,
          taggedEmployees
        );
      }

      resetState();
      onClose(idea == null);
    } catch (error: any) {
      log(`Add/Edit Idea: ${error.message}`);
      setSaving(false);
      setSavingError(intl.formatMessage({ id: "general.save.error" }));
    }
  };

  const handleCancel = () => {
    resetState();
    onClose(false);
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      fullWidth={true}
      maxWidth="lg"
      disableRestoreFocus
    >
      <DialogTabTitle
        tabValue={tabValue}
        setTabValue={setTabValue}
        dialogTitle={intl.formatMessage({
          id: idea ? "ideas.edit" : "ideas.add",
        })}
        handleToggleHelp={handleToggleHelp}
      />

      {/* Contributors */}
      <DialogContent>
        <TabPanel value={tabValue} index={0}>
          <HelpCollapse
            showHelp={showHelp}
            helpText={intl.formatMessage({ id: "ideas.help.text" })}
          />
          <TaggedEmployees
            taggedEmployees={taggedEmployees}
            currentUser={currentUser}
            employeeJoins={idea?.employeeJoins}
            employeeIdField={"employeeIdeaEmployeeJoinsId"}
            inCreate={!idea}
            setTaggedEmployees={setTaggedEmployees}
            label={getEventEmployeesTitle(intl, EventType.IDEA_ADDED)}
          />

          {/* Title */}
          <TextField
            margin="dense"
            id="title"
            sx={{ marginTop: "20px" }}
            data-cy="edit-idea-title"
            label={<FormattedMessage id="ideas.idea.title" />}
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            helperText={error}
            error={error !== ""}
            value={editIdea.title}
            onChange={handleTitleChange}
            autoFocus
          />
          <TextField
            margin="dense"
            id="Description"
            label={<FormattedMessage id="ideas.idea.description" />}
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            value={editIdea.description}
            onChange={handleDescriptionChange}
          />

          <HandleAttachments
            existingAttachments={existingAttachments}
            previewMedias={previewAttachments}
            setPreviewMedias={setPreviewAttachments}
            removedAttachments={removedAttachments}
            setRemovedAttachments={setRemovedAttachments}
          />
          {savingError && <Alert severity="error">{savingError}</Alert>}
        </TabPanel>
        <TabPanel value={tabValue} index={1}>
          <DialogChat
            chatDialogState={chatDialogState}
            setChatDialogState={setChatDialogState}
          />
        </TabPanel>
      </DialogContent>

      <EditDialogActions
        saving={saving}
        onSave={handleSave}
        onCancel={handleCancel}
      />
    </Dialog>
  );
}
