import { useState, useRef } from "react";
import { Goal, Idea } from "@/src/API";
import EditIdea from "./EditIdea";
import IdeaItem from "./IdeaItem";
import GTabPanel from "../Common/GTabPanel/GTabPanel";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import { deleteIdeaDb } from "@/lib/webIdeas";
import { AttachmentFile } from "@/lib/webAttachment";
import { FormattedMessage, useIntl } from "react-intl";
import { useEvents } from "@/contexts/EventsContext";

interface IdeasProps {
  goal?: Goal | null;
  ideas?: (Idea | null)[];
  canAdd?: boolean;
}

export default function Ideas({ goal, ideas, canAdd = true }: IdeasProps) {
  const [addIdea, setAddIdea] = useState(false);
  const [editIdea, setEditIdea] = useState<Idea | undefined>();
  const [deleteIdea, setDeleteIdea] = useState<Idea | undefined>();
  const [deleteAttachments, setDeleteAttachments] = useState<
    AttachmentFile[] | undefined
  >();
  const [saving, setSaving] = useState(false);
  const topRef = useRef<HTMLDivElement | null>(null);
  const intl = useIntl();
  const events = useEvents()?.events;

  if (goal == null && !ideas) {
    return (
      <div>
        <FormattedMessage id="ideas.error.goal.not.gound" />
      </div>
    );
  }
  const showIdeas = ideas ? ideas : goal?.ideas?.items || [];

  const resetState = () => {
    setAddIdea(false);
    setEditIdea(undefined);
    setDeleteIdea(undefined);
    setDeleteAttachments(undefined);
    setSaving(false);
  };

  const handleAdd = () => {
    setAddIdea(true);
  };

  const handleEdit = (idea: Idea) => {
    setEditIdea(idea);
  };

  const handleCloseEdit = (scrollToTop: Boolean) => {
    resetState();
    if (scrollToTop) {
      topRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleDelete = (idea: Idea, attachments?: AttachmentFile[]) => {
    setDeleteIdea(idea);
    setDeleteAttachments(attachments || []);
  };

  const handleDeleteCancel = () => {
    resetState();
  };

  const handleDeleteConfirmed = async () => {
    if (!deleteIdea) {
      return;
    }

    setSaving(true);
    await deleteIdeaDb(deleteIdea, deleteAttachments || [], events);
    resetState();
  };

  return (
    <>
      <div ref={topRef} style={{ paddingTop: "2px" }} />
      <GTabPanel onAdd={canAdd ? handleAdd : undefined}>
        {showIdeas.map((idea) => (
          <IdeaItem
            key={idea?.id || "noIdea"}
            idea={idea}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        ))}
      </GTabPanel>
      {(addIdea || !!editIdea) && (
        <EditIdea
          key={editIdea?.id || "addingIdea"}
          goal={goal!}
          idea={editIdea}
          open={addIdea || !!editIdea}
          onClose={handleCloseEdit}
        />
      )}
      {deleteIdea && (
        <ConfirmationDialog
          title={intl.formatMessage({ id: "ideas.delete.caption" })}
          message={intl.formatMessage({ id: "ideas.delete.confirmation" })}
          messageItem={deleteIdea.title || ""}
          open={!!deleteIdea}
          saving={saving}
          onCancel={handleDeleteCancel}
          onConfirm={handleDeleteConfirmed}
        />
      )}
    </>
  );
}
