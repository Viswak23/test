import { useState, useRef, useMemo } from "react";
import { HelpRequest } from "@/src/API";
import EditHelpRequest from "./EditHelpRequest";
import HelpRequestItem from "./HelpRequestItem";
import GTabPanel from "../Common/GTabPanel/GTabPanel";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import { deleteHelpRequestDb } from "@/lib/webHelpRequests";
import { AttachmentFile } from "@/lib/webAttachment";
import GExpandList from "../Common/GList/GExpandList";
import { sortCreatedAtDescending } from "@/lib/time";
import HelpRequestsExpanded from "./HelpRequestsExpanded";
import { useIntl } from "react-intl";
import { Stack } from "@mui/material";
import { useEvents } from "@/contexts/EventsContext";

interface HelpRequestsProps {
  helpRequests?: (HelpRequest | null)[];
  goalId?: string;
  notRelevantRequests?: (HelpRequest | null)[];
  showResolved?: boolean;
  canHide?: boolean;
  canAdd?: boolean;
}

export default function HelpRequests({
  helpRequests,
  goalId,
  notRelevantRequests,
  showResolved = true,
  canHide = false,
  canAdd = false,
}: HelpRequestsProps) {
  const [addHelpRequest, setAddHelpRequest] = useState(false);
  const [editHelpRequest, setEditHelpRequest] = useState<
    HelpRequest | undefined
  >();
  const [deleteHelpRequest, setDeleteHelpRequest] = useState<
    HelpRequest | undefined
  >();
  const [deleteAttachments, setDeleteAttachments] = useState<
    AttachmentFile[] | undefined
  >();
  const [saving, setSaving] = useState(false);
  const topRef = useRef<HTMLDivElement | null>(null);
  const intl = useIntl();
  const events = useEvents()?.events;

  const openHelpRequests = useMemo(
    () =>
      helpRequests
        ?.filter((hr) => !hr?.resolved)
        .sort(sortCreatedAtDescending) || [],
    [helpRequests]
  );
  const resolvedHelpRequests = useMemo(
    () => helpRequests?.filter((hr) => hr?.resolved) || [],
    [helpRequests]
  );

  const resetState = () => {
    setAddHelpRequest(false);
    setEditHelpRequest(undefined);
    setDeleteHelpRequest(undefined);
    setDeleteAttachments(undefined);
    setSaving(false);
  };

  const handleAdd = () => {
    setAddHelpRequest(true);
  };

  const handleEdit = (helpRequest: HelpRequest) => {
    setEditHelpRequest(helpRequest);
  };

  const handleCloseEdit = (scrollToTop: Boolean) => {
    resetState();
    if (scrollToTop) {
      topRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleDelete = (
    helpRequest: HelpRequest,
    attachments?: AttachmentFile[]
  ) => {
    setDeleteHelpRequest(helpRequest);
    setDeleteAttachments(attachments || []);
  };

  const handleDeleteCancel = () => {
    resetState();
  };

  const handleDeleteConfirmed = async () => {
    if (!deleteHelpRequest) {
      return;
    }

    setSaving(true);
    await deleteHelpRequestDb(
      deleteHelpRequest,
      deleteAttachments || [],
      events
    );
    resetState();
  };

  return (
    <>
      <div ref={topRef} style={{ paddingTop: "2px" }} />
      <Stack>
        <GTabPanel onAdd={canAdd ? handleAdd : undefined}>
          {openHelpRequests?.map((helpRequest) => (
            <HelpRequestItem
              key={helpRequest?.id || "noHelpRequest"}
              helpRequest={helpRequest}
              canHide={canHide}
              onEdit={handleEdit}
              onDelete={handleDelete}
            />
          ))}
        </GTabPanel>

        {showResolved && (
          <HelpRequestsExpanded
            title={intl.formatMessage({
              id: "helprequests.resolved.helprequests",
            })}
            helpRequests={resolvedHelpRequests}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        )}
        {notRelevantRequests && (
          <GExpandList
            title={intl.formatMessage(
              { id: "helprequests.not.relevant.with.count" },
              { count: notRelevantRequests?.length || 0 }
            )}
          >
            {notRelevantRequests?.map((helpRequest) => (
              <HelpRequestItem
                key={helpRequest?.id || "noRelevantHelpRequest"}
                helpRequest={helpRequest}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))}
          </GExpandList>
        )}
        {(addHelpRequest || !!editHelpRequest) && (
          <EditHelpRequest
            key={editHelpRequest?.id || "addingHelpRequest"}
            goalId={
              editHelpRequest
                ? editHelpRequest.goalHelpRequestsId || goalId
                : goalId
            }
            helpRequest={editHelpRequest}
            open={addHelpRequest || !!editHelpRequest}
            onClose={handleCloseEdit}
          />
        )}
        {deleteHelpRequest && (
          <ConfirmationDialog
            title={intl.formatMessage({ id: "helprequests.delete.caption" })}
            message={intl.formatMessage({
              id: "helprequests.delete.confirmation",
            })}
            messageItem={deleteHelpRequest.title || ""}
            open={!!deleteHelpRequest}
            saving={saving}
            onCancel={handleDeleteCancel}
            onConfirm={handleDeleteConfirmed}
          />
        )}
      </Stack>
    </>
  );
}
