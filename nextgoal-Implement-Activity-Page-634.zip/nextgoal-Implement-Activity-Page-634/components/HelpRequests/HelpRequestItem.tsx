import { useMemo, useState } from "react";
import { calculateDaysOfStatus } from "@/lib/time";
import { HelpRequest } from "@/src/API";
import { AttachmentFile, useAttachmentUrls } from "@/lib/webAttachment";
import FeedItem from "../Feeds/FeedItem";
import { EventType, getEventEmployeesTitle } from "@/lib/webEvents";
import HelpRequestFeedDescription from "./HelpRequestFeedDescription";
import { IconButton, Tooltip } from "@mui/material";
import { HideImage } from "@mui/icons-material";
import { useAuthContext } from "@/contexts/AuthContext";
import { updateHelpRequestDb } from "@/lib/webHelpRequests";
import SavingBackdrop from "../Common/SavingBackdrop/SavingBackdrop";
import { canDeleteDbItem } from "@/lib/webHelpers";
import { FormattedMessage, useIntl } from "react-intl";
import { log } from "@/lib/backend/actions/logger";
import ErrorSnackbar from "../Common/Message/ErrorSnackbar";
import { hoverMainToPressed } from "@/config/styling";
import theme from "@/config/theme";
import { useEmployees } from "@/contexts/EmployeesContext";

interface HelpRequestItemProps {
  helpRequest?: HelpRequest | null;
  canHide?: boolean;
  onEdit?: (helpRequest: HelpRequest) => void;
  onDelete?: (helpRequest: HelpRequest, attachments: AttachmentFile[]) => void;
}

export default function HelpRequestItem({
  helpRequest,
  canHide = false,
  onEdit,
  onDelete,
}: HelpRequestItemProps) {
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<any>(null);
  const authUser = useAuthContext()?.currentUser;
  const rawAtachments = useMemo(
    () => (helpRequest ? (helpRequest?.attachments as string[]) : []),
    [helpRequest]
  );
  const attachments = useAttachmentUrls(rawAtachments as string[]);
  const intl = useIntl();
  const employees = useEmployees()?.employees;
  const hideHelpRequest = intl.formatMessage({
    id: "helprequests.hide.helprequest",
  });

  if (!helpRequest) {
    return null;
  }

  const handleEdit = () => {
    if (onEdit && helpRequest) {
      onEdit(helpRequest);
    }
  };

  const handleDelete = () => {
    if (onDelete) {
      onDelete(helpRequest, attachments);
    }
  };

  const handleHideFromUser = async (helpRequest: HelpRequest) => {
    const notRelevantForEmployees = [
      ...(helpRequest?.notRelevantForEmployees || []),
      authUser.attributes.email,
    ];
    setSaving(true);
    try {
      await updateHelpRequestDb(
        {
          id: helpRequest.id,
          notRelevantForEmployees,
        },
        false,
        employees
      );
    } catch (error: any) {
      log(`Update HelpRequest: ${error.message}`);
      setError(intl.formatMessage({ id: "general.save.error" }));
    }
    setSaving(false);
  };

  if (!helpRequest) {
    return null;
  }

  const timeSince = calculateDaysOfStatus(intl, helpRequest.createdAt);
  const hideItem = (
    <IconButton
      aria-label={hideHelpRequest}
      onClick={() => handleHideFromUser(helpRequest)}
      sx={{ ...hoverMainToPressed(theme), bottom: "3px" }}
    >
      <Tooltip title={<FormattedMessage id="helprequests.not.relevant" />}>
        <HideImage />
      </Tooltip>
    </IconButton>
  );

  return (
    <>
      {saving && <SavingBackdrop open={saving} />}
      <FeedItem
        title={helpRequest.title || ""}
        subheader={timeSince}
        description={<HelpRequestFeedDescription helpRequest={helpRequest} />}
        creatorEmail={helpRequest.creatorEmail}
        comments={helpRequest.comments?.items}
        attachments={attachments}
        taggedEmployeeJoins={helpRequest.employeeJoins}
        employeeIdField={"employeeHelpRequestEmployeeJoinsId"}
        taggedEmployeesTitle={getEventEmployeesTitle(
          intl,
          EventType.HELP_REQUEST_ADDED
        )}
        currentGoalId={helpRequest.goalHelpRequestsId!}
        helpRequestId={helpRequest.id}
        additionalFunction={canHide ? hideItem : undefined}
        onEdit={onEdit ? handleEdit : undefined}
        onDelete={onDelete ? handleDelete : undefined}
        deleteDisabled={!canDeleteDbItem(helpRequest)}
        tooltips={{
          editTooltip: intl.formatMessage({ id: "helprequests.edit" }),
          deleteTooltip: intl.formatMessage({
            id: "helprequests.delete.caption",
          }),
          deleteDisabledTooltip: intl.formatMessage({
            id: "helprequests.delete.disabled.tooltip",
          }),
        }}
      />
      <ErrorSnackbar
        error={error}
        setError={(message) => {
          setError(message);
        }}
      />
    </>
  );
}
