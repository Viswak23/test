import { HelpRequest } from "@/src/API";
import GExpandList from "../Common/GList/GExpandList";
import HelpRequestItem from "./HelpRequestItem";
import { AttachmentFile } from "@/lib/webAttachment";
import { Stack } from "@mui/material";

interface HelpRequestsExpandedProps {
  helpRequests?: (HelpRequest | null)[];
  title: string;
  onEdit?: (helpRequest: HelpRequest) => void;
  onDelete?: (helpRequest: HelpRequest, attachments?: AttachmentFile[]) => void;
}

export default function HelpRequestsExpanded({
  helpRequests,
  title,
  onEdit,
  onDelete,
}: HelpRequestsExpandedProps) {
  return (
    <GExpandList title={`${title} (${helpRequests?.length || 0})`}>
      {helpRequests?.map((helpRequest) => (
        <HelpRequestItem
          key={helpRequest?.id || "noResolvedHelpRequest"}
          helpRequest={helpRequest}
          onEdit={onEdit}
          onDelete={onDelete}
        />
      ))}
    </GExpandList>
  );
}
