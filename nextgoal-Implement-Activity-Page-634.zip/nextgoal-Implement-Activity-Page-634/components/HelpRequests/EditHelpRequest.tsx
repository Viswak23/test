import { useState, useMemo, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import TextField from "@mui/material/TextField";
import {
  HelpRequest,
  CreateHelpRequestInput,
  UpdateHelpRequestInput,
} from "@/src/API";
import { useImmer } from "use-immer";
import { Alert, Checkbox, FormControlLabel } from "@mui/material";
import { useAuthStatus } from "@/lib/customHooks";
import {
  EmployeeWithAvatarUrl,
  useEmployees,
} from "@/contexts/EmployeesContext";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import HandleAttachments from "../Common/Attachment/HandleAttachments";
import {
  AttachmentFile,
  AttachmentOwner,
  deleteAttachments,
  saveAttachments,
  useAttachmentUrls,
} from "@/lib/webAttachment";
import TaggedEmployees from "../Common/TaggedEmployees/TaggedEmployees";
import { addHelpRequestDb, updateHelpRequestDb } from "@/lib/webHelpRequests";
import { getCurrentTimestamp } from "@/lib/time";
import { EventType, getEventEmployeesTitle } from "@/lib/webEvents";
import { FormattedMessage, useIntl } from "react-intl";
import { useGoals } from "@/contexts/GoalsContext";
import { isEmployeeGoal } from "@/lib/webEmployee";
import { log } from "@/lib/backend/actions/logger";
import HelpCollapse from "../Common/Dialog/HelpCollapse";
import DialogTabTitle from "../Common/Dialog/DialogTabTitle";
import {
  ChatDialogState,
  defaultChatDialogState,
} from "../Chat/ChatDialogState";
import { useOrganization } from "@/contexts/OrganizationContext";
import { useNorthStars } from "@/contexts/NorthStarsContext";
import { TabPanel } from "../Settings/TabPanel";
import DialogChat from "../Chat/ChatInDialog";
import { getGoalBackgroundInfo } from "@/lib/webGoals";

interface EditHelpRequestProps {
  goalId?: string | null;
  helpRequest?: HelpRequest;
  open: boolean;
  onClose: (scrollToTop: Boolean) => void;
}

const defaultHelp = {
  title: "",
  description: "",
  resolved: false,
  resolvedComment: "",
  companyId: "placeholder",
  creatorEmail: "placeholder",
  reopenedComment: "",
};

export default function EditHelpRequest({
  goalId,
  helpRequest,
  open,
  onClose,
}: EditHelpRequestProps) {
  const [showHelp, setShowHelp] = useState(false);
  const [editHelpRequest, setEditHelpRequest] = useImmer<
    CreateHelpRequestInput | UpdateHelpRequestInput
  >(helpRequest || { ...defaultHelp });
  const [taggedEmployees, setTaggedEmployees] = useState<
    EmployeeWithAvatarUrl[]
  >([]);
  const [saving, setSaving] = useState(false);
  const [savingError, setSavingError] = useState("");
  const [previewAttachments, setPreviewAttachments] = useState<
    AttachmentFile[]
  >([]);
  const [removedAttachments, setRemovedAttachments] = useState<
    AttachmentFile[]
  >([]);
  const [error, setError] = useState("");
  const { goals: fetchedGoals } = useGoals()!;
  const goals = useMemo(() => fetchedGoals || [], [fetchedGoals]);  const employees = useEmployees();
  const [tabValue, setTabValue] = useState(0);
  const [chatDialogState, setChatDialogState] = useImmer<ChatDialogState>(
    defaultChatDialogState
  );
  const organization = useOrganization()?.organization;
  const northStars = useNorthStars()?.northStars;
  const currentGoal = goals.find((goal) => goal.id === goalId);
  const employee = employees?.employees?.find(
    (employee) => employee?.id === currentGoal?.employeeGoalsId
  );

  const currentUser = useAuthStatus();
  const memoizedAttachments = useMemo(
    () => helpRequest?.attachments as string[],
    [helpRequest?.attachments]
  );
  const existingAttachments = useAttachmentUrls(memoizedAttachments);
  const intl = useIntl();

  useEffect(() => {
    (async () => {
      let info = await getGoalBackgroundInfo(
        intl,
        currentGoal?.organizationUnitGoalsId ?? undefined,
        employee ?? undefined,
        goals,
        organization,
        northStars,
        employees?.organizationUnitEmployeeJoins,
        currentGoal
      );
      setChatDialogState((draft) => {
        draft.backgroundInfo = info.info;
        draft.hint = info.hint;
      });
    })();
    if (!helpRequest) {
      setChatDialogState((draft) => {
        draft.question = intl.formatMessage({
          id: "chat.prefilled.question.help.request",
        });
      });
    }
  }, [
    currentGoal,
    intl,
    currentGoal?.organizationUnitGoalsId,
    employee,
    goals,
    organization,
    northStars,
    employees?.organizationUnitEmployeeJoins,
    helpRequest,
    setChatDialogState
  ]);

  const resetState = () => {
    setEditHelpRequest(helpRequest || { ...defaultHelp });
    setTaggedEmployees([]);
    setShowHelp(false);
    setSaving(false);
    setRemovedAttachments([]);
    setPreviewAttachments([]);
    setError("");
    setSavingError("");
  };

  const handleTitleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setError("");
    setEditHelpRequest((draft) => {
      draft.title = event.target.value;
    });
  };

  const handleDescriptionChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditHelpRequest((draft) => {
      draft.description = event.target.value;
    });
  };

  const handleResolvedChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setEditHelpRequest((draft) => {
      draft.resolved = event.target.checked;
    });
  };

  const handleResolvedCommentChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditHelpRequest((draft) => {
      draft.resolvedComment = event.target.value;
    });
  };

  const handleReopenedCommentChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditHelpRequest((draft) => {
      draft.reopenedComment = event.target.value;
    });
  };

  const handleSave = async () => {
    if (!editHelpRequest.title) {
      setError(intl.formatMessage({ id: "helprequests.error.title.required" }));
      return;
    }
    try {
      setSaving(true);
      // Save attachments to S3
      const newAttachments = await saveAttachments(
        previewAttachments,
        AttachmentOwner.HelpRequest
      );

      const employeeGoal = isEmployeeGoal(goals, goalId);
      if (!helpRequest) {
        await addHelpRequestDb(
          {
            ...editHelpRequest,
            goalHelpRequestsId: goalId,
            creatorEmail: currentUser?.attributes.email,
            attachments: newAttachments,
          } as CreateHelpRequestInput,
          taggedEmployees,
          employees?.employees,
          employeeGoal
        );
      } else {
        // Remove deleted attachments from S3
        const remainingAttachments = await deleteAttachments(
          removedAttachments,
          existingAttachments
        );

        const updateObject = {
          ...editHelpRequest,
          attachments: remainingAttachments.concat(newAttachments),
        } as UpdateHelpRequestInput;

        // Check if resolved by has been changed and save the resolver or reopener
        if (editHelpRequest.resolved && !helpRequest.resolved) {
          updateObject.resolvedBy = currentUser?.attributes.email;
          updateObject.resolvedTime = getCurrentTimestamp();
        } else if (!editHelpRequest.resolved && helpRequest.resolved) {
          updateObject.reopenedBy = currentUser?.attributes.email;
          updateObject.reopenedTime = getCurrentTimestamp();
        }
        await updateHelpRequestDb(
          updateObject,
          employeeGoal,
          employees?.employees,
          helpRequest,
          taggedEmployees
        );
      }

      resetState();
      onClose(helpRequest == null);
    } catch (error: any) {
      log(`Add/Update HelpRequest: ${error.message}`);
      setSaving(false);
      setSavingError(intl.formatMessage({ id: "general.save.error" }));
    }
  };

  const handleCancel = () => {
    resetState();
    onClose(false);
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  const reopenedCommentEnabled =
    !editHelpRequest.resolved && helpRequest?.resolvedTime != null;

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      fullWidth={true}
      maxWidth="lg"
      disableRestoreFocus
    >
      <DialogTabTitle
        tabValue={tabValue}
        setTabValue={setTabValue}
        dialogTitle={intl.formatMessage({
          id: helpRequest ? "helprequests.edit" : "helprequests.add",
        })}
        handleToggleHelp={handleToggleHelp}
      />
      <DialogContent>
        <TabPanel value={tabValue} index={0}>
          <HelpCollapse
            showHelp={showHelp}
            helpText={intl.formatMessage({ id: "helprequests.help.text" })}
          />
          <TextField
            margin="dense"
            id="title"
            data-cy="edit-help-request-title"
            label={<FormattedMessage id="helprequests.helprequest.title" />}
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            autoFocus
            helperText={error}
            error={error !== ""}
            value={editHelpRequest.title}
            onChange={handleTitleChange}
          />
          <TextField
            margin="dense"
            id="Description"
            label={
              <FormattedMessage id="helprequests.helprequest.description" />
            }
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            multiline
            value={editHelpRequest.description}
            onChange={handleDescriptionChange}
          />
          <TaggedEmployees
            taggedEmployees={taggedEmployees}
            currentUser={currentUser}
            employeeJoins={helpRequest?.employeeJoins}
            employeeIdField={"employeeHelpRequestEmployeeJoinsId"}
            inCreate={!helpRequest}
            addCurrentEmployee={false}
            setTaggedEmployees={setTaggedEmployees}
            label={getEventEmployeesTitle(intl, EventType.HELP_REQUEST_ADDED)}
          />
          <FormControlLabel
            value={editHelpRequest.resolved}
            label={<FormattedMessage id="helprequests.helprequest.resolved" />}
            labelPlacement="start"
            control={
              <Checkbox
                checked={editHelpRequest.resolved === true}
                onChange={handleResolvedChange}
              />
            }
          />
          <TextField
            margin="dense"
            id="resolvedComment"
            label={
              <FormattedMessage id="helprequests.helprequest.resolved.comment" />
            }
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            value={editHelpRequest.resolvedComment || ""}
            disabled={!editHelpRequest.resolved}
            onChange={handleResolvedCommentChange}
          />
          <TextField
            margin="dense"
            id="reopenedComment"
            label={
              <FormattedMessage id="helprequests.helprequest.reopened.comment" />
            }
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            disabled={!reopenedCommentEnabled}
            value={editHelpRequest.reopenedComment || ""}
            onChange={handleReopenedCommentChange}
          />
          <HandleAttachments
            existingAttachments={existingAttachments}
            previewMedias={previewAttachments}
            setPreviewMedias={setPreviewAttachments}
            removedAttachments={removedAttachments}
            setRemovedAttachments={setRemovedAttachments}
          />
          {savingError && <Alert severity="error">{savingError}</Alert>}
        </TabPanel>
        <TabPanel value={tabValue} index={1}>
          <DialogChat
            chatDialogState={chatDialogState}
            setChatDialogState={setChatDialogState}
          />
        </TabPanel>
      </DialogContent>
      <EditDialogActions
        saving={saving}
        onSave={handleSave}
        onCancel={handleCancel}
      />
    </Dialog>
  );
}
