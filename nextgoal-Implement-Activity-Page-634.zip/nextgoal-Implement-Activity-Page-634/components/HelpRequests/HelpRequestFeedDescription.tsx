import { HelpRequest } from "@/src/API";
import { Stack } from "@mui/material";
import {
  DetailsLabel,
  DetailsText,
  FeedTitle,
  ListText,
} from "../Common/Texts/Texts";
import { showDate } from "@/lib/time";
import { getEmployeeByEmail } from "@/lib/webEmployee";
import { useEmployees } from "@/contexts/EmployeesContext";
import { FormattedMessage, useIntl } from "react-intl";
import { useSettings } from "@/contexts/SettingsInfo";

interface HelpRequestFeedDescriptionProps {
  helpRequest?: HelpRequest | null;
  resolvedEvent?: boolean;
  reopenedEvent?: boolean;
}

export default function HelpRequestFeedDescription({
  helpRequest,
  resolvedEvent = false,
  reopenedEvent = false,
}: HelpRequestFeedDescriptionProps) {
  const employees = useEmployees()?.employees;
  const intl = useIntl();
  const resolver = getEmployeeByEmail(employees, helpRequest?.resolvedBy);
  const reopener = getEmployeeByEmail(employees, helpRequest?.reopenedBy);
  const dbUser = useSettings()?.dbUser;

  return (
    <Stack direction="column" spacing={0}>
      {helpRequest?.title && <FeedTitle>{helpRequest.title}</FeedTitle>}
      <ListText>{helpRequest?.description}</ListText>

      {(resolvedEvent || (!reopenedEvent && helpRequest?.resolved)) && (
        <>
          <Stack direction="row" spacing={1} style={{ marginTop: "12px" }}>
            <DetailsLabel>
              <FormattedMessage id="helprequests.helprequest.resolved" />
            </DetailsLabel>
            <DetailsText>
              {showDate(helpRequest?.resolvedTime, dbUser)} (
              {resolver?.name || helpRequest?.resolvedBy})
            </DetailsText>
          </Stack>
          <Stack direction="row" spacing={1}>
            <DetailsLabel>
              <FormattedMessage id="helprequests.helprequest.resolved.comment" />
            </DetailsLabel>
            <ListText>{helpRequest?.resolvedComment}</ListText>
          </Stack>
        </>
      )}
      {(reopenedEvent ||
        (!resolvedEvent &&
          !helpRequest?.resolved &&
          helpRequest?.reopenedTime)) && (
        <>
          <Stack direction="row" spacing={1} style={{ marginTop: "12px" }}>
            <DetailsLabel>
              <FormattedMessage id="helprequests.helprequest.reopened" />
            </DetailsLabel>
            <DetailsText>
              {showDate(helpRequest?.reopenedTime, dbUser)} (
              {reopener?.name || helpRequest?.reopenedBy})
            </DetailsText>
          </Stack>
          <Stack direction="row" spacing={1}>
            <DetailsLabel>
              <FormattedMessage id="helprequests.helprequest.reopened.comment" />
            </DetailsLabel>
            <ListText>{helpRequest?.reopenedComment}</ListText>
          </Stack>
        </>
      )}
    </Stack>
  );
}
