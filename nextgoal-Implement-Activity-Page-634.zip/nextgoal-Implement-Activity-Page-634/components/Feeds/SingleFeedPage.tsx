"use client";
import { useEffect } from "react";

import { Event } from "@/src/API";
import { useEventsDispatch } from "@/contexts/EventsContext";
import PageLoading from "../Common/Loading/PageLoading";
import EventPage from "./EventPage";

export default function SingleFeedPage({ event }: { event: Event }) {
  const eventsDispatch = useEventsDispatch()!;

  useEffect(() => {
    if (event) {
      eventsDispatch({
        type: "addCurrentEvent",
        currentEvent: event,
      });
    }
  }, [eventsDispatch, event]);

  if (!event) {
    return <PageLoading />;
  }

  return <EventPage />;
}