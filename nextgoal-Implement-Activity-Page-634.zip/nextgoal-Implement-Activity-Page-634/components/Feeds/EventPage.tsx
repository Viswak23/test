import React, { useMemo } from "react";
import { FormattedMessage } from "react-intl";
import ScrollBackUpButton from "../Common/Buttons/ScrollBackUpButton";
import PageBackgroundPaper from "../Common/Layout/PageBackgroundPaper";
import { HeadingMain } from "../Common/Texts/Texts";
import { EventFeedItem } from "./EventFeedItem";
import { useEvents } from "@/contexts/EventsContext";
import PageLoading from "../Common/Loading/PageLoading";
import {
  getAllEventsForGoal,
  getOrganizationEvents,
  hydrateEvent,
  hydrateEvents,
} from "@/lib/webEvents";
import { useGoals } from "@/contexts/GoalsContext";

export default function EventPage() {
  const event = useEvents()?.currentEvent;

  const openGoals = useGoals()?.goals;
  const archivedGoals = useGoals()?.archivedGoals;

  const goalEvent = useMemo(() => {
    const goals = [...openGoals!, ...archivedGoals!];

    if (!event || !goals) return null;
    return hydrateEvent(event, goals);
  }, [event, openGoals, archivedGoals]);

  if (!goalEvent) return <PageLoading />;
  return (
    <PageBackgroundPaper dataCy="single-feed-page">
      <HeadingMain>
        <FormattedMessage id="feeds.title" />
      </HeadingMain>
      <EventFeedItem event={goalEvent} />
      <ScrollBackUpButton />
    </PageBackgroundPaper>
  );
}