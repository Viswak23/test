import React from "react";
import { Stack, Theme, useMediaQuery } from "@mui/material";
import { Employee } from "@/src/API"; // Adjust the import based on where Employee is defined
import { FeedDaysAgoTxt, FeedEmployeeNameTxt } from "../Common/Texts/Texts";
import GridItem from "../Common/Layout/GridItem";
import { FormattedMessage } from "react-intl";

interface FeedSubtitleProps {
  subheader?: string;
  employee?: Employee | null;
}

const FeedSubtitle = ({ subheader, employee }: FeedSubtitleProps) => {
  return (
    <>
      <Stack
        direction={{ xs: "column", sm: "row" }}
        spacing={1}
        sx={{
          marginTop: {
            xs: "7px",
            sm: "5px",
          },
          marginBottom: "0px",
          paddingBottom: "4px",
        }}
      >
        {employee?.name && (
          <FeedEmployeeNameTxt>{employee.name}</FeedEmployeeNameTxt>
        )}

        {/* Days ago label  */}
        <FeedDaysAgoTxt>{subheader}</FeedDaysAgoTxt>
      </Stack>
    </>
  );
};

export default FeedSubtitle;