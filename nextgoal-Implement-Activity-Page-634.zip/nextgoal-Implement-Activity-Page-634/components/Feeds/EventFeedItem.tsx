import { useMemo } from "react";
import { useAttachmentUrls } from "@/lib/webAttachment";
import {
  getEventInfo,
  getEventEmployeeJoinIdField,
  getEventEmployeesTitle,
  EventType,
} from "@/lib/webEvents";
import { Event } from "@/src/API";
import FeedItem from "./FeedItem";
import { calculateDaysOfStatus } from "@/lib/time";
import { useIntl } from "react-intl";

export interface EventFeedItemProps {
  event: Event;
}

export function EventFeedItem({ event }: EventFeedItemProps) {
  const intl = useIntl();
  const eventInfo = useMemo(() => {
    const info = getEventInfo(intl, event);
    return info;
  }, [event, intl]);

  const attachments = useAttachmentUrls(eventInfo.attachments);

  if (!event.goal?.id) {
    return null;
  }

  // Every event has a goal, so we must check event type to check if the feed is ADD_GOAL event and thus add goalId to the feed item.
  // This is needed to bind comments and likes to goal feed item.
  const goalId = [
    EventType.GOAL_ADDED,
    EventType.GOAL_CLOSED,
    EventType.GOAL_OPENED,
  ].includes(event.eventType as EventType)
    ? event?.goalEventsId
    : undefined;
  return (
    <FeedItem
      event={event}
      comments={eventInfo.comments}
      creatorEmail={eventInfo.employeeEmail}
      title={eventInfo.title}
      discussionTitle={eventInfo.discussionTitle}
      subheader={calculateDaysOfStatus(intl, event?.createdAt)}
      description={eventInfo.description}
      taggedEmployeeJoins={eventInfo.employeeJoins}
      taggedEmployeesTitle={getEventEmployeesTitle(intl, event.eventType)}
      employeeIdField={getEventEmployeeJoinIdField(event)}
      attachments={attachments}
      currentGoalId={event.goal?.id}
      goalId={goalId}
      keyResultId={event.keyResultEventsId}
      statusId={event.eventStatusId}
      ideaId={event.eventIdeaId}
      redFlagId={event.redFlagEventsId}
      successStoryId={event.eventSuccessStoryId}
      contributionId={event.eventContributionId}
      helpRequestId={event.eventHelpRequestId}
      keyResultUpdateId={event.eventKeyResultUpdateId}
      goal={event.goal}
    />
  );
}