import { useState, ReactNode, useMemo } from "react";
import { Comment, Event, Goal } from "@/src/API";
import BreadCrumbList from "@/components/Common/Breadcrumb/BreadcrumbList";
import {
  Avatar,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  Collapse,
  Tooltip,
  Link as MUILink,
  Stack,
  useTheme,
  Divider,
  Box,
} from "@mui/material";
import Link from "next/link";
import { useEmployees } from "@/contexts/EmployeesContext";
import ExpandMore from "../Common/ExpandMore/ExpandMore";
import { AttachmentFile } from "@/lib/webAttachment";
import AttachmentList from "../Common/Attachment/AttachmentList";
import {
  EmployeeJoinConnection,
  getEmployeeByEmail,
  useTaggedEmployeesFromJoin,
} from "@/lib/webEmployee";
import FeedTitle from "./FeedTitle";
import Likes from "../Common/Likes/Likes";
import ShowLikes from "../Common/Likes/ShowLikes";
import DeleteButton from "../Common/Buttons/DeleteButton";
import { FormattedMessage, useIntl } from "react-intl";
import { getLinkWithLocale } from "@/lib/localisation";
import FeedSubtitle from "./FeedSubtitle";
import SubItemComments from "../Comments/SubitemComments";
import { hoverLighterToSecondary } from "@/config/styling";
import EditButton from "../Common/Buttons/EditButton";
import AddCommentButton from "../Common/Buttons/AddCommentButton";

export interface FeedItemTooptips {
  deleteTooltip?: string;
  deleteDisabledTooltip?: string;
  editTooltip?: string;
}

export interface FeedItemProps {
  event?: Event;
  title: string;
  discussionTitle?: string;
  subheader?: string;
  description?: string | ReactNode;
  creatorEmail?: string | null; // If creator is not available anymore, show email.
  taggedEmployeeJoins?: EmployeeJoinConnection;
  taggedEmployeesTitle?: string;
  employeeIdField?: string;
  attachments?: AttachmentFile[];
  comments?: (Comment | null)[];
  currentGoalId?: string;
  goalId?: string | null; // This is set when the event is ADD_GOAL.
  keyResultId?: string | null;
  statusId?: string | null;
  ideaId?: string | null;
  redFlagId?: string | null;
  successStoryId?: string | null;
  contributionId?: string | null;
  helpRequestId?: string | null;
  keyResultUpdateId?: string | null;
  goal?: Goal | null; // Used in KeyResults graph.
  additionalFunction?: ReactNode;
  deleteDisabled?: boolean;
  tooltips?: FeedItemTooptips;
  onEdit?: () => void;
  onDelete?: () => void;
}

export default function FeedItem({
  event,
  comments,
  discussionTitle,
  creatorEmail,
  title,
  subheader,
  description,
  taggedEmployeeJoins,
  taggedEmployeesTitle,
  employeeIdField,
  attachments,
  currentGoalId,
  goalId,
  keyResultId,
  statusId,
  ideaId,
  redFlagId,
  successStoryId,
  contributionId,
  helpRequestId,
  keyResultUpdateId,
  goal,
  additionalFunction,
  deleteDisabled,
  tooltips,
  onEdit,
  onDelete,
}: FeedItemProps) {
  const [expanded, setExpanded] = useState(false);
  const [addingComment, setAddingComment] = useState(false);
  const employees = useEmployees()?.employees;
  const employee = useMemo(
    () => getEmployeeByEmail(employees, creatorEmail),
    [employees, creatorEmail]
  );
  const theme = useTheme();
  const intl = useIntl();

  const taggedEmployees = useTaggedEmployeesFromJoin(
    employees,
    taggedEmployeeJoins,
    employeeIdField || ""
  );

  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  const handleAddComment = () => {
    setExpanded(true);
    setAddingComment(true);
  };

  const handleCloseAddComment = (saved: boolean) => {
    if (!saved && (comments?.length || 0) === 0) {
      setExpanded(false);
    }
    setAddingComment(false);
  };

  const commentsTitle = discussionTitle ? (
    <FormattedMessage
      id="comment.with.discussion.title.count"
      values={{
        discussionTitle,
        count: comments?.length || 0,
      }}
    />
  ) : (
    <FormattedMessage
      id="comment.count"
      values={{
        count: comments?.length || 0,
      }}
    />
  );
  const showMore = intl.formatMessage({ id: "general.show.more" });
  const cardStyles = {
    boxShadow:
      "rgba(0, 0, 0, 0.07) 0px 1px 1px, rgba(0, 0, 0, 0.07) 0px 2px 2px, rgba(0, 0, 0, 0.07) 0px 4px 4px, rgba(0, 0, 0, 0.07) 0px 8px 8px, rgba(0, 0, 0, 0.07) 0px 16px 16px",
  };

  const borderStyle = `0.2px solid ${theme.palette.customColors.chick}`;

  const avatarStyle = {
    width: "50px",
    height: "50px",
    border: borderStyle,
  };

  return (
    <Box
      sx={{
        marginBottom: "20px",
      }}
    >
      <Card
        style={cardStyles}
        data-cy="feed-item"
        sx={{ wordBreak: "break-word" }} //this will not let the text overflow out of its container
      >
        {/* Colored header  */}
        <div
          style={{
            backgroundColor: theme.palette.customColors?.lightest,
            color: theme.palette.customColors?.night,
          }}
        >
          <CardHeader
            style={{ padding: "15px" }}
            avatar={
              <Tooltip title={employee?.name || creatorEmail}>
                {employee?.email ? (
                  <MUILink
                    href={getLinkWithLocale(
                      "/employees/" + employee?.email,
                      intl.locale
                    )}
                    locale={intl.locale}
                    data-cy={`employee-link-${employee?.name}`}
                    component={Link}
                  >
                    <Avatar
                      src={employee?.resolvedAvatarUrl}
                      style={avatarStyle}
                    />
                  </MUILink>
                ) : (
                  <Avatar style={avatarStyle} />
                )}
              </Tooltip>
            }
            // title & tagged employees
            title={
              <FeedTitle
                title={title}
                taggedEmployees={taggedEmployees}
                taggedEmployeesTitle={taggedEmployeesTitle}
              />
            }
            // name & days ago label
            subheader={
              <FeedSubtitle subheader={subheader} employee={employee} />
            }
            action={
              <>
                <Stack direction={{ xs: "column", sm: "row" }}>
                  {/* Edit btn */}
                  {!!onEdit && (
                    <EditButton
                      onClick={onEdit}
                      tooltip={tooltips?.editTooltip}
                      dataCy="feed-item-edit"
                    />
                  )}
                  {/* Delete btn */}
                  {onDelete && (
                    <DeleteButton
                      disabled={deleteDisabled}
                      onClick={onDelete}
                      tooltip={tooltips?.deleteTooltip}
                      disabledTooltip={tooltips?.deleteDisabledTooltip}
                    />
                  )}
                  {additionalFunction}
                </Stack>
              </>
            }
          />
        </div>
        <CardContent>
          {/* User's comment & its title */}
          <Box
            sx={{
              padding: "7px 5px 10px 5px",
              width: "100%",
            }}
          >
            {description}
          </Box>

          <AttachmentList attachments={attachments} />
          <BreadCrumbList
            showMainPage={false}
            showLastAsaLink
            currentGoalId={currentGoalId}
          />
        </CardContent>

        <Divider
          variant="middle"
          aria-hidden="true"
          sx={{
            backgroundColor: theme.palette.customColors?.chick,
            opacity: 0.5,
          }}
        />

        <CardActions disableSpacing data-cy="feed-item-actions">
          <Stack
            direction="row"
            spacing={{
              xs: 1,
              sm: 12,
            }}
            alignItems="center"
          >
            {event && <Likes event={event} taggedEmployees={taggedEmployees} />}

            <Box style={{ margin: "10px" }}>
              <Stack
                direction={{ xs: "column", sm: "row" }}
                spacing={1}
                alignItems="center"
                sx={{
                  justifyContent: {
                    xs: "center",
                    sm: "flex-start",
                  },
                  padding: {
                    xs: "24px 0px 12x 0px",
                    sm: "5px 0px 5px 20px",
                  },
                }}
              >
                {/* Add comment btn */}
                <AddCommentButton
                  onClick={handleAddComment}
                  disabled={addingComment}
                  dataCy="feed-item-add-comment"
                />

                {/* Comment amount */}
                <span>{commentsTitle}</span>
              </Stack>
            </Box>
          </Stack>

          {/* Toggle (subcomments) btn */}
          <Stack
            direction="row"
            sx={{
              paddingLeft: {
                xs: "10px",
                sm: "0px",
              },
            }}
          >
            <ExpandMore
              expand={expanded}
              onClick={handleExpandClick}
              aria-expanded={expanded}
              aria-label={showMore}
              sx={{ ...hoverLighterToSecondary(theme) }}
              data-cy="feed-item-expand-comments"
              expandedTooltip={<FormattedMessage id="comment.hide" />}
              collapsedTooltip={
                <FormattedMessage
                  id="comment.show"
                  values={{ count: comments?.length || 0 }}
                />
              }
            />
          </Stack>
        </CardActions>
        <Divider
          variant="fullWidth"
          sx={{
            backgroundColor: theme.palette.customColors?.lighter,
            opacity: 0.2,
          }}
        />
        <Collapse
          in={expanded}
          timeout="auto"
          unmountOnExit
          data-cy="feed-item-comments"
        >
          <CardContent>
            {event && <ShowLikes likes={event?.likes} />}
            <SubItemComments
              comments={comments}
              parentGoalId={currentGoalId}
              addingComment={addingComment}
              onCloseAddComment={handleCloseAddComment}
              goalId={goalId}
              keyResultId={keyResultId}
              statusId={statusId}
              ideaId={ideaId}
              redFlagId={redFlagId}
              successStoryId={successStoryId}
              contributionId={contributionId}
              helpRequestId={helpRequestId}
              keyResultUpdateId={keyResultUpdateId}
              eventId={event?.id}
              taggedEmployees={taggedEmployees || undefined}
            />
          </CardContent>
        </Collapse>
      </Card>
    </Box>
  );
}