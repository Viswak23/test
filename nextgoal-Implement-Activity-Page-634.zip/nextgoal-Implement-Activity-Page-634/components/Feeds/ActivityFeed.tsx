import React from 'react';
import { Stack, Box } from '@mui/material';
import ActivityItem, { ActivityEvent } from './ActivityItem';

interface ActivityFeedProps {
  activities: ActivityEvent[];
  emptyStateMessage?: string;
}

const ActivityFeed: React.FC<ActivityFeedProps> = ({ activities, emptyStateMessage  }) => {
  if (!activities.length) {
    return (
      <Box sx={(theme) => ({
                padding: theme.spacing(2.5),
                textAlign: 'center',
              })}>
        {emptyStateMessage || 'No activities to display'}
      </Box>
    );
  }
  return (
    <Box
      sx={{ padding: '20px', backgroundColor: '#f5f5f5' }}
      role="feed"
      aria-label="Activity Feed"
    >
      <Stack
        component="ul"
        direction="column"
        spacing={3}
        sx={{
          listStyle: 'none',
          margin: 0,
          padding: 0
        }}
      >
        {activities.map((activity) => (
          <li key={activity.id}>
                      <ActivityItem
                        event={activity}
                        onAddComment={(event) => {
                          console.warn('Activity comment feature not implemented');
                        }}
                        onLike={(event) => {
                          console.warn('Activity like feature not implemented');
                        }}
                      />
                    </li>
        ))}
      </Stack>
    </Box>
  );
};

export default ActivityFeed;
