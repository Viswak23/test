import { useState, useEffect } from "react";
import { HeadingMain } from "../Common/Texts/Texts";
import FeedsContent from "./FeedsContent";
import { FormattedMessage } from "react-intl";
import ScrollBackUpButton from "../Common/Buttons/ScrollBackUpButton";
import PageBackgroundPaper from "../Common/Layout/PageBackgroundPaper";

export default function Feeds() {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  if (!isClient) {
    return null;
  }

  return (
    <PageBackgroundPaper dataCy="feeds-page">
      <HeadingMain>
        <FormattedMessage id="feeds.title" />
      </HeadingMain>
      <FeedsContent />
      <ScrollBackUpButton />
    </PageBackgroundPaper>
  );
}