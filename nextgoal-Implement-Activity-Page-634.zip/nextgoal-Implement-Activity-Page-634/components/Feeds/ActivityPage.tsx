import React from 'react';
import ActivityFeed from './ActivityFeed';
import { Stack } from '@mui/material';
import { useEvents } from '@/contexts/EventsContext';
import { useGoals } from '@/contexts/GoalsContext';
import { useEmployees } from '@/contexts/EmployeesContext';
import { formatDistanceToNow } from 'date-fns';


const ActivityPage: React.FC = () => {
  const { events } = useEvents() ?? { events: [] };
  const { goals } = useGoals() ?? { goals: [] };
  const { employees } = useEmployees() ?? { employees: [] };

  // Helper to get details from employee by email
  const getEmployeeDetails = (email: string | undefined) => {
    if (!email) return { userName: "Unknown User", profileImageUrl: "https://via.placeholder.com/50" };
  
    const employee = employees?.find(e => e.email === email);
    return {
      userName: employee ? employee.name : "Unknown User",
      profileImageUrl: employee?.avatarUrl || "https://via.placeholder.com/50"
    };
  };

  // Helper to get the goal title and description by goal ID
  const getGoalDetails = (goalId: string | undefined) => {
    if (!goalId) return { title: "General Goal", description: "No description provided." };

    const goal = goals.find(g => g.id === goalId);
    return {
      title: goal?.title || "General Goal",
      description: goal?.description || "No description provided."
    };
  };

  // Transform events into activities
  const activities = events.map(event => {
    const employeeDetails = getEmployeeDetails(event.owner || undefined);
    const goalDetails = getGoalDetails(event.goalEventsId || undefined);

  

    const timeAgo = event.createdAt
      ? formatDistanceToNow(new Date(event.createdAt), { addSuffix: true })
      : "Unknown Time";

    return {
      id: parseInt(event.id),
      type: event.eventType ?? "General Event",
      user: employeeDetails.userName,
      message: goalDetails.description,
      goal: goalDetails.title,
      imageUrl: employeeDetails.profileImageUrl,
      timeAgo: timeAgo,  // Assign the calculated timeAgo here
      likes: event.likes ? event.likes.length : 0,
      comments: [], 
      referenceImageUrl: "https://via.placeholder.com/100",
    };
  });
  if (!activities.length) {
        return (
          <Stack
            direction="column"
            spacing={2}
            sx={{ padding: { xs: '10px', sm: '20px' } }}
            role="feed"
            aria-label="Activity Feed"
          >
            <div>No activities found</div>
          </Stack>
        );
      }

  return (
    <Stack
      direction="column"
      spacing={2}
      sx={{ padding: { xs: '10px', sm: '20px' } }}
      role="feed"
      aria-label="Activity Feed"
    >
      <ActivityFeed activities={activities} />
    </Stack>
  );
};

export default ActivityPage;
