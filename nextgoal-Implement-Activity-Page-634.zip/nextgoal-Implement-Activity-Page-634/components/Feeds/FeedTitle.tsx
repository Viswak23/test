import React from "react";
import { EmployeeWithAvatarUrl } from "@/contexts/EmployeesContext";
import { Divider, Link as MUILink, useTheme } from "@mui/material";
import Link from "next/link";
import { useIntl } from "react-intl";
import { getLinkWithLocale } from "@/lib/localisation";
import { FeedTitleTxt, TaggedEmployeesTxt } from "../Common/Texts/Texts";

interface FeedTitleInterface {
  title: string;
  taggedEmployees?: EmployeeWithAvatarUrl[] | null;
  taggedEmployeesTitle?: string;
}

export default function FeedTitle({
  title,
  taggedEmployees,
  taggedEmployeesTitle,
}: FeedTitleInterface) {
  const intl = useIntl();
  const theme = useTheme();

  return (
    <>
      <FeedTitleTxt>
        {title}
        {title && <br />}
      </FeedTitleTxt>
      <TaggedEmployeesTxt>
        {taggedEmployees &&
          taggedEmployees.length > 0 &&
          `${taggedEmployeesTitle}: `}
        {taggedEmployees &&
          taggedEmployees.length > 0 &&
          taggedEmployees.map((employee, index) => {
            return (
              <React.Fragment key={employee.id}>
                <MUILink
                  sx={{ color: theme.palette.primary.main }}
                  href={getLinkWithLocale(
                    "/employees/" + employee?.id,
                    intl.locale
                  )}
                  locale={intl.locale}
                  data-cy={`employee-link-${employee?.name}`}
                  component={Link}
                  underline="hover"
                >
                  {employee?.name}
                </MUILink>
                {index < taggedEmployees.length - 1 && ", "}
              </React.Fragment>
            );
          })}
      </TaggedEmployeesTxt>
    </>
  );
}