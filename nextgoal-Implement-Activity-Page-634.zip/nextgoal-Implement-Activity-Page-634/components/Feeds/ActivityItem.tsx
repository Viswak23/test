import React, { useState } from 'react';
import { Box, Typography, TextField, Button, Stack, IconButton, Link, Avatar } from '@mui/material';
import CommentIcon from '@mui/icons-material/Comment';
import FavoriteIcon from '@mui/icons-material/Favorite';

export interface Comment {
  user: string;
  message: string;
  likes: number;
  replies: Comment[];
  profileImageUrl: string;
}

export interface ActivityEvent {
  id: number;  // Ensure this is a number if that's what your types expect
  type: string;
  user: string;
  message: string;
  goal: string;
  imageUrl: string;
  timeAgo: string;
  likes: number;
  comments: Comment[];
  referenceImageUrl: string;
}

interface ActivityItemProps {
  event: ActivityEvent;
  onAddComment: (eventId: number, comment: Comment) => void;
  onLike: (eventId: number) => void;
}

const ActivityItem: React.FC<ActivityItemProps> = ({ event, onAddComment, onLike }) => {
  const [newComment, setNewComment] = useState<string>('');
  const [showCommentInput, setShowCommentInput] = useState<boolean>(false);
  const [showComments, setShowComments] = useState<boolean>(false);
  const [replyContent, setReplyContent] = useState<{ [key: number]: string }>({});
  const [replyInputVisible, setReplyInputVisible] = useState<{ [key: number]: boolean }>({});

  const handleAddComment = () => {
    if (newComment.trim() !== '') {
      onAddComment(event.id, {
        user: 'Current User', // Placeholder user name
        message: newComment,
        likes: 0,
        replies: [],
        profileImageUrl: 'https://via.placeholder.com/30', // Placeholder profile image
      });
      setNewComment('');
    }
  };

  const toggleCommentInput = () => {
    setShowCommentInput((prev) => !prev);
  };

  const toggleShowComments = () => {
    setShowComments((prev) => !prev);
  };

  const handleLike = () => {
    onLike(event.id);
  };

  const handleLikeComment = (commentIndex: number) => {
    event.comments[commentIndex].likes += 1;
  };

  const handleLikeReply = (commentIndex: number, replyIndex: number) => {
    event.comments[commentIndex].replies[replyIndex].likes += 1;
  };

  return (
    <Box sx={{ padding: '16px', borderRadius: '10px', background: '#f5f5f5' }}>
      <Stack direction="row" spacing={2}>
        <Avatar src={event.imageUrl} alt="Event" sx={{ width: 50, height: 50 }} />
        <Box sx={{ flex: 1 }}>
          <Typography variant="subtitle1" fontWeight="bold">{event.type}</Typography>
          <Typography variant="body2" color="primary">{event.user}</Typography>
          <Typography variant="body2" color="primary" style={{ paddingBottom: '10px' }}>{event.timeAgo}</Typography>
        </Box>
      </Stack>
      <Box sx={{ ml: 8 }}>
        <Typography variant="body1" mt={1} style={{ width: 370, paddingBottom: '5px' }}>{event.message}</Typography>
        <Typography variant="body2" color="primary">{event.goal}</Typography>
        <Box mt={2}>
          <Stack direction="row" spacing={1} alignItems="center">
            <IconButton onClick={handleLike}>
              <FavoriteIcon />
            </IconButton>
            <Typography variant="body2">{event.likes}</Typography>
            <IconButton onClick={toggleCommentInput}>
              <CommentIcon />
            </IconButton>
            <Typography variant="body2">{event.comments.length}</Typography>
          </Stack>
          <Link onClick={toggleShowComments} sx={{ cursor: 'pointer', color: 'primary.main' }}>
            {showComments ? 'Hide comments' : 'Show comments'}
          </Link>
          {showCommentInput && (
            <Box mt={1}>
              <TextField
                fullWidth
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Add a comment..."
                size="small"
                style={{ width: 400, padding: "5px" }}
              />
              <Button onClick={handleAddComment} sx={{ mt: 1 }} variant="contained" style={{ padding: "5px" }}>Comment</Button>
            </Box>
          )}
          {showComments && (
            <Box mt={2}>
              {event.comments.map((comment, index) => (
                <Box key={index} sx={{ mt: 1, display: 'flex', alignItems: 'center', width: 450 }}>
                  <Avatar src={comment.profileImageUrl} sx={{ alignSelf: 'flex-start', marginRight: '10px' }} />
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="subtitle2">{comment.user}</Typography>
                    <Typography variant="body2" style={{ width: 400 }}>{comment.message}</Typography>
                    <Stack direction="row" alignItems="center" spacing={1}>
                      <IconButton onClick={() => handleLikeComment(index)}>
                        <FavoriteIcon />
                      </IconButton>
                      <Typography variant="body2">{comment.likes}</Typography>
                      <IconButton onClick={() => setReplyInputVisible({ ...replyInputVisible, [index]: !replyInputVisible[index] })}>
                        <CommentIcon />
                      </IconButton>
                    </Stack>
                    {replyInputVisible[index] && (
                      <Box mt={1}>
                        <TextField
                          fullWidth
                          value={replyContent[index] || ''}
                          onChange={(e) => setReplyContent({ ...replyContent, [index]: e.target.value })}
                          placeholder="Add a reply..."
                          size="small"
                          style={{ width: 400, padding: "5px" }}
                        />
                        <Button onClick={() => handleAddComment()} sx={{ mt: 1 }} variant="contained" style={{ padding: "5px" }}>Reply</Button>
                      </Box>
                    )}
                    {comment.replies.map((reply, replyIndex) => (
                      <Stack key={replyIndex} direction="row" sx={{ ml: 4, mt: 1 }} alignItems="flex-start">
                        <Avatar src={reply.profileImageUrl} sx={{ width: 24, height: 24, alignSelf: 'flex-end', marginRight: '8px' }} />
                        <Box>
                          <Typography variant="subtitle2">{reply.user}</Typography>
                          <Typography variant="body2" style={{ paddingLeft: '5px' }}>{reply.message}</Typography>
                        </Box>
                      </Stack>
                    ))}
                  </Box>
                </Box>
              ))}
            </Box>
          )}
        </Box>
      </Box>
    </Box>
  );
};

export default ActivityItem;
