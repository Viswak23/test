import React from 'react';
import { Typography, Avatar, Stack, Button } from '@mui/material';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';

interface CommentProps {
  comment: {
    id: string;
    user: string;
    message: string | React.ReactNode;
    likes: number;
    replies: number;
    timestamp: string;
  };
}

export const ActivityComment: React.FC<CommentProps> = ({ comment }) => {
  return (
    <Stack direction="row" spacing={2} alignItems="center" component="article" aria-label={`Comment by ${comment.user}`} sx={{ mt: 1 }}>
      <Avatar alt={comment.user}>
        {comment.user.charAt(0).toUpperCase()}
      </Avatar>
      <Stack component="div" role="contentinfo">
        <Typography variant="body2" sx={{ fontWeight: 'bold' }}>{comment.user}</Typography>
        <Typography variant="body2">{comment.message}</Typography>
        <Stack direction={'row'} spacing={2}>
        <Button
          size="small"
          variant="text"
          color="inherit"
          startIcon={<ThumbUpIcon />}
          onClick={() => {/* TODO: Handle like */}}
          aria-label={`Like comment. Current likes: ${comment.likes}`}
        >
          {comment.likes}
        </Button>
        <Button
          size="small"
          variant="text"
          color="inherit"
          startIcon={<ThumbUpIcon />}
          onClick={() => {/* TODO: Handle reply */}}
          aria-label={`replies comment. Current replies: ${comment.replies}`}
        >
          {comment.replies}
        </Button>
        </Stack>
      </Stack>
    </Stack>
  );
};
