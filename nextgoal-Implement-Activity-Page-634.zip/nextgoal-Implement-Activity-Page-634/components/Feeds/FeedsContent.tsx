import React, { useMemo, useState } from "react";
import { useGoals } from "@/contexts/GoalsContext";
import {
  getAllEventsForGoal,
  getOrganizationEvents,
  hydrateEvents,
} from "@/lib/webEvents";
import { useEvents } from "@/contexts/EventsContext";
import { Button, Stack } from "@mui/material";
import { EventFeedItem } from "./EventFeedItem";
import { Goal, Event } from "@/src/API";
import { FormattedMessage } from "react-intl";
import CustomBox from "../Common/Layout/CustomBox";

interface FeedsContentProps {
  goalId?: string;
  organizationGoals?: (Goal | null)[];
}

export default function FeedsContent({
  goalId,
  organizationGoals,
}: FeedsContentProps) {
  const INC_EVENT_COUNT = 15;

  const [eventCount, setEventCount] = useState(INC_EVENT_COUNT);
  const openGoals = useGoals()?.goals;
  const archivedGoals = useGoals()?.archivedGoals;
  const events = useEvents()?.events;

  const goalEvents = useMemo(() => {
    const goals = [...openGoals!, ...archivedGoals!];
    let feedEvents = [] as Event[];
    if (goalId) {
      feedEvents = getAllEventsForGoal(goalId, events, goals);
    } else if (organizationGoals) {
      feedEvents = getOrganizationEvents(organizationGoals, goals, events);
    } else {
      feedEvents = events || [];
    }

    if (!feedEvents) {
      return [];
    }
    return hydrateEvents(feedEvents, goals);
  }, [goalId, events, organizationGoals, archivedGoals, openGoals]);

  const visibleEvents = goalEvents.slice(0, eventCount);

  const handleShowMore = () => {
    setEventCount((c) => c + INC_EVENT_COUNT);
  };

  return (
    <Stack
      direction="column"
      spacing={0}
    >
      {visibleEvents.map((event) => (
        <EventFeedItem key={event.id} event={event} />
      ))}
      <CustomBox>
        <Button
          disabled={eventCount >= goalEvents.length}
          onClick={handleShowMore}
        >
          <FormattedMessage id="general.show.more" />
        </Button>
      </CustomBox>
    </Stack>
  );
}