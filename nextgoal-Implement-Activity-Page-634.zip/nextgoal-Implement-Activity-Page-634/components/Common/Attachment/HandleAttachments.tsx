import { SetStateAction, useRef, useState } from "react";
import { AttachmentFile } from "@/lib/webAttachment";
import AttachmentList from "./AttachmentList";
import { Box, useTheme } from "@mui/material";
import FileUploadIcon from "@mui/icons-material/FileUpload";
import { FormattedMessage } from "react-intl";

interface HandleAttachmentsProps {
  existingAttachments: AttachmentFile[];
  previewMedias: AttachmentFile[];
  setPreviewMedias: (value: SetStateAction<AttachmentFile[]>) => void;
  removedAttachments: AttachmentFile[];
  setRemovedAttachments: (value: SetStateAction<AttachmentFile[]>) => void;
  handleFilesCallback?: (files: FileList) => void;
}

export default function HandleAttachments({
  existingAttachments,
  previewMedias,
  setPreviewMedias,
  removedAttachments,
  setRemovedAttachments,
  handleFilesCallback,
}: HandleAttachmentsProps) {
  const fileInput = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState<boolean>(false);

  const handleDrop = (e: any) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleDragLeave = (e: any) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const handleDragOver = (e: any) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleDragEnter = (e: any) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleFiles = (files: FileList) => {
    if (handleFilesCallback) {
      handleFilesCallback(files);
      return;
    }

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onloadend = (e) => {
        const newMedia = {
          type: file.type,
          url: URL.createObjectURL(file),
          file,
        };
        setPreviewMedias((medias) => medias.concat(newMedia));
      };
    });
  };

  const handleSelectFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    const target = e.target as HTMLInputElement;
    if (!target.files) {
      return;
    }

    handleFiles(target.files);
  };

  const handleRemoveMediaFile = (media: AttachmentFile) => {
    if (previewMedias.find((m) => m.url === media.url)) {
      setPreviewMedias((medias) => medias.filter((m) => m.url !== media.url));
    } else {
      setRemovedAttachments((attachments) => attachments.concat(media));
    }
  };

  const handleOpenFileInput = () => {
    fileInput.current?.click();
  };

  const showAttachments = existingAttachments
    .filter((mf) => !removedAttachments.includes(mf))
    .concat(previewMedias);

  const theme = useTheme();

  return (
    <>
      <input
        accept="image/*, video/*, .pdf"
        id="icon-button-file"
        type="file"
        ref={fileInput}
        hidden={true}
        multiple
        onChange={handleSelectFile}
      />
      <AttachmentList
        attachments={showAttachments}
        handleRemoveAttachment={handleRemoveMediaFile}
      />

      <Box
        sx={{
          p: 2,
          border: `2px dashed ${theme.palette.customColors?.loweropacity}`,
          height: 100,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          marginTop: "12px",
          padding: "20px",
        }}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDragEnter={handleDragEnter}
        onClick={handleOpenFileInput}
      >
        <FileUploadIcon fontSize="large" />
        <p style={{ margin: 0 }}>
          <FormattedMessage id="attachment.add.attachment" />
        </p>
      </Box>
    </>
  );
}
