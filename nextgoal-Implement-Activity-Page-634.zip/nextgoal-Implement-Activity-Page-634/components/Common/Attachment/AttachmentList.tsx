import { AttachmentFile } from "@/lib/webAttachment";
import { Stack } from "@mui/material";
import AttachmentMedia from "./AttachmentMedia";
import AttachmentDocument from "./AttachmentDocument";

interface AttachmentListProps {
  attachments?: AttachmentFile[];
  handleRemoveAttachment?: (attachment: AttachmentFile) => void;
}

export default function AttachmentList({
  attachments,
  handleRemoveAttachment,
}: AttachmentListProps) {
  if (!attachments || attachments.length === 0) {
    return null;
  }

  const mediaFiles = attachments.filter(
    (attachment) =>
      attachment.type?.includes("image") || attachment.type?.includes("video")
  );
  const otherFiles = attachments.filter(
    (attachment) =>
      !attachment.type?.includes("image") && !attachment.type?.includes("video")
  );

  return (
    <Stack direction="column" spacing={1}>
      <Stack
        direction="row"
        spacing={1}
        alignItems="center"
        style={{ marginTop: "12px" }}
      >
        {mediaFiles.map((attachment) => (
          <AttachmentMedia
            key={attachment.url}
            attachment={attachment}
            handleRemoveAttachment={handleRemoveAttachment}
          />
        ))}
      </Stack>
      {otherFiles.map((attachment) => (
        <AttachmentDocument
          key={attachment.url}
          attachment={attachment}
          handleRemoveAttachment={handleRemoveAttachment}
        />
      ))}
    </Stack>
  );
}
