import { AttachmentFile } from "@/lib/webAttachment";
import { Delete } from "@mui/icons-material";
import { Box } from "@mui/material";
import { useTheme } from "@mui/material/styles";

interface AttachmentDocumentProps {
  attachment: AttachmentFile;
  handleRemoveAttachment?: (attachment: AttachmentFile) => void;
}

export default function AttachmentDocument({
  attachment,
  handleRemoveAttachment,
}: AttachmentDocumentProps) {
  const theme = useTheme();

  return (
    <Box style={{ position: "relative" }}>
      {handleRemoveAttachment && (
        <Delete
        style={{
          cursor: 'pointer',
          position: 'absolute',
          right: '12px',
          color: theme.palette.customColors?.delete,
          }}
          onClick={() => handleRemoveAttachment(attachment)}
        />
      )}
      <a
        href={attachment.url}
        target="_blank"
        download
        style={{ color: theme.palette.primary.main, textDecoration: "none" }}
      >
        {attachment.file?.name}
      </a>
    </Box>
  );
}
