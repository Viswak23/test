import { AttachmentFile } from "@/lib/webAttachment";
import { Delete } from "@mui/icons-material";
import { Box } from "@mui/material";
import { FormattedMessage } from "react-intl";
import { useTheme } from "@mui/material/styles";

interface AttachmentMediaProps {
  attachment: AttachmentFile;
  handleRemoveAttachment?: (attachment: AttachmentFile) => void;
}

export default function AttachmentMedia({
  attachment,
  handleRemoveAttachment,
}: AttachmentMediaProps) {
  const theme = useTheme();

  return (
    <Box style={{ position: "relative" }}>
      {handleRemoveAttachment && (
        <Delete
          style={{
            cursor: "pointer",
            position: "absolute",
            right: "12px",
            top: "12px",
            color: theme.palette.customColors?.delete,
          }}
          onClick={() => handleRemoveAttachment(attachment)}
        />
      )}
      {attachment.type?.includes("image") && (
        <Box
          component="img"
          style={{
            height: "auto",
            width: "100%",
            maxWidth: "100%",
          }}
          height={200}
          width={400}
          alt="status image"
          src={attachment.url!}
        />
      )}
      {attachment.type?.includes("video") && (
        <video key={attachment.url} height="200" controls>
          <source src={attachment.url} />
          <FormattedMessage id="attachment.no.support.fideos" />
        </video>
      )}
    </Box>
  );
}
