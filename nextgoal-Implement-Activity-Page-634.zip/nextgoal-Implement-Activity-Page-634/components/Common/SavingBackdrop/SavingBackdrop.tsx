import { Backdrop, CircularProgress, useTheme } from "@mui/material";

interface SavingBackdropProps {
  open: boolean;
}

export default function SavingBackdrop({ open }: SavingBackdropProps) {
  const theme = useTheme();
  return (
    <Backdrop
      sx={{
        color: theme.palette.customColors?.bright,
        zIndex: (theme) => theme.zIndex.drawer + 1,
      }}
      open={open}
    >
      <CircularProgress color="inherit" />
    </Backdrop>
  );
}
