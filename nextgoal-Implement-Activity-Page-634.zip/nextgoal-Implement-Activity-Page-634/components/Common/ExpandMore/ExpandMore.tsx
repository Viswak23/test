import { Divider, Stack, Tooltip } from "@mui/material";
import IconButton, { IconButtonProps } from "@mui/material/IconButton";
import { styled } from "@mui/material/styles";
import { FormattedMessage } from "react-intl";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { hoverLighterToSecondary } from "@/config/styling";
import theme from "@/config/theme";

interface ExpandMoreProps extends IconButtonProps {
  expand: boolean;
  expandedTooltip?: string | React.ReactNode;
  collapsedTooltip?: string | React.ReactNode;
}

const ExpandMore = styled((props: ExpandMoreProps) => {
  const { expand, expandedTooltip, collapsedTooltip, ...other } = props;
  return (
    <IconButton
      sx={{ ...hoverLighterToSecondary(theme) }}
      data-cy="expand-more"
      {...other}
    >
      <Tooltip title={expand ? expandedTooltip : collapsedTooltip}>
        <ExpandMoreIcon />
      </Tooltip>
    </IconButton>
  );
})(({ theme, expand }) => ({
  transform: !expand ? "rotate(0deg)" : "rotate(180deg)",
  transition: theme.transitions.create("transform", {
    duration: theme.transitions.duration.shortest,
  }),
}));

export default ExpandMore;
