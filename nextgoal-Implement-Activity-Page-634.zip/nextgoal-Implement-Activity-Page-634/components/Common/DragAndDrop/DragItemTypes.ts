export enum DragItemTypes {
  ORGANIZATION_CARD = 'organizationCard',
  GOAL_CARD = 'goalCard',
}
