import { Paper } from "@mui/material";
import { CSSProperties } from "react";

interface PageBackgroundPaperProps {
  children: React.ReactNode;
  style?: CSSProperties;
  dataCy?: string;
  headerSpace?: boolean;
}

export default function PageBackgroundPaper({
  children,
  style,
  dataCy,
  headerSpace = true,
}: PageBackgroundPaperProps) {
  // PaddingTop is for menu
  return (
    <Paper
      elevation={3}
      sx={{
        marginTop: 0,
        paddingTop: { xs: "2rem", sm: headerSpace ? "84px" : "2rem" },
        paddingLeft: { xs: "0.5rem", sm: "2rem" },
        paddingRight: { xs: "0.5rem", sm: "2rem" },
        paddingBottom: "2rem",
        marginBottom: "24px",
      }}
      style={{ ...style }}
      data-cy={dataCy}
    >
      {children}
    </Paper>
  );
}
