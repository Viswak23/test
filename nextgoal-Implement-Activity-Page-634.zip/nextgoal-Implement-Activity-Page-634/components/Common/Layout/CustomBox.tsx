import React, { ReactNode } from "react";
import { Box, BoxProps } from "@mui/material";

interface CustomBoxProps extends BoxProps {
  children?: ReactNode;
  style?: React.CSSProperties;
  spacing?: number;
}

export default function CustomBox({ children, style, width = "100%", ...props }: CustomBoxProps) {
  return (
    <Box
      style={{ ...style }}
      sx={{
        display: "flex",
        flexGrow: 1,
        flexBasis: "100%", // ensures each organization item takes up full available space
        padding: 2,
        alignItems: "center",
        justifyContent: "center", 
        width: {width},
        whiteSpace: 'normal',
      }}
      {...props}
    >
      {children}
    </Box>
  );
};