import React from "react";
import { Box, Grid, useMediaQuery, useTheme } from "@mui/material";
import CustomBox from "./CustomBox";

interface StyledCardProps {
  children: React.ReactNode;
}

export default function StyledCard({ children }: StyledCardProps) {
  const theme = useTheme();
  const isBelowMd = useMediaQuery(theme.breakpoints.down("md"));

  return (
    <Grid
      item
      xs={12}
      sm={isBelowMd ? 12 : 4}
      md={isBelowMd ? 12 : 4}
      lg={isBelowMd ? 12 : 4}
      sx={{
        display: "flex",
        justifyContent: "center",
      }}
    >
      <CustomBox
        sx={{
          background: theme.palette.customColors?.bright,
          width: "100%",
          maxWidth: isBelowMd ? "90%" : "100%",
          textAlign: "center",
          borderRadius: "8px",
          boxShadow: "0 4px 8px rgba(196, 203, 236, 0.3)",
        }}
      >
        {children}
      </CustomBox>
    </Grid>
  );
}
