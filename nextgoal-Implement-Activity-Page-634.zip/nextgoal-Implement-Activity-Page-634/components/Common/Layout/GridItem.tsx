import { Grid } from "@mui/material";
import { ReactNode } from "react";

interface GridItemProps {
  children?: React.ReactNode;
  justifyContent?: React.CSSProperties['justifyContent'];
  alignItems?: React.CSSProperties['alignItems'];
  xs?: number;
  sm?: number;
  md?: number;
  lg?: number;
  width?: string;
  style?: React.CSSProperties;
  title?: ReactNode;
}

// Spec. stylings of this component can be overridden in separate files:
export default function GridItem({ children, style, xs = 12, sm = 6, md = 4, width = "50%", justifyContent, alignItems }: GridItemProps) {
  return (
    <Grid item 
    style={{ ...style }}
    justifyContent={justifyContent}
    alignItems={alignItems}
    xs={xs} sm={sm} md={md} // note: do not for the love of god touch this line
    sx={{ width }}>
      {children}
    </Grid>
  );
};
