import { Grid, SxProps, Theme } from "@mui/material";
import { ReactNode } from "react";

interface GridContainerProps {
  children?: React.ReactNode;
  spacing?: number;
  justifyContent?: React.CSSProperties['justifyContent'];
  alignItems?: React.CSSProperties['alignItems'];
  xs?: number;
  sm?: number;
  md?: number;
  width?: string;
  direction?: string;
  title?: ReactNode;
  sx?: SxProps<Theme>;
}

export default function GridContainer({ children, spacing, justifyContent = 'center', alignItems="center", width = '100%', xs = 2, sm = 1, md = 3 }: GridContainerProps) {
  return (
    <Grid
      container
      spacing={{
        xs: xs,
        sm: sm,
        md: md, 
      }}
      alignItems={alignItems}
      justifyContent={justifyContent}
      sx={{ 
        paddingLeft: "5px",
        paddingRight: "5px", 
        width: "100%" 
    }}
    >
      {children}
    </Grid>
  );
}
