import React from "react";
import Link from "next/link";
import {
  Box,
  Link as MUILink,
  styled,
  Typography,
  useTheme,
} from "@mui/material";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import { useGoals } from "@/contexts/GoalsContext";
import { useOrganization } from "@/contexts/OrganizationContext";
import {
  BcLinkElement,
  getOrganizationLinkPath,
  getGoalLinkPath,
} from "@/lib/webBreadCrumb";
import { useIntl } from "react-intl";
import { getLinkWithLocale } from "@/lib/localisation";
import { Pages } from "@/lib/webNavigation";

export enum BreadcrumbType {
  PAGE,
  SUBHEADER,
  LIST,
  DETAIL,
}

interface BreadcrumbProps {
  type?: BreadcrumbType;
  showMainPage?: boolean;
  showLastAsaLink?: boolean;
  organizationUnitId?: string | null;
  currentGoalId?: string;
  extraElement?: BcLinkElement;
}
const StyledBreadcrumbs = styled(Breadcrumbs)`
  .MuiBreadcrumbs-li {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
`;

export default function Breadcrumb({
  type = BreadcrumbType.PAGE,
  showMainPage = true,
  showLastAsaLink = false,
  organizationUnitId,
  currentGoalId,
  extraElement,
}: BreadcrumbProps) {
  const organization = useOrganization()?.organization;
  const goals = useGoals()?.goals;
  const archivedGoals = useGoals()?.archivedGoals;
  const theme = useTheme();
  const intl = useIntl();

  // Cannot use memo here while we are modifying route after it is created
  const route = organizationUnitId
    ? getOrganizationLinkPath(organization!, organizationUnitId)
    : getGoalLinkPath(goals || [], archivedGoals || [], currentGoalId!);

  if (showMainPage) {
    route.unshift({
      title: intl.formatMessage({ id: "general.main.page" }),
      link: Pages.appGoals   ,
    });
  }

  const lastElement = showLastAsaLink ? null : route.pop();

  let style;
  let linkStyle = {};

  switch (type) {
    case BreadcrumbType.PAGE:
      style = {
        marginTop: "18px",
        marginBottom: "18px",
      };
    case BreadcrumbType.SUBHEADER:
      style = {
        marginTop: "6px",
        marginBottom: "6px",
      };
      break;
    case BreadcrumbType.LIST:
      style = {
        marginTop: "0",
        marginBottom: "0",
        lineHeight: "20px",
      };
      linkStyle = {
        fontWeight: 400,
        fontSize: "0.875rem",
        lineHeight: "20px",
      };
      break;
    case BreadcrumbType.DETAIL:
      style = {
        marginTop: "0",
        marginBottom: "0",
      };
      linkStyle = {
        fontWeight: 400,
      };
      break;
  }

  const breadcrumbLabel = intl.formatMessage({ id: "general.breadcrumb" });

  return (
    <StyledBreadcrumbs
      aria-label={breadcrumbLabel}
      sx={{
        maxWidth: "100%",
      }}
    >
      {route.map((element) => (
        <MUILink
          key={element.link}
          underline="hover"
          color={theme.palette.customColors?.lighter}
          href={getLinkWithLocale(element.link, intl.locale)}
          locale={intl.locale}
          component={Link}
          style={linkStyle}
          noWrap
        >
          {element.title}
          {element.closed &&
            intl.formatMessage({ id: "goals.breadcrumb.closed" })}
        </MUILink>
      ))}
      {!showLastAsaLink && (
        <Typography color="text.primary" style={linkStyle} noWrap>
          {lastElement?.title}
        </Typography>
      )}
      {extraElement && (
        <MUILink
          key={extraElement.link}
          underline="hover"
          color={theme.palette.primary.main}
          href={getLinkWithLocale(extraElement.link, intl.locale)}
          locale={intl.locale}
          component={Link}
          style={linkStyle}
          noWrap
        >
          {extraElement.title}
        </MUILink>
      )}
    </StyledBreadcrumbs>
  );
}
