import React, { useMemo } from "react";
import Link from "next/link";
import { Link as MUILink, Typography, useTheme } from "@mui/material";
import { Stack } from "@mui/material/";
import { useGoals } from "@/contexts/GoalsContext";
import { useOrganization } from "@/contexts/OrganizationContext";
import {
  BcLinkElement,
  getOrganizationLinkPath,
  getGoalLinkPath,
} from "@/lib/webBreadCrumb";
import { useIntl } from "react-intl";
import { getLinkWithLocale } from "@/lib/localisation";
import { Pages } from "@/lib/webNavigation";

interface BreadcrumbListProps {
  showMainPage?: boolean;
  showLastAsaLink?: boolean;
  organizationUnitId?: string | null;
  currentGoalId?: string;
  extraElement?: BcLinkElement;
}

export default function BreadcrumbList({
  showMainPage = true,
  showLastAsaLink = false,
  organizationUnitId,
  currentGoalId,
  extraElement,
}: BreadcrumbListProps) {
  const organization = useOrganization()?.organization;
  const goals = useGoals()?.goals;
  const archivedGoals = useGoals()?.archivedGoals;
  const intl = useIntl();
  const theme = useTheme();

  const route = useMemo(
    () =>
      organizationUnitId
        ? getOrganizationLinkPath(organization!, organizationUnitId)
        : getGoalLinkPath(goals || [], archivedGoals || [], currentGoalId!),
    [organization, goals, organizationUnitId, currentGoalId, archivedGoals]
  );

  const lastElement = showLastAsaLink ? null : route.pop();
  if (showMainPage) {
    route.unshift({
      title: intl.formatMessage({ id: "goals.top.level" }),
      link: Pages.appGoals,
    });
  }

  const elemStyle = {
    fontWeight: 400,
    fontSize: "0.875rem",
    lineHeight: "20px",
    color: theme.palette.customColors?.babyblue,
    fontStyle: "italic",
  };

  return (
    <Stack
      direction="row"
      spacing={1}
      style={{
        margin: "6px 0px 0px 4px",
        lineHeight: "20px",
      }}
      textOverflow={"ellipsis"}
    >
      {route.map((element, index) => (
        <React.Fragment key={`${index}-${element.link}`}>
          <MUILink
            underline="hover"
            href={getLinkWithLocale(element.link, intl.locale)}
            locale={intl.locale}
            component={Link}
            style={elemStyle}
            noWrap
          >
            {element.title}
            {element.closed &&
              intl.formatMessage({ id: "goals.breadcrumb.closed" })}
          </MUILink>
          {(index < route.length - 1 || lastElement || extraElement) && (
            <Typography color="text.primary" style={elemStyle} noWrap>
              {index === route.length - 1 ? " > " : " / "}
            </Typography>
          )}
        </React.Fragment>
      ))}
      {!showLastAsaLink && lastElement && (
        <Typography color="text.primary" style={elemStyle} noWrap>
          {lastElement?.title}
        </Typography>
      )}
      {extraElement && (
        <MUILink
          key={extraElement.link}
          underline="hover"
          href={getLinkWithLocale(extraElement.link, intl.locale)}
          locale={intl.locale}
          component={Link}
          style={elemStyle}
          noWrap
        >
          {extraElement.title}
        </MUILink>
      )}
    </Stack>
  );
}
