import React from "react";
import { Breadcrumbs, Link, styled } from "@mui/material";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import { BcIdElement } from "@/lib/webBreadCrumb";
import { useIntl } from "react-intl";

interface OrganizationBreadCrumbProps {
  organizationPath: BcIdElement[];
  lastElement?: BcIdElement;
  onSelectOrganization: (organizationId: string | undefined) => void;
}
const StyledBreadcrumbs = styled(Breadcrumbs)`
  .MuiBreadcrumbs-li {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    /* flex: 1; */
  }
`;

export default function OrganizationBreadCrumb({
  organizationPath,
  lastElement,
  onSelectOrganization,
}: OrganizationBreadCrumbProps) {
  const intl = useIntl();
  const orgBreadCrumb = intl.formatMessage({
    id: "general.organization.breadcrumb",
  });
  return (
    <StyledBreadcrumbs
      aria-label={orgBreadCrumb}
      separator={<NavigateNextIcon fontSize="small" />}
      style={{
        padding: 10,
      }}
    >
      {organizationPath.map((org) => (
        <Link
          key={org.organizationUnit?.id || "top-level"}
          onClick={() => onSelectOrganization(org.organizationUnit?.id)}
          style={{
            cursor: "pointer",
            textDecoration: "none",
          }}
          noWrap
        >
          {org.title}
        </Link>
      ))}
      <span>{lastElement?.title}</span>
    </StyledBreadcrumbs>
  );
}
