import { SyntheticEvent, useEffect, useMemo } from "react";
import {
  EmployeeWithAvatarUrl,
  useEmployees,
} from "@/contexts/EmployeesContext";
import {
  getEmployeeByEmail,
  useTaggedEmployeesFromJoin,
} from "@/lib/webEmployee";
import { Autocomplete, Chip, TextField } from "@mui/material";
import { EmployeeJoinConnection } from "@/lib/webEmployee";
import { FormattedMessage, useIntl } from "react-intl";

interface TaggedEmployeesProps {
  taggedEmployees: EmployeeWithAvatarUrl[];
  currentUser: any;
  employeeJoins?: EmployeeJoinConnection;
  employeeIdField: string;
  inCreate: boolean;
  addCurrentEmployee?: boolean;
  label?: string;
  setTaggedEmployees: (employees: EmployeeWithAvatarUrl[]) => void;
}

export default function TaggedEmployees({
  taggedEmployees,
  currentUser,
  employeeJoins,
  employeeIdField,
  inCreate,
  addCurrentEmployee = true,
  label,
  setTaggedEmployees,
}: TaggedEmployeesProps) {
  const employees = useEmployees()?.employees;
  const intl = useIntl();
  const currentEmployee = useMemo(
    () => getEmployeeByEmail(employees, currentUser?.attributes.email),
    [employees, currentUser?.attributes.email]
  );
  const ownersAsEmployees = useTaggedEmployeesFromJoin(
    employees,
    employeeJoins,
    employeeIdField
  );

  useEffect(() => {
    setTaggedEmployees(
      inCreate
        ? currentEmployee && addCurrentEmployee
          ? [currentEmployee]
          : []
        : ownersAsEmployees || []
    );
  }, [
    currentEmployee,
    inCreate,
    ownersAsEmployees,
    setTaggedEmployees,
    addCurrentEmployee,
  ]);

  const handleAssignedToChange = (
    event: SyntheticEvent<Element, Event> | null,
    selectedEmployees: EmployeeWithAvatarUrl[]
  ) => {
    setTaggedEmployees(selectedEmployees);
  };

  // Hard rendering because of the problem: https://stackoverflow.com/questions/75818761/material-ui-autocomplete-warning-a-props-object-containing-a-key-prop-is-be
  return (
    <Autocomplete
      id="employee-select"
      multiple
      options={employees || []}
      getOptionLabel={(option) => option?.name || ""}
      isOptionEqualToValue={(option, value) => option?.id === value?.id}
      sx={{ marginTop: "12px" }}
      value={taggedEmployees}
      onChange={handleAssignedToChange}
      renderOption={(props, option) => {
        return (
          <li {...props} key={option.id}>
            {option.name}
          </li>
        );
      }}
      renderTags={(tagValue, getTagProps) => {
        return tagValue.map((option, index) => (
          <Chip
            {...getTagProps({ index })}
            key={option.id}
            label={option.name}
          />
        ));
      }}
      renderInput={(params) => {
        return (
          <TextField
            {...params}
            label={label || <FormattedMessage id="Tagged employees" />}
            placeholder={
              label || intl.formatMessage({ id: "Tagged employees" })
            }
          />
        );
      }}
    />
  );
}
