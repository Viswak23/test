import React from "react";
import {
  Box,
  Fab,
  List,
  ListItem,
  ListItemText,
  useTheme,
} from "@mui/material";
import { isArray } from "lodash";
import { useIntl } from "react-intl";

interface GTabPanelProps {
  children?: React.ReactNode[] | React.ReactNode;
  noResultsText?: string;
  addLabel?: String;
  addDisabled?: boolean;
  onAdd?: () => void;
}

export default function GTabPanel({
  children,
  noResultsText,
  addLabel,
  addDisabled = false,
  onAdd,
}: GTabPanelProps) {
  const intl = useIntl();
  const theme = useTheme();
  const addLabelText = addLabel || intl.formatMessage({ id: "general.add" });
  const addButton = intl.formatMessage({ id: "general.add" });

  // Check if there are any children. Affects layout.
  const childrenExists =
    (isArray(children) && children.filter((child) => child).length > 0) ||
    children != null;

  return (
    <Box style={{ paddingLeft: "12px", minHeight: "48px" }}>
      {(childrenExists || noResultsText || onAdd) && (
        <List
          dense={true}
          style={{ paddingTop: 0, marginTop: "6px", marginRight: "12px" }}
        >
          {!childrenExists && noResultsText && (
            <ListItem>
              <ListItemText
                primary={noResultsText}
                style={{ fontStyle: "italic", opacity: 0.6 }}
              />
            </ListItem>
          )}
          {children}
          {onAdd && (
            <ListItem
              style={{
                width: "100%",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              {/* the "add"/"lisää" button */}
              <Fab
                onClick={onAdd}
                sx={{
                  transition: "0.3s ease",
                  color: theme.palette.customColors?.bright,
                  backgroundColor: theme.palette.customColors?.lighter,
                  "&:hover": {
                    backgroundColor: theme.palette.customColors?.add,
                  },
                }}
                aria-label={addButton}
                disabled={addDisabled}
                size="medium"
                style={{
                  margin: "12px",
                  marginBottom: "20px",
                  padding: "35px",
                }}
                data-cy="add-subitem-button"
              >
                {addLabelText}
              </Fab>
            </ListItem>
          )}
        </List>
      )}
    </Box>
  );
}
