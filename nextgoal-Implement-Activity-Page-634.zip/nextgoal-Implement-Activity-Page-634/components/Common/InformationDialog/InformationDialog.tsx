import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
} from "@mui/material";
import { FormattedMessage } from "react-intl";

interface ConfirmationDialogProps {
  title: string;
  message: string;
  open: boolean;
  onClose: () => void;
}

export default function ConfirmationDialog({
  title,
  message,
  open,
  onClose,
}: ConfirmationDialogProps) {
  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="lg"
      disableRestoreFocus
      data-cy="information-dialog"
    >
      <DialogTitle>{title}</DialogTitle>
      <DialogContent>
        <span>{message}</span>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>
          <FormattedMessage id="general.close" />
        </Button>
      </DialogActions>
    </Dialog>
  );
}
