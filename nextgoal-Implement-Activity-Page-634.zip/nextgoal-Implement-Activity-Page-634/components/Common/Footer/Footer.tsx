import React from "react";
import { Box, Typography, useTheme } from "@mui/material";
import { FooterText } from "@/components/Common/Texts/Texts";

const Footer = () => {
  const theme = useTheme();

  return (
    <Box
      sx={{
        justifyContent: "center",
        alignItems: "center",
        padding: "30px",
        marginTop: "auto",
        backgroundColor:
          theme.palette.primary.main || theme.palette.background.paper,
        position: "relative",
      }}
    >
      <div>
        <FooterText>
          {/* Placeholder text. */} © 2024 Workzep. All rights reserved.
        </FooterText>
      </div>
    </Box>
  );
};

export default Footer;
