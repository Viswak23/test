import { hoverMainToAdd } from "@/config/styling";
import theme from "@/config/theme";
import { Button, CircularProgress } from "@mui/material";
import { FormattedMessage } from "react-intl";

interface SaveButtonProps {
  saving: boolean;
  onClick: () => void;
  title?: string;
  disabled?: boolean;
}

export default function SaveButton({
  saving,
  onClick,
  title,
  disabled = false,
}: SaveButtonProps) {
  // Can't use defaults because of the translation
  const titleText = title || <FormattedMessage id="general.save" />;

  return (
    <Button
      disabled={saving || disabled}
      startIcon={saving ? <CircularProgress size={20} /> : undefined}
      data-cy="dialog-button-save"
      onClick={onClick}
      style={{ marginRight: "24px" }}
      sx={{ ...hoverMainToAdd(theme) }}
    >
      {saving ? <FormattedMessage id="general.saving" /> : titleText}
    </Button>
  );
}
