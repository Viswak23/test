import { Theme } from "@emotion/react";
import { Button, SxProps } from "@mui/material";
import React from "react";

interface ActionButtonProps {
  children?: React.ReactNode;
  style?: React.CSSProperties;
  onClick?: () => void;
  disabled?: boolean;
  sx?: SxProps<Theme>;
  variant?: "text" | "outlined" | "contained";
  [key: string]: any;
}

export default function PublicActionButton({
  children,
  style,
  onClick,
  disabled,
  variant = "contained",
  sx,
  ...props
}: ActionButtonProps) {
  return (
    <Button
      variant={variant}
      sx={{
        borderRadius: "12px",
        ...sx,
      }}
      style={{ ...style }}
      disabled={disabled}
      onClick={onClick}
      {...props}
    >
      {children}
    </Button>
  );
}
