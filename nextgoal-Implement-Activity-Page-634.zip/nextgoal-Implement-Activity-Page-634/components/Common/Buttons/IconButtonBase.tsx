import React from "react";
import IconButton from "@mui/material/IconButton";
import { hoverMainToAdd } from "@/config/styling";
import { Tooltip, useTheme } from "@mui/material";

export interface IconButtonCommonProps {
  onClick?: () => void;
  tooltip?: string;
  disabledTooltip?: string;
  disabled?: boolean;
  href?: string;
  dataCy?: string;
  sx?: object;
}

interface IconButtonBaseProps {
  onClick?: () => void;
  tooltip: string;
  ariaLabel: string;
  disabled?: boolean;
  href?: string;
  dataCy?: string;
  sx?: object;
  children?: React.ReactNode;
}

export default function IconButtonBase({
  onClick,
  tooltip,
  ariaLabel,
  disabled = false,
  dataCy,
  href,
  sx,
  children,
}: IconButtonBaseProps) {
  const theme = useTheme();

  /*  
    span element is neede to avoid error: You are providing a disabled `button` child to the Tooltip component.
    If putting other way around, you cannot see the tooltip when the element is disabled.
  */
  return (
    <Tooltip title={tooltip}>
      <span>
        <IconButton
          disabled={disabled}
          aria-label={ariaLabel}
          onClick={onClick ? onClick : undefined}
          data-cy={dataCy}
          href={href || ""}
          sx={{
            paddingTop: 0,
            paddingBottom: 0,
            paddingLeft: 0,
            alignContent: "center",
            ...hoverMainToAdd(theme),
            ...sx,
          }}
        >
          {children}
        </IconButton>
      </span>
    </Tooltip>
  );
}
