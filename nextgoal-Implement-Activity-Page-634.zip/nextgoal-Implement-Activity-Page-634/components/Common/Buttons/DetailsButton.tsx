import { KeyboardDoubleArrowRightOutlined } from "@mui/icons-material";
import { useIntl } from "react-intl";
import IconButtonBase, { IconButtonCommonProps } from "./IconButtonBase";

// Details button is used to dive into goal or organisation page from a list item.
export default function DetailsButton(props: IconButtonCommonProps) {
  const intl = useIntl();
  const { tooltip, ...other } = props;

  return (
    <IconButtonBase
      tooltip={tooltip || intl.formatMessage({ id: "general.details" })}
      ariaLabel={intl.formatMessage({ id: "general.details" })}
      {...other}
    >
      <KeyboardDoubleArrowRightOutlined />
    </IconButtonBase>
  );
}
