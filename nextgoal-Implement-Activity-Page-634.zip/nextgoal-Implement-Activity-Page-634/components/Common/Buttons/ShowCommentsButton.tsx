import React from "react";
import { useIntl } from "react-intl";
import { Comment } from "@mui/icons-material";
import IconButtonBase, { IconButtonCommonProps } from "./IconButtonBase";

export default function ShowCommentsButton(props: IconButtonCommonProps) {
  const intl = useIntl();
  const { tooltip, ...other } = props;

  return (
    <IconButtonBase
      tooltip={tooltip || intl.formatMessage({ id: "comment.show.no.count" })}
      ariaLabel={intl.formatMessage({ id: "comment.show.no.count" })}
      {...other}
    >
      <Comment />
    </IconButtonBase>
  );
}
