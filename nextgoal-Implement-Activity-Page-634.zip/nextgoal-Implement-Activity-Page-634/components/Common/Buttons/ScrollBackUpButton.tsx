import { useState, useEffect } from "react";
import { Fab } from "@mui/material";
import ArrowUpwardIcon from "@mui/icons-material/ArrowUpward";
import { styled, useTheme } from "@mui/material/styles";
import { useIntl } from "react-intl";
import { hoverMainAndWhiteToOpposite } from "@/config/styling";

const StyledFab = styled(Fab)(({ theme }) => ({
  position: "fixed",
  bottom: theme.spacing(10),
  right: theme.spacing(2),
  zIndex: 1000,
  ...hoverMainAndWhiteToOpposite(theme),
}));

const ScrollBackUpButton: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener("scroll", toggleVisibility);

    return () => window.removeEventListener("scroll", toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };
  const intl = useIntl();
  const scrollLabel = intl.formatMessage({ id: "general.scroll.back.up" });

  return (
    <div>
      {isVisible && (
        <StyledFab size="medium" onClick={scrollToTop} aria-label={scrollLabel}>
          <ArrowUpwardIcon />
        </StyledFab>
      )}
    </div>
  );
};

export default ScrollBackUpButton;
