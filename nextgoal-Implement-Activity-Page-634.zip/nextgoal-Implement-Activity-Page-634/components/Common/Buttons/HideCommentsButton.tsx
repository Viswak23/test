import React from "react";
import { useIntl } from "react-intl";
import { CommentsDisabled } from "@mui/icons-material";
import IconButtonBase, { IconButtonCommonProps } from "./IconButtonBase";

export default function HideCommentsButton(props: IconButtonCommonProps) {
  const intl = useIntl();
  const { tooltip, ...other } = props;

  return (
    <IconButtonBase
      tooltip={tooltip || intl.formatMessage({ id: "comment.hide" })}
      ariaLabel={intl.formatMessage({ id: "comment.hide" })}
      {...other}
    >
      <CommentsDisabled />
    </IconButtonBase>
  );
}
