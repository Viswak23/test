import { Help } from "@mui/icons-material";
import { useTheme } from "@mui/material/styles";
import { useIntl } from "react-intl";
import IconButtonBase, { IconButtonCommonProps } from "./IconButtonBase";

export default function HelpButton(props: IconButtonCommonProps) {
  const theme = useTheme();
  const intl = useIntl();
  const { tooltip, ...other } = props;

  return (
    <IconButtonBase
      tooltip={tooltip || intl.formatMessage({ id: "general.help" })}
      ariaLabel={intl.formatMessage({ id: "general.help" })}
      {...other}
    >
      <Help />
    </IconButtonBase>
  );
}
