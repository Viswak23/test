import React from "react";
import { useIntl } from "react-intl";
import { ControlPoint } from "@mui/icons-material";
import IconButtonBase, { IconButtonCommonProps } from "./IconButtonBase";

export default function AddButton(props: IconButtonCommonProps) {
  const intl = useIntl();
  const { tooltip, ...other } = props;

  return (
    <IconButtonBase
      tooltip={tooltip || intl.formatMessage({ id: "general.add" })}
      ariaLabel={intl.formatMessage({ id: "general.add" })}
      {...other}
    >
      <ControlPoint />
    </IconButtonBase>
  );
}
