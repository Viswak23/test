import React from "react";
import { useIntl } from "react-intl";
import { List } from "@mui/icons-material";
import IconButtonBase, { IconButtonCommonProps } from "./IconButtonBase";

export default function ListButton(props: IconButtonCommonProps) {
  const intl = useIntl();
  const { tooltip, ...other } = props;

  return (
    <IconButtonBase
      tooltip={tooltip || intl.formatMessage({ id: "general.updates.show" })}
      ariaLabel={intl.formatMessage({ id: "general.updates.show" })}
      {...other}
    >
      <List />
    </IconButtonBase>
  );
}
