import React from "react";
import { AddComment } from "@mui/icons-material";
import { useIntl } from "react-intl";
import IconButtonBase, { IconButtonCommonProps } from "./IconButtonBase";

export default function AddCommentButton(props: IconButtonCommonProps) {
  const intl = useIntl();
  const { tooltip, ...other } = props;

  return (
    <IconButtonBase
      tooltip={tooltip || intl.formatMessage({ id: "comment.add" })}
      ariaLabel={intl.formatMessage({ id: "comment.add" })}
      {...other}
    >
      <AddComment />
    </IconButtonBase>
  );
}
