import { Delete } from "@mui/icons-material";
import { useIntl } from "react-intl";
import IconButtonBase, { IconButtonCommonProps } from "./IconButtonBase";

// Delete button is used with every delete functionality in UI.
export default function DeleteButton(props: IconButtonCommonProps) {
  const intl = useIntl();
  const { tooltip, disabledTooltip, disabled, ...other } = props;

  let resolvedTooltip;
  if (disabled) {
    resolvedTooltip =
      disabledTooltip ||
      intl.formatMessage({
        id: "general.delete.tooltip.only.admin.or.creator",
      });
  } else {
    resolvedTooltip = tooltip || intl.formatMessage({ id: "general.delete" });
  }

  return (
    <IconButtonBase
      tooltip={resolvedTooltip}
      ariaLabel={intl.formatMessage({ id: "general.delete" })}
      disabled={disabled}
      {...other}
    >
      <Delete />
    </IconButtonBase>
  );
}
