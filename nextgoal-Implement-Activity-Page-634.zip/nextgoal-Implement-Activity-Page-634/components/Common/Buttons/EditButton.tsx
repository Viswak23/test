import { Edit } from "@mui/icons-material";
import { useIntl } from "react-intl";
import IconButtonBase, { IconButtonCommonProps } from "./IconButtonBase";

// Edit button is used with every delete functionality in UI.
export default function EditButton(props: IconButtonCommonProps) {
  const intl = useIntl();
  const { tooltip, ...other } = props;

  return (
    <IconButtonBase
      tooltip={tooltip || intl.formatMessage({ id: "general.edit" })}
      ariaLabel={intl.formatMessage({ id: "general.edit" })}
      {...other}
    >
      <Edit />
    </IconButtonBase>
  );
}
