import React from "react";
import { useIntl } from "react-intl";
import { Update } from "@mui/icons-material";
import IconButtonBase, { IconButtonCommonProps } from "./IconButtonBase";

export default function UpdateButton(props: IconButtonCommonProps) {
  const intl = useIntl();
  const { tooltip, ...other } = props;

  return (
    <IconButtonBase
      tooltip={tooltip || intl.formatMessage({ id: "general.update" })}
      ariaLabel={intl.formatMessage({ id: "general.update" })}
      {...other}
    >
      <Update />
    </IconButtonBase>
  );
}
