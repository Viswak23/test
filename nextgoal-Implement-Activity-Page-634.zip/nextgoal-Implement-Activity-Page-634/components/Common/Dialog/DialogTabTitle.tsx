import { Box, DialogTitle, Stack, Tab, Tabs } from "@mui/material";
import { FormTitle } from "../Texts/Texts";
import HelpButton from "../Buttons/HelpButton";
import { FormattedMessage } from "react-intl";

interface DialogTabTitleProps {
  tabValue: number;
  setTabValue: (newValue: number) => void;
  dialogTitle: string;
  handleToggleHelp: () => void;
}

export default function DialogTabTitle({
  tabValue,
  setTabValue,
  dialogTitle,
  handleToggleHelp,
}: DialogTabTitleProps) {
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  return (
    <DialogTitle>
      <Stack direction="row" spacing={1} alignItems={"center"}>
        <Tabs value={tabValue} onChange={handleTabChange} centered>
          <Tab
            label={
              <FormTitle>
                {dialogTitle}
              </FormTitle>
            }
          />
          <Tab
            label={
              <FormTitle>
                <FormattedMessage id="general.dialog.tab.workmate" />
              </FormTitle>
            }
          />
        </Tabs>
        <Box sx={{ flexGrow: 1 }} />
        {/* Help btn */}
        <HelpButton onClick={handleToggleHelp} data-cy="show-edit-goal-help" />
      </Stack>
    </DialogTitle>
  );
}
