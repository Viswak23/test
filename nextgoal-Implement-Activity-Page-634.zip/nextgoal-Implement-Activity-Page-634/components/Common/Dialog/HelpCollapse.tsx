import { Collapse } from "@mui/material";
interface HelpCollapseProps {
  showHelp: boolean;
  helpText: string;
}
export default function HelpCollapse({
  showHelp,
  helpText,
}: HelpCollapseProps) {
  return (
    <Collapse in={showHelp} unmountOnExit>
      <p style={{ marginTop: 0 }}>{helpText}</p>
    </Collapse>
  );
}
