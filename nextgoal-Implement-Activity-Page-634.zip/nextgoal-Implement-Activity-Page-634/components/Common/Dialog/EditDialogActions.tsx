import { DialogActions, Button } from "@mui/material";
import SaveButton from "../Buttons/SaveButton";
import { FormattedMessage } from "react-intl";
import { hoverMainToRed } from "@/config/styling";
import theme from "@/config/theme";

interface EditDialogActionsProps {
  saving: boolean;
  onSave: () => void;
  onCancel: (event?: object, reason?: string) => void;
  saveDisabled?: boolean;
}

export default function EditDialogActions({
  saving,
  onSave,
  onCancel,
  saveDisabled = false,
}: EditDialogActionsProps) {
  return (
    <DialogActions>
      <Button
        onClick={onCancel}
        disabled={saving}
        data-cy="dialog-button-cancel"
        sx={{ ...hoverMainToRed(theme) }}
      >
        <FormattedMessage id="general.cancel" />
      </Button>
      <SaveButton saving={saving} onClick={onSave} disabled={saveDisabled} />
    </DialogActions>
  );
}
