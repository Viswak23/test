"use client";
import React, { useEffect, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
} from "@mui/material";
import { Hub } from "aws-amplify";
import { ConnectionState, CONNECTION_STATE_CHANGE } from "@aws-amplify/pubsub";
import { useImmer } from "use-immer";
import { FormattedMessage, useIntl } from "react-intl";

export default function WebsocketHandler() {
  const [isOffline, setIsOffline] = useState(false);
  const [hasInitialized, setHasInitialized] = useState(false);
  const [dialogContent, setDialogContent] = useImmer({
    title: "",
    message: "",
    requiredReload: false,
  });
  const intl = useIntl();

  useEffect(() => {
    const listener = (data: any) => {
      const { payload } = data;
      if (payload.event === CONNECTION_STATE_CHANGE) {
        const connectionState = payload.data.connectionState as ConnectionState;
        if (!hasInitialized) {
          setHasInitialized(true);
          return;
        }

        if (connectionState === ConnectionState.Connected) {
          setIsOffline(false);
        } else if (
          connectionState === ConnectionState.ConnectedPendingNetwork
        ) {
          setIsOffline(true);
          setDialogContent((draft) => {
            draft.title = intl.formatMessage({
              id: "general.dialog.connection.lost.title",
            });
            draft.message = intl.formatMessage({
              id: "general.dialog.connection.lost.message",
            });
            draft.requiredReload = false;
          });
        } else {
          setIsOffline(true);
          setDialogContent((draft) => {
            draft.title = intl.formatMessage({
              id: "general.dialog.expired.session.title",
            });
            draft.message = intl.formatMessage({
              id: "general.dialog.expired.session.message",
            });
            draft.requiredReload = true;
          });
        }
      }
    };

    Hub.listen("api", listener);

    return () => Hub.remove("api", listener);
  }, [hasInitialized]);

  const handleReload = () => {
    if (dialogContent.requiredReload) {
      window.location.reload();
    } else {
      setIsOffline(false);
    }
  };

  return (
    <>
      {isOffline && (
        <Dialog open={isOffline}>
          <DialogTitle>{dialogContent.title}</DialogTitle>
          <DialogContent>{dialogContent.message}</DialogContent>
          <DialogActions>
            <Button onClick={handleReload} color="primary">
              <FormattedMessage
                id={
                  dialogContent.requiredReload
                    ? "general.reload"
                    : "general.close"
                }
              />
            </Button>
          </DialogActions>
        </Dialog>
      )}
    </>
  );
}
