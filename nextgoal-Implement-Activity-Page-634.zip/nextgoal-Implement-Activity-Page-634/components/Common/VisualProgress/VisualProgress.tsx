import { CSSProperties } from "react";
import { Stack, Box } from "@mui/material";
import LinearProgressWithLabel from "@/components/Common/VisualProgress/LinearProgressWithLabel";
import { TextTimeSince } from "@/components/Common/Texts/Texts";

interface VisualProgressProps {
  label?: string;
  value?: number;
  style?: CSSProperties;
}

export default function VisualProgress({
  label,
  value,
  style,
}: VisualProgressProps) {
  if (value && value < 0) {
    value = 0;
  }

  return (
    <Stack direction="row" spacing={1} alignItems={"center"} style={style}>
      {label && (
        <TextTimeSince style={{ width: "100px" }}>{label}</TextTimeSince>
      )}
      {value != null && value >= 0 && (
        <Box sx={{ minWidth: "100px", paddingRight: "20px" }}>
          {" "}
          {/* width of target date/key result visual progress bars */}
          <LinearProgressWithLabel value={value} />
        </Box>
      )}
    </Stack>
  );
}
