import React, { ReactNode, CSSProperties } from "react";
import {
  InputLabel,
  Typography,
  createTheme,
  ThemeProvider,
  useMediaQuery,
} from "@mui/material";
import Linkify from "react-linkify";
import { SxProps, Theme, useTheme } from "@mui/material/styles";
import CustomBox from "../Layout/CustomBox";
import { Check } from "@mui/icons-material";

interface TextsProps {
  children: ReactNode;
  style?: CSSProperties;
  dataCy?: string;
  sx?: SxProps<Theme>;
}

export function TextTimeSince({ children, style }: TextsProps) {
  return (
    <Typography
      variant="body1"
      component="span"
      sx={{ opacity: 0.6 }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}

export function StatusLabelTxt({ children, sx }: TextsProps) {
  return (
    <Typography
      variant="body1"
      component="span"
      sx={{
        opacity: 0.6,
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

export function StrongText({ children, sx }: TextsProps) {
  return (
    <Typography
      variant="body1"
      component="span"
      sx={{
        fontWeight: "bold",
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

export function EmployeeName({ children, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      variant="body1"
      component="span"
      sx={{
        opacity: 0.6,
        fontWeight: "bold",
        color: theme.palette.primary.main,
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

// "No comment added", etc.
export function LackOfLikes({ children, dataCy }: TextsProps) {
  return (
    <Typography
      variant="body1"
      component="span"
      sx={{
        opacity: 0.5,
        justifyContent: "flex-start",
        padding: "10px",
      }}
    >
      {children}
    </Typography>
  );
}

export function ThoseWhoLike({ children, sx }: TextsProps) {
  const theme = useTheme();

  return (
    <Typography
      variant="body1"
      component="span"
      sx={{
        color: theme.palette.customColors?.night,
        opacity: 0.5,
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

export function CardText({ children }: TextsProps) {
  return <Typography variant="body1">{children}</Typography>;
}

export function TabTitle({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      variant="h5"
      style={style}
      sx={{
        fontWeight: "bold",
        padding: "20px",
        paddingBottom: "10px",
        justifyContent: "center",
        margin: "20px",
        color: theme.palette.secondary.main,
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

export function TabSubTitle({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      style={style}
      sx={{
        color: theme.palette.secondary.main,
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

export function DetailsText({ children, style, sx }: TextsProps) {
  return (
    <Typography
      variant="body1"
      fontSize={{
        xs: "13px",
        sm: "15px",
      }}
      style={{
        ...style,
      }}
      sx={{
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

// Main page goals cards' title
export function FormTitle({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      variant="h6"
      color={theme.palette.primary.main}
      fontSize={{
        xs: "18px",
        sm: "20px",
      }}
      sx={{
        flexGrow: 1,
        paddingLeft: 1,
        textAlign: "initial",
        fontWeight: "bold",
        ...sx,
      }}
      style={style}
    >
      {children}
    </Typography>
  );
}

// Form descripiton
export function FormDescription({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      variant="h5"
      component="span"
      fontSize={{
        xs: "16px",
        sm: "18px",
      }}
      style={{ ...style }}
      sx={{
        color: theme.palette.customColors?.night,
        padding: "0px 10px 5px 10px",
        margin: "auto 0px 0px 15px 0px",
        textAlign: "initial",
        justifyContent: "flex-start",
        ...sx,
      }}
    >
      <p>{children}</p>
    </Typography>
  );
}

export function FormText({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      variant="h6"
      component="span"
      fontSize={{
        xs: "15px",
        sm: "16px",
      }}
      style={{ ...style }}
      sx={{
        color: theme.palette.customColors?.night,
        opacity: 0.6,
        fontWeight: "initial",
        padding: "0px 10px 5px 10px",
        margin: "auto 0px 0px 16px 0px",
        textAlign: "initial",
        justifyContent: "flex-start",
        ...sx,
      }}
    >
      <p>{children}</p>
    </Typography>
  );
}

// The user's email
export function EmailDetailsText({ children, style, sx }: TextsProps) {
  const theme = useTheme();

  return (
    <CustomBox>
      <Typography
        variant="body1"
        style={style}
        fontSize={{
          xs: "13px",
          sm: "15px",
        }}
        sx={{
          color: theme.palette.secondary.main,
          opacity: "0.8",
          textAlign: "center",
          fontFamily: "sans-serif",
          ...sx,
        }}
      >
        {children}
      </Typography>
    </CustomBox>
  );
}

export function DetailsTextWithoutCustomBox({
  children,
  style,
  sx,
}: TextsProps) {
  return (
    <Typography variant="body1" style={style} sx={{ ...sx }}>
      {children}
    </Typography>
  );
}

export function DetailsLabel({ children, style, sx }: TextsProps) {
  return (
    <Typography
      variant="body1"
      sx={{
        opacity: 0.6,
        padding: "0px",
        ...sx,
      }}
      style={{
        ...style,
      }}
    >
      {children}
    </Typography>
  );
}

export function ListText({ children }: TextsProps, multiline: boolean = true) {
  if (children?.toString().includes("\n") && multiline) {
    const lines = children?.toString().split("\n");
    children = lines.map((line, index) => (
      <React.Fragment key={index}>
        {line}
        {index < lines.length - 1 && <br />}
      </React.Fragment>
    ));
  }

  return (
    <Typography variant="body1" component="span">
      {/* Linkify will scan the text for any links and makes them clickable.*/}
      <Linkify> {children}</Linkify>
    </Typography>
  );
}
export function LightText({ children, sx }: TextsProps) {
  return (
    <Typography
      variant="body1"
      sx={{
        opacity: "60%",
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

export function ListSecondaryText({ children, sx }: TextsProps) {
  return (
    <Typography
      variant="body1"
      sx={{
        opacity: 0.6,
        fontWeight: 400,
        fontSize: "0.875rem",
        lineHeight: "20px",
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

export function Label({ children }: TextsProps) {
  return <InputLabel sx={{ fontSize: "0.8rem" }}>{children}</InputLabel>;
}

export function FeedTitle({ children }: TextsProps) {
  return (
    <Typography variant="body1" sx={{ fontWeight: "bold" }}>
      <Linkify>{children}</Linkify>
    </Typography>
  );
}

// Employee name displayed in comments/etc.
export function FeedEmployeeNameTxt({ children, style, sx }: TextsProps) {
  const theme = useTheme();

  return (
    <Typography
      variant="body2"
      style={{ ...style }}
      sx={{
        fontWeight: "bold",
        opacity: 0.7,
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

// Comment/feed item title text
export function FeedTitleTxt({ children, style, sx }: TextsProps) {
  const theme = useTheme();

  return (
    <Typography
      variant="body2"
      style={{ ...style }}
      sx={{
        color: theme.palette.customColors?.night,
        opacity: 0.6,
        fontWeight: "bold",
        fontSize: "14.5px",
        marginBottom: "5px",
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

export function TaggedEmployeesTxt({ children, style, sx }: TextsProps) {
  const theme = useTheme();

  return (
    <Typography
      variant="body2"
      style={{ ...style }}
      sx={{
        color: theme.palette.customColors?.night,
        opacity: 0.6,
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

// Days ago label displayed in comments/etc.
export function FeedDaysAgoTxt({ children, style, sx }: TextsProps) {
  const theme = useTheme();

  return (
    <Typography
      variant="body2"
      style={{ ...style }}
      sx={{
        color: theme.palette.customColors?.night,
        opacity: 0.6,
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

const headingTheme = createTheme();

headingTheme.typography.h5 = {
  fontSize: "1.2rem",
  "@media (min-width:600px)": {
    fontSize: "1.5rem",
  },
  [headingTheme.breakpoints.up("md")]: {
    fontSize: "1.8rem",
  },
};

// Pages' main heading typography!
export function HeadingMain({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <ThemeProvider theme={headingTheme}>
      <Typography
        variant="h5" // automatically resizes
        component="h1"
        align="center"
        sx={{
          marginTop: "18px",
          padding: "0px 6px 32px 6px",
          color: theme.palette.primary.main,
          fontWeight: "bold",

          ...sx,
        }}
      >
        {children}
      </Typography>
    </ThemeProvider>
  );
}

// The goals/main page layout has diff. requirements than the other pages, hence the separation
export function HeadingMain2({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <ThemeProvider theme={headingTheme}>
      <Typography
        variant="h5" // automatically resizes
        component="h1"
        align="center"
        sx={{
          padding: "0px 6px 6px 6px",
          color: theme.palette.primary.main,
          fontWeight: "bold",
          ...sx,
        }}
      >
        {children}
      </Typography>
    </ThemeProvider>
  );
}

// Main page goals cards' title
export function HeadingCard({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      variant="h6"
      noWrap
      color={theme.palette.primary.main}
      sx={{
        flexGrow: 1,
        paddingLeft: 2,
        ...sx,
      }}
      style={style}
    >
      {children}
    </Typography>
  );
}

export function GroupHeadingCard({ children, style, sx }: TextsProps) {
  const theme = useTheme();

  return (
    <Typography
      variant="h6"
      sx={{
        flexGrow: 1,
        color: theme.palette.primary.main,
        fontWeight: "bold",
        ...sx,
      }}
      style={style}
    >
      {children}
    </Typography>
  );
}

export function SubheadingCard({ children, style, sx }: TextsProps) {
  const theme = useTheme();

  return (
    <Typography
      variant="body2"
      style={{ ...style }}
      sx={{
        color: theme.palette.secondary.main,
        fontWeight: "bold",
        margin: "12px 0px 12px 0px",
        fontSize: "20px",
        ...sx,
      }}
      noWrap
    >
      {children}
    </Typography>
  );
}

export function SubheadingSmallCard({ children, style }: TextsProps) {
  const theme = useTheme();

  return (
    <Typography variant="body2" style={style}>
      {children}
    </Typography>
  );
}

export function CardTitle({ children, sx }: TextsProps) {
  const theme = useTheme();
  const isBelowMd = useMediaQuery(theme.breakpoints.down("md"));

  return (
    <Typography
      variant="h5"
      component="span"
      fontSize={{
        xs: "25px",
        sm: "27px",
      }}
      sx={{
        marginTop: isBelowMd ? "0" : "8px",
        fontFamily: "sans-serif",
      }}
    >
      {children}
    </Typography>
  );
}

// THE PUBLIC PAGES' TYPOGRAPHIES

// App title
export function AppTitle({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      color={theme.palette.primary.main}
      style={{ ...style }}
      sx={{
        marginTop: "5px",
        textAlign: "center",
        fontWeight: "bold",
        paddingBottom: "10px",
        fontSize: "60px",
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

export function ChapterHeading({ children, style, sx }: TextsProps) {
  const theme = useTheme();

  return (
    <Typography
      component="h4"
      margin={{
        xs: "auto 20px",
        sm: "auto 15px",
        md: "auto 12px",
      }}
      style={{ ...style }}
      sx={{
        color: theme.palette.primary.main,
        fontSize: "30px",
        textAlign: "center",
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

// The one sentence summary below the Workzep title
export function IntroSloganText({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      variant="h5"
      component="h1"
      color={theme.palette.primary.main}
      style={{ ...style }}
      sx={{
        margin: "15px 20px 0px 20px",
        paddingBottom: "10px",
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

export function SloganText({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      variant="h5"
      component="h1"
      color={theme.palette.primary.main}
      style={{ ...style }}
      sx={{
        margin: "15px 20px 0px 20px",
        paddingBottom: "10px",
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

export function BodyText({ children, style, sx }: TextsProps) {
  return (
    <Typography
      variant="body1"
      component="span"
      style={{ ...style }}
      sx={{
        fontSize: "18px",
        padding: "0px 30px 30px 30px",
        margin: "0px 15px 0px 15px",
        ...sx,
      }}
    >
      <p>{children}</p>
    </Typography>
  );
}

// public home page box's text
export function BoxBodyText({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      variant="h4"
      component="span"
      color={theme.palette.customColors?.chick}
      fontSize={{
        xs: "18px",
        sm: "20px",
      }}
      style={{ ...style }}
      sx={{
        padding: "0px 30px 30px 30px",
        margin: "0px 15px 0px 15px",
        textAlign: "center",
        ...sx,
      }}
    >
      <p>{children}</p>
    </Typography>
  );
}

// Title text before 3 columns
export function ColumnBodyTitle({ children, style, sx }: TextsProps) {
  const theme = useTheme();

  return (
    <Typography
      variant="h5"
      component="span"
      fontSize={{
        xs: "25px",
        sm: "27px",
      }}
      style={{ ...style }}
      sx={{
        margin: "auto",
        fontFamily: "sans-serif",
        textAlign: "center",
        ...sx,
      }}
    >
      {children}
    </Typography>
  );
}

// Description text before 3 columns
export function ColumnBodyDescription({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      variant="body1"
      component="span"
      color={theme.palette.customColors?.night}
      style={{ ...style }}
      sx={{
        fontSize: "18px",
        padding: "0px 30px 35px 30px",
        margin: "auto 0px 15px 0px 15px",
        textAlign: "center",
        justifyContent: "center",
        ...sx,
      }}
    >
      <p>{children}</p>
    </Typography>
  );
}

export function ListBullet({ children, style, sx }: TextsProps) {
  return (
    <li style={{ paddingTop: "12px", ...style }}>
      <Typography
        variant="body1"
        component="span"
        sx={{
          fontSize: "18px",
          ...sx,
        }}
      >
        {/* p tags here add space between points */}
        {children}
      </Typography>
    </li>
  );
}

export function FooterText({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      variant="h6"
      textAlign="center"
      color={theme.palette.customColors?.bright}
      sx={{
        fontWeight: 400,
        fontSize: "0.875rem",
        ...sx,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function RegisterTitle({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      variant="h2"
      textAlign="center"
      color={theme.palette.primary.dark}
      sx={{
        fontWeight: 400,
        fontSize: "1.3rem",
        ...sx,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function ConfirmationTitle({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      component="h2"
      variant="h4"
      color={theme.palette.primary.dark}
      sx={{
        fontWeight: "bold",
        marginY: "15px",
        ...sx,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function ConfirmationDescription({ children, style, sx }: TextsProps) {
  return (
    <Typography
      variant="body1"
      sx={{
        marginY: "15px",
        fontSize: "20px",
        ...sx,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function SettingsParagraph({ children, style, sx }: TextsProps) {
  return (
    <Typography
      variant="body1"
      sx={{
        ...sx,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function NotificationHeader({ children, style, sx }: TextsProps) {
  return (
    <Typography
      variant="body1"
      sx={{
        marginY: "15px",
        fontSize: "16px",
        ...sx,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}

export function PricingHeading({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      textAlign={"center"}
      variant="h1"
      component="h1"
      color={theme.palette.customColors.night}
      sx={{
        fontSize: "2rem",

        ...sx,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function PricingHeadingHighlight({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      textAlign={"center"}
      variant="h1"
      component="span"
      color="secondary.main"
      sx={{
        fontSize: "2rem",

        ...sx,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}

export function PricingBody({ children, style, sx }: TextsProps) {
  return (
    <Typography
      variant="body1"
      textAlign={"center"}
      sx={{ opacity: "0.7", ...sx }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}

export function CardFeatureText({ children, style, sx }: TextsProps) {
  return (
    <Typography
      py={"5px"}
      variant="body1"
      component="span"
      sx={{
        fontSize: "16px",
        display: "flex",
        alignItems: "start",
        ...sx,
      }}
      style={{ ...style }}
    >
      <Check
        sx={{
          color: "secondary.main",
          fontWeight: "bold",
          marginRight: "5px",
        }}
      />{" "}
      {children}
    </Typography>
  );
}
export function NotificationTitle({ children, style, sx }: TextsProps) {
  const theme = useTheme();
  return (
    <Typography
      variant="h4"
      color={theme.palette.primary.dark}
      sx={{
        fontSize: "14px",
        ...sx,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}

export function BenefitsText({ children, style, sx }: TextsProps) {
  return (
    <Typography
      variant="h3"
      component="span"
      sx={{
        fontSize: "1.5rem",
        ...sx,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function NotificationBody({ children, style, sx }: TextsProps) {
  return (
    <Typography
      variant="body1"
      sx={{
        fontSize: "14px",
        opacity: 0.6,
        ...sx,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}

export function ClickableText({ children, style, sx }: TextsProps) {
  // it's not actually clickable but has the cursor pointer.
  return (
    <Typography
      variant="body1"
      sx={{
        fontSize: "14px",
        textAlign: "center",
        marginBottom: "10px",
        color: "primary.light",
        ":hover": {
          cursor: "pointer",
          color: "customColors.pressed",
        },
        ...sx,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
