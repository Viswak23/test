import { DesktopSidebarSkeleton } from "@/components/Sidebar/DesktopBar";
import { Box, CircularProgress } from "@mui/material";

export default function PageLoading() {
  return (
    <Box
      style={{
        width: "auto",
        height: "auto",
        textAlign: "center",
        paddingTop: "80px",
      }}
    >
      <DesktopSidebarSkeleton />
      <CircularProgress style={{ marginTop: "64px" }} />
    </Box>
  );
}
