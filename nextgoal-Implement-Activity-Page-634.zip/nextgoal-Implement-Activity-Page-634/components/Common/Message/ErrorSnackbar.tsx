import { Snackbar } from "@mui/material";
import { SyntheticEvent } from "react";

interface ErrorSnackbarProps {
  error: string | null;
  setError: (message: string | null) => void;
}

export default function ErrorSnackbar({ error, setError }: ErrorSnackbarProps) {
  const handleClose = (event?: SyntheticEvent | Event, reason?: string) => {
    if (reason === "clickaway") {
      return;
    }
    setError(null);
  };

  return (
    <Snackbar
      open={!!error}
      autoHideDuration={3000}
      message={error}
      onClose={handleClose}
    />
  );
}
