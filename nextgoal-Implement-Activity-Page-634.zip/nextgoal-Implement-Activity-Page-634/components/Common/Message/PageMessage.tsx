import { Box, Typography } from "@mui/material";
import { ReactNode } from "react";

interface PageMessageProps {
  message: string;
  children?: ReactNode;
}
export default function PageMessage({ message, children }: PageMessageProps) {
  return (
    <Box
      mx="auto"
      mt={10}
      paddingTop="3rem"
      px="auto"
      display="flex"
      flexDirection="column"
      justifyContent="center"
      alignItems="center"
      gap={3}
      style={{ marginTop: "120px" }}
    >
      <Typography variant="h5">{message}</Typography>
      {children}
    </Box>
  );
}
