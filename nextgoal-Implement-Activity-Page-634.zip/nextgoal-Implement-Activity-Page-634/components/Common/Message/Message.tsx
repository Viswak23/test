import { useState } from "react";
import { deleteMessage, getMessage } from "@/lib/localStorage";
import { Snackbar } from "@mui/material";

export default function Message() {
  const [message, setMessage] = useState(getMessage);

  const handleClose = () => {
    deleteMessage();
    setMessage("");
  };
  return (
    <Snackbar
      open={!!message}
      autoHideDuration={3000}
      message={message}
      onClose={handleClose}
    />
  );
}
