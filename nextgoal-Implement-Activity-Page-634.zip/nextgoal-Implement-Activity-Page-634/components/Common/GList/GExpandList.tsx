import React, { useState, ReactNode } from "react";
import { Box, Collapse, Stack, List, useTheme } from "@mui/material";
import { SubheadingCard } from "@/components/Common/Texts/Texts";
import ExpandMore from "@/components/Common/ExpandMore/ExpandMore";
import { FormattedMessage } from "react-intl";
import AddButton from "../Buttons/AddButton";

export interface GExpandListProps {
  title: string;
  children: ReactNode;
  visibleElements?: React.ReactNode;
  onAdd?: () => void;
  addDisabled?: boolean;
  style?: React.CSSProperties;
  dataCy?: string;
}

export default function GExpandList({
  title,
  children,
  visibleElements,
  onAdd,
  addDisabled = false,
  style,
  dataCy,
}: GExpandListProps) {
  const [expanded, setExpanded] = useState(false);

  const handleAdd = () => {
    setExpanded(true);
    if (onAdd) {
      onAdd();
    }
  };

  const theme = useTheme();

  return (
    <Box style={{ ...style }} data-cy={dataCy}>
      <Stack
        direction="row"
        sx={{
          alignItems: "center",
          justifyContent: "flex-start",
          marginTop: "18px",
        }}
        spacing={1}
      >
        <SubheadingCard style={{ marginLeft: "18px" }}>{title}</SubheadingCard>
        {children && (
          <ExpandMore
            expand={expanded}
            onClick={() => setExpanded(!expanded)}
            aria-expanded={expanded}
            aria-label={`Show all ${title}`}
            sx={{ padding: 0 }}
            expandedTooltip={<FormattedMessage id="general.show.less" />}
            collapsedTooltip={<FormattedMessage id="general.show.more" />}
          />
        )}
        {onAdd && (
          <AddButton
            aria-label={`Add ${title}`}
            onClick={handleAdd}
            disabled={addDisabled}
            dataCy="add-button"
          />
        )}
      </Stack>
      {visibleElements}
      <Collapse in={expanded} timeout="auto" unmountOnExit>
        <List
          dense={true}
          style={{ paddingTop: 0, marginTop: "6px", marginRight: "12px" }}
        >
          {children}
        </List>
      </Collapse>
    </Box>
  );
}
