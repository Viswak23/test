import React from "react";
import { Box } from "@mui/material";
import { ListText, TextTimeSince } from "@/components/Common/Texts/Texts";
import { calculateDaysOfStatus } from "@/lib/time";
import { useIntl } from "react-intl";

interface GListRowTimeAndStatusProps {
  time?: string;
  status?: string | null;
}

export default function GListRowTimeAndStatus({
  time,
  status,
}: GListRowTimeAndStatusProps) {
  const intl = useIntl();

  return (
    <Box>
      <TextTimeSince>{`${calculateDaysOfStatus(intl, time)} `}</TextTimeSince>
      <ListText>{status}</ListText>
    </Box>
  );
}
