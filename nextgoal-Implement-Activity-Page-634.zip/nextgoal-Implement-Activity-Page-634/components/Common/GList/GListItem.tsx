import React from "react";
import {
  Avatar,
  ListItem,
  ListItemAvatar,
  Stack,
  Tooltip,
  useMediaQuery,
} from "@mui/material";
import { useEmployees } from "@/contexts/EmployeesContext";
import { getEmployeeByEmail } from "@/lib/webEmployee";

interface GListItemProps {
  avatarEmail?: string;
  children: React.ReactNode;
  style?: React.CSSProperties;
  showNoAvatar?: boolean;
  commenterName?: string;
  separateAvatar?: boolean;
}

export default function GListItem({
  avatarEmail,
  children,
  style,
  showNoAvatar = false,
}: GListItemProps) {
  const employees = useEmployees()?.employees;
  const owner = getEmployeeByEmail(employees, avatarEmail);
  const isNarrowerScreen = useMediaQuery("(max-width:470px)");

  return (
    <ListItem>
      {!showNoAvatar && (
        <>
          {avatarEmail && (
            <Stack
              direction={isNarrowerScreen ? "column" : "row"} // Switch direction based on screen width
              alignItems={isNarrowerScreen ? "center" : "flex-start"} // Align items accordingly
              sx={
                isNarrowerScreen
                  ? { marginBottom: "10px", justifyContent: "center" }
                  : undefined
              } // Center everything when screen width is below 470px
            >
              <Tooltip title={avatarEmail}>
                <ListItemAvatar>
                  <Avatar
                    src={owner?.resolvedAvatarUrl}
                    sx={{
                      width: "43px",
                      height: "43px",
                      border: "black 2px",
                    }}
                  />
                </ListItemAvatar>
              </Tooltip>
              <Stack direction="column" spacing={0} style={style}>
                {children}
              </Stack>
            </Stack>
          )}
        </>
      )}
    </ListItem>
  );
}
