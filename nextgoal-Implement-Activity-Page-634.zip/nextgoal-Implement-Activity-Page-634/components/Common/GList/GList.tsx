import React, { ReactNode } from "react";
import {
  Box,
  Icon,
  List,
  ListItem,
  ListItemText,
  Stack,
  Tooltip,
  useTheme,
} from "@mui/material";
import { SubheadingCard } from "@/components/Common/Texts/Texts";
import { Label } from "@/components/Common/Texts/Texts";
import { FormattedMessage, useIntl } from "react-intl";
import AddButton from "../Buttons/AddButton";

export enum GoalListTitleStyle {
  DETAILS,
  DIALOG,
}

interface GListProps {
  children: ReactNode;
  title?: string;
  titleStyle?: GoalListTitleStyle;
  noResultsText?: string;
  icon?: React.ReactNode;
  onAdd?: () => void;
  addDisabled?: boolean;
  marginTop?: boolean;
}

export default function GList({
  children,
  title,
  titleStyle = GoalListTitleStyle.DETAILS,
  noResultsText,
  icon,
  onAdd,
  addDisabled = false,
  marginTop = true,
}: GListProps) {
  const intl = useIntl();
  const theme = useTheme();

  return (
    <Box style={marginTop ? { marginTop: "12px" } : undefined}>
      <Stack direction="row" spacing={1}>
        {icon && (
          <Icon aria-label={intl.formatMessage({ id: "redflags.title" })}>
            {icon}
          </Icon>
        )}
        {title &&
          (titleStyle === GoalListTitleStyle.DETAILS ? (
            <SubheadingCard>{title}</SubheadingCard>
          ) : (
            <Label>{title}</Label>
          ))}
        {onAdd && (
          <AddButton
            aria-label={intl.formatMessage(
              {
                id: "general.add.item",
              },
              { name: title }
            )}
            tooltip={intl.formatMessage(
              {
                id: "general.add.item",
              },
              { name: title }
            )}
            onClick={onAdd}
            disabled={addDisabled}
            dataCy="add-button"
          />
        )}
      </Stack>
      {(children || noResultsText) && (
        <List
          dense={true}
          style={{ paddingTop: 0, marginTop: "6px", marginRight: "12px" }}
        >
          {!children && noResultsText && (
            <ListItem>
              <ListItemText
                primary={noResultsText}
                style={{ fontStyle: "italic", opacity: 0.6 }}
              />
            </ListItem>
          )}
          {children}
        </List>
      )}
    </Box>
  );
}
