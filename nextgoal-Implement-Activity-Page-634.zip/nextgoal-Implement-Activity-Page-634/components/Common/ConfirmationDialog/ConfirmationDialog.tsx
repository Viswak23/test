import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Stack,
} from "@mui/material";
import SaveButton from "../Buttons/SaveButton";
import { FormattedMessage, useIntl } from "react-intl";

interface ConfirmationDialogProps {
  title: string;
  message: string;
  messageItem?: string;
  open: boolean;
  saving: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export default function ConfirmationDialog({
  title,
  message,
  messageItem,
  open,
  saving,
  onConfirm,
  onCancel,
}: ConfirmationDialogProps) {
  const intl = useIntl();

  return (
    <Dialog open={open} onClose={onCancel} maxWidth="lg" disableRestoreFocus>
      <DialogTitle>{title}</DialogTitle>
      <DialogContent>
        <Stack direction="column" spacing={1} alignItems="center">
          <span>{message}</span>
          <span>{messageItem}</span>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button
          onClick={onCancel}
          disabled={saving}
          data-cy="dialog-button-cancel"
        >
          <FormattedMessage id="general.cancel" />
        </Button>
        <SaveButton
          saving={saving}
          onClick={onConfirm}
          title={intl.formatMessage({ id: "general.ok" })}
        />
      </DialogActions>
    </Dialog>
  );
}
