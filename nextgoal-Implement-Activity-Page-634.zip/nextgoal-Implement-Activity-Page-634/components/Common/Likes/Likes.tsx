import { useEffect, useState } from "react";
import { Box, IconButton, Stack, Tooltip, useTheme } from "@mui/material";
import ThumbUp from "@mui/icons-material/ThumbUp";
import { useAuthStatus } from "@/lib/customHooks";
import { updateEventDb } from "@/lib/webEvents";
import { FormattedMessage, useIntl } from "react-intl";
import { Event } from "@/src/API";

import ErrorSnackbar from "../Message/ErrorSnackbar";
import { log } from "@/lib/backend/actions/logger";
import { hoverLighterToSecondary } from "@/config/styling";
import {
  createNewNotification,
  NotificationType,
} from "@/lib/webNotifications";
import {
  EmployeeWithAvatarUrl,
  useEmployees,
} from "@/contexts/EmployeesContext";

interface LikesProps {
  event: Event;
  taggedEmployees: EmployeeWithAvatarUrl[] | null;
}

export default function Likes({ event, taggedEmployees }: LikesProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const theme = useTheme();
  const currentUser = useAuthStatus()?.attributes.email;
  const intl = useIntl();
  const likeLabel = intl.formatMessage({ id: "general.like" });
  const employees = useEmployees()?.employees;

  useEffect(() => {
    const exists = event.likes?.find((like) => like === currentUser);
    setIsLiked(!!exists);
  }, [event.likes, currentUser]);

  const handleLikeClick = async () => {
    const currentLike = !isLiked;
    const isExistingLike = event.likes?.some((like) => like === currentUser);

    if (
      isLoading ||
      (currentLike && isExistingLike) ||
      (!currentLike && !isExistingLike)
    ) {
      return;
    }

    setIsLoading(true);
    const updatedLikes = currentLike
      ? (event.likes || []).concat(currentUser)
      : (event.likes || []).filter((like) => like !== currentUser);

    try {
      await updateEventDb({
        id: event.id,
        likes: updatedLikes,
      });
      if (!isExistingLike) {
        const eventOwner = employees?.find((e) => e.email === event.owner);
        let employeesOfInterest = taggedEmployees || [eventOwner]; // if tagged employees, the event owner is one of them automatically.
        await createNewNotification(
          NotificationType.LIKE,
          employeesOfInterest,
          currentUser,
          event.id
        );
      }
      setIsLiked(currentLike);
    } catch (error: any) {
      log(`Update Like: ${error.message}`);
      setError("Failed to update likes. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const tooltip = isLiked ? (
    <FormattedMessage id="likes.remove" />
  ) : (
    <FormattedMessage id="likes.like" />
  );
  const likesTitle = (
    <FormattedMessage
      id="likes.likes"
      values={{ count: event.likes?.length || 0 }}
    />
  );

  return (
    <Box style={{ marginRight: "10px" }}>
      <Stack
        direction={{ xs: "column", sm: "row" }}
        spacing={1}
        alignItems="center"
        sx={{
          justifyContent: {
            xs: "center",
            sm: "flex-start",
          },
          padding: {
            xs: "20px 20px 0x 0px",
            sm: "5px 0px 5px 20px",
          },
          marginLeft: {
            xs: "10px",
            sm: "5px",
          },
        }}
      >
        {/* Like btn for comments */}
        <IconButton
          aria-label={likeLabel}
          size="small"
          onClick={handleLikeClick}
          disabled={isLoading}
          sx={{ ...hoverLighterToSecondary(theme) }}
          data-cy="feed-item-likes"
        >
          <Tooltip title={tooltip}>
            <ThumbUp
              style={
                isLiked
                  ? { color: theme.palette.customColors?.add }
                  : { color: theme.palette.customColors?.lighter }
              }
            />
          </Tooltip>
        </IconButton>
        <span data-cy="likes-count">{likesTitle}</span>
      </Stack>
      <ErrorSnackbar error={error} setError={setError} />
    </Box>
  );
}
