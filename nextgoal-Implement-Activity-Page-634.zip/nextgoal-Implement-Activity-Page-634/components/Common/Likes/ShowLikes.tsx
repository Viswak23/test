import { useMemo } from "react";
import { Box, Stack, Tooltip, useTheme } from "@mui/material";
import {
  DetailsText,
  EmployeeName,
  LackOfLikes,
  ListSecondaryText,
  StatusLabelTxt,
  ThoseWhoLike,
} from "../Texts/Texts";
import { useEmployees } from "@/contexts/EmployeesContext";
import { FormattedMessage } from "react-intl";

interface ShowLikesProps {
  likes?: string[] | null;
}

export default function ShowLikes({ likes }: ShowLikesProps) {
  const employees = useEmployees()?.employees;
  const theme = useTheme();

  const likesWithNames = useMemo(
    () =>
      likes?.map((like) => {
        const employee = employees?.find((employee) => employee.email === like);
        return { name: employee?.name || like, email: like };
      }),
    [likes, employees]
  );

  if (!likes || likes.length === 0) {
    return (
      <Box sx={{ marginBottom: "12px" }}>
        <LackOfLikes>
          <FormattedMessage id="likes.no.likes" />
        </LackOfLikes>
      </Box>
    );
  }

  const likesLabel = (
    <ThoseWhoLike>
      <FormattedMessage
        id="likes.people.who.like"
        values={{ count: likes.length || 0 }}
      />
    </ThoseWhoLike>
  );

  return (
    <Stack
      direction={{ xs: "column", sm: "row" }}
      spacing={1}
      alignItems="center"
    >
      <Box>
        <DetailsText>{likesLabel}</DetailsText>
      </Box>
      <Stack direction="row">
        {likesWithNames?.map((like, index) => (
          <ListSecondaryText
            key={like.email}
            sx={{ color: theme.palette.customColors?.lighter }}
          >
            <Tooltip title={like.email}>
              <span>{like.name}</span>
            </Tooltip>
            {index < likes.length - 1 && ","}
          </ListSecondaryText>
        ))}
      </Stack>
    </Stack>
  );
}
