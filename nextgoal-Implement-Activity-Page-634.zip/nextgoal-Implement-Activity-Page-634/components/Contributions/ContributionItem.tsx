import { useMemo } from "react";
import { calculateDaysOfStatus } from "@/lib/time";
import { Contribution } from "@/src/API";
import FeedItem from "../Feeds/FeedItem";
import { AttachmentFile, useAttachmentUrls } from "@/lib/webAttachment";
import { EventType, getEventEmployeesTitle } from "@/lib/webEvents";
import { canDeleteDbItem } from "@/lib/webHelpers";
import { useIntl } from "react-intl";
import ContributionFeedDescription from "./ContributionFeedDescription";

interface ContributionItemProps {
  contribution?: Contribution | null;
  onEdit: (contribution: Contribution) => void;
  onDelete: (contribution: Contribution, attachments: AttachmentFile[]) => void;
}

export default function ContributionItem({
  contribution,
  onEdit,
  onDelete,
}: ContributionItemProps) {
  const rawAtachments = useMemo(
    () => (contribution ? (contribution?.attachments as string[]) : []),
    [contribution]
  );
  const attachments = useAttachmentUrls(rawAtachments as string[]);
  const intl = useIntl();

  if (!contribution) {
    return null;
  }

  const handleEdit = () => {
    if (onEdit && contribution) {
      onEdit(contribution);
    }
  };

  const handleDelete = () => {
    onDelete(contribution, attachments);
  };

  if (!contribution) {
    return null;
  }

  const timeSince = calculateDaysOfStatus(intl, contribution.createdAt);

  return (
    <FeedItem
      title={intl.formatMessage({ id: "contributions.contribution.title" })}
      subheader={timeSince}
      description={<ContributionFeedDescription contribution={contribution} />}
      creatorEmail={contribution.creatorEmail}
      comments={contribution.comments?.items}
      attachments={attachments}
      taggedEmployeeJoins={contribution.employeeJoins}
      employeeIdField={"employeeContributionEmployeeJoinsId"}
      taggedEmployeesTitle={getEventEmployeesTitle(
        intl,
        EventType.CONTRIBUTION_ADDED
      )}
      currentGoalId={contribution.goalContributionsId!}
      contributionId={contribution.id}
      deleteDisabled={!canDeleteDbItem(contribution)}
      onEdit={handleEdit}
      onDelete={handleDelete}
      tooltips={{
        editTooltip: intl.formatMessage({ id: "contributions.edit" }),
        deleteTooltip: intl.formatMessage({
          id: "contributions.delete.caption",
        }),
        deleteDisabledTooltip: intl.formatMessage({
          id: "contributions.delete.disabled.tooltip",
        }),
      }}
    />
  );
}
