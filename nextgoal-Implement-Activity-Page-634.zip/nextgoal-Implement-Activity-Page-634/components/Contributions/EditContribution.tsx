import { useEffect, useMemo, useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import TextField from "@mui/material/TextField";
import {
  Contribution,
  CreateContributionInput,
  UpdateContributionInput,
} from "@/src/API";
import { useImmer } from "use-immer";
import {
  addContributionDb,
  updateContributionDb,
} from "@/lib/webContributions";
import { Alert } from "@mui/material";
import { useAuthStatus } from "@/lib/customHooks";
import {
  EmployeeWithAvatarUrl,
  useEmployees,
} from "@/contexts/EmployeesContext";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import {
  AttachmentFile,
  AttachmentOwner,
  deleteAttachments,
  saveAttachments,
  useAttachmentUrls,
} from "@/lib/webAttachment";
import TaggedEmployees from "../Common/TaggedEmployees/TaggedEmployees";
import HandleAttachments from "../Common/Attachment/HandleAttachments";
import { EventType, getEventEmployeesTitle } from "@/lib/webEvents";
import { FormattedMessage, useIntl } from "react-intl";
import { isEmployeeGoal } from "@/lib/webEmployee";
import { useGoals } from "@/contexts/GoalsContext";
import { log } from "@/lib/backend/actions/logger";
import HelpCollapse from "../Common/Dialog/HelpCollapse";
import DialogTabTitle from "../Common/Dialog/DialogTabTitle";
import {
  ChatDialogState,
  defaultChatDialogState,
} from "../Chat/ChatDialogState";
import { useOrganization } from "@/contexts/OrganizationContext";
import { useNorthStars } from "@/contexts/NorthStarsContext";
import { TabPanel } from "../Settings/TabPanel";
import DialogChat from "../Chat/ChatInDialog";
import { getGoalBackgroundInfo } from "@/lib/webGoals";

interface EditContributionProps {
  goalId?: string | null;
  contribution?: Contribution;
  open: boolean;
  onClose: (scrollToTop: Boolean) => void;
}

const defaultContribution = {
  description: "",
  companyId: "placeholder",
  creatorEmail: "placeholder",
};

export default function EditContribution({
  goalId,
  contribution,
  open,
  onClose,
}: EditContributionProps) {
  const [showHelp, setShowHelp] = useState(false);
  const [editContribution, setEditContribution] = useImmer<
    CreateContributionInput | UpdateContributionInput
  >(contribution || { ...defaultContribution });
  const [taggedEmployees, setTaggedEmployees] = useState<
    EmployeeWithAvatarUrl[]
  >([]);
  const [saving, setSaving] = useState(false);
  const [savingError, setSavingError] = useState("");
  const [previewAttachments, setPreviewAttachments] = useState<
    AttachmentFile[]
  >([]);
  const [removedAttachments, setRemovedAttachments] = useState<
    AttachmentFile[]
  >([]);
  const [error, setError] = useState("");
  const { goals: fetchedGoals } = useGoals()!;
  const goals = useMemo(() => fetchedGoals || [], [fetchedGoals]);
  const currentUser = useAuthStatus();
  const memoizedAttachments = useMemo(
    () => contribution?.attachments as string[],
    [contribution?.attachments]
  );
  const existingAttachments = useAttachmentUrls(memoizedAttachments);
  const intl = useIntl();
  const employees = useEmployees();
  const [tabValue, setTabValue] = useState(0);
  const [chatDialogState, setChatDialogState] = useImmer<ChatDialogState>(
    defaultChatDialogState
  );
  const organization = useOrganization()?.organization;
  const northStars = useNorthStars()?.northStars;
  const currentGoal = goals.find((goal) => goal.id === goalId);
  const employee = employees?.employees?.find(
    (employee) => employee?.id === currentGoal?.employeeGoalsId
  );

  useEffect(() => {
    (async () => {
      let info = await getGoalBackgroundInfo(
        intl,
        currentGoal?.organizationUnitGoalsId ?? undefined,
        employee ?? undefined,
        goals,
        organization,
        northStars,
        employees?.organizationUnitEmployeeJoins,
        currentGoal
      );
      setChatDialogState((draft) => {
        draft.backgroundInfo = info.info;
        draft.hint = info.hint;
      });
    })();
    if (!contribution) {
      setChatDialogState((draft) => {
        draft.question = intl.formatMessage({
          id: "chat.prefilled.question.contribution",
        });
      });
    }
  }, [
    currentGoal,
    intl,
    currentGoal?.organizationUnitGoalsId,
    employee,
    goals,
    organization,
    northStars,
    employees?.organizationUnitEmployeeJoins,
    contribution,
    setChatDialogState
  ]);

  const resetState = () => {
    setEditContribution(contribution || { ...defaultContribution });
    setTaggedEmployees([]);
    setShowHelp(false);
    setSaving(false);
    setRemovedAttachments([]);
    setPreviewAttachments([]);
    setError("");
    setSavingError("");
  };

  const handleDescriptionChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setError("");
    setEditContribution((draft) => {
      draft.description = event.target.value;
    });
  };

  const handleSave = async () => {
    if (!editContribution.description) {
      setError(
        intl.formatMessage({ id: "contributions.error.description.required" })
      );
      return;
    }
    try {
      setSaving(true);
      // Save attachments to S3
      const newAttachments = await saveAttachments(
        previewAttachments,
        AttachmentOwner.Contribution
      );

      const employeeGoal = isEmployeeGoal(goals, goalId);
      if (!contribution) {
        await addContributionDb(
          {
            ...editContribution,
            goalContributionsId: goalId,
            creatorEmail: currentUser?.attributes.email,
            attachments: newAttachments,
          } as CreateContributionInput,
          employees?.employees,
          taggedEmployees,
          employeeGoal
        );
      } else {
        // Remove deleted attachments from S3
        const remainingAttachments = await deleteAttachments(
          removedAttachments,
          existingAttachments
        );
        await updateContributionDb(
          {
            ...editContribution,
            attachments: remainingAttachments.concat(newAttachments),
          } as UpdateContributionInput,
          contribution,
          taggedEmployees
        );
      }
      resetState();
      onClose(contribution == null);
    } catch (error: any) {
      log(`Add/Update Contribution: ${error.message}`);
      setSavingError(intl.formatMessage({ id: "general.save.error" }));
      setSaving(false);
    }
  };

  const handleCancel = (event?: object, reason?: string) => {
    if (reason === "backdropClick") {
      // Don't do anything. Accidental click can't delete all the information.
      return;
    }

    resetState();
    onClose(false);
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      fullWidth={true}
      maxWidth="lg"
      disableRestoreFocus
      data-cy="edit-contribution-dialog"
    >
      <DialogTabTitle
        tabValue={tabValue}
        setTabValue={setTabValue}
        dialogTitle={intl.formatMessage({
          id: contribution ? "contributions.edit" : "contributions.add",
        })}
        handleToggleHelp={handleToggleHelp}
      />
      <DialogContent>
        <TabPanel value={tabValue} index={0}>
          <HelpCollapse
            showHelp={showHelp}
            helpText={intl.formatMessage({ id: "contributions.help.text" })}
          />
          <TaggedEmployees
            taggedEmployees={taggedEmployees}
            currentUser={currentUser}
            employeeJoins={contribution?.employeeJoins}
            employeeIdField={"employeeContributionEmployeeJoinsId"}
            inCreate={!contribution}
            setTaggedEmployees={setTaggedEmployees}
            label={getEventEmployeesTitle(intl, EventType.CONTRIBUTION_ADDED)}
          />

          {/* Description */}
          <TextField
            autoFocus
            margin="dense"
            sx={{ marginTop: "6px" }}
            id="description"
            data-cy="edit-contribution-description"
            label={<FormattedMessage id="contributions.description" />}
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            helperText={error}
            error={error !== ""}
            value={editContribution.description}
            onChange={handleDescriptionChange}
          />

          <HandleAttachments
            existingAttachments={existingAttachments}
            previewMedias={previewAttachments}
            setPreviewMedias={setPreviewAttachments}
            removedAttachments={removedAttachments}
            setRemovedAttachments={setRemovedAttachments}
          />
        </TabPanel>
        <TabPanel value={tabValue} index={1}>
          <DialogChat
            chatDialogState={chatDialogState}
            setChatDialogState={setChatDialogState}
          />
        </TabPanel>
      </DialogContent>

      {savingError && <Alert severity="error">{savingError}</Alert>}

      <EditDialogActions
        saving={saving}
        onSave={handleSave}
        onCancel={handleCancel}
      />
    </Dialog>
  );
}
