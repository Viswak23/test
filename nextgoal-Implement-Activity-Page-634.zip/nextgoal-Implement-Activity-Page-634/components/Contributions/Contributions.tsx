import { useState, useRef } from "react";
import { Contribution, Goal } from "@/src/API";
import EditContribution from "./EditContribution";
import ContributionItem from "./ContributionItem";
import GTabPanel from "../Common/GTabPanel/GTabPanel";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import { deleteContributionDb } from "@/lib/webContributions";
import { AttachmentFile } from "@/lib/webAttachment";
import { useIntl } from "react-intl";
import { useEvents } from "@/contexts/EventsContext";

interface ContributionsProps {
  goal?: Goal | null;
  contributions?: (Contribution | null)[];
  canAdd?: boolean;
}

export default function Contributions({
  goal,
  contributions,
  canAdd = true,
}: ContributionsProps) {
  const [addContribution, setAddContribution] = useState(false);
  const [editContribution, setEditContribution] = useState<
    Contribution | undefined
  >();
  const [deleteContribution, setDeleteContribution] = useState<
    Contribution | undefined
  >();
  const [deleteAttachments, setDeleteAttachments] = useState<
    AttachmentFile[] | undefined
  >();
  const [saving, setSaving] = useState(false);
  const topRef = useRef<HTMLDivElement | null>(null);
  const intl = useIntl();
  const events = useEvents()?.events;

  if (!goal && !contributions) {
    return <div>Error finding the goal for contributions</div>;
  }
  const showContributions = contributions
    ? contributions
    : goal?.contributions?.items || [];

  const resetState = () => {
    setAddContribution(false);
    setEditContribution(undefined);
    setDeleteContribution(undefined);
    setDeleteAttachments(undefined);
    setSaving(false);
  };

  const handleAdd = () => {
    setAddContribution(true);
  };

  const handleEdit = (contribution: Contribution) => {
    setEditContribution(contribution);
  };

  const handleCloseEdit = (scrollToTop: Boolean) => {
    resetState();
    if (scrollToTop) {
      topRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleDelete = (
    contribution: Contribution,
    attachments?: AttachmentFile[]
  ) => {
    setDeleteContribution(contribution);
    setDeleteAttachments(attachments || []);
  };

  const handleDeleteCancel = () => {
    setDeleteContribution(undefined);
    setDeleteAttachments(undefined);
  };

  const handleDeleteConfirmed = async () => {
    if (!deleteContribution) {
      return;
    }

    setSaving(true);
    await deleteContributionDb(deleteContribution, deleteAttachments || [], events);
    resetState();
  };

  return (
    <>
      <div ref={topRef} style={{ paddingTop: "2px" }} />
      <GTabPanel onAdd={canAdd ? handleAdd : undefined}>
        {showContributions.map((contribution) => (
          <ContributionItem
            key={contribution?.id || "noContribution"}
            contribution={contribution}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        ))}
      </GTabPanel>
      {(addContribution || !!editContribution) && (
        <EditContribution
          key={editContribution?.id || "addingContribution"}
          goalId={
            editContribution ? editContribution.goalContributionsId : goal?.id
          }
          contribution={editContribution}
          open={addContribution || !!editContribution}
          onClose={handleCloseEdit}
        />
      )}
      {deleteContribution && (
        <ConfirmationDialog
          title={intl.formatMessage({ id: "contributions.delete.caption" })}
          message={intl.formatMessage({
            id: "contributions.delete.confirmation",
          })}
          messageItem={deleteContribution.description || ""}
          open={!!deleteContribution}
          saving={saving}
          onCancel={handleDeleteCancel}
          onConfirm={handleDeleteConfirmed}
        />
      )}
    </>
  );
}
