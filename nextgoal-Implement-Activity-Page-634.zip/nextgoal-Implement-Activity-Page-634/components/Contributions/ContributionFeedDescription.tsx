import { Contribution } from "@/src/API";
import { ListText } from "../Common/Texts/Texts";

interface ContributionFeedDescriptionProps {
  contribution?: Contribution | null;
}

export default function ContributionFeedDescription({
  contribution,
}: ContributionFeedDescriptionProps) {
  return <ListText>{contribution?.description}</ListText>;
}
