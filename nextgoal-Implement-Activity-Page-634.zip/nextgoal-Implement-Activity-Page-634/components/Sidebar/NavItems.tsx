import { Pages } from "@/lib/webNavigation";
import { List, Stack } from "@mui/material";
import {
  Flag,
  Flame,
  LayoutDashboard,
  LucideIcon,
  Star,
  User,
  Users,
} from "lucide-react";
import { useIntl } from "react-intl";
import { NavItem } from "../UI/Nav/NavItem";
import { useMemo } from 'react';
interface NavItemsProps {
  open: boolean;
  selectedPage: string;
}
export default function NavItems({ open, selectedPage }: NavItemsProps) {
  const intl = useIntl();
  interface NavLink {
      label: string;
      link: string;
      icon: LucideIcon;
    }
    const navLinks = useMemo(() => ([
    {
      label: intl.formatMessage({ id: "general.menu.dashboard" }),
      link: Pages.appDashboard,
      icon: LayoutDashboard,
    },
    {
      label: intl.formatMessage({ id: "general.menu.goals" }),
      link: Pages.appGoals,
      icon: Flag,
    },
    {
      label: intl.formatMessage({ id: "general.menu.activity" }),
      link: Pages.appActivity,
      icon: Flame,
    },
    {
      label: intl.formatMessage({ id: "general.menu.organizations" }),
      link: Pages.appOrganizations,
      icon: Users,
    },
    {
      label: intl.formatMessage({ id: "general.menu.northstars" }),
      link: Pages.appNorthstars,
      icon: Star,
    },
    {
      label: intl.formatMessage({ id: "general.menu.profile" }),
      link: Pages.appProfile,
      icon: User,
    },
  ]), [intl]);
  return (
    <List>
      <Stack>
        {navLinks.map((nav, index) => (
          <NavItem
            active={selectedPage === nav.link}
            key={`nav-item-${nav.link}`}
            open={open}
            Icon={nav.icon as LucideIcon}
            label={nav.label}
            link={nav.link}
          />
        ))}
      </Stack>
    </List>
  );
}
