import theme from "@/config/theme";
import { useAuthContext } from "@/contexts/AuthContext";
import { useEmployees } from "@/contexts/EmployeesContext";
import { getGreetingText } from "@/lib/time";
import { Employee } from "@/src/API";
import { Stack } from "@mui/material";
import Link from "next/link";
import { useIntl } from "react-intl";
import {
  Paragraph1,
  Paragraph1Skeleton,
  Paragraph4,
  Paragraph4Skeleton,
} from "../UI/Texts/Texts";
import { CustomAvatar, CustomAvatarSkeleton } from "../UI/User/Avatar";

interface UserProps {
  open: boolean;
}

interface EmployeesState {
  employeesByEmail: Record<string, Employee>;
}

export function User({ open }: UserProps) {
  const intl = useIntl();
  const greetingMessage = getGreetingText(intl);
  const { currentUser: authuser } = useAuthContext() ?? {};
 if (!authuser?.attributes?.email) {
   return <UserSkeleton open={open} />;
 }
  const employeeContext = useEmployees() as EmployeesState;
  const employee = employeeContext?.employeesByEmail?.[authuser.attributes.email] ?? {
    name: intl.formatMessage({ id: "employees.unknown" }),
    resolvedAvatarUrl: "",
  };

  return (
    <Stack
      alignItems={"center"}
      flexDirection={"row"}
      gap={"16px"}
      width="full"
      height={"45px"} // if not set, nav will jump a couple of pixles when expanded and closed
    >
      <CustomAvatar
        size="sm"
        image={employee?.resolvedAvatarUrl || ""}
        alt={`${employee?.name}`}
      />
      {open && (
        <Stack>
          <Paragraph4 style={{ color: theme.palette.secondary.main }}>
            {greetingMessage}
          </Paragraph4>
          <Link href={"/profile"}>
            <Paragraph1>{employee?.name}</Paragraph1>
          </Link>
        </Stack>
      )}
    </Stack>
  );
}
export function UserSkeleton({ open }: UserProps) {
  return (
    <Stack
      alignItems={"center"}
      justifyContent={"center"}
      flexDirection={"row"}
      gap={"16px"}
      width="100%"
      height={"45px"} // if not set, nav will jump a couple of pixles when expanded and closed
    >
      <CustomAvatarSkeleton size="sm" alt={undefined} />
      {open && (
        <Stack width={"50%"}>
          <Paragraph4Skeleton />
          <Paragraph1Skeleton />
        </Stack>
      )}
    </Stack>
  );
}
