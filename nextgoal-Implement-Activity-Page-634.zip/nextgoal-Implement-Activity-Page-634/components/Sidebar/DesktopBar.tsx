import Box from "@mui/material/Box";
import CssBaseline from "@mui/material/CssBaseline";
import MuiDrawer from "@mui/material/Drawer";
import { CSSObject, styled, Theme, useTheme } from "@mui/material/styles";
import * as React from "react";

import { Pages } from "@/lib/webNavigation";
import { List, Stack } from "@mui/material";
import { Columns, Megaphone, Settings2 } from "lucide-react";
import { usePathname } from "next/navigation";
import { useIntl } from "react-intl";
import ButtonIcon from "../UI/Buttons/ButtonIcon";
import Logo from "../UI/Nav/Logo";
import { NavItemSkeleton, NavItem } from "../UI/Nav/NavItem";
import NavItems from "./NavItems";
import { UserSkeleton, User } from "./User";

const drawerWidth = 240;

const openedMixin = (theme: Theme): CSSObject => ({
  width: drawerWidth,
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: "hidden",
});

const closedMixin = (theme: Theme): CSSObject => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: "hidden",
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up("sm")]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const Drawer = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme }) => ({
  width: drawerWidth,
  height: "100vh",
  flexShrink: 0,
  whiteSpace: "nowrap",
  boxSizing: "border-box",
  variants: [
    {
      props: ({ open }) => open,
      style: {
        ...openedMixin(theme),
        "& .MuiDrawer-paper": openedMixin(theme),
      },
    },
    {
      props: ({ open }) => !open,
      style: {
        ...closedMixin(theme),
        "& .MuiDrawer-paper": closedMixin(theme),
      },
    },
  ],
}));

interface DesktopDrawerProps {
  selectedPage: string;
}

export function DesktopDrawer({ selectedPage }: DesktopDrawerProps) {
  const theme = useTheme();
  const intl = useIntl();
  const pathname = usePathname();

  const [open, setOpen] = React.useState(true);

  const handleDrawerToggle = () => {
    setOpen((prev) => !prev);
  };

  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />
      <Drawer variant="permanent" open={open}>
        <Stack sx={{ paddingX: "12px", paddingY: "20px", height: "100%" }}>
          <Box alignSelf={"center"} mt={"5px"}>
            <User open={open} />
          </Box>

          {/* Nav Items */}
          <Stack
            mt={"40px"}
            width={"full"}
            height={"100%"}
            justifyContent={"space-between"}
          >
            <NavItems open={open} selectedPage={selectedPage} />
            <Stack>
              <NavItem
                active={selectedPage == Pages.appSettings}
                open={open}
                Icon={Settings2}
                label={intl.formatMessage({ id: "general.menu.settings" })}
                link={Pages.appSettings}
              />
              <NavItem
                open={open}
                variant="button"
                Icon={Megaphone}
                label={intl.formatMessage({ id: "general.menu.feedback" })}
              />
              <Stack
                direction={open ? "row" : "column-reverse"}
                alignItems={"center"}
              >
                <Logo open={open} />
                <Box mx={"auto"}>
                  <ButtonIcon
                    Icon={<Columns size={20} strokeWidth={1.25} />}
                    tooltip={
                      open
                        ? intl.formatMessage({ id: "general.close" })
                        : intl.formatMessage({ id: "general.open" })
                    }
                    onClick={handleDrawerToggle}
                  />
                </Box>
              </Stack>
            </Stack>
          </Stack>
        </Stack>
      </Drawer>
    </Box>
  );
}

export function DesktopSidebarSkeleton() {
  const [open, setOpen] = React.useState(true);

  const handleDrawerToggle = () => {
    setOpen((prev) => !prev);
  };

  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />
      <Drawer variant="permanent" open={open}>
        <Stack
          sx={{ paddingX: "12px", paddingY: "20px", height: "100%" }}
          width={"100%"}
        >
          <Stack
            direction={"row"}
            alignSelf={"center"}
            justifyContent={"center"}
            mt={"5px"}
            width={"100%"}
          >
            <UserSkeleton open={open} />
          </Stack>

          {/* Nav Items */}
          <Stack
            mt={"40px"}
            width={"100%"}
            height={"100%"}
            justifyContent={"space-between"}
          >
            <List>
              <Stack width={"100%"}>
                {Array.from({ length: 6 }).map((_, index) => (
                  <NavItemSkeleton key={index} open={open} />
                ))}
              </Stack>
            </List>
            <Stack width={"100%"}>
              <NavItemSkeleton open={open} />
              <NavItemSkeleton open={open} />
              <Stack
                width={"100%"}
                direction={open ? "row" : "column-reverse"}
                alignItems={"center"}
              >
                <NavItemSkeleton open={open} />
              </Stack>
            </Stack>
          </Stack>
        </Stack>
      </Drawer>
    </Box>
  );
}
