import { Pages } from "@/lib/webNavigation";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import MenuIcon from "@mui/icons-material/Menu";
import { Stack } from "@mui/material";
import MuiAppBar, { AppBarProps as MuiAppBarProps } from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import CssBaseline from "@mui/material/CssBaseline";
import Divider from "@mui/material/Divider";
import Drawer from "@mui/material/Drawer";
import IconButton from "@mui/material/IconButton";
import { styled, useTheme } from "@mui/material/styles";
import Toolbar from "@mui/material/Toolbar";
import { Megaphone, Settings2 } from "lucide-react";
import * as React from "react";
import { useIntl } from "react-intl";
import Logo from "../UI/Nav/Logo";
import { NavItem } from "../UI/Nav/NavItem";
import NavItems from "./NavItems";
import { User } from "./User";

const drawerWidth = 240;

interface AppBarProps extends MuiAppBarProps {
  open?: boolean;
}

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})<AppBarProps>(({ theme }) => ({
  transition: theme.transitions.create(["margin", "width"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  variants: [
    {
      props: ({ open }) => open,
      style: {
        transition: theme.transitions.create(["margin", "width"], {
          easing: theme.transitions.easing.easeOut,
          duration: theme.transitions.duration.enteringScreen,
        }),
      },
    },
  ],
  backgroundColor: theme.palette.background.paper,
  color: theme.palette.primary.main,
  boxShadow: "none",
  borderBottom: "1px solid #e0e0e0",
}));

const DrawerHeader = styled("div")(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
  justifyContent: "flex-start",
}));

interface MobileDrawerProps {
  selectedPage: Pages;
}

export default function MobileDrawer({ selectedPage }: MobileDrawerProps) {
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);
  const intl = useIntl();

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />
      <AppBar position="fixed" open={open}>
        <Toolbar>
          <Logo open={true} />
          <IconButton
            color="inherit"
            aria-label={intl.formatMessage({ id: "general.menu.open" })}
            edge="end"
            onClick={handleDrawerOpen}
            sx={open ? { display: "none" } : undefined}
          >
            <MenuIcon />
          </IconButton>
        </Toolbar>
      </AppBar>
      <Drawer
        sx={{
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: drawerWidth,
          },
        }}
        variant="persistent"
        anchor="right"
        open={open}
      >
        <DrawerHeader>
          <IconButton
            onClick={handleDrawerClose}
            aria-label={intl.formatMessage({ id: "general.menu.close" })}
          >
            {theme.direction === "rtl" ? (
              <ChevronLeftIcon />
            ) : (
              <ChevronRightIcon />
            )}
          </IconButton>
        </DrawerHeader>
        <Divider />
        <Stack
          sx={{ paddingX: "12px", paddingY: "20px", height: "100%" }}
          //   alignItems={"center"}
        >
          <Box alignSelf={"center"} mt={"5px"}>
            <User open={true} />
          </Box>

          {/* Nav Items */}
          <Stack
            mt={"40px"}
            width={"full"}
            height={"100%"}
            justifyContent={"space-between"}
          >
            <NavItems open={open} selectedPage={selectedPage} />
            <Stack>
              <NavItem
                active={selectedPage == Pages.appSettings}
                open={open}
                Icon={Settings2}
                label={intl.formatMessage({ id: "general.menu.settings" })}
                link={Pages.appSettings}
              />
              <NavItem
                open={open}
                variant="button"
                Icon={Megaphone}
                label={intl.formatMessage({ id: "general.menu.feedback" })}
              />
              
            </Stack>
          </Stack>
        </Stack>
      </Drawer>
    </Box>
  );
}
