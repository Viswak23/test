import { useMediaQuery } from "@mui/material";

import theme from "@/config/theme";
import { getSelectedPage } from "@/lib/webNavigation";
import { usePathname } from "next/navigation";
import { useIntl } from "react-intl";
import { DesktopDrawer } from "./DesktopBar";
import MobileDrawer from "./MobileBar";
// temp image
export default function Sidebar() {
  const intl = useIntl();
  const pathname = usePathname();
  const selectedPage = getSelectedPage(pathname, intl.locale);
  const isMdScreen = useMediaQuery(theme.breakpoints.up("md")); // Check if screen is sized md or larger

  return (
    <>
      {isMdScreen ? (
        <DesktopDrawer selectedPage={selectedPage} />
      ) : (
        <MobileDrawer selectedPage={selectedPage} />
      )}
    </>
  );
}
