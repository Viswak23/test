import { Box, IconButton, styled, TextField } from "@mui/material";

export const ChatMessageContainer = styled(Box)({
  flexGrow: 1,
  overflowY: "auto",
  padding: "20px",
  "@media (max-width: 768px)": {
    height: "400px",
    fontSize: "12px",
  },
});
export const ChatMessage = styled(Box)({
  display: "flex",
  marginBottom: "20px",
});

export const ChatMessageText = styled(Box)({
  padding: "10px 10px",
  borderRadius: "10px",
  maxWidth: "85%",
  whiteSpace: "pre-wrap",
});

export const InputContainer = styled(Box)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  marginTop: "0px",
  borderTop: `1px solid ${theme.palette.customColors?.textbubble || "#e2e8f0"}`, // Use theme color or fallback
  paddingTop: "10px",
  width: "100%",
}));

export const StyledTextField = styled(TextField)(({ theme }) => ({
  flexGrow: 1,
  "& .MuiOutlinedInput-root": {
    borderRadius: "10px", // Border radius for the text field
    // On default
    "& fieldset": {
      borderRadius: "10px",
      borderColor: theme.palette.secondary.main,
    },
    // On hover
    "&:hover fieldset": {
      borderColor: theme.palette.secondary.main, // Border color on hover
    },
    // On focus
    "&.Mui-focused fieldset": {
      borderColor: theme.palette.secondary.main, // Border color when focused
    },
  },
}));

export const SendButton = styled(IconButton)(({ theme }) => ({
  marginLeft: theme.spacing(1),
  borderRadius: "10px", // Rounded corners
  "&:hover": {
    boxShadow: "none",
  },
}));
