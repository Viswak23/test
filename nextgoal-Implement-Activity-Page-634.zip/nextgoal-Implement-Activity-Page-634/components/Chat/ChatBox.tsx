"use client";

import { useState } from "react";
import { Box, Fab, IconButton, styled, useTheme } from "@mui/material";
import { ChatBubble, HighlightOff, Forum, Send } from "@mui/icons-material";
import { useIntl } from "react-intl";
import {
  hoverMainAndWhiteToOpposite,
  hoverSecondaryToRed,
} from "@/config/styling";
import { SubheadingCard } from "../Common/Texts/Texts";
import ChatContainer from "./ChatContainer";

const StyledFab = styled(Fab)(({ theme }) => ({
  position: "fixed",
  bottom: theme.spacing(2),
  right: theme.spacing(2),
  zIndex: 1000,
  ...hoverMainAndWhiteToOpposite(theme),
}));

const FloatingBox = styled(Box)(({ theme }) => ({
  position: "fixed",
  top: theme.spacing(12),
  bottom: theme.spacing(2), // Adjust to ensure it doesn't touch the footer
  right: theme.spacing(2),
  zIndex: 1000,
  width: "450px",
  backgroundColor: theme.palette.customColors?.bright,
  color: theme.palette.customColors?.night,
  boxShadow: theme.shadows[5],
  padding: "10px",
  borderRadius: "5px",
  display: "flex",
  flexDirection: "column",
  "@media (max-width: 600px)": {
    width: "90%",
  },
}));

const Header = styled(Box)(({ theme }) => ({
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  width: "100%",
  marginBottom: "0px",
  borderBottom: `1px solid ${
    theme.palette.customColors?.textbubble || "#e2e8f0"
  }`, // Use theme color or fallback
  paddingBottom: "10px",
  position: "relative", // Ensure IconButton is positioned correctly
}));

export default function ChatBox() {
  const intl = useIntl();
  const theme = useTheme();

  const [isOpen, setIsOpen] = useState(false);
  const scrollUpLabel = intl.formatMessage({ id: "general.scroll.back.up" });

  return (
    <div>
      {isOpen ? (
        <FloatingBox>
          <Header>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                marginLeft: "12px",
              }}
            >
              <Forum sx={{ color: "secondary.main" }} />
              <SubheadingCard
                sx={{ color: theme.palette.secondary.main, paddingLeft: "8px" }}
              >
                WorkMate
              </SubheadingCard>
            </Box>

            {/* Close chat btn */}
            <IconButton
              onClick={() => setIsOpen(false)}
              sx={{
                position: "absolute",
                bottom: 18,
                right: 6,
                alignItems: "center",
                ...hoverSecondaryToRed(theme),
              }}
            >
              <HighlightOff />
            </IconButton>
          </Header>

          {/* The chat itself */}
          <ChatContainer />
        </FloatingBox>
      ) : (
        <StyledFab
          size="medium"
          onClick={() => setIsOpen(true)}
          aria-label={scrollUpLabel}
        >
          <ChatBubble />
        </StyledFab>
      )}
    </div>
  );
}
