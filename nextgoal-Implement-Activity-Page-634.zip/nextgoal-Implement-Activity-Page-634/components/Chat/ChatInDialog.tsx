import ChatBackgroundInfo from "./ChatBackgroundInfo";
import ChatContainer from "./ChatContainer";
import { Message } from "@/lib/webChat";
import { ChatDialogState } from "./ChatDialogState";

interface DialogChatProps {
  chatDialogState: ChatDialogState;
  setChatDialogState: (state: ChatDialogState) => void;
}

export default function DialogChat({
  chatDialogState,
  setChatDialogState,
}: DialogChatProps) {
  const handleSubmitInitialQuestion = () => {
    setChatDialogState({
      ...chatDialogState,
      isInChat: true,
      messages: [
        {
          role: "user",
          content: chatDialogState.question,
        },
      ],
    });
  };

  const handleMessageChange = (message: Message[]) => {
    setChatDialogState({
      ...chatDialogState,

      messages: message,
    });
  };

  return (
    <>
      {!chatDialogState.isInChat && (
        <ChatBackgroundInfo
          onSubmit={handleSubmitInitialQuestion}
          setChatDialogState={setChatDialogState!}
          chatDialogState={chatDialogState}
        />
      )}
      {chatDialogState.isInChat && (
        <ChatContainer
          backgroundInfo={chatDialogState.backgroundInfo}
          inputMessages={chatDialogState.messages}
          onMessageChange={handleMessageChange}
        />
      )}
    </>
  );
}
