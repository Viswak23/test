import {
  Checkbox,
  FormControlLabel,
  Stack,
  TextField,
  Typography,
  useTheme,
} from "@mui/material";
import { FormattedMessage, useIntl } from "react-intl";
import {
  InputContainer,
  SendButton,
  StyledTextField,
} from "./ChatStyledComponents";
import { Send } from "@mui/icons-material";
import { hoverSecondaryToAddWBg } from "@/config/styling";
import { ChatDialogState } from "./ChatDialogState";

interface ChatBackgroundInfoProps {
  setChatDialogState: (state: ChatDialogState) => void;
  chatDialogState: ChatDialogState;
  onSubmit: () => void;
}

export default function ChatBackgroundInfo({
  onSubmit,
  chatDialogState,
  setChatDialogState,
}: ChatBackgroundInfoProps) {
  const intl = useIntl();
  const theme = useTheme();

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      onSubmit();
    }
  };

  return (
    <Stack direction="column" spacing={2} alignItems="flex-start">
      <FormControlLabel
        value={chatDialogState.isUsingBackgroundInfo}
        label={<FormattedMessage id="chat.dialog.use.background.info" />}
        labelPlacement="end"
        control={
          <Checkbox
            checked={chatDialogState.isUsingBackgroundInfo}
            onChange={(e) =>
              setChatDialogState({
                ...chatDialogState,
                isUsingBackgroundInfo: e.target.checked,
              })
            }
          />
        }
      />
      {chatDialogState.isUsingBackgroundInfo && (
        <>
          <TextField
            margin="dense"
            id="edit-chat-background-info"
            type="text"
            fullWidth
            variant="outlined"
            autoComplete="off"
            data-cy="edit-chat-background-info"
            multiline
            maxRows={5}
            value={chatDialogState.backgroundInfo}
            onChange={(e) =>
              setChatDialogState({
                ...chatDialogState,
                backgroundInfo: e.target.value,
              })
            }
          />
          {chatDialogState.hint && (
            <Typography
              sx={{
                color: theme.palette.secondary.light,
              }}
              variant="body2"
            >
              {chatDialogState.hint}
            </Typography>
          )}
        </>
      )}
      <InputContainer>
        <StyledTextField
          variant="outlined"
          autoFocus
          fullWidth
          placeholder={intl.formatMessage({
            id: "general.chatbot.write.a.message",
          })}
          value={chatDialogState.question}
          onChange={(e) =>
            setChatDialogState({ ...chatDialogState, question: e.target.value })
          }
          onKeyDown={handleKeyDown}
          multiline
          maxRows={5}
        />
        <SendButton
          onClick={onSubmit}
          sx={{ ...hoverSecondaryToAddWBg(theme) }}
        >
          <Send />
        </SendButton>
      </InputContainer>
    </Stack>
  );
}
