import { hoverSecondaryToAddWBg } from "@/config/styling";
import { getMessage, Message } from "@/lib/webChat";
import { Send } from "@mui/icons-material";
import { Box, CircularProgress, useTheme } from "@mui/material";
import { useCallback, useEffect, useRef, useState } from "react";
import { useIntl } from "react-intl";
import {
  ChatMessage,
  ChatMessageContainer,
  ChatMessageText,
  InputContainer,
  SendButton,
  StyledTextField,
} from "./ChatStyledComponents";
import { log } from "@/lib/backend/actions/logger";
import ReactMarkdown from "react-markdown";

interface ChatContainerProps {
  backgroundInfo?: string;
  inputMessages?: Message[];
  onMessageChange?: (message: Message[]) => void;
}

export default function ChatContainer({
  backgroundInfo,
  inputMessages,
  onMessageChange,
}: ChatContainerProps) {
  const intl = useIntl();
  const theme = useTheme();
  const chatRef = useRef<HTMLDivElement>(null);
  const [input, setInput] = useState("");
  const [error, setError] = useState(false);
  const [messages, setMessages] = useState<Message[]>(
    inputMessages ?? [
      {
        role: "assistant",
        content: intl.formatMessage({
          id: "general.chatbot.welcome.message",
        }),
      },
    ]
  );
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = () => {
    if (input.length <= 0) {
      setError(true);
      return;
    }
    setMessages([...messages, { role: "user", content: input }]);
    runCompletion([...messages, { role: "user", content: input }]);
    if (onMessageChange) {
      onMessageChange([...messages, { role: "user", content: input }]);
    }
    setInput("");
    setError(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      if (e.shiftKey) {
        // Allow new line when Shift + Enter is pressed
        return;
      } else {
        // Prevent default Enter key behavior and submit the form
        e.preventDefault();
        handleSubmit();
      }
    }
  };

  const runCompletion = useCallback(
    async (messages: Message[]): Promise<void> => {
      try {
        setIsLoading(true);
        const responseMessage = await getMessage(
          backgroundInfo ??
            intl.formatMessage({ id: "general.chatbot.system.content" }),
          messages
        );
        setMessages([
          ...messages,
          {
            role: "assistant",
            content: responseMessage ?? "No response is available currently",
          },
        ]);
        if (onMessageChange) {
          onMessageChange([
            ...messages,
            {
              role: "assistant",
              content: responseMessage ?? "No response is available currently",
            },
          ]);
        }
      } catch (error: any) {
        log("Error while compiling Chat message: " + error.message);
      } finally {
        setIsLoading(false);
      }
    },
    [backgroundInfo, intl, onMessageChange]
  );
  useEffect(() => {
    if (backgroundInfo && inputMessages && inputMessages.length === 1) {
      runCompletion(inputMessages);
    }
  }, [backgroundInfo, inputMessages, runCompletion]);

  useEffect(() => {
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <>
      <ChatMessageContainer ref={chatRef}>
        {messages.map((message, index) => {
          const isUser = message.role === "user";
          return (
            <ChatMessage
              key={index}
              style={{ justifyContent: isUser ? "flex-end" : "flex-start" }}
            >
              <ChatMessageText
                style={{
                  backgroundColor: isUser
                    ? theme.palette.customColors?.midnight
                    : theme.palette.customColors?.textbubble,
                  color: isUser
                    ? theme.palette.customColors?.bright
                    : theme.palette.customColors?.night,
                }}
              >
                <ReactMarkdown>{message.content}</ReactMarkdown>
              </ChatMessageText>
            </ChatMessage>
          );
        })}
        {isLoading && (
          <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            margin="20px auto 0"
          >
            <CircularProgress size={20} />
          </Box>
        )}
      </ChatMessageContainer>
      {/* Input field & Send btn */}
      <InputContainer>
        <StyledTextField
          error={error}
          variant="outlined"
          autoFocus
          fullWidth
          placeholder={intl.formatMessage({
            id: "general.chatbot.write.a.message",
          })}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          multiline
          maxRows={3}
        />
        <SendButton
          onClick={handleSubmit}
          sx={{ ...hoverSecondaryToAddWBg(theme) }}
        >
          <Send />
        </SendButton>
      </InputContainer>
    </>
  );
}
