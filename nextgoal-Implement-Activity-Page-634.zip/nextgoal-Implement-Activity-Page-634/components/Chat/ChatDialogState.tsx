'use client'

import { Message } from "@/lib/webChat";

export interface ChatDialogState {
  backgroundInfo: string;
  hint: string;
  isUsingBackgroundInfo: boolean;
  question: string;
  messages: Message[];
  isInChat: boolean;
}

export const defaultChatDialogState: ChatDialogState = {
    backgroundInfo: "",
    isUsingBackgroundInfo: true,
    question: "",
    hint: "",
    messages: [],
    isInChat: false,
  };