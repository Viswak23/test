import "dayjs/locale/fi";
import "dayjs/locale/en-gb";
import "dayjs/locale/en";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { Employee } from "@/src/API";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { getDayJsLocale } from "@/lib/localisation";

interface LocalizeDatePickerProps {
  children: React.ReactNode;
  dbUser?: Employee | null;
}

export default function LocalizeDatePicker({
  children,
  dbUser,
}: LocalizeDatePickerProps) {
  return (
    <LocalizationProvider
      dateAdapter={AdapterDayjs}
      adapterLocale={getDayJsLocale(dbUser?.locale)}
    >
      {children}
    </LocalizationProvider>
  );
}
