import React, { useState } from "react";
import { useNorthStars } from "@/contexts/NorthStarsContext";
import Stack from "@mui/material/Stack";
import { AutoAwesome } from "@mui/icons-material";
import IconButton from "@mui/material/IconButton";
import { Collapse, Tooltip } from "@mui/material";
import NorthStarItem from "./NorthStarItem";
import { deleteNorthStarDb } from "@/lib/webNorthStars";
import { useIntl } from "react-intl";
import { useTheme } from "@mui/material/styles";
import { hoverMainToStar } from "@/config/styling";

export default function NorthStars() {
  const northStarsState = useNorthStars()!;
  const [expanded, setExpanded] = useState(false);
  const intl = useIntl();
  const theme = useTheme();

  const compNorthStarsLabel = intl.formatMessage({
    id: "general.company.northstars",
  });

  const handleDelete = async (id: string) => {
    await deleteNorthStarDb(id);
  };

  return (
    <>
      <Stack
        direction="column"
        spacing={1}
        style={{ marginTop: "20px" }}
        data-cy="north-stars-container"
      >
        <Stack direction="row" spacing={1} alignItems="center">
          <Tooltip
            title={intl.formatMessage({ id: "northstars.tooltip" })}
            arrow
          >
            <IconButton
              size="large"
              aria-label={compNorthStarsLabel}
              onClick={() => setExpanded(!expanded)}
              sx={{ ...hoverMainToStar(theme) }}
            >
              <AutoAwesome />
            </IconButton>
          </Tooltip>
        </Stack>

        <Collapse
          in={expanded && northStarsState.northStars?.length > 0}
          unmountOnExit
          style={{ marginTop: 0, paddingRight: "24px" }}
        >
          {northStarsState.northStars?.map((star) => (
            <NorthStarItem
              key={star.id}
              northStar={star}
              onDelete={handleDelete}
            />
          ))}
        </Collapse>
      </Stack>
    </>
  );
}
