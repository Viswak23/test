import { useState, ChangeEvent } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import TextField from "@mui/material/TextField";
import { Alert, Stack } from "@mui/material";
import {
  CreateNorthStarInput,
  NorthStar,
  UpdateNorthStarInput,
} from "@/src/API";
import { useImmer } from "use-immer";
import { addNorthStarDb, updateNorthStarDb } from "@/lib/webNorthStars";
import { useAuthStatus } from "@/lib/customHooks";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import { FormattedMessage, useIntl } from "react-intl";
import { log } from "@/lib/backend/actions/logger";
import HelpButton from "../Common/Buttons/HelpButton";
import { FormTitle } from "../Common/Texts/Texts";
import HelpCollapse from "../Common/Dialog/HelpCollapse";

interface EditNorthStarProps {
  northStar?: NorthStar;
  open: boolean;
  onClose: () => void;
}

export default function EditNorthStar({
  northStar,
  open,
  onClose,
}: EditNorthStarProps) {
  const defaultNorthStar = {
    title: "",
    description: "",
    companyId: "placeholder",
    creatorEmail: "placeholder",
  };

  const [editNorthStar, setEditNorthStar] = useImmer<
    CreateNorthStarInput | UpdateNorthStarInput
  >(northStar || { ...defaultNorthStar });
  const [showHelp, setShowHelp] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savingError, setSavingError] = useState("");
  const currentUser = useAuthStatus();
  const intl = useIntl();

  const handleTitleChange = (event: ChangeEvent<HTMLInputElement>) => {
    setEditNorthStar((draft) => {
      draft.title = event.target.value;
    });
  };

  const handleDescriptionChange = (event: ChangeEvent<HTMLInputElement>) => {
    setEditNorthStar((draft) => {
      draft.description = event.target.value;
    });
  };

  const resetStates = () => {
    setEditNorthStar(northStar || { ...defaultNorthStar });
    setShowHelp(false);
    setSaving(false);
    setSavingError("");
  };

  const handleCancel = () => {
    resetStates();
    onClose();
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      if (!northStar) {
        await addNorthStarDb({
          ...editNorthStar,
          creatorEmail: currentUser?.attributes.email,
        } as CreateNorthStarInput);
      } else {
        await updateNorthStarDb(editNorthStar as UpdateNorthStarInput);
      }
      resetStates();
      onClose();
    } catch (error: any) {
      log(`Add/Edit Northstar: ${error.message}`);
      setSaving(false);
      setSavingError(intl.formatMessage({ id: "general.save.error" }));
    }
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  const dialogTitle = editNorthStar ? (
    <FormTitle>
      <FormattedMessage id="northstars.edit.caption" />
    </FormTitle>
  ) : (
    <FormTitle>
      <FormattedMessage id="northstars.add.caption" />
    </FormTitle>
  );

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      fullWidth={true}
      maxWidth="lg"
      disableRestoreFocus
    >
      <DialogTitle>
        <Stack direction="row" spacing={1} alignItems={"center"}>
          {dialogTitle}
          {/* Help btn */}
          <HelpButton onClick={handleToggleHelp} />
        </Stack>
      </DialogTitle>

      <DialogContent>
        <HelpCollapse
          showHelp={showHelp}
          helpText={intl.formatMessage({ id: "northstars.edit.help.text" })}
        />
        <TextField
          autoFocus
          margin="dense"
          id="title"
          label={<FormattedMessage id="northstars.northstar.title" />}
          type="text"
          fullWidth
          variant="standard"
          autoComplete="off"
          value={editNorthStar.title}
          onChange={handleTitleChange}
        />
        <TextField
          margin="dense"
          id="title"
          label={<FormattedMessage id="northstars.northstar.description" />}
          type="text"
          fullWidth
          variant="standard"
          autoComplete="off"
          multiline
          value={editNorthStar.description}
          onChange={handleDescriptionChange}
        />
        {savingError && <Alert severity="error">{savingError}</Alert>}
      </DialogContent>
      <EditDialogActions
        saving={saving}
        onSave={handleSave}
        onCancel={handleCancel}
      />
    </Dialog>
  );
}
