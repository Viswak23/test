import { useState } from "react";
import { NorthStar } from "@/src/API";
import { Stack, ListItem, Grid } from "@mui/material";
import { DetailsLabel, DetailsText } from "@/components/Common/Texts/Texts";
import { Star } from "@mui/icons-material";
import { useIntl } from "react-intl";
import { canDeleteDbItem } from "@/lib/webHelpers";
import { useTheme } from "@mui/material";

import EditNorthStar from "./EditNorthStar";
import DeleteButton from "../Common/Buttons/DeleteButton";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import EditButton from "../Common/Buttons/EditButton";

export interface NorthStarItemProps {
  northStar: NorthStar;
  onDelete?: (id: string) => void;
  isEditable?: Boolean;
  sx?: any;
}

export default function NorthStarItem({
  northStar,
  onDelete,
  isEditable,
  sx,
}: NorthStarItemProps) {
  const [editing, setEditing] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const intl = useIntl();
  const theme = useTheme();

  const handleEdit = () => {
    setEditing(true);
  };

  const handleDelete = () => {
    setConfirmDelete(true);
  };

  const handleConfirmDelete = () => {
    onDelete && onDelete(northStar.id);
    setConfirmDelete(false);
  };

  const handleCancelDelete = () => {
    setConfirmDelete(false);
  };

  return (
    <>
      <ListItem
        style={{
          marginLeft: "40px",
          marginTop: 0,
          marginBottom: 0,
          ...sx,
          wordBreak: "break-word",
        }}
      >
        <Stack direction="row" spacing={1} alignItems="flex-start">
          {/* First column contains icon */}
          <Star style={{ color: theme.palette.primary.main, padding: "2px" }} />
          {/* Second column contains title and description */}
          <Stack direction="column" spacing={1}>
            <DetailsLabel>{northStar.title}</DetailsLabel>
            <DetailsText>{northStar.description}</DetailsText>
          </Stack>
          {/* Third column contains edit and delete buttons */}
          {isEditable && (
            <Stack direction="row" spacing={0} alignItems="center">
              <EditButton
                onClick={handleEdit}
                tooltip={intl.formatMessage({ id: "northstars.edit.caption" })}
              />
              <DeleteButton
                onClick={handleDelete}
                tooltip={intl.formatMessage({
                  id: "northstars.delete.caption",
                })}
                disabledTooltip={intl.formatMessage({
                  id: "northstars.delete.disabled.tooltip",
                })}
                disabled={!canDeleteDbItem(northStar)}
              />
            </Stack>
          )}
        </Stack>
      </ListItem>
      {editing && (
        <EditNorthStar
          northStar={northStar}
          open={editing}
          onClose={() => setEditing(false)}
        />
      )}
      {confirmDelete && (
        <ConfirmationDialog
          title={intl.formatMessage({ id: "northstars.delete.caption" })}
          message={intl.formatMessage({ id: "northstars.delete.confirmation" })}
          open={confirmDelete}
          saving={false}
          onConfirm={handleConfirmDelete}
          onCancel={handleCancelDelete}
        />
      )}
    </>
  );
}
