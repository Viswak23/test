import { useState, useEffect, useMemo } from "react";
import { Stack } from "@mui/material";
import { HeadingMain } from "@/components/Common/Texts/Texts";
import NextTargetDates from "@/components/Dashboard/NextTargetDates";
import { useGoals } from "@/contexts/GoalsContext";
import { getKeyResults } from "@/lib/webKeyResults";
import DashboardSummary from "./DashboardSummary";
import { getRedFlags } from "@/lib/webRedFlags";
import { getHelpRequests } from "@/lib/webHelpRequests";
import DashboardTabs from "./DashboardTabs";
import { FormattedMessage } from "react-intl";
import ScrollBackUpButton from "../Common/Buttons/ScrollBackUpButton";
import PageBackgroundPaper from "../Common/Layout/PageBackgroundPaper";

export default function Dashboard() {
  const [isClient, setIsClient] = useState(false);
  const goals = useGoals()?.goals;

  const notPersonalGoals = useMemo(
    () => goals?.filter((goal) => goal?.employee == null),
    [goals]
  );

  useEffect(() => {
    setIsClient(true);
  }, []);

  const allKeyResults = useMemo(() => {
    return getKeyResults(notPersonalGoals);
  }, [notPersonalGoals]);

  const openRedFlags = useMemo(() => {
    return getRedFlags(notPersonalGoals, false);
  }, [notPersonalGoals]);

  const openHelpRequests = useMemo(() => {
    return getHelpRequests(notPersonalGoals, false);
  }, [notPersonalGoals]);

  if (!isClient) {
    return null;
  }

  return (
    <PageBackgroundPaper>
      <HeadingMain>
        <FormattedMessage id="dashboard.title" />
      </HeadingMain>
      <DashboardSummary
        goals={goals}
        keyResults={allKeyResults}
        openRedFlags={openRedFlags}
        openHelpRequests={openHelpRequests}
      />
      <NextTargetDates />
      <DashboardTabs
        keyResults={allKeyResults}
        redFlags={openRedFlags}
        helpRequests={openHelpRequests}
        goals={notPersonalGoals}
      />
      <ScrollBackUpButton />
    </PageBackgroundPaper>
  );
}
