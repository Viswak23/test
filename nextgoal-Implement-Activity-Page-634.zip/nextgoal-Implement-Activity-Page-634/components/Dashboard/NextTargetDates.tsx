import { useMemo } from "react";
import { Box, List, ListItem, ListItemText, Stack } from "@mui/material";
import { useGoals } from "@/contexts/GoalsContext";
import { getNextFiveGoals } from "@/lib/webGoals";
import { SubheadingCard } from "@/components/Common/Texts/Texts";
import { FormattedMessage } from "react-intl";
import { NextTargetDate } from "./NextTargetDate";

export default function NextTargetDates() {
  const goals = useGoals()?.goals;
  const nextTargetDateGoals = useMemo(() => getNextFiveGoals(goals), [goals]);

  return (
    <Box style={{ margin: "40px 5px 40px 5px" }}>
      <SubheadingCard style={{ textAlign: "center", marginBottom: "24px" }}>
        <FormattedMessage id="goals.next.target.dates" />
      </SubheadingCard>
      <List dense={true} style={{ paddingTop: 0, marginTop: 0, width: "100%" }}>
        {nextTargetDateGoals.length === 0 && (
          <ListItem style={{ paddingLeft: 0 }}>
            <ListItemText
              primary={
                <FormattedMessage id="goals.no.goals.with.target.date" />
              }
            />
          </ListItem>
        )}
        {nextTargetDateGoals.map((goal) => {
          return <NextTargetDate key={goal.id} goal={goal} />;
        })}
      </List>
    </Box>
  );
}
