import { Box, ListItem, Stack } from "@mui/material";
import Breadcrumb, { BreadcrumbType } from "../Common/Breadcrumb/Breadcrumb";
import VisualProgress from "../Common/VisualProgress/VisualProgress";
import { showDate, timeToTarget } from "@/lib/time";
import { calculateProgress } from "@/lib/webGoals";
import { Goal } from "@/src/API";
import { useIntl } from "react-intl";
import {
  DetailsText,
  DetailsTextWithoutCustomBox,
  TextTimeSince,
} from "../Common/Texts/Texts";
import { useSettings } from "@/contexts/SettingsInfo";

interface NextTargetDateProps {
  goal: Goal;
}

export function NextTargetDate({ goal }: NextTargetDateProps) {
  const intl = useIntl();
  const dbUser = useSettings()?.dbUser;

  return (
    <ListItem style={{ paddingLeft: "12px" }}>
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: { xs: "1fr", sm: "200px 1fr" },
          gap: { xs: 2, sm: 6 }, // space btwn columns & rows
          paddingBottom: { xs: "12px", sm: "6px" },
          alignItems: "start",
        }}
      >
        {/* First column: date & days until/since label */}
        <Box>
          <Stack direction="column" spacing={2}>
            <DetailsTextWithoutCustomBox>
              {showDate(goal.targetDate, dbUser)}
            </DetailsTextWithoutCustomBox>
            <TextTimeSince>
              {timeToTarget(intl, goal?.targetDate)}
            </TextTimeSince>
          </Stack>
        </Box>

        {/* Second column: breadcrumb & progress bar */}
        <Box>
          <Stack direction="column" spacing={2}>
            <Breadcrumb
              type={BreadcrumbType.LIST}
              organizationUnitId={goal.organizationUnitGoalsId}
              showMainPage={!goal.organizationUnitGoalsId}
              showLastAsaLink
              extraElement={{
                title: goal.title,
                link: `/goals/${goal.id}`,
              }}
            />
            <VisualProgress value={calculateProgress(goal)} />
            <br />
          </Stack>
        </Box>
      </Box>
    </ListItem>
  );
}
