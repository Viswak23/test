import { useMemo } from "react";
import { Goal, KeyResult, RedFlag, HelpRequest } from "@/src/API";
import { Stack, useMediaQuery, useTheme } from "@mui/material";
import GoalDetailRow from "../Goal/GoalDetailRow";
import { calculateKeyResultsProgress } from "@/lib/webKeyResults";
import KeyResultsDistributionWithBadges from "../KeyResults/KeyResultsDistributionWithBadges";
import { useIntl } from "react-intl";

interface DashboardSummaryProps {
  goals?: (Goal | null)[];
  keyResults?: (KeyResult | null)[];
  openRedFlags?: (RedFlag | null)[];
  openHelpRequests?: (HelpRequest | null)[];
}

export default function DashboardSummary({
  goals,
  keyResults,
  openRedFlags,
  openHelpRequests,
}: DashboardSummaryProps) {
  const keyResultsProgress = useMemo(
    () => calculateKeyResultsProgress(keyResults),
    [keyResults]
  );
  const intl = useIntl();
  const theme = useTheme();
  const isMediumScreen = useMediaQuery(theme.breakpoints.down("md"));

  return (
    <Stack
      direction="column"
      spacing={2}
      alignItems={"center"}
      sx={{
        padding: "0px 0px 10px 0px",
      }}
    >
      <Stack
        direction={{ xs: "column", md: "row" }}
        spacing={{ xs: 2, lg: 4 }}
        alignItems={"center"}
      >
        <GoalDetailRow
          label={intl.formatMessage({ id: "goals.number.of.goals" })}
          centerItems
        >
          {goals?.length || 0}
        </GoalDetailRow>

        <GoalDetailRow
          centerItems
          label={intl.formatMessage({ id: "keyresults.readiness" })}
        >
          {`${keyResultsProgress || 0}%`}
        </GoalDetailRow>
        <GoalDetailRow
          centerItems
          label={intl.formatMessage({ id: "redflags.open.red.flags" })}
        >
          {`${openRedFlags?.length || 0}`}
        </GoalDetailRow>
        <GoalDetailRow
          centerItems
          label={intl.formatMessage({ id: "helprequests.open.help.requests" })}
        >
          {`${openHelpRequests?.length || 0}`}
        </GoalDetailRow>
      </Stack>
      <GoalDetailRow
        label={intl.formatMessage({ id: "keyresults.title" })}
        wrapToTextComponent={false}
        centerItems={isMediumScreen}
      >
        <KeyResultsDistributionWithBadges keyResults={keyResults} />
      </GoalDetailRow>
    </Stack>
  );
}
