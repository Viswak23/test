import { useState } from "react";
import { Goal, KeyResult, RedFlag, HelpRequest } from "@/src/API";
import RedFlags from "../RedFlags/RedFlags";
import HelpRequests from "../HelpRequests/HelpRequests";
import { Box, Tab, Tabs } from "@mui/material";
import GoalListDashboard from "../GoalList/GoalListInGrid";
import { FormattedMessage } from "react-intl";
import KeyResultsDistGraph from "../Graphs/KeyResultsDistGraph";
import FeedsContent from "../Feeds/FeedsContent";

interface TabPanelProps {
  goals?: (Goal | null)[];
  keyResults?: (KeyResult | null)[];
  redFlags?: (RedFlag | null)[];
  helpRequests?: (HelpRequest | null)[];
  organizationGoals?: (Goal | null)[];
}

enum TabIndex {
  KEY_RESULTS = 0,
  RED_FLAGS = 1,
  HELP_NEEDED = 2,
  GOALS = 3,
  FEEDS = 4,
}

export default function DashboardTabs({
  goals,
  keyResults,
  redFlags,
  helpRequests,
  organizationGoals, // Feeds are shown in organization details, not in dashboard
}: TabPanelProps) {
  const [selectedTab, setSelectedTab] = useState(TabIndex.KEY_RESULTS);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setSelectedTab(newValue);
  };

  function getTabContext(tabIndex: number) {
    switch (tabIndex) {
      case TabIndex.KEY_RESULTS:
        return <KeyResultsDistGraph keyResults={keyResults} />;
      case TabIndex.RED_FLAGS:
        return (
          <RedFlags redFlags={redFlags} canAdd={false} showResolved={false} />
        );
      case TabIndex.HELP_NEEDED:
        return (
          <HelpRequests helpRequests={helpRequests} showResolved={false} />
        );
      case TabIndex.GOALS:
        return <GoalListDashboard goals={goals} />;
      case TabIndex.FEEDS:
        return <FeedsContent organizationGoals={organizationGoals} />;
      default:
        return <div>Unknown tab</div>;
    }
  }

  return (
    <Box style={{ minHeight: "200px", marginTop: "24px" }}>
      <Tabs
        value={selectedTab}
        onChange={handleTabChange}
        variant="scrollable"
        scrollButtons="auto"
        data-cy="dashboard-tabs"
      >
        <Tab
          value={TabIndex.KEY_RESULTS}
          label={<FormattedMessage id="keyresults.title" />}
          data-cy="key-results-tab"
        />
        <Tab
          value={TabIndex.RED_FLAGS}
          label={<FormattedMessage id="redflags.open.red.flags" />}
          data-cy="red-flags-tab"
        />
        <Tab
          value={TabIndex.HELP_NEEDED}
          label={<FormattedMessage id="helprequests.open.help.requests" />}
          data-cy="help-needed-tab"
        />
        <Tab
          value={TabIndex.GOALS}
          label={<FormattedMessage id="goals.title" />}
          data-cy="goals-results-tab"
        />
        {organizationGoals && (
          <Tab
            value={TabIndex.FEEDS}
            label={<FormattedMessage id="feeds.title" />}
            data-cy="feeds-tab"
          />
        )}
      </Tabs>
      {getTabContext(selectedTab)}
    </Box>
  );
}
