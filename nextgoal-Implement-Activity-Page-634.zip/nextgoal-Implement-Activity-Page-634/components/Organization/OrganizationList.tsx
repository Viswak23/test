import * as React from "react";
import { useState, useMemo } from "react";
import EditOrganization from "@/components/Organization/EditOrganization";
import { HeadingMain2 } from "@/components/Common/Texts/Texts";
import Stack from "@mui/material/Stack";
import { useOrganization } from "@/contexts/OrganizationContext";
import OrganizationBreadCrumb from "@/components/Common/Breadcrumb/OrganizationBreadCrumb";
import { getOrganizationIdPath } from "@/lib/webBreadCrumb";
import { Button, useTheme } from "@mui/material";
import EmployeesList from "@/components/Employee/EmployeesList";
import { sortOrganizationUnits } from "@/lib/webOrganization";
import OrganizationUnitsInOrder from "./OrganizationUnitsInOrder";
import AddEmployeeToOrganizationUnit from "../Employee/AddEmployeeToOrganizationUnit";
import { FormattedMessage, useIntl } from "react-intl";
import PageBackgroundPaper from "../Common/Layout/PageBackgroundPaper";

interface OrganizationListProps {
  parentOrganizationUnitId?: string;
}

export default function OrganizationList({
  parentOrganizationUnitId,
}: OrganizationListProps) {
  const [currentOrganizationUnitId, setCurrentOrganizationUnitId] = useState(
    parentOrganizationUnitId
  );
  const [addingOrg, setAddingOrg] = useState(false);
  const [addingEmployee, setAddingEmployee] = useState(false);
  const organization = useOrganization()?.organization;
  const intl = useIntl();
  const theme = useTheme();

  const handleAddOrganization = () => {
    setAddingOrg(true);
  };

  const handleAddOrganizationClose = () => {
    setAddingOrg(false);
  };

  const handleAddEmployee = () => {
    setAddingEmployee(true);
  };

  const handleAddEmployeeClose = () => {
    setAddingEmployee(false);
  };

  const handleSelectOrgnanization = (organizationId: string | undefined) => {
    setCurrentOrganizationUnitId(organizationId);
  };

  let subOrganization = useMemo(() => {
    let result = organization?.filter(
      (org) =>
        (currentOrganizationUnitId == null &&
          org.organizationUnitChildOrzganizationUnitsId == null) ||
        (org.organizationUnitChildOrzganizationUnitsId != null &&
          currentOrganizationUnitId ===
            org.organizationUnitChildOrzganizationUnitsId)
    );
    return sortOrganizationUnits(result);
  }, [organization, currentOrganizationUnitId]);
  const newPosition = subOrganization?.length || 0;

  const orgIdPath =
    currentOrganizationUnitId && organization
      ? getOrganizationIdPath(
          organization,
          intl.formatMessage({ id: "organizationunits.top.level" }),
          currentOrganizationUnitId,
          parentOrganizationUnitId
        )
      : undefined;
  const lastElement = orgIdPath?.pop();
  const currentOrganizationUnit = organization?.find(
    (org) => org.id === currentOrganizationUnitId
  );

  return (
    <PageBackgroundPaper
      style={{
        backgroundColor: theme.palette.customColors?.lightest,
      }}
      headerSpace={false}
    >
      <HeadingMain2>
        <FormattedMessage id="organizationunits.title" />
      </HeadingMain2>
      <Stack
        spacing={{
          xs: 2,
          sm: 1,
        }}
        direction="column"
      >
        {orgIdPath && (
          <OrganizationBreadCrumb
            organizationPath={orgIdPath}
            lastElement={lastElement}
            onSelectOrganization={handleSelectOrgnanization}
          />
        )}
        {/* The organizations! */}
        <OrganizationUnitsInOrder
          key={`ordered-org-list-${subOrganization[0]?.id}-${subOrganization.length}`}
          organizationUnits={subOrganization}
          onSelectOrgnanization={handleSelectOrgnanization}
        />

        <EmployeesList organizationUnit={currentOrganizationUnit} />

        {/* Buttons */}
        <Stack
          direction={{ xs: "column", sm: "row" }}
          sx={{
            overflow: "auto",
            justifyContent: {
              xs: "center",
              sm: "flex-start",
            },
            alignItems: "center",
            paddingTop: {
              xs: "12px",
              sm: "6px",
            },
          }}
          style={{ marginTop: "12px" }}
          spacing={{
            xs: 2,
            sm: 2,
          }}
        >
          <Button
            variant="contained"
            data-cy="add-organization-unit-button"
            onClick={handleAddOrganization}
            sx={{
              padding: { xs: 2, sm: 1 },
              minWidth: "240px",
              width: { xs: "100%", sm: "auto" },
              alignSelf: "center",
            }}
          >
            <FormattedMessage id="organizationunits.add" />
          </Button>
          {currentOrganizationUnitId && (
            <Button
              variant="contained"
              data-cy="add-employee-button"
              onClick={handleAddEmployee}
              sx={{
                padding: { xs: 2, sm: 1 },
                minWidth: "240px",
                width: { xs: "100%", sm: "auto" },
                alignSelf: "center",
              }}
              disabled={!currentOrganizationUnitId}
            >
              <FormattedMessage id="employees.title" />
            </Button>
          )}
        </Stack>
      </Stack>

      {addingOrg && (
        <EditOrganization
          parentOrganizationId={currentOrganizationUnitId}
          newPosition={newPosition}
          open={addingOrg}
          onClose={handleAddOrganizationClose}
        />
      )}
      {addingEmployee && currentOrganizationUnit && (
        <AddEmployeeToOrganizationUnit
          organizationUnit={currentOrganizationUnit}
          open={addingEmployee}
          onClose={handleAddEmployeeClose}
        />
      )}
    </PageBackgroundPaper>
  );
}
