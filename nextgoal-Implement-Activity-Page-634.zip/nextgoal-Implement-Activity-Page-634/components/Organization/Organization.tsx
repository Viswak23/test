import { useState, useMemo, useRef } from "react";
import Edit from "@mui/icons-material/Edit";
import Link from "next/link";
import { OrganizationUnit } from "@/src/API";
import Card from "@mui/material/Card";
import Stack from "@mui/material/Stack";
import { SubheadingCard } from "../Common/Texts/Texts";
import IconButton from "@mui/material/IconButton";
import Source from "@mui/icons-material/Source";
import ExpandMore from "@/components/Common/ExpandMore/ExpandMore";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { getAllSuborganizations } from "@/lib/webOrganization";
import EditOrganization from "@/components/Organization/EditOrganization";
import { useOrganization } from "@/contexts/OrganizationContext";
import { useDrag, useDrop } from "react-dnd";
import { DragItemTypes } from "../Common/DragAndDrop/DragItemTypes";

import CustomBox from "../Common/Layout/CustomBox";
import { FormattedMessage, useIntl } from "react-intl";
import DetailsButton from "../Common/Buttons/DetailsButton";

type OrganizationProps = {
  organizationUnit: OrganizationUnit;
  currentPosition: number;
  onSelectOrganization: (organizationId: string | undefined) => void;
  onPositionChange: (dragId: string, hoverIndex: number) => void;
  onPositionSave: () => void;
};

export default function Organization({
  organizationUnit,
  currentPosition,
  onSelectOrganization,
  onPositionChange,
  onPositionSave,
}: OrganizationProps) {
  const [editOrg, setEditOrg] = useState(false);
  const ref = useRef(null);
  const [{ isDragging }, drag] = useDrag(() => ({
    type: DragItemTypes.ORGANIZATION_CARD,
    item: () => {
      return { id: organizationUnit.id, index: currentPosition };
    },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }));
  const [{ isOver }, drop] = useDrop(() => ({
    accept: DragItemTypes.ORGANIZATION_CARD,
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
    hover(item: any, monitor) {
      // Example: https://codesandbox.io/s/github/react-dnd/react-dnd/tree/gh-pages/examples_hooks_ts/04-sortable/simple?from-embed=&file=/src/Container.tsx
      if (!ref.current) {
        return;
      }

      const dragIndex = item.index;
      const hoverIndex = currentPosition;
      if (item.id === organizationUnit.id) {
        return;
      }

      const hoverBoundingRect = (
        ref.current as HTMLDivElement
      ).getBoundingClientRect();

      const hoverMiddleX =
        (hoverBoundingRect.right - hoverBoundingRect.left) / 2;
      const clientOffset = monitor.getClientOffset();
      const hoverClientX = (clientOffset as any).x - hoverBoundingRect.left;
      // When dragging right, move when > 50% of the width
      // When dragging left, move when < 50% of the width
      if (dragIndex < hoverIndex && hoverClientX < hoverMiddleX - 20) {
        return;
      }
      if (dragIndex > hoverIndex && hoverClientX > hoverMiddleX + 20) {
        return;
      }

      onPositionChange(item.id, hoverIndex);
    },
    drop() {
      // Save positions to database after drop
      onPositionSave();
    },
  }));
  const organization = useOrganization()?.organization;

  // Get the number of suborganizations
  const suborgs = useMemo(
    () => getAllSuborganizations(organizationUnit.id, organization),
    [organizationUnit, organization]
  );

  const draggingStyle = isDragging ? { opacity: 0.5 } : {};
  const overStyle = isOver ? { background: "#f5f5f5" } : {};
  drag(drop(ref));

  const intl = useIntl();
  const editLabel = intl.formatMessage({ id: "general.edit" });
  const showMoreLabel = intl.formatMessage({ id: "general.show.more" });
  const detailsLabel = intl.formatMessage({ id: "general.details" });

  return (
    <>
      <Card
        ref={ref}
        data-cy={`organization-unit-card-${organizationUnit.name}`}
        style={{
          ...draggingStyle,
          ...overStyle,
          marginBottom: "12px",
          paddingLeft: "6px",
          paddingBottom: "5px",
          boxShadow:
            "rgba(67, 71, 85, 0.27) 0px 0px 0.25em, rgba(90, 125, 188, 0.05) 0px 0.25em 1em",
        }}
      >
        <Stack
          direction="column"
          spacing={1}
          alignItems="center"
          justifyContent="space-between"
          style={{ height: "100%" }}
          textOverflow={"ellipsis"}
        >
          <CustomBox>
            <SubheadingCard>{organizationUnit?.name || ""}</SubheadingCard>
          </CustomBox>
          <Stack
            direction="row"
            spacing={{ xs: 0.5, sm: 1, md: 2 }} // between org. btns
            justifyContent="end"
            alignItems="center"
            paddingRight="10px"
            paddingLeft="10px"
            paddingBottom="10px"
            paddingTop="5px"
          >
            <SubheadingCard>{`${suborgs.length} org`}</SubheadingCard>
            <ExpandMore
              expand={false}
              onClick={() => onSelectOrganization(organizationUnit.id)}
              aria-expanded={false}
              aria-label={showMoreLabel}
              data-cy="expand-organization-unit-button"
              sx={{ color: "primary.main" }}
              style={{ marginLeft: "6px" }}
              expandedTooltip={<FormattedMessage id="general.show.less" />}
              collapsedTooltip={<FormattedMessage id="general.show.more" />}
            />

            <IconButton
              aria-label={editLabel}
              color="primary"
              data-cy="edit-organization-unit-button"
              onClick={() => setEditOrg(true)}
            >
              <Edit />
            </IconButton>
            <DetailsButton
              tooltip={detailsLabel}
              href={`/organization/${organizationUnit.id}`}
              dataCy="link-to-organization-details"
            />
          </Stack>
        </Stack>
      </Card>
      {editOrg && (
        <EditOrganization
          key={organizationUnit.name}
          orgUnit={organizationUnit}
          open={editOrg}
          onClose={() => setEditOrg(false)}
        />
      )}
    </>
  );
}
