import { useState, useMemo } from "react";
import { DetailsLabel, HeadingMain } from "../Common/Texts/Texts";
import Stack from "@mui/material/Stack";
import EditOrganization from "./EditOrganization";
import { useOrganization } from "@/contexts/OrganizationContext";
import { useTheme } from "@mui/material";
import Grid from "@mui/material/Unstable_Grid2";
import ExpandMore from "../Common/ExpandMore/ExpandMore";
import DashboardSummary from "../Dashboard/DashboardSummary";
import { useGoals } from "@/contexts/GoalsContext";
import {
  deleteOrganizationUnitWithChildrenDb,
  getAllSuborganizations,
  getOrganizationUnitGoals,
} from "@/lib/webOrganization";
import { getKeyResults } from "@/lib/webKeyResults";
import { getRedFlags } from "@/lib/webRedFlags";
import { getHelpRequests } from "@/lib/webHelpRequests";
import DashboardTabs from "../Dashboard/DashboardTabs";
import InformationDialog from "../Common/InformationDialog/InformationDialog";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import { useEmployees } from "@/contexts/EmployeesContext";
import DeleteButton from "../Common/Buttons/DeleteButton";
import { canDeleteDbItem } from "@/lib/webHelpers";
import { FormattedMessage, useIntl } from "react-intl";
import { OrganizationUnit } from "@/src/API";
import PageBackgroundPaper from "../Common/Layout/PageBackgroundPaper";
import GoalDetailRow from "../Goal/GoalDetailRow";
import Breadcrumb from "../Common/Breadcrumb/Breadcrumb";
import { hoverMainToPressed } from "@/config/styling";
import EditButton from "../Common/Buttons/EditButton";
import { Pages } from "@/lib/webNavigation";
import router from "next/router";

interface OrganizationDetailsProps {
  organizationUnit: OrganizationUnit;
}

export default function OrganizationDetails({
  organizationUnit,
}: OrganizationDetailsProps) {
  const [editMode, setEditMode] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [showCannotDeleteOrganization, setShowCannotDeleteOrganization] =
    useState(false);
  const [
    showConfirmDeleteOrganizationUnit,
    setShowConfirmDeleteOrganizationUnit,
  ] = useState(false);
  const [saving, setSaving] = useState(false);

  const organization = useOrganization();
  const employeeJoins = useEmployees()?.organizationUnitEmployeeJoins;
  const goals = useGoals()?.goals;
  const intl = useIntl();
  const theme = useTheme();
  const editLabel = intl.formatMessage({ id: "general.edit" });
  const showMoreLabel = intl.formatMessage({ id: "general.show.more" });

  const organizationGoals = useMemo(
    () => getOrganizationUnitGoals(organizationUnit?.id, goals),
    [organizationUnit?.id, goals]
  );

  const allKeyResults = useMemo(() => {
    return getKeyResults(organizationGoals);
  }, [organizationGoals]);

  const openRedFlags = useMemo(() => {
    return getRedFlags(organizationGoals, false);
  }, [organizationGoals]);

  const openHelpRequests = useMemo(() => {
    return getHelpRequests(organizationGoals, false);
  }, [organizationGoals]);

  const handleEdit = () => {
    setEditMode(true);
  };

  const handleClose = () => {
    setEditMode(false);
  };

  const handleDeleteOrganizationUnit = () => {
    if (!organizationUnit) return;

    // Check if child organization units exists.
    const childOrgUnits = getAllSuborganizations(
      organizationUnit.id,
      organization?.organization
    );
    if (childOrgUnits.length) {
      setShowCannotDeleteOrganization(true);
      return;
    }

    const childGoals = getOrganizationUnitGoals(organizationUnit.id, goals);
    if (childGoals.length) {
      setShowCannotDeleteOrganization(true);
      return;
    }

    setShowConfirmDeleteOrganizationUnit(true);
  };

  const handleCloseCannotDeleteOrganizationUnit = () => {
    setShowCannotDeleteOrganization(false);
  };

  const handleConfirmDeleteOrganizationUnit = async () => {
    setSaving(true);
    await deleteOrganizationUnitWithChildrenDb(organizationUnit, employeeJoins);
    // If parent organizationUnit, redirect to there. Otherwise, redirect to main page.
    if (organizationUnit?.organizationUnitChildOrzganizationUnitsId) {
      window.location.href = `/organization/${organizationUnit?.organizationUnitChildOrzganizationUnitsId}`;
    } else {
       try {
           await deleteOrganizationUnitWithChildrenDb(organizationUnit, employeeJoins);
           router.push(Pages.appGoals);
         } catch (error) {
           console.error('Failed to delete organization unit:', error);
           // Show error message to user
         } finally {
           setSaving(false);
         }
        
    }
  };

  const handleCancelDeleteOrganizationUnit = () => {
    setShowConfirmDeleteOrganizationUnit(false);
  };

  return (
    <>
      <PageBackgroundPaper>
        <Grid container spacing={2}>
          <Grid xs={0} sm={2} />
          <Grid
            xs={12}
            sm={8}
            alignContent="center"
            sx={{ textAlign: "center", wordBreak: "break-word" }}
          >
            <HeadingMain>{organizationUnit?.name}</HeadingMain>
            <DetailsLabel>{organizationUnit?.description}</DetailsLabel>
          </Grid>
          <Grid xs={12} sm={2}>
            {/* Org. buttons */}
            <Stack
              direction="row"
              spacing={1}
              sx={{ paddingBottom: "12px" }}
              alignItems="center"
              justifyContent={{ xs: "center", sm: "flex-end" }}
            >
              <Stack>
                <ExpandMore
                  expand={expanded}
                  onClick={() => setExpanded(!expanded)}
                  aria-expanded={expanded}
                  aria-label={showMoreLabel}
                  sx={{ ...hoverMainToPressed(theme) }}
                  expandedTooltip={<FormattedMessage id="general.show.less" />}
                  collapsedTooltip={<FormattedMessage id="general.show.more" />}
                />
              </Stack>

              <Stack>
                <EditButton
                  onClick={handleEdit}
                  tooltip={intl.formatMessage({ id: "general.edit" })}
                />
              </Stack>

              <Stack>
                <DeleteButton
                  disabled={!canDeleteDbItem(organizationUnit)}
                  onClick={handleDeleteOrganizationUnit}
                  tooltip={intl.formatMessage({
                    id: "organizationunits.delete.caption",
                  })}
                  disabledTooltip={intl.formatMessage({
                    id: "organizationunits.delete.disabled.tooltip",
                  })}
                />
              </Stack>
            </Stack>
          </Grid>
          <Grid xs={0} sm={2} />
          <Grid xs={12} sm={8}>
            <Stack
              direction="column"
              sx={{
                alignItems: "center",
                paddingBottom: "15px",
              }}
            >
              <GoalDetailRow
                style={{
                  fontWeight: "bold",
                  color: theme.palette.secondary.main,
                }}
                label={intl.formatMessage({
                  id: "organizationunits.parent.organization.units",
                })}
                wrapToTextComponent={false}
              >
                {organizationUnit.organizationUnitChildOrzganizationUnitsId ? (
                  <Breadcrumb
                    organizationUnitId={organizationUnit.id}
                    showMainPage={false}
                  />
                ) : (
                  <DetailsLabel>
                    <FormattedMessage id="organizationunits.no.organization.units" />
                  </DetailsLabel>
                )}
              </GoalDetailRow>
            </Stack>
          </Grid>
        </Grid>
        {expanded && (
          <>
            <DashboardSummary
              goals={organizationGoals}
              keyResults={allKeyResults}
              openRedFlags={openRedFlags}
              openHelpRequests={openHelpRequests}
            />
            <DashboardTabs
              keyResults={allKeyResults}
              redFlags={openRedFlags}
              helpRequests={openHelpRequests}
              goals={organizationGoals}
              organizationGoals={organizationGoals}
            />
          </>
        )}
      </PageBackgroundPaper>
      {editMode && (
        <EditOrganization
          key={organizationUnit?.name}
          orgUnit={organizationUnit}
          open={editMode}
          onClose={handleClose}
        />
      )}
      {showCannotDeleteOrganization && (
        <InformationDialog
          title={intl.formatMessage({
            id: "organizationunits.error.cannot.delete.caption",
          })}
          message={intl.formatMessage({
            id: "organizationunits.error.cannot.delete.message",
          })}
          open={showCannotDeleteOrganization}
          onClose={handleCloseCannotDeleteOrganizationUnit}
        />
      )}
      {showConfirmDeleteOrganizationUnit && (
        <ConfirmationDialog
          title={intl.formatMessage({ id: "organizationunits.delete.caption" })}
          message={intl.formatMessage({
            id: "organizationunits.delete.confirmation",
          })}
          messageItem={organizationUnit?.name || ""}
          open={showConfirmDeleteOrganizationUnit}
          saving={saving}
          onConfirm={handleConfirmDeleteOrganizationUnit}
          onCancel={handleCancelDeleteOrganizationUnit}
        />
      )}
    </>
  );
}
