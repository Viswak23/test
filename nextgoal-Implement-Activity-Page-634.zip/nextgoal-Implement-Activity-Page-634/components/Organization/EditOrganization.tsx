import React from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import TextField from "@mui/material/TextField";
import {
  addOrganizationUnitDb,
  updateOrganizationUnitDb,
} from "@/lib/webOrganization";
import {
  UpdateOrganizationUnitInput,
  CreateOrganizationUnitInput,
  OrganizationUnit,
} from "@/src/API";
import { useImmer } from "use-immer";
import { useAuthStatus } from "@/lib/customHooks";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import { Alert, Stack } from "@mui/material";
import { FormattedMessage, useIntl } from "react-intl";
import { log } from "@/lib/backend/actions/logger";
import { FormTitle } from "../Common/Texts/Texts";
import HelpButton from "../Common/Buttons/HelpButton";
import HelpCollapse from "../Common/Dialog/HelpCollapse";

interface EditOrganizationProps {
  orgUnit?: OrganizationUnit;
  parentOrganizationId?: string;
  newPosition?: number;
  open: boolean;
  onClose: () => void;
}

export default function EditOrganization({
  orgUnit,
  parentOrganizationId,
  newPosition,
  open,
  onClose,
}: EditOrganizationProps) {
  const defaultOrganization = {
    name: "",
    companyId: "placeholder",
    creatorEmail: "placeholder",
  };

  const [editOrganizationUnit, setEditOrganizationUnit] = useImmer<
    CreateOrganizationUnitInput | UpdateOrganizationUnitInput
  >(orgUnit || { ...defaultOrganization });
  const [saving, setSaving] = React.useState(false);
  const [nameError, setNameError] = React.useState("");
  const [error, setError] = React.useState("");
  const [showHelp, setShowHelp] = React.useState(false);
  const currentUser = useAuthStatus();
  const intl = useIntl();

  const resetStates = () => {
    setEditOrganizationUnit(orgUnit || { ...defaultOrganization });
    setSaving(false);
    setNameError("");
  };

  const handleOrgTitleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setNameError("");
    setEditOrganizationUnit((draft) => {
      draft.name = event.target.value;
    });
  };

  const handleOrgDescriptionChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditOrganizationUnit((draft) => {
      draft.description = event.target.value;
    });
  };

  const handleCancel = () => {
    resetStates();
    onClose();
  };

  const handleSave = async () => {
    if (!editOrganizationUnit.name) {
      setNameError(
        intl.formatMessage({ id: "organizationunits.error.name.required" })
      );
      return;
    }

    try {
      setSaving(true);
      if (orgUnit) {
        await updateOrganizationUnitDb(
          editOrganizationUnit as UpdateOrganizationUnitInput
        );
      } else {
        const newOrganization = {
          ...editOrganizationUnit,
          organizationUnitChildOrzganizationUnitsId: parentOrganizationId,
          creatorEmail: currentUser?.attributes.email,
          position: newPosition,
        };
        await addOrganizationUnitDb(
          newOrganization as CreateOrganizationUnitInput
        );
      }
      resetStates();
      onClose();
    } catch (error: any) {
      log(`Add/Edit Organization: ${error.message}`);
      setError("Unable to save, please try again...");
      setSaving(false);
    }
  };

  const dialogTitle = orgUnit ? (
    <FormTitle>
      <FormattedMessage id="organizationunits.edit" />
    </FormTitle>
  ) : (
    <FormTitle>
      <FormattedMessage id="organizationunits.add" />
    </FormTitle>
  );

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      fullWidth={true}
      maxWidth="lg"
      disableRestoreFocus
      onKeyUp={(e) => {
        if (e.key === "Enter") handleSave();
      }}
    >
      <DialogTitle>
        <Stack direction="row" spacing={1} alignItems={"center"}>
          {dialogTitle}
          <HelpButton
            onClick={handleToggleHelp}
            data-cy="show-add-organization-help"
          />
        </Stack>
      </DialogTitle>
      <DialogContent>
        <HelpCollapse
          showHelp={showHelp}
          helpText={intl.formatMessage({ id: "organizationunits.help.text" })}
        />
        <TextField
          autoFocus={true}
          margin="dense"
          id="name"
          label={<FormattedMessage id="organizationunits.name" />}
          type="text"
          fullWidth
          variant="standard"
          autoComplete="off"
          required
          helperText={nameError}
          error={nameError !== ""}
          value={editOrganizationUnit.name || ""}
          data-cy="edit-organization-name-input"
          onChange={handleOrgTitleChange}
        />
        {error && <Alert severity="error">{error}</Alert>}

        <TextField
          margin="dense"
          id="description"
          label={<FormattedMessage id="organizationunits.description" />}
          type="text"
          fullWidth
          variant="standard"
          autoComplete="off"
          helperText={
            <FormattedMessage id="organizationunits.description.helper" />
          }
          value={editOrganizationUnit.description}
          data-cy="edit-organization-description-input"
          onChange={handleOrgDescriptionChange}
        />
      </DialogContent>
      <EditDialogActions
        saving={saving}
        onCancel={handleCancel}
        onSave={handleSave}
      />
    </Dialog>
  );
}
