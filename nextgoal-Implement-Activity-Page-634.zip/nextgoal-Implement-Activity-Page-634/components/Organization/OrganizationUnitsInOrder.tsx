import React from "react";
import { useState } from "react";
import { Box, Stack } from "@mui/material";
import Organization from "./Organization";
import { updateOrganizationUnitDb } from "@/lib/webOrganization";

interface OrganizationUnitsInOrderProps {
  organizationUnits: any[];
  onSelectOrgnanization: (organizationId: string | undefined) => void;
}

export default function OrganizationUnitsInOrder({
  organizationUnits,
  onSelectOrgnanization,
}: OrganizationUnitsInOrderProps) {
  function setInitialOrder() {
    return organizationUnits.map((org) => org.id);
  }
  const [order, setOrder] = useState<string[]>(setInitialOrder);

  const handlePositionChange = (dragId: string, hoverIndex: number) => {
    setOrder((prevOrder) => {
      const newOrder = [...prevOrder];
      newOrder.splice(prevOrder.indexOf(dragId), 1);
      newOrder.splice(hoverIndex, 0, dragId);
      return newOrder;
    });
  };

  const handleSavePositions = async () => {
    await Promise.all(
      order.map((orgId, index) => {
        const org = organizationUnits.find((org) => org.id === orgId);
        if (!org) {
          return Promise.resolve();
        }
        return updateOrganizationUnitDb({ ...org, position: index });
      })
    );
  };

  return (
    // returns container for the org. items
    <Stack
      direction={{ xs: "column", md: "row" }}
      spacing={2}
      flexWrap="wrap"
      useFlexGap
      sx={{ width: "100%" }}
    >
      {order.map((orderItem, index) => {
        const orgUnit = organizationUnits.find((ou) => ou.id === orderItem);
        if (!orgUnit) {
          return null;
        }

        return (
          // returns org. items: allowing for proper organization within container & individual styling for each item
          <Box
            key={`${orgUnit.id}-${index}`}
            sx={{
              width: { xs: "100%", md: "240px" },
            }}
          >
            <Organization
              organizationUnit={orgUnit}
              currentPosition={index}
              onSelectOrganization={onSelectOrgnanization}
              onPositionChange={handlePositionChange}
              onPositionSave={handleSavePositions}
            />
          </Box>
        );
      })}
    </Stack>
  );
}
