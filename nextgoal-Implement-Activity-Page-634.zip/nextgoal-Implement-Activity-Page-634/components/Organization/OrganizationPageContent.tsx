"use client";

import Breadcrumb from "../Common/Breadcrumb/Breadcrumb";
import { Stack } from "@mui/material";
import OrganizationDetails from "./OrganizationDetails";
import OrganizationUnitGoalList from "../GoalList/OrganizationUnitGoalList";
import OrganizationList from "./OrganizationList";
import Message from "../Common/Message/Message";
import ScrollBackUpButton from "../Common/Buttons/ScrollBackUpButton";
import { OrganizationUnit } from "@/src/API";
import PageMessage from "../Common/Message/PageMessage";
import { useOrganization } from "@/contexts/OrganizationContext";
import { useIntl } from "react-intl";

interface OrganizationPageContentProps {
  organizationUnitId: string;
}

export default function OrganizationPageContent({
  organizationUnitId,
}: OrganizationPageContentProps) {
  const organization = useOrganization()?.organization;
  const intl = useIntl();
  const currentOrganizationUnit = organization?.find(
    (orgUnit: OrganizationUnit) => orgUnit.id === organizationUnitId
  );

  if (!currentOrganizationUnit) {
    return (
      <PageMessage
        message={intl.formatMessage({
          id: "organizationunits.error.loading.failed",
        })}
      />
    );
  }

  return (
    <>
      <OrganizationDetails organizationUnit={currentOrganizationUnit} />
      <Stack direction="column" spacing={2}>
        <OrganizationUnitGoalList organizationUnit={currentOrganizationUnit} />
        <OrganizationUnitGoalList
          organizationUnit={currentOrganizationUnit}
          internalGoals
        />
        <OrganizationList
          parentOrganizationUnitId={currentOrganizationUnit.id}
        />
        <ScrollBackUpButton />
      </Stack>
      <Message />
    </>
  );
}
