import { useMemo, useState } from "react";
import CommentItem from "./CommentItem";
import EditComment from "./EditComment";
import { Comment } from "@/src/API";
import { sortCreatedAtAscending } from "@/lib/time";
import { FormattedMessage } from "react-intl";
import { LackOfLikes } from "../Common/Texts/Texts";
import { EmployeeWithAvatarUrl } from "@/contexts/EmployeesContext";

interface SubItemCommentsProps {
  comments?: (Comment | null)[];
  parentGoalId?: string;
  addingComment: boolean;
  onCloseAddComment: (saved: boolean) => void;
  goalId?: string | null;
  keyResultId?: string | null;
  redFlagId?: string | null;
  statusId?: string | null;
  successStoryId?: string | null;
  contributionId?: string | null;
  taskId?: string | null;
  ideaId?: string | null;
  helpRequestId?: string | null;
  keyResultUpdateId?: string | null;
  eventId?: string | null;
  taggedEmployees?: EmployeeWithAvatarUrl[];
}

export default function SubItemComments({
  comments,
  parentGoalId,
  addingComment,
  onCloseAddComment,
  goalId,
  keyResultId,
  redFlagId,
  statusId,
  successStoryId,
  contributionId,
  taskId,
  ideaId,
  helpRequestId,
  keyResultUpdateId,
  eventId,
  taggedEmployees,
}: SubItemCommentsProps) {
  const [editingComment, setEditingComment] = useState<Comment>();
  const handleEditComment = (comment: Comment) => {
    setEditingComment(comment);
  };

  const handleCloseEditComment = () => {
    setEditingComment(undefined);
  };

  // Check that comments are in correct order.
  const visibleComments = useMemo(() => {
    if (!comments) return null;
    return [...comments].sort(sortCreatedAtAscending);
  }, [comments]);

  if (!parentGoalId) {
    return (
      <div>
        <FormattedMessage id="comment.error.could.not.find.parent.goal" />
      </div>
    );
  }

  return (
    <>
      {visibleComments &&
        visibleComments.map((comment) => {
          if (editingComment && editingComment.id === comment?.id) {
            return (
              <EditComment
                key={comment?.id}
                comment={comment}
                parentGoalId={parentGoalId}
                onClose={handleCloseEditComment}
                eventId={eventId || undefined}
              />
            );
          }
          return (
            <CommentItem
              key={comment?.id}
              comment={comment}
              parentGoalId={parentGoalId}
              onEdit={handleEditComment}
              eventId={eventId || undefined}
              taggedEmployees={taggedEmployees}
            />
          );
        })}
      {(!comments || comments.length === 0) && !addingComment && (
        <div>
          <LackOfLikes>
            <FormattedMessage id="comment.no.comments" />
          </LackOfLikes>
        </div>
      )}
      {addingComment && (
        /* EditComment is giving id's to the save db functions. Nulls are not accepted, either a value or undefined. */
        <EditComment
          goalId={goalId || undefined}
          parentGoalId={parentGoalId}
          keyResultId={keyResultId || undefined}
          redFlagId={redFlagId || undefined}
          statusId={statusId || undefined}
          successStoryId={successStoryId || undefined}
          contributionId={contributionId || undefined}
          taskId={taskId || undefined}
          ideaId={ideaId || undefined}
          helpRequestId={helpRequestId || undefined}
          keyResultUpdateId={keyResultUpdateId || undefined}
          onClose={onCloseAddComment}
          eventId={eventId || undefined}
          taggedEmployees={taggedEmployees}
        />
      )}
    </>
  );
}
