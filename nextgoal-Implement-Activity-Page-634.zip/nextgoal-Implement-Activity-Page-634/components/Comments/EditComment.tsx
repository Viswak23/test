import React, { useMemo, useState } from "react";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import { Comment, CreateCommentInput, UpdateCommentInput } from "@/src/API";
import {
  addCommentDb,
  getCommentById,
  updateCommentDb,
} from "@/lib/webComments";
import { useImmer } from "use-immer";
import { useAuthStatus } from "@/lib/customHooks";
import { FormattedMessage, useIntl } from "react-intl";
import { Alert } from "@mui/material";
import theme from "@/config/theme";
import { hoverMainToAdd, hoverMainToRed } from "@/config/styling";
import { log } from "@/lib/backend/actions/logger";
import {
  createNewNotification,
  NotificationType,
} from "@/lib/webNotifications";
import {
  EmployeeWithAvatarUrl,
  useEmployees,
} from "@/contexts/EmployeesContext";
import { useGoals } from "@/contexts/GoalsContext";
import { useEvents } from "@/contexts/EventsContext";
import { getEventEmployeeJoinIdField, getEventInfo } from "@/lib/webEvents";
import { useTaggedEmployeesFromJoin } from "@/lib/webEmployee";

interface EditCommentProps {
  comment?: CreateCommentInput | UpdateCommentInput;
  goalId?: string; // There can be comments for other entities than goals
  commentId?: string; // Reply to a comment
  statusId?: string; // A comment to a status
  redFlagId?: string; // A comment to a red flag
  successStoryId?: string; // A comment to a success story
  taskId?: string; // A comment to a task
  keyResultId?: string; // A comment to a key result
  contributionId?: string; // A comment to a contribution
  ideaId?: string; // A comment to an idea
  helpRequestId?: string; // A comment to a help request
  keyResultUpdateId?: string; // A comment to a key result update
  parentGoalId: string; // We want the event to have always a pointer to the goal who's subitem it is
  onClose: (saved: boolean) => void;
  eventId?: string;
  parentComment?: Comment;
  taggedEmployees?: EmployeeWithAvatarUrl[];
}

export default function EditComment({
  comment,
  goalId,
  commentId,
  statusId,
  redFlagId,
  successStoryId,
  taskId,
  keyResultId,
  contributionId,
  ideaId,
  helpRequestId,
  keyResultUpdateId,
  parentGoalId,
  onClose,
  eventId,
  parentComment,
  taggedEmployees,
}: EditCommentProps) {
  const defaultComment = {
    text: "",
    companyId: "placeholder",
    hostGoalId: "placeholder",
    creatorEmail: "placeholder",
  };
  const [newComment, setNewComment] = useImmer<
    CreateCommentInput | UpdateCommentInput
  >(
    comment || {
      ...defaultComment,
    }
  );
  const currentUser = useAuthStatus();
  const [saveError, setSaveError] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const intl = useIntl();
  const employees = useEmployees()?.employees!;
  const goals = useGoals()?.goals!;
  const archivedGoals = useGoals()?.archivedGoals!;
  const event = useEvents()?.events.find((event) => event.id == eventId);
  const goal = [...goals, ...archivedGoals].find(
    (goal) => goal.id === parentGoalId
  );
  const isPersonalGoal = goal?.employeeGoalsId ? true : false;

  const resetState = () => {
    setNewComment(
      comment || {
        ...defaultComment,
      }
    );
    setSaveError("");
    setIsSaving(false);
  };

  const handleSave = async () => {
    try {
      setIsSaving(true);
      if (!comment) {
        const updateObject = {
          ...newComment,
          goalCommentsId: goalId,
          commentRepliesId: commentId,
          statusCommentsId: statusId,
          redFlagCommentsId: redFlagId,
          taskCommentsId: taskId,
          successStoryCommentsId: successStoryId,
          keyResultCommentsId: keyResultId,
          contributionCommentsId: contributionId,
          ideaCommentsId: ideaId,
          helpRequestCommentsId: helpRequestId,
          keyResultUpdateCommentsId: keyResultUpdateId,
          creatorEmail: currentUser?.attributes.email,
        } as CreateCommentInput;

        await addCommentDb(updateObject as CreateCommentInput, parentGoalId);
        //if comment id exists, means it's a reply
        if (!isPersonalGoal) {
          if (commentId) {
            //reply
            const commentOwner =
              employees.find((e) => e.email === parentComment?.owner) || null;
            if (commentOwner) {
              await createNewNotification(
                NotificationType.REPLY,
                [commentOwner],
                currentUser?.attributes.email,
                eventId,
                parentGoalId
              );
            }
          } else {
            const eventOwner = employees.find((e) => e.email === event?.owner);
            let employeesOfInterest = taggedEmployees || [eventOwner];
            await createNewNotification(
              NotificationType.COMMENT,
              employeesOfInterest,
              currentUser?.attributes.email,
              eventId,
              parentGoalId
            );
          }
        }
      } else {
        await updateCommentDb(newComment as UpdateCommentInput);
      }
      onClose(true);
      resetState();
    } catch (error: any) {
      log(`Edit Comment: ${error.message}`);

      setIsSaving(false);
      setSaveError(intl.formatMessage({ id: "general.save.error" }));
    }
  };

  const handleCancel = () => {
    resetState();
    onClose(false);
  };

  const handleCommentChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setNewComment((draft) => {
      draft.text = event.target.value;
    });
  };

  const handleEnter = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      handleSave();
    }
  };

  return (
    <>
      <Stack
        direction="row"
        alignItems="center"
        style={{ margin: "20px 0px 12px 18px" }}
        onKeyDown={handleEnter}
      >
        <Stack direction={"row"} sx={{ width: "100%" }}>
          <TextField
            label={<FormattedMessage id="comment.comment" />}
            variant="standard"
            autoComplete="off"
            value={newComment.text || ""}
            onChange={handleCommentChange}
            autoFocus
            style={{ width: "80%" }}
            multiline
            data-cy="edit-comment-textfield"
          />
        </Stack>
        <Stack direction={{ xs: "column", sm: "row" }}>
          <Stack direction="row">
            <Button
              onClick={handleSave}
              disabled={isSaving}
              data-cy="comment-save"
              sx={{ ...hoverMainToAdd(theme) }}
            >
              {isSaving ? (
                <FormattedMessage id="general.saving" />
              ) : (
                <FormattedMessage id="general.save" />
              )}
            </Button>
          </Stack>
          <Stack direction="row">
            <Button
              onClick={handleCancel}
              disabled={isSaving}
              data-cy="comment-cancel"
              sx={{ ...hoverMainToRed(theme) }}
            >
              <FormattedMessage id="general.cancel" />
            </Button>
          </Stack>
        </Stack>
      </Stack>
      {saveError && <Alert severity="error">{saveError}</Alert>}
    </>
  );
}
