import AddCommentButton from "../Common/Buttons/AddCommentButton";
import ShowCommentsButton from "../Common/Buttons/ShowCommentsButton";
import HideCommentsButton from "../Common/Buttons/HideCommentsButton";
import { useIntl } from "react-intl";

interface CommentsIconsProps {
  showComments: boolean;
  addingComment: boolean;
  commentsCount: number;
  canAddComment?: boolean;
  onShowComments: () => void;
  onHideComments: () => void;
  onAddComment: () => void;
}

export default function CommentsIcons({
  showComments,
  addingComment,
  commentsCount,
  canAddComment = true,
  onShowComments,
  onHideComments,
  onAddComment,
}: CommentsIconsProps) {
  const intl = useIntl();

  return (
    <>
      <AddCommentButton
        onClick={onAddComment}
        disabled={addingComment || !canAddComment}
      />

      {!showComments && (
        <ShowCommentsButton
          onClick={onShowComments}
          disabled={addingComment || commentsCount === 0}
          tooltip={intl.formatMessage(
            { id: "comment.show" },
            { count: commentsCount }
          )}
        />
      )}
      {showComments && (
        <HideCommentsButton onClick={onHideComments} disabled={addingComment} />
      )}
    </>
  );
}
