import React, { useMemo, useState } from "react";
import { calculateDaysOfStatus, sortCreatedAtAscending } from "@/lib/time";
import { TextTimeSince, ListText, EmployeeName } from "../Common/Texts/Texts";
import { Comment } from "@/src/API";
import { Avatar, Box, IconButton, Stack, Tooltip } from "@mui/material";
import EditComment from "./EditComment";
import { ExpandLess, ExpandMore, Reply } from "@mui/icons-material";
import { FormattedMessage, useIntl } from "react-intl";
import {
  EmployeeWithAvatarUrl,
  useEmployees,
} from "@/contexts/EmployeesContext";
import {
  getEmployeeByEmail,
  useTaggedEmployeesFromJoin,
} from "@/lib/webEmployee";
import theme from "../../config/theme";
import { hoverLighterToSecondary } from "@/config/styling";
import EditButton from "../Common/Buttons/EditButton";
import DeleteButton from "../Common/Buttons/DeleteButton";
import { canDeleteDbItem } from "@/lib/webHelpers";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import { deleteCommentsWithReplies } from "@/lib/webComments";

interface CommentItemProps {
  comment: Comment | null; // This is because Amplify generated code where everything is XXX | null in API even though ! is used in schema.
  parentGoalId: string; // Get this for the events, and maybe it needs for the goal itself.
  canReply?: boolean;
  onEdit?: (comment: Comment) => void;
  eventId?: string;
  taggedEmployees?: EmployeeWithAvatarUrl[];
}

export default function CommentItem({
  comment,
  parentGoalId,
  canReply = true,
  onEdit,
  eventId,
  taggedEmployees,
}: CommentItemProps) {
  const [showReply, setShowReply] = useState(false);
  const [addingReply, setAddingReply] = useState(false);
  const [editingReply, setEditingReply] = useState<Comment>();
  const [deleteComment, setDeleteComment] = useState<boolean>(false);
  const [deleting, setDeleting] = useState(false);

  const intl = useIntl();

  const employees = useEmployees()?.employees;
  const commenter = getEmployeeByEmail(employees, comment?.creatorEmail);

  // Sort replies
  const visibleReplies = useMemo(() => {
    // Create a mutable copy of the array before sorting
    return [...(comment?.replies?.items || [])].sort(sortCreatedAtAscending);
  }, [comment?.replies]);

  if (!comment) {
    return null;
  }

  const handleEdit = () => {
    if (onEdit) {
      onEdit(comment);
    }
  };

  const handleAddReply = () => {
    setShowReply(true);
    setAddingReply(true);
  };

  const handleCloseAddReply = (saved: boolean) => {
    if (!saved && comment.replies?.items?.length === 0) {
      setShowReply(false);
    }
    setAddingReply(false);
  };

  const handleShowReplies = () => {
    setShowReply(!showReply);
  };

  const handleHideReplies = () => {
    setShowReply(false);
  };

  const handleEditReply = (comment: Comment) => {
    setEditingReply(comment);
  };

  const handleCloseEditReply = () => {
    setEditingReply(undefined);
  };

  const handleDeleteCancel = () => {
    resetState();
  };

  const resetState = () => {
    setDeleting(false);
    setDeleteComment(false);
  };

  const handleDeleteConfirmed = async () => {
    setDeleting(true);
    await deleteCommentsWithReplies([comment]);
    resetState();
  };

  const repliesCount = comment.replies?.items?.length || 0;

  return (
    <>
      <Stack direction="column" spacing={0}>
        <Stack
          direction="row"
          spacing={2}
          sx={{
            width: "100%",
            padding: "12px 6px 0px 6px",
            margin: { xs: "12px 0px 6px 0px", sm: "6px 0px 6px 0px" }, // space btwn comments
          }}
          data-cy="comment-item"
          alignItems={"flex-start"}
        >
          <Tooltip title={comment?.creatorEmail}>
            <Avatar
              src={commenter?.resolvedAvatarUrl}
              sx={{
                width: "43px",
                height: "43px",
                border: "black 2px",
              }}
              style={{ marginTop: "10px" }}
            />
          </Tooltip>

          <Stack
            direction="column"
            sx={{
              width: "100%",
              marginLeft: "18px", // vertical space btwn avatar & everything else
            }}
          >
            {/* Commenter name and days since label + icons*/}
            <Stack
              direction={"row"}
              spacing={2}
              style={{
                width: "100%",
                marginBottom: "6px",
              }}
              alignItems={"flex-start"}
            >
              {/* Commenter name */}
              <EmployeeName>{commenter?.name}</EmployeeName>

              <Stack
                direction={"row"}
                spacing={2}
                justifyContent="space-between"
                alignItems={"center"}
                style={{ flexGrow: 1 }}
              >
                {/* Time of the comemnt */}
                <Box>
                  <TextTimeSince>
                    {calculateDaysOfStatus(intl, comment.createdAt)}
                  </TextTimeSince>
                </Box>
              </Stack>
            </Stack>

            <Stack direction="column">
              {/* Second row: Comment text */}
              <Stack
                direction="row"
                sx={{
                  margin: { xs: "6px", sm: "6px 0px 6px 0px" },
                }}
              >
                <ListText>{comment.text}</ListText>
              </Stack>

              {/* Third row: Buttons and replies */}
              <Stack
                direction="row"
                spacing={{ xs: 1, sm: 0 }}
                alignItems={"center"}
              >
                <EditButton
                  onClick={handleEdit}
                  tooltip={intl.formatMessage({ id: "comment.edit" })}
                  disabled={!!addingReply || !!editingReply}
                  dataCy="comment-edit-button"
                  sx={{ ...hoverLighterToSecondary(theme) }}
                />

                {canDeleteDbItem(comment) && (
                  <DeleteButton
                    disabled={!!addingReply || !!editingReply}
                    onClick={() => setDeleteComment(true)}
                    tooltip={intl.formatMessage({
                      id: "comment.delete.caption",
                    })}
                    sx={{ ...hoverLighterToSecondary(theme) }}
                  />
                )}

                {canReply && (
                  <IconButton
                    size="small"
                    onClick={handleAddReply}
                    disabled={!!addingReply || !!editingReply}
                    data-cy="comment-reply-button"
                    sx={{ ...hoverLighterToSecondary(theme) }}
                  >
                    <Tooltip title={<FormattedMessage id="comment.reply" />}>
                      <Reply />
                    </Tooltip>
                  </IconButton>
                )}
                {canReply && (
                  <Stack
                    direction="row"
                    alignItems="center"
                    style={{ marginLeft: "6px" }}
                  >
                    <ListText>
                      <FormattedMessage
                        id="comment.replies"
                        values={{ count: repliesCount }}
                      />
                    </ListText>
                    {!showReply && repliesCount !== 0 && (
                      <IconButton
                        size="small"
                        onClick={handleShowReplies}
                        disabled={!!addingReply || !!editingReply}
                        data-cy="comment-show-replies-button"
                        sx={{ ...hoverLighterToSecondary(theme) }}
                      >
                        <Tooltip
                          title={<FormattedMessage id="comment.show.replies" />}
                        >
                          <ExpandMore />
                        </Tooltip>
                      </IconButton>
                    )}
                    {showReply && (
                      <IconButton
                        size="small"
                        onClick={handleHideReplies}
                        disabled={!!addingReply || !!editingReply}
                      >
                        <Tooltip
                          title={<FormattedMessage id="comment.hide.replies" />}
                        >
                          <ExpandLess />
                        </Tooltip>
                      </IconButton>
                    )}
                  </Stack>
                )}
              </Stack>
            </Stack>
          </Stack>
        </Stack>

        {showReply && (
          <Box sx={{ paddingLeft: { xs: "24px", sm: "48px" } }}>
            {visibleReplies?.map((reply) => (
              <React.Fragment key={reply!.id}>
                {editingReply && editingReply.id === reply?.id ? (
                  <EditComment
                    commentId={reply!.id}
                    comment={reply}
                    parentGoalId={parentGoalId}
                    onClose={handleCloseEditReply}
                    eventId={eventId}
                  />
                ) : (
                  <CommentItem
                    comment={reply}
                    parentGoalId={parentGoalId}
                    canReply={false}
                    onEdit={handleEditReply}
                    eventId={eventId}
                    taggedEmployees={taggedEmployees}
                  />
                )}
              </React.Fragment>
            ))}
            {addingReply && (
              <EditComment
                parentComment={comment}
                commentId={comment.id}
                parentGoalId={parentGoalId}
                onClose={handleCloseAddReply}
                eventId={eventId}
                taggedEmployees={taggedEmployees}
              />
            )}
          </Box>
        )}
      </Stack>
      {deleteComment && (
        <ConfirmationDialog
          title={intl.formatMessage({ id: "comment.delete.caption" })}
          message={intl.formatMessage({ id: "comment.delete.confirmation" })}
          messageItem={comment.text || ""}
          open={!!deleteComment}
          saving={deleting}
          onCancel={handleDeleteCancel}
          onConfirm={handleDeleteConfirmed}
        />
      )}
    </>
  );
}
