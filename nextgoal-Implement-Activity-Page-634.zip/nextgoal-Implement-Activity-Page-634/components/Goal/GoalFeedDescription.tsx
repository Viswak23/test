import { Goal } from "@/src/API";
import { Stack } from "@mui/material";
import { FeedTitle, ListSecondaryText, ListText } from "../Common/Texts/Texts";
import { showDate } from "@/lib/time";
import { useIntl } from "react-intl";
import { useSettings } from "@/contexts/SettingsInfo";

interface GoalFeedDescriptionProps {
  goal?: Goal | null;
}

export default function GoalFeedDescription({
  goal,
}: GoalFeedDescriptionProps) {
  const intl = useIntl();
  const dbUser = useSettings()?.dbUser;

  return (
    <Stack direction="column" spacing={0}>
      <FeedTitle>{goal?.title}</FeedTitle>
      <ListText>
        {goal?.isClosed ? goal?.closingNotes : goal?.description}
      </ListText>

      <Stack
        direction={{ xs: "column", sm: "row" }}
        spacing={1}
        sx={{
          marginLeft: "10px",
          paddingTop: { xs: "20px", sm: "15px" },
        }}
      >
        <Stack direction="row">
          <ListSecondaryText>{`Start: ${
            goal?.startDate
              ? `${showDate(goal.startDate, dbUser)}`
              : intl.formatMessage({ id: "goals.no.start.date" })
          }`}</ListSecondaryText>
        </Stack>
        <Stack direction="row">
          <ListSecondaryText>{`Target: ${
            goal?.targetDate
              ? `${showDate(goal.targetDate, dbUser)}`
              : intl.formatMessage({ id: "goals.no.target.date" })
          }`}</ListSecondaryText>
        </Stack>
      </Stack>
    </Stack>
  );
}
