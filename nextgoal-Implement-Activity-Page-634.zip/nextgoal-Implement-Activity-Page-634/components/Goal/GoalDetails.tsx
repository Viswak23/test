import React, { useState } from "react";
import { HeadingMain } from "@/components/Common/Texts/Texts";
import IconButton from "@mui/material/IconButton";
import Stack from "@mui/material/Stack";
import { useGoals } from "@/contexts/GoalsContext";
import EditGoal from "./EditGoal";
import { useOrganization } from "@/contexts/OrganizationContext";
import GoalDetailRow from "./GoalDetailRow";
import LatestStatus from "../Status/LatestStatus";
import Breadcrumb, { BreadcrumbType } from "../Common/Breadcrumb/Breadcrumb";
import { showDate } from "@/lib/time";
import GoalStatus from "./GoalStatus";
import {
  Alert,
  Box,
  Chip,
  Divider,
  Snackbar,
  Tooltip,
  useTheme,
} from "@mui/material";
import InformationDialog from "../Common/InformationDialog/InformationDialog";
import {
  deleteGoalWithChildrenDb,
  getChildGoals,
  updateGoalStatus,
} from "@/lib/webGoals";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import { Goal, UpdateGoalInput } from "@/src/API";
import DeleteButton from "../Common/Buttons/DeleteButton";
import { canDeleteDbItem } from "@/lib/webHelpers";
import CloseGoal from "./CloseGoal";
import { FormattedMessage, useIntl } from "react-intl";
import { getLinkWithLocale } from "@/lib/localisation";
import { useRouter } from "next/navigation";
import { hoverAddToMain, hoverRedToMain } from "@/config/styling";
import { log } from "@/lib/backend/actions/logger";
import { useSettings } from "@/contexts/SettingsInfo";
import { useEvents } from "@/contexts/EventsContext";
import EditButton from "../Common/Buttons/EditButton";
import PageLoading from "../Common/Loading/PageLoading";
import { useEmployees } from "@/contexts/EmployeesContext";
import { Pages } from "@/lib/webNavigation";

interface GoalDetailsProps {
  goal?: Goal | null;
}

export default function GoalDetails({ goal }: GoalDetailsProps) {
  const [editGoal, setEditGoal] = useState(false);
  const [showCannotDeleteGoal, setShowCannotDeleteGoal] = useState(false);
  const [showDeleteGoal, setShowDeleteGoal] = useState(false);
  const [closeGoal, setCloseGoal] = useState(false);
  const [openGoal, setOpenGoal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savingError, setSavingError] = useState("");
  const dbUser = useSettings()?.dbUser;

  const goalsState = useGoals();
  const events = useEvents()?.events;
  const organization = useOrganization()?.organization;
  const intl = useIntl();
  const theme = useTheme();
  const router = useRouter();
  const employees = useEmployees()?.employees;
  const closeLabel = intl.formatMessage({ id: "general.close" });
  const openLabel = intl.formatMessage({ id: "general.open" });

  // This happens when user deletes a goal and the redirect has not happened yet
  if (!goal) {
    return <PageLoading />;
  }

  const organizationUnit = organization?.find(
    (org) => org.id === goal?.organizationUnitGoalsId
  );

  const handleEditGoal = () => {
    setEditGoal(true);
  };

  const handleDeleteGoal = () => {
    const children = getChildGoals(goal, goalsState?.goals);
    if (!!children.length) {
      setShowCannotDeleteGoal(true);
      return;
    }

    setShowDeleteGoal(true);
  };

  const onCancel = () => {
    setEditGoal(false);
  };

  const handleCloseCannotDeleteGoal = () => {
    setShowCannotDeleteGoal(false);
  };

  const handleConfirmDeleteGoal = async () => {
    setSaving(true);
    await deleteGoalWithChildrenDb(intl, goal, events);
    // Redirect either to the user page, organization page, or if a company goal, to the main page
    if (goal.employeeGoalsId) {
      router.push(
        getLinkWithLocale(`/employees/${goal.creatorEmail}`, intl.locale)
      );
    } else if (goal.organizationUnitGoalsId) {
      // redirect does throw an error for unknown reason: https://stackoverflow.com/questions/76191324/next-13-4-error-next-redirect-in-api-routes
      // so we use router.push instead
      router.push(
        getLinkWithLocale(
          `/organization/${goal.organizationUnitGoalsId}`,
          intl.locale
        )
      );
    } else {
      router.push(getLinkWithLocale(Pages.appGoals, intl.locale));
    }
  };

  const handleCancelCloseGoal = () => {
    setCloseGoal(false);
  };

  const handleCancelDeleteGoal = () => {
    setShowDeleteGoal(false);
  };
  const handleCloseGoal = () => {
    setCloseGoal(true);
  };
  const handleOpenGoal = () => {
    setOpenGoal(true);
  };
  const handleConfirmOpenGoal = async () => {
    try {
      setSaving(true);
      const inputGoal = {
        ...goal,
        isClosed: false,
        statusFlag: null,
        closingNotes: null,
      };
      await updateGoalStatus(inputGoal as UpdateGoalInput, employees);
      setSaving(false);
      setOpenGoal(false);
    } catch (error: any) {
      log(`Open Goal: ${error.message}`);
      setSavingError(intl.formatMessage({ id: "general.save.error" }));
      setSaving(false);
    }
  };
  const handleCancelOpenGoal = () => {
    setOpenGoal(false);
  };

  if (!goal) {
    return (
      <div>
        <FormattedMessage id="goals.error.loading" />
      </div>
    );
  }

  return (
    <>
      <Stack spacing={1} width={"100%"}>
        <Stack
          spacing={1}
          direction="row"
          alignItems={"center"}
          style={{ marginBottom: 0 }}
        >
          <Stack
            data-cy="goal-detail-heading-container"
            flexGrow={1}
            alignItems="flex-start"
            width={"70%"}
          >
            <HeadingMain
              sx={{
                wordBreak: "break-word",
                textAlign: "left",
              }}
            >
              {goal.title}
            </HeadingMain>
            {goal.isClosed === true && (
              <Chip label={<FormattedMessage id="goal.close.tag" />} />
            )}
          </Stack>

          <Stack
            direction={{ xs: "column", sm: "row" }}
            spacing={0}
            alignItems={"center"}
          >
            {/* Edit btn */}
            <EditButton onClick={handleEditGoal} />

            {!goal.isClosed ? (
              // Close & archive goal btn
              <IconButton
                aria-label={closeLabel}
                size="small"
                onClick={handleCloseGoal}
              >
                <Tooltip
                  title={<FormattedMessage id="goal.close.action.close.tip" />}
                >
                  <Chip
                    label={<FormattedMessage id="goal.close.action.close" />}
                    sx={{
                      padding: "6px",
                      ...hoverRedToMain(theme),
                    }}
                  />
                </Tooltip>
              </IconButton>
            ) : (
              // Open goal btn
              <IconButton
                aria-label={openLabel}
                size="small"
                sx={{ color: "primary.main" }}
                onClick={handleOpenGoal}
              >
                <Tooltip
                  title={<FormattedMessage id="goal.close.action.open.tip" />}
                >
                  <Chip
                    label={<FormattedMessage id="goal.close.action.open" />}
                    sx={{ ...hoverAddToMain(theme) }}
                  />
                </Tooltip>
              </IconButton>
            )}

            {/* Delete btn */}
            <DeleteButton
              onClick={handleDeleteGoal}
              tooltip={intl.formatMessage({ id: "goals.delete.caption" })}
              disabled={!canDeleteDbItem(goal)}
              disabledTooltip={intl.formatMessage({
                id: "goals.delete.disabled.tooltip",
              })}
              dataCy="delete-goal-button"
            />
          </Stack>
        </Stack>

        {/* Breadcrumb */}
        <Stack
          sx={{
            justifyContent: "center",
            alignItems: { xs: "center", sm: "flex-start" },
          }}
          textOverflow={"ellipsis"}
        >
          <GoalDetailRow
            label={intl.formatMessage({ id: "goals.breadcrumb" })}
          />
          {goal && (
            <Breadcrumb
              currentGoalId={goal.id}
              type={BreadcrumbType.DETAIL}
              showLastAsaLink={false}
            />
          )}
        </Stack>

        <Divider
          variant="middle"
          aria-hidden="true"
          sx={{
            color: theme.palette.customColors?.chick,
            paddingTop: "18px",
            marginBottom: "18px",
          }}
        />
      </Stack>

      <Stack
        direction="column"
        spacing={{ xs: 3, sm: 2 }}
        style={{ marginTop: "24px" }}
      >
        <GoalStatus goal={goal} />
        <GoalDetailRow
          label={intl.formatMessage({
            id: "organizationunits.organization.units",
          })}
          wrapToTextComponent={false}
        >
          {organizationUnit && (
            <Breadcrumb
              organizationUnitId={organizationUnit.id}
              showMainPage={false}
              type={BreadcrumbType.DETAIL}
              showLastAsaLink={true}
            />
          )}
          {!organizationUnit && <FormattedMessage id="goals.company.goal" />}
        </GoalDetailRow>
        <GoalDetailRow
          label={intl.formatMessage({ id: "goals.parentgoals" })}
          wrapToTextComponent={false}
        >
          {goal.goalChildGoalsId ? (
            <Breadcrumb currentGoalId={goal?.id} />
          ) : (
            <FormattedMessage id="goals.no.parent.goals" />
          )}
        </GoalDetailRow>
        <Stack
          direction="row"
          spacing={4}
          justifyContent={{ xs: "center", sm: "flex-start" }}
        >
          <GoalDetailRow label={intl.formatMessage({ id: "goals.start.date" })}>
            {goal.startDate ? (
              `${showDate(goal.startDate, dbUser)}`
            ) : (
              <FormattedMessage id="goals.no.start.date" />
            )}
          </GoalDetailRow>
          <GoalDetailRow
            label={intl.formatMessage({ id: "goals.target.date" })}
          >
            {goal.targetDate ? (
              `${showDate(goal.targetDate, dbUser)}`
            ) : (
              <FormattedMessage id="goals.no.target.date" />
            )}
          </GoalDetailRow>
        </Stack>
        <Box>
          <GoalDetailRow
            label={intl.formatMessage({ id: "goals.description" })}
          >
            {goal?.description || ""}
          </GoalDetailRow>
          {goal?.reward && (
            <GoalDetailRow label={intl.formatMessage({ id: "goals.reward" })}>
              {goal?.reward || ""}
            </GoalDetailRow>
          )}
          <LatestStatus goal={goal} />
        </Box>
      </Stack>
      {editGoal && (
        <EditGoal
          key={goal.updatedAt}
          goal={goal}
          open={editGoal}
          onClose={onCancel}
        />
      )}
      {showCannotDeleteGoal && (
        <InformationDialog
          title={intl.formatMessage({ id: "goals.error.cannot.delete.goal" })}
          message={intl.formatMessage({
            id: "goals.error.cannot.delete.goal.description",
          })}
          open={showCannotDeleteGoal}
          onClose={handleCloseCannotDeleteGoal}
        />
      )}
      {showDeleteGoal && (
        <ConfirmationDialog
          title={intl.formatMessage({ id: "goals.delete.caption" })}
          message={intl.formatMessage({ id: "goals.delete.confirmation" })}
          messageItem={goal?.title || ""}
          open={showDeleteGoal}
          saving={saving}
          onConfirm={handleConfirmDeleteGoal}
          onCancel={handleCancelDeleteGoal}
        />
      )}
      {closeGoal && (
        <CloseGoal
          goal={goal}
          open={closeGoal}
          onClose={handleCancelCloseGoal}
        />
      )}
      {openGoal && (
        <ConfirmationDialog
          title={intl.formatMessage({ id: "goal.open.title" })}
          message={intl.formatMessage({ id: "goal.open.message" })}
          messageItem={goal?.title || ""}
          open={openGoal}
          saving={saving}
          onConfirm={handleConfirmOpenGoal}
          onCancel={handleCancelOpenGoal}
        />
      )}
      {savingError && (
        <Snackbar
          open={savingError.length > 0}
          autoHideDuration={5000}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
          onClose={() => setSavingError("")}
        >
          <Alert severity="error">{savingError}</Alert>
        </Snackbar>
      )}
    </>
  );
}
