"use client";

import { Stack, useTheme } from "@mui/material";
import GoalDetails from "./GoalDetails";
import KeyResults from "../KeyResults/KeyResults";
import GoalTabs from "./GoalTabs";
import { useIntl } from "react-intl";
import { useGoals } from "@/contexts/GoalsContext";
import Message from "../Common/Message/Message";
import ScrollBackUpButton from "../Common/Buttons/ScrollBackUpButton";
import PageMessage from "../Common/Message/PageMessage";
import PageBackgroundPaper from "../Common/Layout/PageBackgroundPaper";
import PageLoading from "../Common/Loading/PageLoading";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getLinkWithLocale } from "@/lib/localisation";
import { Link as MUILink } from "@mui/material";
import Link from "next/link";
import { Pages } from "@/lib/webNavigation";

interface GoalPageContentProps {
  goalId: string;
}

export default function GoalPageContent({ goalId }: GoalPageContentProps) {
  const goalsState = useGoals();
  const intl = useIntl();
  const router = useRouter();
  const theme = useTheme();
  const [goalNotFound, setGoalNotFound] = useState(false);

  let goal = goalsState?.goals.find((g) => g.id === goalId);
  // If not found, try archive.
  if (!goal) {
    const archivedGoals = goalsState?.archivedGoals;
    goal = archivedGoals?.find((g) => g.id === goalId);
  }

  useEffect(() => {
    // If a deleted goal is tried to access, show an error message.
    // Timeout is needed while after the goal deletion, it takes a bit before the redirect happens.
    if (!goal) {
      setTimeout(() => {
        if (!goal) {
          setGoalNotFound(true);
        }
      }, 3000);
    }
  }, [goal, intl, router, theme.palette.customColors?.lighter]);

  if (goalNotFound) {
    return (
      <PageMessage
        message={intl.formatMessage({ id: "goals.error.loading.failed" })}
      >
        <MUILink
          underline="hover"
          color={theme.palette.customColors?.lighter}
          href={getLinkWithLocale(Pages.appGoals, intl.locale)}
          locale={intl.locale}
          component={Link}
        >
          {intl.formatMessage({ id: "general.back.to.home" })}
        </MUILink>
      </PageMessage>
    );
  }

  // Happens when the goal is deleted.
  if (!goal) {
    return <PageLoading />;
  }

  return (
    <PageBackgroundPaper dataCy="goal-page">
      <Stack direction="column" spacing={1}>
        <GoalDetails goal={goal} />
        <KeyResults
          goal={goal}
          canAdd
          canEdit
          showTitle
          showNoKeyResults
          showLocation={false}
        />
        <GoalTabs goal={goal} showSubgoals showAllKeyResults />
        <ScrollBackUpButton />
      </Stack>
      <Message />
    </PageBackgroundPaper>
  );
}
