import React, { ReactNode, CSSProperties } from "react";
import { Stack, useMediaQuery, useTheme } from "@mui/material";
import { DetailsLabel, DetailsText } from "@/components/Common/Texts/Texts";
interface GoalDetailRowProps {
  label: string;
  children?: ReactNode;
  style?: CSSProperties;
  containerStyle?: CSSProperties;
  wrapToTextComponent?: boolean;
  centerItems?: boolean;
}

export default function GoalDetailRow({
  label,
  children,
  style,
  containerStyle,
  wrapToTextComponent = true,
  centerItems = false,
}: GoalDetailRowProps) {
  const theme = useTheme();
  const isSmallScreen = useMediaQuery(theme.breakpoints.down("sm"));

  return (
    <Stack
      direction="column"
      spacing={0}
      alignItems={centerItems || isSmallScreen ? "center" : "flex-start"}
      style={containerStyle}
    >
      <DetailsLabel
        style={{
          paddingTop: "6px",
          width: "100%",
          textAlign: centerItems || isSmallScreen ? "center" : "left",
          ...style,
        }}
      >
        {label}
      </DetailsLabel>
      {wrapToTextComponent && (
        <DetailsText
          style={{
            textAlign: centerItems || isSmallScreen ? "center" : "left",
            wordBreak: "break-word",
          }}
        >
          {children}
        </DetailsText>
      )}
      {!wrapToTextComponent && children}
    </Stack>
  );
}
