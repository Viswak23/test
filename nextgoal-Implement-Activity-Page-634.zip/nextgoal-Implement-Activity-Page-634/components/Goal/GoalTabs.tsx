import { useState, useMemo } from "react";
import { Tabs, Tab } from "@mui/material";
import { useGoals } from "@/contexts/GoalsContext";
import SuccessStories from "@/components/SuccessStories/SuccessStories";
import RedFlags from "@/components/RedFlags/RedFlags";
import Subgoals from "@/components/Subgoals/Subgoals";
import { Flag } from "lucide-react";
import AllKeyResults from "../KeyResults/AllKeyResults";
import { getGoalsWithRedFlags, getRedFlags } from "@/lib/webRedFlags";
import Tasks from "../Tasks/Tasks";
import Contributions from "../Contributions/Contributions";
import Ideas from "../Ideas/Ideas";
import { Goal } from "@/src/API";
import KeyResults from "../KeyResults/KeyResults";
import HelpRequests from "../HelpRequests/HelpRequests";
import FeedsContent from "../Feeds/FeedsContent";
import RedFlagsExpanded from "../RedFlags/RedFlagsExpanded";
import HelpRequestsExpanded from "../HelpRequests/HelpRequestsExpanded";
import { getSubgoalsHelpRequests } from "@/lib/webHelpRequests";
import { FormattedMessage, useIntl } from "react-intl";

interface GoalTabsProps {
  goal: Goal | null;
  showKeyResults?: boolean;
  showSubgoals?: boolean;
  showAllKeyResults?: boolean;
}

enum TabIndex {
  KEY_RESULTS = 0,
  RED_FLAGS = 1,
  HELP_NEEDED = 2,
  IDEAS = 3,
  SUCCESS_STORIES = 4,
  CONTRIBUTIONS = 5,
  EVENTS = 6,
  SUBGOALS = 8,
  ALL_KEY_RESULTS = 9,
}

export default function GoalTabs({
  goal,
  showKeyResults = false,
  showSubgoals = false,
  showAllKeyResults = false,
}: GoalTabsProps) {
  const [selectedTab, setSelectedTab] = useState(
    showKeyResults ? TabIndex.KEY_RESULTS : TabIndex.RED_FLAGS
  );
  const goals = useGoals()?.goals;
  const intl = useIntl();

  const notResolvedRedFlags = useMemo(
    () => getGoalsWithRedFlags(goal?.id, goals || [], false),
    [goal?.id, goals]
  );

  const childrenRedFlags = useMemo(
    () =>
      getRedFlags(
        notResolvedRedFlags.filter((g) => g.id != goal?.id),
        false
      ),
    [notResolvedRedFlags, goal]
  );

  const childrenOpenHelpRequests = useMemo(
    () => getSubgoalsHelpRequests(goal, goals, false),
    [goals, goal]
  );

  if (!goal) {
    return (
      <div>
        <FormattedMessage id="goals.error.loading" />
      </div>
    );
  }

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setSelectedTab(newValue);
  };

  function getTabContext(tabIndex: number) {
    switch (tabIndex) {
      case TabIndex.KEY_RESULTS:
        return <KeyResults goal={goal} inTab />;
      case TabIndex.RED_FLAGS:
        return (
          <>
            <RedFlags
              redFlags={goal?.redFlags?.items}
              goalId={goal?.id}
              canAdd
            />
            <RedFlagsExpanded
              title={intl.formatMessage({
                id: "redflags.child.goals.open.red.flags",
              })}
              redFlags={childrenRedFlags}
            />
          </>
        );
      case TabIndex.HELP_NEEDED:
        return (
          <>
            <HelpRequests
              helpRequests={goal?.helpRequests?.items}
              goalId={goal?.id}
              canAdd
            />
            <HelpRequestsExpanded
              title={intl.formatMessage({
                id: "helprequests.child.goal.open.help.requests",
              })}
              helpRequests={childrenOpenHelpRequests}
            />
          </>
        );
      case TabIndex.IDEAS:
        return <Ideas goal={goal} />;
      case TabIndex.SUCCESS_STORIES:
        return <SuccessStories goal={goal} />;
      case TabIndex.CONTRIBUTIONS:
        return <Contributions goal={goal} />;
      case TabIndex.EVENTS:
        return <FeedsContent goalId={goal?.id} />;
      case TabIndex.SUBGOALS:
        return <Subgoals goal={goal} />;
      case TabIndex.ALL_KEY_RESULTS:
        return <AllKeyResults goalId={goal?.id} />;
      default:
        return <div>Unknown tab</div>;
    }
  }

  // Under the toggle btn inside a goal:
  return (
    <>
      <Tabs
        value={selectedTab}
        onChange={handleTabChange}
        variant="scrollable"
        scrollButtons="auto"
        data-cy="goal-tabs"
      >
        {showKeyResults && (
          <Tab
            value={TabIndex.KEY_RESULTS}
            label={<FormattedMessage id="keyresults.title" />}
            data-cy="key-results-tab"
          />
        )}
        <Tab
          value={TabIndex.RED_FLAGS}
          label={<FormattedMessage id="redflags.title" />}
          icon={
            notResolvedRedFlags && notResolvedRedFlags.length > 0 ? (
              <Flag style={{ color: "red" }} />
            ) : undefined
          }
          iconPosition="start"
          data-cy="red-flags-tab"
        />
        <Tab
          value={TabIndex.HELP_NEEDED}
          label={<FormattedMessage id="helprequests.title" />}
          data-cy="help-needed-tab"
        />
        <Tab
          value={TabIndex.IDEAS}
          label={<FormattedMessage id="ideas.title" />}
          data-cy="ideas-tab"
        />
        <Tab
          value={TabIndex.SUCCESS_STORIES}
          label={<FormattedMessage id="successstories.title" />}
          data-cy="success-stories-tab"
        />
        <Tab
          value={TabIndex.CONTRIBUTIONS}
          label={<FormattedMessage id="contributions.title" />}
          data-cy="contributions-tab"
        />
        {!goal.employeeGoalsId && (
          <Tab
            value={TabIndex.EVENTS}
            label={<FormattedMessage id="feeds.title" />}
            data-cy="events-tab"
          />
        )}
        {showSubgoals && (
          <Tab
            value={TabIndex.SUBGOALS}
            label={<FormattedMessage id="goals.subgoals" />}
            data-cy="subgoals-tab"
          />
        )}
        {showAllKeyResults && (
          <Tab
            value={TabIndex.ALL_KEY_RESULTS}
            label={<FormattedMessage id="keyresults.all.key.results" />}
            data-cy="all-key-results-tab"
          />
        )}
      </Tabs>
      {getTabContext(selectedTab)}
    </>
  );
}
