import { useMemo, CSSProperties } from "react";
import { Goal, RedFlag } from "@/src/API";
import {
  Chip,
  Stack,
  Tooltip,
  useTheme,
  useMediaQuery,
  Box,
} from "@mui/material";
import { EmojiPeople, OutlinedFlag } from "@mui/icons-material";
import {
  getStatusFlagText,
  getProgressString,
  calculateKeyResultsProgress,
} from "@/lib/webKeyResults";
import VisualProgress from "@/components/Common/VisualProgress/VisualProgress";
import { timeToTarget } from "@/lib/time";
import {
  calculateProgress,
  getCloseFlagColor,
  getCloseStatusFlagText,
} from "@/lib/webGoals";
import { DetailsLabel } from "../Common/Texts/Texts";
import KeyResultIcon from "../KeyResults/KeyResultIcon";
import { useGoals } from "@/contexts/GoalsContext";
import { getAllRedFlagsOfGoal } from "@/lib/webRedFlags";
import { getAllHelpRequests } from "@/lib/webHelpRequests";
import { FormattedMessage, useIntl } from "react-intl";

interface GoalStatusProps {
  goal: Goal;
  style?: CSSProperties;
  notResolvedRedFlags?: (RedFlag | null)[];
}

export default function GoalStatus({
  goal,
  style,
  notResolvedRedFlags,
}: GoalStatusProps) {
  const goals = useGoals()?.goals;
  const theme = useTheme();
  const intl = useIntl();

  const isSmallScreen = useMediaQuery("(max-width:695px)");

  // Red flags. Fetch them if not already fetched by parent component (GoalListItem)
  const raisedRedFlags = useMemo(
    () =>
      notResolvedRedFlags
        ? notResolvedRedFlags
        : getAllRedFlagsOfGoal(goal.id, goals || [], false),
    [goal.id, goals, notResolvedRedFlags]
  );

  const openHelpRequests = useMemo(
    () => getAllHelpRequests(goal, goals || []),
    [goal, goals]
  );

  const redFlagsStyle =
    raisedRedFlags.length > 0
      ? { color: theme.palette.customColors?.redflag }
      : { color: theme.palette.customColors?.loweropacity }; // gray

  const helpRequestsStyle =
    openHelpRequests.length > 0
      ? { color: theme.palette.primary.main }
      : { color: theme.palette.customColors?.loweropacity };

  // Progress
  const progress = useMemo(() => calculateProgress(goal), [goal]);
  const keyResultsProgress = useMemo(
    () => calculateKeyResultsProgress(goal.keyResults?.items),
    [goal]
  );
  const keyResults = goal.keyResults?.items || [];

  return (
    <Stack
      spacing={2}
      style={style}
      alignItems="center"
      sx={{ paddingTop: "6px" }}
    >
      <Stack
        direction={{ xs: "column", sm: "row" }}
        spacing={2}
        sx={{
          width: "100%",
          padding: { xs: "6px 0px 6px 0px", sm: "0px" },
        }}
        alignItems="center"
      >
        {/* Target date label */}
        <Stack direction="row">
          <VisualProgress
            label={timeToTarget(intl, goal.targetDate!)}
            value={progress}
          />
        </Stack>

        {/* Key results label & its progress bar */}
        <Stack direction="row" spacing={2} alignItems="center">
          {keyResults.length > 0 && keyResultsProgress >= 0 ? (
            <VisualProgress
              label={intl.formatMessage({ id: "keyresults.title" })}
              value={keyResultsProgress}
            />
          ) : (
            <DetailsLabel>
              <FormattedMessage id="keyresults.no.key.results" />
            </DetailsLabel>
          )}
        </Stack>

        {/* Icons */}
        {!isSmallScreen && (
          <Stack direction="row">
            <Box
              display="flex"
              gap={1}
              width="100%"
              sx={{
                flexWrap: "wrap",
                justifyContent: "center",
                alignItems: "flex-start",
                padding: {
                  xs: "6px 0px 6px 0px",
                  sm: "3px 0px 6px 0px",
                },
              }}
            >
              {/* Key result icons */}
              {keyResults.map((kr) => {
                const progress = getProgressString(kr);
                return (
                  <Tooltip
                    key={kr?.id}
                    title={`${kr?.description} - status ${getStatusFlagText(
                      intl,
                      kr?.statusFlag
                    )}${progress ? `: ${progress}` : ""}`}
                  >
                    <span>
                      <KeyResultIcon keyResult={kr} />
                    </span>
                  </Tooltip>
                );
              })}

              {/* Red flags */}
              <Tooltip
                title={
                  <FormattedMessage
                    id="redflags.redflags"
                    values={{ count: raisedRedFlags.length || 0 }}
                  />
                }
              >
                <Box display="flex" alignItems="center" style={redFlagsStyle}>
                  <span style={{ paddingBottom: "6px" }}>
                    {raisedRedFlags.length > 0 && `${raisedRedFlags.length}x`}
                  </span>
                  <OutlinedFlag />
                </Box>
              </Tooltip>

              {/* Help requests */}
              <Tooltip
                title={
                  <FormattedMessage
                    id="helprequests.open.help.requests"
                    values={{ count: openHelpRequests.length || 0 }}
                  />
                }
              >
                <Box
                  display="flex"
                  alignItems="center"
                  style={helpRequestsStyle}
                >
                  <span style={{ paddingBottom: "6px" }}>
                    {openHelpRequests.length > 0 &&
                      `${openHelpRequests.length}x`}
                  </span>
                  <EmojiPeople />
                </Box>
              </Tooltip>
            </Box>
          </Stack>
        )}
      </Stack>

      {isSmallScreen && (
        <Stack direction="row" spacing={2} alignItems="center" width="100%">
          <Box
            display="flex"
            gap={1}
            width="100%"
            sx={{
              flexWrap: "wrap",
              justifyContent: "center",
              alignItems: "flex-start",
              padding: {
                xs: "6px 0px 6px 0px",
                sm: "3px 0px 6px 0px",
              },
            }}
          >
            {/* Key result icons */}
            {keyResults.map((kr) => {
              const progress = getProgressString(kr);
              return (
                <Tooltip
                  key={kr?.id}
                  title={`${kr?.description} - status ${getStatusFlagText(
                    intl,
                    kr?.statusFlag
                  )}${progress ? `: ${progress}` : ""}`}
                >
                  <span>
                    <KeyResultIcon keyResult={kr} />
                  </span>
                </Tooltip>
              );
            })}

            {/* Red flags */}
            <Tooltip
              title={
                <FormattedMessage
                  id="redflags.redflags"
                  values={{ count: raisedRedFlags.length || 0 }}
                />
              }
            >
              <Box display="flex" alignItems="center" style={redFlagsStyle}>
                <span style={{ paddingBottom: "6px" }}>
                  {raisedRedFlags.length > 0 && `${raisedRedFlags.length}x`}
                </span>
                <OutlinedFlag />
              </Box>
            </Tooltip>

            {/* Help requests */}
            <Tooltip
              title={
                <FormattedMessage
                  id="helprequests.open.help.requests"
                  values={{ count: openHelpRequests.length || 0 }}
                />
              }
            >
              <Box display="flex" alignItems="center" style={helpRequestsStyle}>
                <span style={{ paddingBottom: "6px" }}>
                  {openHelpRequests.length > 0 && `${openHelpRequests.length}x`}
                </span>
                <EmojiPeople />
              </Box>
            </Tooltip>
          </Box>
        </Stack>
      )}

      {goal.isClosed === true && (
        <Chip
          label={intl.formatMessage({
            id: getCloseStatusFlagText(goal.statusFlag),
          })}
          size="small"
          color={getCloseFlagColor(goal.statusFlag)}
        />
      )}
    </Stack>
  );
}
