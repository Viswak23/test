import React, { useCallback, useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  TextField,
  Collapse,
  Alert,
} from "@mui/material";
import { Goal, UpdateGoalInput, CreateGoalInput, Employee } from "@/src/API";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import dayjs, { Dayjs } from "dayjs";
import Stack from "@mui/material/Stack";
import { FormTitle, Label } from "@/components/Common/Texts/Texts";
import { addGoalDb, getGoalBackgroundInfo, updateGoalDb } from "@/lib/webGoals";
import { useImmer } from "use-immer";
import { useAuthStatus } from "@/lib/customHooks";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import { FormattedMessage, useIntl } from "react-intl";
import LocalizeDatePicker from "../LocalizeDatePicker/LocalizeDatePicker";
import { useSettings } from "@/contexts/SettingsInfo";
import { TabPanel } from "../Settings/TabPanel";
import { Message } from "@/lib/webChat";
import DialogChat from "../Chat/ChatInDialog";
import { useNorthStars } from "@/contexts/NorthStarsContext";
import { useOrganization } from "@/contexts/OrganizationContext";
import { useGoals } from "@/contexts/GoalsContext";
import HelpCollapse from "../Common/Dialog/HelpCollapse";
import { useEmployees } from "@/contexts/EmployeesContext";
import DialogTabTitle from "../Common/Dialog/DialogTabTitle";
import {
  ChatDialogState,
  defaultChatDialogState,
} from "../Chat/ChatDialogState";

interface EditGoalProps {
  goal?: Goal;
  newPosition?: number;
  parentId?: string;
  organizationUnitId?: string;
  employee?: Employee;
  open: boolean;
  onClose: () => void;
}

// CompanyId is filled in webGoal when doing the mutation.
const defaultGoal = {
  title: "",
  description: "",
  reward: "",
  companyId: "placeholder",
  useTasks: false,
  creatorEmail: "placeholder",
};

export default function EditGoal({
  goal,
  newPosition,
  parentId,
  organizationUnitId,
  employee,
  open,
  onClose,
}: EditGoalProps) {
  const [editGoal, setEditGoal] = useImmer<CreateGoalInput | UpdateGoalInput>(
    goal || { ...defaultGoal }
  );
  // Datepicker uses dayjs values, save that and in save convert toISOString for dynamo
  const [startDate, setStartDate] = useState<Dayjs | null>(
    goal?.title
      ? goal?.startDate
        ? dayjs(goal.startDate)
        : null
      : dayjs(new Date())
  );
  const [targetDate, setTargetDate] = useState<Dayjs | null>(
    goal?.targetDate ? dayjs(goal.targetDate) : null
  );
  const [showHelp, setShowHelp] = useState(false);
  const [saving, setSaving] = useState(false);
  const [titleError, setTitleError] = useState("");
  const [dateError, setDateError] = useState("");
  const [saveError, setSaveError] = useState("");
  const [tabValue, setTabValue] = useState(0);
  const currentUser = useAuthStatus();
  const dbUser = useSettings()?.dbUser;
  const intl = useIntl();
  const [chatDialogState, setChatDialogState] = useImmer<ChatDialogState>(
    defaultChatDialogState
  );
  const northStars = useNorthStars()?.northStars;
  const organizations = useOrganization()?.organization;
  const goals = useGoals()?.goals;
  const employees = useEmployees();

  const resetStates = () => {
    setEditGoal(goal || { ...defaultGoal });
    setStartDate(goal?.startDate ? dayjs(goal.startDate) : null);
    setTargetDate(goal?.targetDate ? dayjs(goal.targetDate) : null);
    setShowHelp(false);
    setSaving(false);
    setTitleError("");
    setDateError("");
    setSaveError("");
  };

  const getPrefilledQuestion = useCallback(() => {
    if (organizationUnitId) {
      const currentOrg = organizations?.find(
        (org) => org.id === organizationUnitId
      )!;
      const parentOrg = organizations?.find(
        (org) => org.id === currentOrg.parentOrganizationUnit?.id
      )!;
      if (parentOrg) {
        return intl.formatMessage(
          {
            id: "chat.prefilled.question.child.org.goal",
          },
          { currentOrg: currentOrg.name, parentOrg: parentOrg.name }
        );
      } else {
        return intl.formatMessage(
          {
            id: "chat.prefilled.question.org.goal",
          },
          { currentOrg: currentOrg.name }
        );
      }
    } else if (employee) {
      return intl.formatMessage({
        id: "chat.prefilled.question.personal.goal",
      });
    } else {
      return intl.formatMessage({
        id: "chat.prefilled.question.company.goal",
      });
    }
  }, [employee, intl, organizationUnitId, organizations]);
  useEffect(() => {
    (async () => {
      const { info, hint } = await getGoalBackgroundInfo(
        intl,
        goal?.organizationUnitGoalsId ?? organizationUnitId,
        employee ??
          (goal &&
            employees?.employees?.find((e) => e.id === goal?.employeeGoalsId)),
        goals,
        organizations,
        northStars,
        employees?.organizationUnitEmployeeJoins,
        goal
      );
      setChatDialogState((draft) => {
        draft.backgroundInfo = info;
        draft.hint = hint;
      });
    })();
    if (!goal) {
      setChatDialogState((draft) => {
        draft.question = getPrefilledQuestion();
      });
    }
  }, [
    employee,
    goal,
    goals,
    intl,
    northStars,
    organizations,
    organizationUnitId,
    setChatDialogState,
    employees,
    getPrefilledQuestion,
  ]);

  const handleGoalTitleChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditGoal((draft) => {
      draft.title = event.target.value;
    });
    setTitleError("");
  };

  const handleGoalDescriptionChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditGoal((draft) => {
      draft.description = event.target.value;
    });
  };

  const handleGoalRewardChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditGoal((draft) => {
      draft.reward = event.target.value;
    });
  };

  const handleGoalStartDateChange = (value: Dayjs | null) => {
    if (targetDate && value && value.isAfter(targetDate)) {
      setDateError(
        intl.formatMessage({ id: "goals.error.start.date.after.end.date" })
      );
      return;
    }
    setDateError("");
    setStartDate(value);
  };

  const handleGoalTargetDateChange = (value: Dayjs | null) => {
    if (startDate && value && value.isBefore(startDate)) {
      setDateError(
        intl.formatMessage({ id: "goals.error.start.date.after.end.date" })
      );
      return;
    }
    setDateError("");
    setTargetDate(value);
  };

  const handleCancel = (event?: object, reason?: string) => {
    if (reason === "backdropClick") {
      // Don't do anything. Accidental click can't delete all the information.
      return;
    }
    // Clear states if cancelled
    resetStates();
    onClose();
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  const handleSave = async () => {
    // Validate data first.
    if (!editGoal.title) {
      setTitleError(intl.formatMessage({ id: "goals.error.title.required" }));
      return;
    }

    if (startDate && targetDate && startDate.isAfter(targetDate)) {
      setDateError(
        intl.formatMessage({ id: "goals.error.start.date.after.end.date" })
      );
      return;
    }

    try {
      setSaving(true);
      const inputGoal = {
        ...editGoal,
      };
      // Dates must be separately handled.
      if (startDate) {
        inputGoal.startDate = startDate.toISOString();
      }
      if (targetDate) {
        inputGoal.targetDate = targetDate.toISOString();
      }

      if (!goal) {
        inputGoal.organizationUnitGoalsId = organizationUnitId;
        inputGoal.goalChildGoalsId = parentId;
        inputGoal.employeeGoalsId = employee?.id;
        inputGoal.creatorEmail = currentUser?.attributes.email;
        inputGoal.position = newPosition;
        inputGoal.isClosed = false;

        await addGoalDb(inputGoal as CreateGoalInput, employees?.employees!);
      } else {
        await updateGoalDb(inputGoal as UpdateGoalInput);
      }
      onClose();
      resetStates();
    } catch (error: any) {
      `Add/Update Goal: ${error.message}`;
      setSaveError(intl.formatMessage({ id: "general.save.error" }));
      setSaving(false);
    }
  };

  return (
    <LocalizeDatePicker dbUser={dbUser}>
      <Dialog
        open={open}
        onClose={handleCancel}
        fullWidth={true}
        maxWidth="lg"
        disableRestoreFocus
      >
        <DialogTabTitle
          tabValue={tabValue}
          setTabValue={setTabValue}
          dialogTitle={intl.formatMessage({
            id: goal ? "goals.edit" : "goals.add",
          })}
          handleToggleHelp={handleToggleHelp}
        />
        <DialogContent>
          <TabPanel value={tabValue} index={0}>
            <HelpCollapse
              showHelp={showHelp}
              helpText={intl.formatMessage({ id: "goals.help.text" })}
            />
            <TextField
              autoFocus
              margin="dense"
              id="title"
              label={<FormattedMessage id="goals.goal.title" />}
              type="text"
              fullWidth
              variant="standard"
              autoComplete="off"
              data-cy="edit-goal-title-input"
              helperText={titleError}
              error={titleError !== ""}
              value={editGoal.title}
              required
              onChange={handleGoalTitleChange}
            />

            {/* Description */}
            <TextField
              margin="dense"
              id="description"
              label={<FormattedMessage id="goals.description" />}
              type="text"
              fullWidth
              variant="standard"
              autoComplete="off"
              multiline
              data-cy="edit-goal-description-input"
              value={editGoal.description || ""}
              onChange={handleGoalDescriptionChange}
            />

            {/* Reward */}
            <TextField
              sx={{ marginBottom: "18px" }} // adds necessary space above start date row
              margin="dense"
              id="reward"
              label={<FormattedMessage id="goals.reward" />}
              type="text"
              fullWidth
              variant="standard"
              autoComplete="off"
              multiline
              data-cy="edit-goal-reward-input"
              value={editGoal.reward || ""}
              onChange={handleGoalRewardChange}
            />

            <Stack
              direction="row"
              spacing={1}
              style={{ marginTop: "6px", marginBottom: "12px" }}
            >
              {/* Start date */}
              <Stack
                direction="column"
                spacing={1}
                data-cy="edit-goal-start-date-container"
              >
                <Label>
                  <FormattedMessage id="goals.start.date" />
                </Label>
                <DatePicker
                  value={startDate}
                  onChange={handleGoalStartDateChange}
                />
              </Stack>

              {/* Goal date */}
              <Stack
                direction="column"
                spacing={1}
                data-cy="edit-goal-target-date-container"
              >
                <Label>
                  <FormattedMessage id="goals.target.date" />
                </Label>
                <DatePicker
                  value={targetDate}
                  data-cy="edit-goal-target-date-datepicker"
                  onChange={handleGoalTargetDateChange}
                />
              </Stack>
            </Stack>
            <Collapse in={dateError !== ""} unmountOnExit>
              <Label>{dateError}</Label>
            </Collapse>
          </TabPanel>
          <TabPanel value={tabValue} index={1}>
            <DialogChat
              chatDialogState={chatDialogState}
              setChatDialogState={setChatDialogState}
            />
          </TabPanel>
        </DialogContent>
        {saveError && <Alert severity="error">{saveError}</Alert>}
        <EditDialogActions
          saving={saving}
          onSave={handleSave}
          onCancel={handleCancel}
          saveDisabled={titleError !== "" || dateError !== ""}
        />
      </Dialog>
    </LocalizeDatePicker>
  );
}
