import React, { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  InputLabel,
  MenuItem,
  Select,
  SelectChangeEvent,
  Alert,
} from "@mui/material";
import { Goal, UpdateGoalInput, CreateGoalInput } from "@/src/API";
import Stack from "@mui/material/Stack";
import { CloseGoalStatus, updateGoalStatus } from "@/lib/webGoals";
import { useImmer } from "use-immer";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import { FormattedMessage, useIntl } from "react-intl";
import { getCloseStatusFlagText } from "@/lib/webGoals";
import { log } from "@/lib/backend/actions/logger";
import HelpButton from "../Common/Buttons/HelpButton";
import { FormTitle } from "../Common/Texts/Texts";
import HelpCollapse from "../Common/Dialog/HelpCollapse";
import { useEmployees } from "@/contexts/EmployeesContext";

interface CloseGoalProps {
  goal: Goal;
  open: boolean;
  onClose: () => void;
}

export default function CloseGoal({ goal, open, onClose }: CloseGoalProps) {
  const [closeGoal, setCloseGoal] = useImmer<CreateGoalInput | UpdateGoalInput>(
    { ...goal, statusFlag: CloseGoalStatus.ACHIEVED }
  );
  const [showHelp, setShowHelp] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savingError, setSavingError] = useState("");
  const employees = useEmployees()?.employees;

  const intl = useIntl();

  const resetStates = () => {
    setCloseGoal({ ...goal, statusFlag: CloseGoalStatus.ACHIEVED });
    setShowHelp(false);
    setSaving(false);
    setSavingError("");
  };

  const handleNotesChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setCloseGoal((draft) => {
      draft.closingNotes = event.target.value;
    });
  };

  const handleCancel = (event?: object, reason?: string) => {
    if (reason === "backdropClick") {
      // Don't do anything. Accidental click can't delete all the information.
      return;
    }
    // Clear states if cancelled
    resetStates();
    onClose();
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };
  const handleChangeCloseFlag = (event: SelectChangeEvent) => {
    setCloseGoal((draft) => {
      draft.statusFlag = event?.target.value as CloseGoalStatus;
    });
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      const inputGoal = {
        ...closeGoal,
        isClosed: true,
      };
      await updateGoalStatus(inputGoal as UpdateGoalInput, employees);
      resetStates();
      onClose();
    } catch (error: any) {
      log(`Close Goal: ${error.message}`);
      setSaving(false);
      setSavingError(intl.formatMessage({ id: "goal.error.close.goal" }));
    }
  };

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      fullWidth={true}
      maxWidth="lg"
      disableRestoreFocus
    >
      <DialogTitle>
        <Stack direction="row" spacing={1} alignItems={"center"}>
          <FormTitle>
            <FormattedMessage id="goal.close.title" />
          </FormTitle>
          {/* Help btn */}
          <HelpButton
            onClick={handleToggleHelp}
            data-cy="show-close-goal-help"
          />
        </Stack>
      </DialogTitle>
      <DialogContent>
        <HelpCollapse
          showHelp={showHelp}
          helpText={intl.formatMessage({ id: "goal.close.help.text" })}
        />
        <TextField
          autoFocus
          margin="dense"
          id="notes"
          label={<FormattedMessage id="goal.close.notes" />}
          type="text"
          fullWidth
          variant="standard"
          autoComplete="off"
          data-cy="edit-goal-title-input"
          value={closeGoal.closingNotes || ""}
          onChange={handleNotesChange}
        />
        <InputLabel id="select-statusflag-label">Status</InputLabel>
        <Select
          labelId="select-statusflag-label"
          value={closeGoal.statusFlag?.toString()}
          defaultValue={CloseGoalStatus.ACHIEVED}
          label={intl.formatMessage({ id: "status.status" })}
          onChange={handleChangeCloseFlag}
          variant="standard"
          sx={{ minWidth: 200 }}
        >
          <MenuItem value={CloseGoalStatus.ACHIEVED}>
            <FormattedMessage
              id={getCloseStatusFlagText(CloseGoalStatus.ACHIEVED)}
            />
          </MenuItem>
          <MenuItem value={CloseGoalStatus.SOMEWHAT_ACHIEVED}>
            <FormattedMessage
              id={getCloseStatusFlagText(CloseGoalStatus.SOMEWHAT_ACHIEVED)}
            />
          </MenuItem>
          <MenuItem value={CloseGoalStatus.FAILED}>
            <FormattedMessage
              id={getCloseStatusFlagText(CloseGoalStatus.FAILED)}
            />
          </MenuItem>
        </Select>
      </DialogContent>
      {savingError && <Alert severity="error">{savingError}</Alert>}
      <EditDialogActions
        saving={saving}
        onSave={handleSave}
        onCancel={handleCancel}
        saveDisabled={false}
      />
    </Dialog>
  );
}
