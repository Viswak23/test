import {
  calculateKeyResultsSummary,
  getKeyResultColor,
  getKeyResultFlagByIndex,
  getStatusFlagText,
} from "@/lib/webKeyResults";
import { KeyResult } from "@/src/API";
import { BarChart } from "@mui/x-charts/BarChart";
import { BarItemIdentifier } from "@mui/x-charts";
import { useMemo, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { Stack } from "@mui/material";
import KeyResults from "../KeyResults/KeyResults";
import { TabTitle } from "../Common/Texts/Texts";

interface KeyResultsDistGraphProps {
  keyResults?: (KeyResult | null)[];
}

export default function KeyResultsDistGraph({
  keyResults,
}: KeyResultsDistGraphProps) {
  const [selected, setSelected] = useState<number>();
  const intl = useIntl();

  const krDistributionData = useMemo(() => {
    return calculateKeyResultsSummary(undefined, undefined, keyResults);
  }, [keyResults]);

  const dataLabels = useMemo(() => {
    return krDistributionData.map((item, index) =>
      getStatusFlagText(intl, getKeyResultFlagByIndex(index))
    );
  }, [krDistributionData, intl]);

  const dataColors = useMemo(() => {
    return krDistributionData.map((item, index) =>
      getKeyResultColor(getKeyResultFlagByIndex(index))
    );
  }, [krDistributionData]);

  const listedKeyResults = useMemo(() => {
    return selected == null
      ? []
      : keyResults?.filter(
          (kr) => kr && kr.statusFlag === getKeyResultFlagByIndex(selected)
        );
  }, [keyResults, selected]);

  const handleSelect = (
    event: React.MouseEvent,
    barItemIdentifier: BarItemIdentifier
  ) => {
    setSelected(barItemIdentifier.dataIndex);
  };

  return (
    <Stack direction="column" sx={{ textAlign: "center", paddingTop: "18px" }}>
      <BarChart
        onItemClick={handleSelect}
        xAxis={[
          {
            id: "barCategories",
            data: dataLabels,
            scaleType: "band",
            colorMap: {
              type: "ordinal",
              colors: dataColors,
            },
          },
        ]}
        series={[
          {
            data: krDistributionData,
          },
        ]}
        yAxis={[
          {
            tickMinStep: 1,
          },
        ]}
        height={300}
      />
      {selected != null && (
        <KeyResults
          keyResultsList={listedKeyResults}
          showLocation
          showTitle={false}
          showNoKeyResults={selected != null && selected >= 0}
          canAdd={false}
          canEdit={false}
        />
      )}
    </Stack>
  );
}
