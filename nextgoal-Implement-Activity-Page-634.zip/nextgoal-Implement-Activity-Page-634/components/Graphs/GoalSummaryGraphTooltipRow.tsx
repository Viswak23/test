import { Stack, SvgIconProps } from "@mui/material";
import { DetailsText, LightText } from "../Common/Texts/Texts";

interface GoalSummaryGraphTooltipRowProps {
  label: string;
  icon: React.ComponentType<SvgIconProps>;
  value: string;
  color: string;
  noValue: boolean;
}

export default function GoalSummaryGraphTooltipRow({
  icon,
  label,
  value,
  color,
  noValue,
}: GoalSummaryGraphTooltipRowProps) {
  const Icon = icon;
  const iconColor = value !== "" ? color : "grey";
  const iconStyle = value !== "" ? {} : { opacity: "60%" };

  return (
    <Stack
      direction={"row"}
      spacing={1}
      alignItems={"center"}
      sx={{ height: "24px" }}
    >
      <Icon fontSize="small" sx={{ color: iconColor, ...iconStyle }} />
      {noValue ? (
        <LightText>{label}</LightText>
      ) : (
        <DetailsText>{label}</DetailsText>
      )}
    </Stack>
  );
}
