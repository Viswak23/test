import { Stack, SvgIconProps } from "@mui/material";
import { DetailsText } from "../Common/Texts/Texts";

interface GoalSummaryGraphLegendItemProps {
  label: string;
  icon: React.ComponentType<SvgIconProps>;
  color: string;
}

export default function GoalSummaryGraphLegendItem({
  icon,
  label,
  color,
}: GoalSummaryGraphLegendItemProps) {
  const Icon = icon;

  return (
    <Stack
      direction={"row"}
      spacing={1}
      alignItems={"center"}
      sx={{ height: "24px", marginRight: "16px" }}
    >
      <Icon fontSize="small" sx={{ color }} />
      <DetailsText>{label}</DetailsText>
    </Stack>
  );
}
