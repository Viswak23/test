import { Stack } from "@mui/material";
import {
  ChangeHistory,
  CircleOutlined,
  CropSquare,
  OfflineBolt,
} from "@mui/icons-material";
import GoalSummaryGraphLegendItem from "./GoalSummaryGraphLegendItem";
import { LineSeriesType } from "@mui/x-charts";

interface GoalSummaryGraphLegendProps {
  seriesToDisplay: LineSeriesType[];
}

// Create own legend for mui-x graphs so that we can controll the content in more detailed way.
export default function GoalSummaryGraphLegend({
  seriesToDisplay,
}: GoalSummaryGraphLegendProps) {
  return (
    <Stack
      direction="row"
      spacing={0}
      sx={{
        flexWrap: "wrap",
        alignItems: "flex-start",
        marginLeft: "16px",
        marginBottom: "-12px",
        paddingLeft: { xs: "0px", md: "40px" },
      }}
    >
      {seriesToDisplay.map((serie: any) => {
        let icon = ChangeHistory;
        if (serie.id?.startsWith("keyResultData")) {
          icon = OfflineBolt;
        } else if (serie.id === "eventsData") {
          icon = CropSquare;
        } else if (serie.id === "targetData") {
          icon = CircleOutlined;
        }
        return (
          <GoalSummaryGraphLegendItem
            key={serie.label}
            label={serie.label}
            icon={icon}
            color={serie.color}
          />
        );
      })}
    </Stack>
  );
}
