import { useEvents } from "@/contexts/EventsContext";
import { useSettings } from "@/contexts/SettingsInfo";
import { getTimestamp, getTimeStampForGraph, showDate } from "@/lib/time";
import { EventType, getEventInfo } from "@/lib/webEvents";
import {
  getKeyResultColor,
  getKeyResultReadiness,
  getStatusFlagText,
  KeyResultStatus,
} from "@/lib/webKeyResults";
import { Goal, Event } from "@/src/API";
import { Box, useTheme } from "@mui/material";
import {
  ChartsAxisHighlight,
  ChartsTooltip,
  ChartsXAxis,
  ChartsYAxis,
  LinePlot,
  LineSeriesType,
  MarkPlot,
  MarkElement,
  ResponsiveChartContainer,
  MarkElementProps,
  ChartsAxisContentProps,
} from "@mui/x-charts";
import { useMemo, useRef } from "react";
import { IntlShape, useIntl } from "react-intl";
import GoalSummaryGraphTooltip from "./GoalSummaryGraphTooltip";
import GoalSummaryGraphLegend from "./GoalSummaryGraphLegend";

interface GoalSummaryGraphProps {
  goal: Goal;
}

interface KeyResultDataSetInterface {
  label: string;
  id: string;
  status: KeyResultStatus;
  data: (number | null)[];
}

export interface EventsDataSetInterface {
  label: string;
  value: number | null;
  events: (Event | null | undefined)[];
}

interface GraphDataInterface {
  timestamps: number[];
  keyResultsData?: KeyResultDataSetInterface[];
  targetData?: (number | null)[];
  statusData?: (number | null)[];
  eventsData?: EventsDataSetInterface[];
}

interface DatapointsInterface {
  timestamp: string;
  source: string;
  keyResultId?: string;
  eventLabel?: string;
  value: number | null;
  event?: Event | null;
}

const testStatusUpdates = [
  { createdAt: "2024-08-24", gutFeeling: 40 },
  { createdAt: "2024-09-25", gutFeeling: 60 },
  { createdAt: "2024-10-26", gutFeeling: 80 },
  { createdAt: "2024-11-24", gutFeeling: 40 },
  { createdAt: "2024-12-25", gutFeeling: 60 },
  { createdAt: "2025-01-26", gutFeeling: 80 },
];

enum DataSources {
  Target = "target",
  Keyresult = "keyresult",
  Status = "status",
  Event = "event",
}

// Creates an ordered datapoint array from the goal status updates, key results and events
function getDatapointArray(
  goal: Goal,
  goalEvents: Event[] | undefined,
  intl: IntlShape
): DatapointsInterface[] {
  const eventValue = 0;
  const datapointArray: DatapointsInterface[] = [];

  // Add target data to datapointArray if goal has target date
  if (goal.targetDate) {
    const goalStart = goal.startDate ? goal.startDate : goal.createdAt;
    datapointArray.push({
      timestamp: goalStart,
      source: DataSources.Target,
      value: 0,
    });
    datapointArray.push({
      timestamp: goal.targetDate,
      source: DataSources.Target,
      value: 100,
    });
    // Add also 0 frot gut feeling
    datapointArray.push({
      timestamp: goalStart,
      source: DataSources.Status,
      value: 0,
    });
  }

  // Add key results data to datapointArray
  if (goal.keyResults?.items) {
    goal.keyResults.items.forEach((keyResult) => {
      // If there are no target value, we cannot show it's progress
      if (!keyResult || keyResult.targetValue == null) {
        return;
      }
      // Push the initial value of the key result
      if (keyResult.initialValue != null) {
        datapointArray.push({
          timestamp: keyResult.createdAt,
          source: DataSources.Keyresult,
          keyResultId: keyResult.id,
          value: getKeyResultReadiness(
            keyResult.initialValue,
            keyResult.targetValue
          ),
        });
      }

      keyResult.updates?.items?.forEach((update) => {
        if (
          !update ||
          update.currentValueAfter == null ||
          update.dateOfUpdate == null
        ) {
          return;
        }

        datapointArray.push({
          timestamp: update.dateOfUpdate,
          source: DataSources.Keyresult,
          keyResultId: keyResult.id,
          value: getKeyResultReadiness(
            update.currentValueAfter,
            keyResult.targetValue!
          ),
        });
      });
    });
  }

  // Add status data to datapointArray
  testStatusUpdates.forEach((statusUpdate) => {
    if (!statusUpdate.createdAt || statusUpdate.gutFeeling == null) {
      return;
    }

    datapointArray.push({
      timestamp: statusUpdate.createdAt,
      source: DataSources.Status,
      value: statusUpdate.gutFeeling,
    });
  });

  // Add interesting events data to datapointArray with const value.
  goalEvents?.forEach((event) => {
    if (
      !event ||
      !event.createdAt ||
      // We are not interested of all the events.
      event.eventType === EventType.GOAL_ADDED ||
      event.eventType === EventType.GOAL_OPENED ||
      event.eventType === EventType.GOAL_CLOSED ||
      event.eventType === EventType.KEY_RESULT_ADDED ||
      event.eventType === EventType.KEY_RESULT_UPDATE_ADDED ||
      event.eventType === EventType.STATUS_ADDED
    ) {
      return;
    }

    const eventInfo = getEventInfo(intl, event);
    datapointArray.push({
      timestamp: event.createdAt,
      source: DataSources.Event,
      value: eventValue,
      eventLabel: eventInfo.title,
      event: event,
    });
  });

  // Sort datapoints by timestamp
  datapointArray.sort(
    (a, b) => getTimestamp(a.timestamp) - getTimestamp(b.timestamp)
  );

  return datapointArray;
}

// Create the data object for the graph
function createGraphData(
  datapointArray: DatapointsInterface[],
  goal: Goal,
  intl: IntlShape
): GraphDataInterface {
  const result: GraphDataInterface = {
    timestamps: [],
    keyResultsData: [],
    targetData: [],
    statusData: [],
    eventsData: [],
  };
  goal.keyResults?.items?.forEach((kr) => {
    if (!kr) {
      return;
    }

    result.keyResultsData!.push({
      label: intl.formatMessage(
        { id: "keyresults.graph.label" },
        {
          description: kr.description,
          status: getStatusFlagText(intl, kr.statusFlag),
        }
      ),
      id: kr.id,
      status: (kr.statusFlag as KeyResultStatus) || KeyResultStatus.UNKNOWN,
      data: [],
    });
  });

  // Create datasets from datapoints
  datapointArray.forEach((datapoint) => {
    // If the previous result has the same date, add the entry to the previous result.
    if (
      result.timestamps.length > 0 &&
      result.timestamps[result.timestamps.length - 1] ===
        getTimeStampForGraph(datapoint.timestamp)
    ) {
      if (datapoint.source === DataSources.Target) {
        result.targetData![result.targetData!.length - 1] = datapoint.value;
      } else if (datapoint.source === DataSources.Status) {
        result.statusData![result.statusData!.length - 1] = datapoint.value;
      } else if (datapoint.source === DataSources.Event) {
        // If there were already an event at the same date, we will give a different label to the event.
        if (
          result.eventsData &&
          result.eventsData[result.eventsData!.length - 1].events.length > 0
        ) {
          result.eventsData![result.eventsData.length - 1].events.push(
            datapoint.event
          );
          result.eventsData![result.eventsData!.length - 1].label =
            intl.formatMessage(
              { id: "feeds.multiple.events" },
              {
                count:
                  result.eventsData![result.eventsData!.length - 1].events!
                    .length,
              }
            );
        } else {
          result.eventsData![result.eventsData!.length - 1] = {
            label:
              datapoint.eventLabel ||
              intl.formatMessage({ id: "feeds.unknown.event" }),
            value: datapoint.value,
            events: [datapoint.event!],
          };
        }
      } else {
        result.keyResultsData?.forEach((krd) => {
          if (krd.id === datapoint.keyResultId) {
            krd.data[krd.data.length - 1] = datapoint.value;
          }
        });
      }
    } else {
      result.timestamps.push(getTimeStampForGraph(datapoint.timestamp));
      result.targetData!.push(
        datapoint.source === DataSources.Target ? datapoint.value : null
      );
      result.statusData!.push(
        datapoint.source === DataSources.Status ? datapoint.value : null
      );
      result.eventsData!.push(
        datapoint.source === DataSources.Event
          ? {
              label:
                datapoint.eventLabel ||
                intl.formatMessage({ id: "feeds.unknown.event" }),
              value: datapoint.value,
              events: [datapoint.event!],
            }
          : { label: "", value: null, events: [] }
      );

      result.keyResultsData?.forEach((krd) => {
        krd.data.push(
          krd.id === datapoint.keyResultId ? datapoint.value : null
        );
      });
    }
  });

  return result;
}

export default function GoalSummaryGraph({ goal }: GoalSummaryGraphProps) {
  const theme = useTheme();
  const intl = useIntl();
  const dbUser = useSettings()?.dbUser;
  const events = useEvents()?.events;
  const currentEvent = useRef<EventsDataSetInterface | null>(null);

  const goalEvents = useMemo(
    () => events?.filter((e) => e.goalEventsId === goal.id),
    [events, goal.id]
  );

  const data: GraphDataInterface = useMemo(() => {
    // Create datapoint array
    const datapointArray = getDatapointArray(goal, goalEvents, intl);

    // Create a result object.
    const result = createGraphData(datapointArray, goal, intl);

    return result;
  }, [goal, goalEvents, intl]);

  // Create series for the graph
  const series: LineSeriesType[] = [];
  if (data.timestamps.length > 0) {
    series.push({
      id: "statusData",
      data: data.statusData,
      connectNulls: true,
      label: intl.formatMessage({
        id: "status.gutfeeling",
      }),
      type: "line",
      color: theme.palette.customColors?.graphline1,
      valueFormatter: (v: any) => (v === null ? "" : `${v} %`),
    });

    // If there are multiple key results with the same status, we will give them slighly different colors.
    const keyResultColorIndexes = {
      [KeyResultStatus.UNKNOWN]: 0,
      [KeyResultStatus.COMPLETED]: 0,
      [KeyResultStatus.ON_TRACK]: 0,
      [KeyResultStatus.AT_RISK]: 0,
      [KeyResultStatus.BEHIND]: 0,
      [KeyResultStatus.FAILED]: 0,
    };

    data.keyResultsData!.forEach((krd, index) => {
      series.push({
        id: `keyResultData${index}`,
        data: krd.data,
        connectNulls: true,
        label: krd.label,
        type: "line",
        color: getKeyResultColor(krd.status, keyResultColorIndexes[krd.status]),
        valueFormatter: (v: number | null) => (v === null ? "" : `${v} %`),
      });
      keyResultColorIndexes[krd.status]++;
    });

    series.push({
      id: "eventsData",
      data: data.eventsData?.map((ed) => ed.value),
      label: intl.formatMessage({
        id: "goals.events",
      }),
      type: "line",
      color: "gray",
      valueFormatter: (v: number | null, { dataIndex }) =>
        data.eventsData![dataIndex].label,
    });

    if (data.targetData!.length > 0) {
      series.push({
        id: "targetData",
        data: data.targetData,
        connectNulls: true,
        label: intl.formatMessage({
          id: "keyresults.graph.path.to.target",
        }),
        type: "line",
        color: theme.palette.customColors?.graphline2,
        valueFormatter: (v: number | null) => (v === null ? "" : `${v} %`),
      });
    }
  }

  // Use triangles with statusdata, squares with eventsdata and circles with key results and target data
  const slotsMark = (props: MarkElementProps) => {
    if (props.id === "eventsData") {
      return <MarkElement {...props} shape="square" />;
    } else if (props.id === "statusData") {
      return <MarkElement {...props} shape="triangle" />;
    }

    return <MarkElement {...props} />;
  };

  // We need to have our own tooltip in order to show the information we like to show.
  const EnrichenedTooltip = (props: ChartsAxisContentProps) => {
    const eventsData = { eventsData: data.eventsData };
    currentEvent.current =
      data.eventsData && props.dataIndex != null
        ? data.eventsData[props.dataIndex]
        : null;
    return <GoalSummaryGraphTooltip {...props} {...eventsData} />;
  };

  // XXX: Placeholder for the next stage of the development
  const onItemClick = (props: any) => {
    // TODO: Implement click handling for chart items
    // This will be used in the next stage of development when user can open all the events from the graph.
    // console.log(currentEvent.current);
  };

  return (
    <Box
      style={{
        width: "100%",
        height: "auto",
        overflow: "hidden",
      }}
    >
      <GoalSummaryGraphLegend seriesToDisplay={series} />
      <ResponsiveChartContainer
        height={360}
        series={series}
        xAxis={[
          {
            data: data.timestamps,
            scaleType: "time",
            valueFormatter: (value) => showDate(value, dbUser),
          },
        ]}
        yAxis={[
          {
            min: 0,
            max: 100,
          },
        ]}
        sx={{
          ".MuiLineElement-series-targetData": {
            strokeDasharray: "5 5",
          },
          "& .MuiLineElement-series-eventsData": {
            display: "none",
          },
        }}
      >
        <LinePlot />
        <MarkPlot
          slots={{
            mark: slotsMark,
          }}
          onItemClick={onItemClick}
        />
        <ChartsXAxis />
        <ChartsYAxis />
        <ChartsTooltip
          trigger="axis"
          slots={{
            axisContent: EnrichenedTooltip,
          }}
        />
        <ChartsAxisHighlight x="line" />
      </ResponsiveChartContainer>
    </Box>
  );
}
