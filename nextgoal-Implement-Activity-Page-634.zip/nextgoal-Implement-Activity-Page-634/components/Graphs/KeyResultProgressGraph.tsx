import { getTimestamp, isBefore, showDate, sortUpdateDate } from "@/lib/time";
import { KeyResult, Goal } from "@/src/API";
import { useMemo } from "react";
import { useIntl } from "react-intl";
import { LineSeriesType } from "@mui/x-charts";
import { ResponsiveChartContainer } from "@mui/x-charts/ResponsiveChartContainer";
import { LinePlot, MarkPlot } from "@mui/x-charts/LineChart";
import { ChartsXAxis } from "@mui/x-charts/ChartsXAxis";
import { ChartsYAxis } from "@mui/x-charts/ChartsYAxis";
import { ChartsReferenceLine } from "@mui/x-charts/ChartsReferenceLine";
import { ChartsTooltip } from "@mui/x-charts/ChartsTooltip";
import { ChartsLegend } from "@mui/x-charts/ChartsLegend";
import { ChartsAxisHighlight } from "@mui/x-charts/ChartsAxisHighlight";
import { Box, useTheme } from "@mui/material";
import { useSettings } from "@/contexts/SettingsInfo";

interface KeyResultProgressGraphProps {
  keyResult: KeyResult | null;
  goal?: Goal | null;
}

export default function KeyResultProgressGraph({
  keyResult,
  goal,
}: KeyResultProgressGraphProps) {
  const intl = useIntl();
  const theme = useTheme();
  const dbUser = useSettings()?.dbUser;

  const showDirectToTarget =
    goal?.targetDate != null && keyResult?.targetValue != null;

  interface ResultInterface {
    xAxisLabels: number[];
    data: (number | null)[];
    targetData: (number | null)[];
    targetValue?: number;
    minValue: number | null;
    maxValue: number | null;
  }

  const data: ResultInterface = useMemo(() => {
    const result: ResultInterface = {
      xAxisLabels: [],
      data: [],
      targetData: [],
      targetValue: undefined,
      minValue: null,
      maxValue: null,
    };

    // Save new value into dataset. Also add a timestamp to the xAxisLabels and null to targetData
    const saveNewValue = (
      timeStamp: string,
      value?: number | null,
      targetValue?: number | null,
      first?: boolean
    ) => {
      if (first) {
        result.data.unshift(value || null);
        result.xAxisLabels.unshift(getTimestamp(timeStamp));
        result.targetData.unshift(targetValue || null);
      } else {
        result.data.push(value || null);
        result.xAxisLabels.push(getTimestamp(timeStamp));
        result.targetData.push(targetValue || null);
      }

      // Update min and max values
      if (value && (!result.minValue || value < result.minValue)) {
        result.minValue = value;
      }
      if (value && (!result.maxValue || value > result.maxValue)) {
        result.maxValue = value;
      }
    };

    if (!keyResult) {
      return result;
    }

    // Sort the updates by date
    let updates = [...(keyResult.updates?.items || [])];
    updates.sort((a, b) => sortUpdateDate(a, b));

    // Save the target value if exists
    if (keyResult.targetValue != null) {
      result.targetValue = keyResult.targetValue;
      if (!result.minValue || keyResult.targetValue < result.minValue) {
        result.minValue = keyResult.targetValue;
      }
      if (!result.maxValue || keyResult.targetValue > result.maxValue) {
        result.maxValue = keyResult.targetValue;
      }
    }

    // Push the keyresult updates into array.
    let targetPushed = false;
    if (updates.length > 0) {
      updates.forEach((item, index) => {
        if (!item) {
          return;
        }

        // If the target date is before the update date, push null to targetData, target Date to labels, and current value to data
        if (
          !targetPushed &&
          showDirectToTarget &&
          isBefore(goal?.targetDate!, item?.dateOfUpdate)
        ) {
          saveNewValue(item.dateOfUpdate, item.currentValueAfter || 0); // Target value should never be null while showDirectToTarget is true
          targetPushed = true;
        }
        // If the target date is the same as the update date, push the target value to targetData and set targetPushed to true
        else if (
          showDirectToTarget &&
          goal?.targetDate === item?.dateOfUpdate
        ) {
          saveNewValue(
            item.dateOfUpdate,
            item.currentValueAfter || 0,
            keyResult.targetValue || 0
          );
          targetPushed = true;
        } else {
          saveNewValue(item.dateOfUpdate, item.currentValueAfter || 0);
        }
      });
    }

    if (updates.length === 0) {
      // If the target date is before the creation date, push the target value first
      if (
        showDirectToTarget &&
        isBefore(goal.targetDate!, keyResult.createdAt)
      ) {
        saveNewValue(goal.targetDate!, null, keyResult.targetValue || 0);
      }

      // Push the initial value and date to the beginning
      saveNewValue(keyResult.createdAt, keyResult.initialValue, null, true);

      // If the target date is after the creation date and there are no updates, push the target value last
      if (
        showDirectToTarget &&
        goal?.targetDate &&
        !isBefore(goal.targetDate, keyResult.createdAt)
      ) {
        saveNewValue(goal.targetDate, null, keyResult.targetValue || 0);
      }
    }

    // Handle cases when there are updates
    else {
      // If the creation date was before the first update, push the initial value first
      if (isBefore(keyResult.createdAt, updates[0]!.dateOfUpdate)) {
        saveNewValue(keyResult.createdAt, keyResult.initialValue, null, true);
      }

      // If the target date is after the last update, push the target value last
      if (showDirectToTarget) {
        // Iterate in reverse to find the last update before the goal's target date
        for (let i = updates.length - 1; i >= 0; i--) {
          const update = updates[i];
          if (update) {
            if (isBefore(update.dateOfUpdate, goal.targetDate!)) {
              saveNewValue(goal.targetDate!, null, keyResult.targetValue || 0);
              break;
            }
          }
        }
      }
    }

    // Set the first value to start target value.
    if (showDirectToTarget) {
      if (result.data.length > 0) {
        result.targetData[0] = result.data[0] || 0;
      }
    }

    return result;
  }, [keyResult, goal, showDirectToTarget]);

  const series: LineSeriesType[] = [];

  if (data.data.length > 0) {
    series.push({
      data: data.data,
      label: intl.formatMessage({
        id: "keyresults.graph.current.value",
      }),
      type: "line",
      color: theme.palette.customColors?.graphline1,
    });
  }

  if (showDirectToTarget) {
    series.push({
      data: data.targetData,
      label: intl.formatMessage({
        id: "keyresults.graph.path.to.target",
      }),
      connectNulls: true,
      id: "targetData",
      type: "line",
      color: theme.palette.customColors?.graphline2,
    });
  }

  // Set the y-axis min and max values to the graph
  let yMin = data.minValue || undefined;
  let yMax = data.maxValue || undefined;

  if (yMin && yMax) {
    const diff = yMax - yMin;
    yMin -= diff * 0.1;
    yMax += diff * 0.1;
  }

  // The graph is not drawn in development environment without mouse over: Must test in prod environment!
  // https://stackoverflow.com/questions/78410757/material-ui-chart-only-loading-lines-after-hovering

  return (
    <Box
      style={{
        width: "100%",
        height: "auto",
        maxWidth: "500px",
        overflow: "hidden",
      }}
    >
      <ResponsiveChartContainer
        height={240}
        series={series}
        xAxis={[
          {
            data: data.xAxisLabels,
            scaleType: "time",
            valueFormatter: (value) => showDate(value, dbUser),
          },
        ]}
        yAxis={[
          {
            min: yMin,
            max: yMax,
          },
        ]}
        sx={{
          ".MuiLineElement-series-targetData": {
            strokeDasharray: "5 5",
          },
        }}
      >
        <ChartsLegend />
        <LinePlot />
        <MarkPlot />
        <ChartsXAxis />
        <ChartsYAxis />
        {data.targetValue && (
          <ChartsReferenceLine
            y={data.targetValue}
            label={intl.formatMessage({
              id: "keyresults.graph.label.target",
            })}
            lineStyle={{
              stroke: theme.palette.customColors?.graphline2,
              strokeDasharray: "3 3",
            }}
            alwaysShow
          />
        )}
        <ChartsTooltip trigger="axis" />
        <ChartsAxisHighlight x="line" />
      </ResponsiveChartContainer>
    </Box>
  );
}
