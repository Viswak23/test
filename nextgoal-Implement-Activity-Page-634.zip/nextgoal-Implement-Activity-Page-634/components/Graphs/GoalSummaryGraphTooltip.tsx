import { Box, Divider, Stack, useTheme } from "@mui/material";
import { DetailsText, LightText } from "../Common/Texts/Texts";
import { ChangeHistory, CropSquare, OfflineBolt } from "@mui/icons-material";
import GoalSummaryGraphTooltipRow from "./GoalSummaryGraphTooltipRow";

// Create our own tooltip for mui-x graphs so that we can control the content in a more detailed way.
// We use any while it's extended from the mui-x tooltip.
export default function GoalSummaryGraphTooltip(props: any) {
  const theme = useTheme();

  return (
    <Box
      sx={{
        background: "white",
        boxShadow: theme.shadows[5],
        marginLeft: "12px",
      }}
    >
      <Stack direction="column" spacing={1} sx={{ paddingBottom: "12px" }}>
        <LightText sx={{ padding: "12px 12px 0 12px" }}>
          {props.axis.valueFormatter(props.axisValue)}
        </LightText>
        <Divider />
        {
          // Switch to two columns and add first icons and labels to the first column
          // And then add the values to the second one. Then you get all the values to the same position.
        }
        <Stack
          direction="row"
          justifyContent={"space-between"}
          sx={{ paddingLeft: "12px", paddingRight: "12px" }}
          spacing={4}
        >
          <Stack direction="column" spacing={1} flexGrow={1}>
            {props.series.map((serie: any, index: number) => {
              if (serie.id === "statusData") {
                return (
                  <GoalSummaryGraphTooltipRow
                    key={props.series[index].id}
                    label={props.series[index].label}
                    icon={ChangeHistory}
                    value={props.series[index].valueFormatter(
                      props.series[index].data[props.dataIndex]
                    )}
                    color={props.series[index].color}
                    noValue={props.series[index] == null}
                  />
                );
              } else if (serie.id.startsWith("keyResultData")) {
                return (
                  <GoalSummaryGraphTooltipRow
                    key={props.series[index].id}
                    label={props.series[index].label}
                    icon={OfflineBolt}
                    value={props.series[index].valueFormatter(
                      props.series[index].data[props.dataIndex]
                    )}
                    color={props.series[index].color}
                    noValue={props.series[index] == null}
                  />
                );
              } else if (serie.id === "eventsData") {
                // Show label only if there is an event.
                if (props.eventsData[props.dataIndex].label === "") {
                  return null;
                }

                return (
                  <GoalSummaryGraphTooltipRow
                    key={props.series[index].id}
                    label={props.eventsData[props.dataIndex].label}
                    icon={CropSquare}
                    value=""
                    color={props.series[index].color}
                    noValue={false}
                  />
                );
              }
              // Else it's target data and we don't want to show it in the tooltip.
              return null;
            })}
          </Stack>
          <Stack direction="column" spacing={1}>
            {props.series.map((serie: any, index: number) => {
              // Don't add event or target data values
              if (serie.id === "eventsData" || serie.id === "targetData") {
                return null;
              }

              // XXX: A hack to get align the values and to make empty values to take space in the tooltip. :-(
              return (
                <Box key={props.series[index].label} sx={{ height: "24px" }}>
                  <DetailsText>
                    {props.series[index].valueFormatter(
                      props.series[index].data[props.dataIndex]
                    )}
                  </DetailsText>
                </Box>
              );
            })}
          </Stack>
        </Stack>
      </Stack>
    </Box>
  );
}
