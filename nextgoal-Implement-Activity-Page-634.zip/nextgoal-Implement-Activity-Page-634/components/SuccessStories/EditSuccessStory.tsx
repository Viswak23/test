import { useState, useMemo, useEffect } from "react";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import TextField from "@mui/material/TextField";
import {
  CreateSuccessStoryInput,
  SuccessStory,
  UpdateSuccessStoryInput,
} from "@/src/API";
import { useImmer } from "use-immer";
import {
  addSuccessStoryDb,
  updateSuccessStoryDb,
} from "@/lib/webSuccessStories";
import { Alert } from "@mui/material";
import { useAuthStatus } from "@/lib/customHooks";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import {
  EmployeeWithAvatarUrl,
  useEmployees,
} from "@/contexts/EmployeesContext";
import TaggedEmployees from "../Common/TaggedEmployees/TaggedEmployees";
import {
  AttachmentFile,
  AttachmentOwner,
  deleteAttachments,
  saveAttachments,
  useAttachmentUrls,
} from "@/lib/webAttachment";
import HandleAttachments from "../Common/Attachment/HandleAttachments";
import { EventType, getEventEmployeesTitle } from "@/lib/webEvents";
import { useIntl } from "react-intl";
import { useGoals } from "@/contexts/GoalsContext";
import { isEmployeeGoal } from "@/lib/webEmployee";
import { log } from "@/lib/backend/actions/logger";
import HelpCollapse from "../Common/Dialog/HelpCollapse";
import DialogTabTitle from "../Common/Dialog/DialogTabTitle";
import {
  ChatDialogState,
  defaultChatDialogState,
} from "../Chat/ChatDialogState";
import { useNorthStars } from "@/contexts/NorthStarsContext";
import { useOrganization } from "@/contexts/OrganizationContext";
import { TabPanel } from "../Settings/TabPanel";
import DialogChat from "../Chat/ChatInDialog";
import { getGoalBackgroundInfo } from "@/lib/webGoals";

interface EditSuccessStoryProps {
  goalId?: string | null;
  successStory?: SuccessStory;
  open: boolean;
  onClose: (scrollToTop: Boolean) => void;
}

const defaultStory = {
  name: "",
  companyId: "placeholder",
  creatorEmail: "placeholder",
};

export default function EditSuccessStory({
  goalId,
  successStory,
  open,
  onClose,
}: EditSuccessStoryProps) {
  const [editSuccessStory, setEditSuccessStory] = useImmer<
    CreateSuccessStoryInput | UpdateSuccessStoryInput
  >(successStory || { ...defaultStory });
  const [showHelp, setShowHelp] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savingError, setSavingError] = useState("");
  const [taggedEmployees, setTaggedEmployees] = useState<
    EmployeeWithAvatarUrl[]
  >([]);
  const [previewMedias, setPreviewMedias] = useState<AttachmentFile[]>([]);
  const [removedAttachments, setRemovedAttachments] = useState<
    AttachmentFile[]
  >([]);
  const [error, setError] = useState("");
  const { goals: fetchedGoals } = useGoals()!;
  const goals = useMemo(() => fetchedGoals || [], [fetchedGoals]);
  const currentUser = useAuthStatus();
  const memoizedAttachments = useMemo(
    () => successStory?.attachments as string[],
    [successStory?.attachments]
  );
  const existingAttachments = useAttachmentUrls(memoizedAttachments);
  const intl = useIntl();
  const employees = useEmployees();
  const [tabValue, setTabValue] = useState(0);
  const [chatDialogState, setChatDialogState] = useImmer<ChatDialogState>(
    defaultChatDialogState
  );
  const organization = useOrganization()?.organization;
  const northStars = useNorthStars()?.northStars;
  const currentGoal = goals.find((goal) => goal.id === goalId);
  const employee = employees?.employees?.find(
    (employee) => employee?.id === currentGoal?.employeeGoalsId
  );

  useEffect(() => {
    (async () => {
      let info = await getGoalBackgroundInfo(
        intl,
        currentGoal?.organizationUnitGoalsId ?? undefined,
        employee ?? undefined,
        goals,
        organization,
        northStars,
        employees?.organizationUnitEmployeeJoins,
        currentGoal
      );
      setChatDialogState((draft) => {
        draft.backgroundInfo = info.info;
        draft.hint = info.hint;
      });
    })();
    if (!successStory) {
      setChatDialogState((draft) => {
        draft.question = intl.formatMessage({
          id: "chat.prefilled.question.success.story",
        });
      });
    }
  }, [
    currentGoal,
    intl,
    currentGoal?.organizationUnitGoalsId,
    employee,
    goals,
    organization,
    northStars,
    employees?.organizationUnitEmployeeJoins,
    successStory,
    setChatDialogState
  ]);

  const resetState = () => {
    setEditSuccessStory(successStory || { ...defaultStory });
    setShowHelp(false);
    setSaving(false);
    setTaggedEmployees([]);
    setPreviewMedias([]);
    setRemovedAttachments([]);
    setError("");
    setSavingError("");
  };

  const handleEventTextChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setError("");
    setEditSuccessStory((draft) => {
      draft.name = event.target.value;
    });
  };

  const handleCancel = (event?: object, reason?: string) => {
    if (reason === "backdropClick") {
      // Don't do anything. Accidental click can't delete all the information.
      return;
    }

    resetState();
    onClose(false);
  };

  const handleSave = async () => {
    if (!editSuccessStory.name) {
      setError(intl.formatMessage({ id: "successstories.title.required" }));
      return;
    }
    try {
      setSaving(true);
      // Save attachments to S3
      const newAttachments = await saveAttachments(
        previewMedias,
        AttachmentOwner.SuccessStory
      );

      const employeeGoal = isEmployeeGoal(goals, goalId);
      if (!successStory) {
        await addSuccessStoryDb(
          {
            ...editSuccessStory,
            goalSuccessStoriesId: goalId,
            creatorEmail: currentUser?.attributes.email,
            attachments: newAttachments,
          } as CreateSuccessStoryInput,
          taggedEmployees,
          employeeGoal,
          employees?.employees
        );
      } else {
        // Remove deleted attachments from S3
        const remainingAttachments = await deleteAttachments(
          removedAttachments,
          existingAttachments
        );

        await updateSuccessStoryDb(
          {
            ...editSuccessStory,
            attachments: remainingAttachments.concat(newAttachments),
          } as UpdateSuccessStoryInput,
          successStory,
          taggedEmployees
        );
      }

      resetState();
      onClose(successStory == null);
    } catch (error: any) {
      log(`Add/Edit SuccessStory: ${error.message}`);
      setSaving(false);
      setSavingError(intl.formatMessage({ id: "general.save.error" }));
    }
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      fullWidth={true}
      maxWidth="lg"
      disableRestoreFocus
      onKeyUp={(e) => {
        if (e.key === "Enter") handleSave();
      }}
    >
      <DialogTabTitle
        tabValue={tabValue}
        setTabValue={setTabValue}
        dialogTitle={intl.formatMessage({
          id: successStory ? "successstories.edit" : "successstories.add",
        })}
        handleToggleHelp={handleToggleHelp}
      />

      {/* Made it possible */}
      <DialogContent>
        <TabPanel value={tabValue} index={0}>
          <HelpCollapse
            showHelp={showHelp}
            helpText={intl.formatMessage({ id: "successstories.help.text" })}
          />
          <TaggedEmployees
            taggedEmployees={taggedEmployees}
            currentUser={currentUser}
            employeeJoins={successStory?.employeeJoins}
            employeeIdField={"employeeSuccessStoryEmployeeJoinsId"}
            inCreate={!successStory}
            setTaggedEmployees={setTaggedEmployees}
            label={getEventEmployeesTitle(intl, EventType.SUCCESS_STORY_ADDED)}
          />

          {/* Title */}
          <TextField
            autoFocus
            margin="dense"
            sx={{ marginTop: "6px" }}
            id="title"
            label={intl.formatMessage({
              id: "successstories.successstory.title",
            })}
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            helperText={error}
            error={error !== ""}
            value={editSuccessStory.name}
            onChange={handleEventTextChange}
          />

          <HandleAttachments
            existingAttachments={existingAttachments}
            previewMedias={previewMedias}
            setPreviewMedias={setPreviewMedias}
            removedAttachments={removedAttachments}
            setRemovedAttachments={setRemovedAttachments}
          />
          {savingError && <Alert severity="error">{savingError}</Alert>}
        </TabPanel>
        <TabPanel value={tabValue} index={1}>
          <DialogChat
            chatDialogState={chatDialogState}
            setChatDialogState={setChatDialogState}
          />
        </TabPanel>
      </DialogContent>

      <EditDialogActions
        saving={saving}
        onCancel={handleCancel}
        onSave={handleSave}
      />
    </Dialog>
  );
}
