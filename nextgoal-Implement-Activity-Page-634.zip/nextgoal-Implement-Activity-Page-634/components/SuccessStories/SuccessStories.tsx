import { useState, useRef } from "react";
import { Goal, SuccessStory } from "@/src/API";
import EditSuccessStory from "./EditSuccessStory";
import SuccessStoryItem from "./SuccessStoryItem";
import GTabPanel from "../Common/GTabPanel/GTabPanel";
import { AttachmentFile } from "@/lib/webAttachment";
import { deleteSuccessStoryDb } from "@/lib/webSuccessStories";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import { FormattedMessage, useIntl } from "react-intl";
import { useEvents } from "@/contexts/EventsContext";

interface SuccessStoriesProps {
  goal?: Goal | null;
  successStories?: (SuccessStory | null)[];
  canAdd?: boolean;
}

export default function SuccessStories({
  goal,
  successStories,
  canAdd = true,
}: SuccessStoriesProps) {
  const [addStory, setAddStory] = useState(false);
  const [editStory, setEditStory] = useState<SuccessStory | undefined>();
  const [deleteStory, setDeleteStory] = useState<SuccessStory | undefined>();
  const [deleteAttachments, setDeleteAttachments] = useState<
    AttachmentFile[] | undefined
  >();
  const [saving, setSaving] = useState(false);
  const topRef = useRef<HTMLDivElement | null>(null);
  const intl = useIntl();
  const events = useEvents()?.events;

  if (!goal && !successStories) {
    return (
      <div>
        <FormattedMessage id="successstories.error.getting.goal" />
      </div>
    );
  }
  const showSuccessStories = successStories
    ? successStories
    : goal?.successStories?.items || [];

  const resetState = () => {
    setAddStory(false);
    setEditStory(undefined);
    setDeleteStory(undefined);
    setDeleteAttachments(undefined);
    setSaving(false);
  };

  const handleAdd = () => {
    setAddStory(true);
  };

  const handleEdit = (successStory: SuccessStory) => {
    setEditStory(successStory);
  };

  const handleCloseEdit = (scrollToTop: Boolean) => {
    resetState();
    if (scrollToTop) {
      topRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleDelete = (
    successStory: SuccessStory,
    attachments?: AttachmentFile[]
  ) => {
    setDeleteStory(successStory);
    setDeleteAttachments(attachments || []);
  };

  const handleDeleteCancel = () => {
    setDeleteStory(undefined);
    setDeleteAttachments(undefined);
  };

  const handleDeleteConfirmed = async () => {
    if (!deleteStory) {
      return;
    }

    setSaving(true);
    await deleteSuccessStoryDb(deleteStory, deleteAttachments || [], events);
    resetState();
  };

  return (
    <>
      <div ref={topRef} style={{ paddingTop: "2px" }} />
      <GTabPanel onAdd={canAdd ? handleAdd : undefined}>
        {showSuccessStories.map((story) => (
          <SuccessStoryItem
            key={story?.id || "noSuccessStory"}
            story={story}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        ))}
      </GTabPanel>
      {(addStory || !!editStory) && (
        <EditSuccessStory
          key={editStory?.id || "noSuccessStory"}
          goalId={editStory ? editStory.goalSuccessStoriesId : goal?.id}
          successStory={editStory}
          open={addStory || !!editStory}
          onClose={handleCloseEdit}
        />
      )}
      {deleteStory && (
        <ConfirmationDialog
          title={intl.formatMessage({ id: "successstories.delete.caption" })}
          message={intl.formatMessage({
            id: "successstories.delete.confirmation",
          })}
          messageItem={deleteStory.name || ""}
          open={!!deleteStory}
          saving={saving}
          onCancel={handleDeleteCancel}
          onConfirm={handleDeleteConfirmed}
        />
      )}
    </>
  );
}
