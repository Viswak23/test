import { SuccessStory } from "@/src/API";
import { ListText } from "../Common/Texts/Texts";

interface SuccessStoryFeedDescriptionProps {
  story?: SuccessStory | null;
}

export default function SuccessStoryFeedDescription({
  story,
}: SuccessStoryFeedDescriptionProps) {
  return <ListText>{story?.name}</ListText>;
}
