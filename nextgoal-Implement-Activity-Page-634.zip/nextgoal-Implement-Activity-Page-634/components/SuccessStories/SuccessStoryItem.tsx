import { useMemo } from "react";
import { calculateDaysOfStatus } from "@/lib/time";
import { SuccessStory } from "@/src/API";
import FeedItem from "../Feeds/FeedItem";
import { AttachmentFile, useAttachmentUrls } from "@/lib/webAttachment";
import { EventType, getEventEmployeesTitle } from "@/lib/webEvents";
import { canDeleteDbItem } from "@/lib/webHelpers";
import { useIntl } from "react-intl";
import SuccessStoryFeedDescription from "./SuccessStoryFeedDescription";

interface SuccessStoryProps {
  story?: SuccessStory | null;
  onEdit?: (story: SuccessStory) => void;
  onDelete: (story: SuccessStory, attachments: AttachmentFile[]) => void;
}

export default function SuccessStoryItem({
  story,
  onEdit,
  onDelete,
}: SuccessStoryProps) {
  const rawAtachments = useMemo(
    () => (story ? (story?.attachments as string[]) : []),
    [story]
  );
  const attachments = useAttachmentUrls(rawAtachments as string[]);
  const intl = useIntl();

  if (!story) {
    return null;
  }

  const handleEdit = () => {
    if (onEdit && story) {
      onEdit(story);
    }
  };

  if (!story) {
    return null;
  }

  const handleDelete = () => {
    onDelete(story, attachments);
  };

  const timeSince = calculateDaysOfStatus(intl, story.createdAt);

  return (
    <FeedItem
      title={""}
      subheader={timeSince}
      description={<SuccessStoryFeedDescription story={story} />}
      creatorEmail={story.creatorEmail}
      taggedEmployeeJoins={story.employeeJoins}
      employeeIdField={"employeeSuccessStoryEmployeeJoinsId"}
      taggedEmployeesTitle={getEventEmployeesTitle(
        intl,
        EventType.SUCCESS_STORY_ADDED
      )}
      comments={story.comments?.items}
      attachments={attachments}
      currentGoalId={story?.goalSuccessStoriesId || undefined}
      successStoryId={story.id}
      onEdit={handleEdit}
      onDelete={handleDelete}
      deleteDisabled={!canDeleteDbItem(story)}
      tooltips={{
        editTooltip: intl.formatMessage({ id: "successstories.edit" }),
        deleteTooltip: intl.formatMessage({
          id: "successstories.delete.caption",
        }),
        deleteDisabledTooltip: intl.formatMessage({
          id: "successstories.delete.disabled.tooltip",
        }),
      }}
    />
  );
}
