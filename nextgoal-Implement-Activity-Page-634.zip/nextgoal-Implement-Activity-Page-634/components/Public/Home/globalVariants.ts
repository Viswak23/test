export const rightSideVariants = {
  hidden: {
    opacity: 0,
    x: 100,
  },
  visible: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.5,
      staggerChildren: 0.2,
    },
  },
};

export const leftSideVariants = {
  hidden: {
    opacity: 0,
    x: -100,
  },
  visible: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.5,
      staggerChildren: 0.5,
      //   delayChildren: 0.3,
    },
  },
};
export const leftToRightVariants = {
  hidden: {
    x: "100vw",
  },
  visible: {
    x: 0,
    transition: {
      duration: 0.5,
      type: "spring",
      stiffness: 100,
    },
  },
  exit: {
    x: "-100vw",
    transition: {
      duration: 0.5,
      type: "spring",
      stiffness: 150,
    },
  },
};

export const leftSideButtonChild = {
  hidden: {
    opacity: 0,
    x: -100,
  },
  visible: {
    opacity: 1,
    x: 0,
    transition: {
      duration: 0.5,
      type: "spring",
      stiffness: 120,
    },
  },
};

export const titleVariants = {
  hidden: {
    opacity: 0,
    y: 100,
  },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      ease: "easeOut",
      staggerChildren: 0.2,
      delayChildren: 0.3,
    },
  },
};

export const buttonHoverVariants = {
  hover: {
    scale: 1.1,
    transition: {
      duration: 0.3,
      type: "spring",
      stiffness: 500,
    },
  },
};

export const sliderVariants = {
  enter: {
    x: 1000,
    opacity: 0,
  },
  center: {
    x: 0,
    opacity: 1,
    transition: {
      duration: 1,
    },
  },
  exit: {
    x: -1000,
    opacity: 0,
    transition: {
      duration: 1,
    },
  },
};
