"use client";
import React from "react";
import Image from "next/image";
import { FormattedMessage } from "react-intl";
import { motion } from "framer-motion";
import {
  buttonHoverVariants,
  leftSideButtonChild,
  leftSideVariants,
  rightSideVariants,
} from "../globalVariants";

export default function WorkmateSection() {
  const handleScrollTo = (section: string) => {
    const element = document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };
  return (
    <div
      className="bg-gradient-to-tl from-cyan to-primary py-24 md:overflow-hidden"
      id="workmate-section"
    >
      <div className="container mx-auto flex items-center justify-between w-full lg:gap-24 md:gap-12">
        <motion.div
          variants={leftSideVariants}
          initial="hidden"
          whileInView={"visible"}
          viewport={{ once: true }}
        >
          <motion.h1
            variants={leftSideVariants}
            className="text-3xl lg:leading-[1.2] lg:text-5xl text-white md:text-4xl  font-bold"
          >
            <FormattedMessage id="public.landingpage.workmate.heading" />
          </motion.h1>
          <motion.p
            variants={leftSideVariants}
            className="text-white opacity-90 mt-8"
          >
            <FormattedMessage id="public.landingpage.workmate.subheading" />
          </motion.p>
          <motion.div variants={leftSideButtonChild}>
            <motion.button
              aria-label="get started"
              variants={buttonHoverVariants}
              whileHover={"hover"}
              onClick={() => handleScrollTo("contact-section")}
              className=" mt-16 bg-white text-primary shadow-2xl hover:shadow-primary  p-2 px-4 rounded-md  font-normal  h-12 "
            >
              <FormattedMessage id="public.landingpage.workmate.action.button" />
            </motion.button>
          </motion.div>
        </motion.div>
        <motion.div
          variants={rightSideVariants}
          initial="hidden"
          whileInView={"visible"}
          viewport={{ once: true }}
          className=" md:block hidden lg:min-w-[550px] md:min-w-[350px] lg:-mr-24 md:-mr-24"
        >
          <Image
            src={"/workmate.png"}
            width={800}
            height={800}
            alt="Workmate"
            className="-mr-6"
          />
        </motion.div>
      </div>
    </div>
  );
}
