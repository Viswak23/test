"use client";
import { Check } from "@mui/icons-material";
import React from "react";
import { cn } from "@/lib/utils";
import { FormattedMessage } from "react-intl";
import { motion } from "framer-motion";
import {
  buttonHoverVariants,
  leftSideVariants,
  rightSideVariants,
} from "../globalVariants";

interface PlanCardProps {
  title: string;
  price: string;
  description: string;
  features: string[];
}

export default function PlanCard({
  title,
  price,
  description,
  features,
}: PlanCardProps) {
  const handleScrollTo = (section: string) => {
    const element = document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };
  return (
    <motion.div
      variants={title == "Pro" ? leftSideVariants : rightSideVariants}
      initial="hidden"
      whileInView={"visible"}
      viewport={{ once: true }}
      className="md:w-1/2 w-full"
    >
      <div className="relative group h-full">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan to-primary rounded-lg blur opacity-25 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
        <div
          className={`bg-white  rounded-md p-5  flex flex-col justify-between relative h-full`}
        >
          <div>
            <div>
              <span
                className={cn(
                  `py-2 px-5 ${
                    title == "Pro"
                      ? "bg-violete text-white"
                      : "bg-transparent border rounded-lg border-violete text-violete"
                  }  rounded-lg`
                )}
              >
                {title}
              </span>
              <p className="text-gray text-sm mt-5">{description}</p>
              <p className="text-gray text-sm mt-5">
                <span className="text-2xl font-bold font-cabin text-violete">
                  {price}
                </span>{" "}
                {title == "Pro" ? (
                  <FormattedMessage id="public.pricing.plan.pro.price" />
                ) : (
                  ""
                )}
              </p>
            </div>
            <div className="bg-slate-200 h-[1px] w-full my-4"></div>
            <div>
              <ul className="text-gray text-sm pl-5 flex flex-col gap-3">
                {features.map((feature, index) => (
                  <li className="flex  gap-2 text-black" key={index}>
                    <span>
                      <Check className="text-violete font-black text-xl" />
                    </span>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <div>
            <div className="bg-slate-200 h-[1px] w-full my-2 mt-6"></div>
            <div className="">
              <motion.button
                aria-label="select plan"
                whileHover={{ backgroundColor: "#7e3af2" }}
                onClick={() => handleScrollTo("contact-section")}
                className="w-full h-12 focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5 mb-2 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-900"
              >
                {title == "Pro" ? (
                  <FormattedMessage id="public.pricing.plan.pro.get.started" />
                ) : (
                  <FormattedMessage id="public.pricing.plan.ultimate.contact.us" />
                )}
              </motion.button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
