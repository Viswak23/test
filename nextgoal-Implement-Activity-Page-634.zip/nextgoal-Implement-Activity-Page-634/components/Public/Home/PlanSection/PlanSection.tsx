"use client";
import React from "react";
import PlanCard from "./PlanCard";
import { FormattedMessage, useIntl } from "react-intl";
import { motion } from "framer-motion";
import { titleVariants } from "../globalVariants";

export default function PlanSection() {
  const intl = useIntl();
  const proPrice = "€17";
  const cardsContent = [
    {
      plan: intl.formatMessage({ id: "public.pricing.plan.pro.title" }),
      description: intl.formatMessage({
        id: "public.pricing.plan.pro.description",
      }),
      price: proPrice,
      features: [
        intl.formatMessage({ id: "public.pricing.plan.pro.feature.one" }),
        intl.formatMessage({ id: "public.pricing.plan.pro.feature.two" }),
        intl.formatMessage({ id: "public.pricing.plan.pro.feature.three" }),
        intl.formatMessage({ id: "public.pricing.plan.pro.feature.four" }),
      ],
    },
    {
      plan: intl.formatMessage({ id: "public.pricing.plan.ultimate.title" }),
      description: intl.formatMessage({
        id: "public.pricing.plan.ultimate.description",
      }),
      price: intl.formatMessage({
        id: "public.pricing.plan.ultimate.price",
      }),
      features: [
        intl.formatMessage({ id: "public.pricing.plan.ultimate.feature.one" }),
        intl.formatMessage({ id: "public.pricing.plan.ultimate.feature.two" }),
      ],
    },
  ];
  return (
    <div className="bg-white py-24">
      <div
        className="container  flex flex-col mx-auto items-center justify-center"
        id="plan-section"
      >
        <motion.div
          variants={titleVariants}
          initial="hidden"
          whileInView={"visible"}
          viewport={{ once: true }}
          className="text-center"
        >
          <motion.h1
            variants={titleVariants}
            className="md:text-4xl text-2xl font-normal text-black "
          >
            <FormattedMessage id="public.pricing.plan.title" />
          </motion.h1>
          <motion.p variants={titleVariants} className="text-gray mt-6">
            <FormattedMessage id="public.pricing.plan.subtitle" />
          </motion.p>
        </motion.div>
        <div className="mt-16 flex md:flex-row flex-col md:items-stretch items-center justify-center gap-6">
          {cardsContent.map((card, index) => {
            return (
              <PlanCard
                key={index}
                title={card.plan}
                description={card.description}
                price={card.price}
                features={card.features}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
}
