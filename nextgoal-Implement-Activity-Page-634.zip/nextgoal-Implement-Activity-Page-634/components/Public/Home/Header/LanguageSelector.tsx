import React, { useEffect, useRef, useState } from "react";
import { EN, ES, FI, SE } from "./Flags";
import { FormattedMessage, useIntl } from "react-intl";
import { setPreferredLanguage } from "@/lib/cookies";
import { usePathname, useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { LangDropdownVariants } from "./variants";

export default function LanguageSelector() {
  const pathname = usePathname();
  const router = useRouter();
  const [language, setLangauge] = useState("en");
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const intl = useIntl();
  const handleLanguageChange = (event: any) => {
    const lang = event.target.dataset.value;
    if (lang !== intl.locale) {
      setPreferredLanguage(lang);
      const newPath = pathname.replace(`/${intl.locale}`, `/${lang}`);
      router.push(newPath);
      router.refresh();
    }
    handleToggleMenu();
    setLangauge(event.target.dataset.value);
    setOpen(false);
  };
  const languages: any = {
    en: intl.formatMessage({ id: "general.language.english" }),
    fi: intl.formatMessage({ id: "general.language.finnish" }),
  };
  const handleToggleMenu = () => {
    setOpen(!open);
  };
  const getFlag = (language: string) => {
    switch (language) {
      case "en":
        return <EN />;
      case "fi":
        return <FI />;
      default:
        return <EN />;
    }
  };
  const getLanguageString = (language: string) => {
    return languages[language];
  };
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    };

    if (open) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [open]);
  useEffect(() => {
    setLangauge(intl.locale);
  }, [intl.locale]);
  return (
    <div className=" rounded-lg  lg:w-[115px] w-fit" ref={menuRef}>
      <div className="relative">
        <button
          aria-label="language"
          onClick={handleToggleMenu}
          className="flex items-center gap-4 md:w-full md:ml-5 hover:bg-slate-50 p-1 rounded-full md:rounded-md transition-all ease-in"
        >
          {getFlag(language)}
          <span className="md:block hidden ">
            {getLanguageString(language)}
          </span>
        </button>
        <AnimatePresence>
          {open && (
            <motion.ul
              variants={LangDropdownVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              className={
                "absolute z-30 lg:left-3 right-0 gap-4 bg-white rounded-lg mt-4 p-1 shadow-sm shadow-black drop-shadow-lg w-32 flex flex-col "
              }
            >
              {language != "en" && (
                <li
                  data-value="en"
                  className="hover:bg-secondary rounded-lg w-full flex px-2 py-1 cursor-pointer items-center gap-4 "
                  onClick={handleLanguageChange}
                >
                  {getFlag("en")}
                  <FormattedMessage id="general.language.english" />
                </li>
              )}

              {language != "fi" && (
                <li
                  data-value="fi"
                  className="hover:bg-secondary rounded-lg w-full flex px-2 py-1 cursor-pointer items-center gap-4"
                  onClick={handleLanguageChange}
                >
                  {getFlag("fi")}
                  <FormattedMessage id="general.language.finnish" />
                </li>
              )}
            </motion.ul>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
