import React from "react";

export function EN() {
  return (
    <svg
      className="w-7 h-7 rounded-full"
      aria-hidden="true"
      xmlns="http://www.w3.org/2000/svg"
      xmlnsXlink="http://www.w3.org/1999/xlink"
      viewBox="0 0 3900 3900"
    >
      <path fill="#b22234" d="M0 0h7410v3900H0z" />
      <path
        d="M0 450h7410m0 600H0m0 600h7410m0 600H0m0 600h7410m0 600H0"
        stroke="#fff"
        strokeWidth="300"
      />
      <path fill="#3c3b6e" d="M0 0h2964v2100H0z" />
      <g fill="#fff">
        <g id="d">
          <g id="c">
            <g id="e">
              <g id="b">
                <path
                  id="a"
                  d="M247 90l70.534 217.082-184.66-134.164h228.253L176.466 307.082z"
                />
                <use xlinkHref="#a" y="420" />
                <use xlinkHref="#a" y="840" />
                <use xlinkHref="#a" y="1260" />
              </g>
              <use xlinkHref="#a" y="1680" />
            </g>
            <use xlinkHref="#b" x="247" y="210" />
          </g>
          <use xlinkHref="#c" x="494" />
        </g>
        <use xlinkHref="#d" x="988" />
        <use xlinkHref="#c" x="1976" />
        <use xlinkHref="#e" x="2470" />
      </g>
    </svg>
  );
}

export function FI() {
  return (
    <svg
      className="w-7 h-7 rounded-full border border-slate-300"
      aria-hidden="true"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 48 48"
    >
      <rect fill="#fff" width="48" height="48" />
      <rect fill="#003580" x="13" y="0" width="8" height="48" />
      <rect fill="#003580" x="0" y="17" width="48" height="8" />
    </svg>
  );
}
export function SE() {
  return (
    <svg
      className="w-7 h-7 rounded-full "
      aria-hidden="true"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 48 48"
    >
      <rect fill="#005BAC" width="48" height="48" />
      <rect fill="#FFC72C" x="13" y="0" width="8" height="48" />
      <rect fill="#FFC72C" x="0" y="17" width="48" height="8" />
    </svg>
  );
}

export function ES() {
  return (
    <svg
      className="w-7 h-7 rounded-full shadow-sm shadow-black drop-shadow-sm"
      aria-hidden="true"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 48 48"
    >
      <rect fill="#C60B1E" width="48" height="48" />
      <rect fill="#FFC400" y="16" width="48" height="16" />
    </svg>
  );
}
