export const LangDropdownVariants = {
  hidden: {
    opacity: 0,
    y: -100,
  },
  visible: {
    opacity: 1,

    y: 0,
    transition: {
      type: "spring",
      stiffness: 250,
    },
  },
  exit: {
    opacity: 0,

    y: -100,
    transition: {},
  },
};

export const linkItemVariants = {
  hidden: { opacity: 0, y: "50%" },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      ease: "easeOut", // Add ease-out easing function
    },
  },
  exit: {
    opacity: 0,
    y: "50%",
    transition: {
      duration: 0.1,
      ease: "easeOut", // Add ease-out easing function
    },
  },
};

export const navLinksVariants = {
  hidden: {
    height: "0vh",
    paddingTop: 0,
  },
  visible: {
    height: "100vh",
    paddingTop: 64,
    transition: {
      duration: 0.5,
      staggerChildren: 0.1,
      delayChildren: 0.3,
    },
    when: "beforeChildren",
  },
  exit: {
    height: "0vh",
    paddingTop: 0,
    transition: {
      duration: 0.5,
      staggerChildren: 0.05,
      staggerDirection: -1,
    },
    when: "afterChildren",
  },
};
