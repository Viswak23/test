"use client";

import Link from "next/link";
import React, { useEffect, useState } from "react";
import Image from "next/image";
import logo from "@/public/logo.svg";
import { FormattedMessage, useIntl } from "react-intl";
import LanguageSelector from "./LanguageSelector";
import { cn } from "@/lib/utils";
import { getSelectedPage } from "@/lib/webNavigation";
import { usePathname } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { linkItemVariants, navLinksVariants } from "./variants";
import { leftSideVariants, rightSideVariants } from "../globalVariants";
import { useMobileView } from "@/hooks/useMobileView";

export default function Header() {
  const mobileView = useMobileView();
  const intl = useIntl();
  const headerLinks = [
    {
      title: intl.formatMessage({ id: "public.landingpage.header.link.home" }),
      url: "/",
    },
    {
      title: intl.formatMessage({ id: "public.landingpage.header.link.blog" }),
      url: "/blog",
    },
    {
      title: intl.formatMessage({
        id: "public.landingpage.header.link.register",
      }),
      url: "/register",
    },
    {
      title: intl.formatMessage({ id: "public.landingpage.header.link.login" }),
      url: "/login",
    },
  ];
  const pathname = usePathname();
  const selectedPage = getSelectedPage(pathname, intl.locale);

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleScrollTo = (section: string) => {
    const element = document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };
  return (
    <nav className="bg-white">
      <div className=" container flex flex-wrap md:flex-nowrap items-center justify-between mx-auto py-5">
        <motion.div
          variants={leftSideVariants}
          initial="hidden"
          animate="visible"
        >
          <Link
            href="https://workzep.com/"
            className="flex items-center space-x-3 rtl:space-x-reverse"
          >
            <Image src={logo} alt="Workzep Logo" width={32} height={32} />
            <span className="self-center text-2xl font-semibold whitespace-nowrap">
              <FormattedMessage id="public.landingpage.footer.workzep" />
            </span>
          </Link>
        </motion.div>
        <motion.div
          variants={rightSideVariants}
          initial="hidden"
          animate="visible"
          className="flex md:order-2 space-x-3 md:space-x-0 rtl:space-x-reverse items-center"
        >
          <button
            aria-label="book-a-demo"
            className=" lg:block hidden md:w-40 w-full place-self-end hover:text-white text-primary hover:bg-primary transition-all ease-in border rounded-lg border-primary p-3"
            onClick={() => handleScrollTo("contact-section")}
          >
            <FormattedMessage id="public.landingpage.cta.bookademo.button" />
          </button>
          <LanguageSelector />

          <button
            className="md:hidden group inline-flex w-12 h-12 text-primary bg-white text-center items-center justify-center rounded shadow-[0_1px_0_theme(colors.slate.950/.04),0_1px_2px_theme(colors.slate.950/.12),inset_0_-2px_0_theme(colors.slate.950/.04)] hover:shadow-[0_1px_0_theme(colors.slate.950/.04),0_4px_8px_theme(colors.slate.950/.12),inset_0_-2px_0_theme(colors.slate.950/.04)] transition"
            aria-pressed={mobileMenuOpen}
            onClick={() => setMobileMenuOpen((prev) => !prev)}
          >
            <span className="sr-only">
              <FormattedMessage id="public.landingpage.header.sr-only.menu" />
            </span>
            <svg
              className="w-6 h-6 fill-current pointer-events-none"
              viewBox="0 0 16 16"
              xmlns="http://www.w3.org/2000/svg"
            >
              <rect
                className="origin-center -translate-y-[5px] translate-x-[7px] transition-all duration-300 ease-[cubic-bezier(.5,.85,.25,1.1)] group-[[aria-pressed=true]]:translate-x-0 group-[[aria-pressed=true]]:translate-y-0 group-[[aria-pressed=true]]:rotate-[315deg]"
                y="7"
                width="9"
                height="2"
                rx="1"
              ></rect>
              <rect
                className="origin-center transition-all duration-300 ease-[cubic-bezier(.5,.85,.25,1.8)] group-[[aria-pressed=true]]:rotate-45"
                y="7"
                width="16"
                height="2"
                rx="1"
              ></rect>
              <rect
                className="origin-center translate-y-[5px] transition-all duration-300 ease-[cubic-bezier(.5,.85,.25,1.1)] group-[[aria-pressed=true]]:translate-y-0 group-[[aria-pressed=true]]:rotate-[135deg]"
                y="7"
                width="9"
                height="2"
                rx="1"
              ></rect>
            </svg>
          </button>
        </motion.div>
        {/* mobile menu */}

        {mobileView ? (
          <>
            <AnimatePresence>
              {mobileMenuOpen && (
                <div className={`items-center justify-between w-full`}>
                  <motion.ul
                    variants={navLinksVariants}
                    initial="hidden"
                    animate="visible"
                    exit="exit"
                    className="flex flex-col items-center font-medium mt-4 rtl:space-x-reverse z-20 absolute left-0 bg-white w-full gap-4"
                  >
                    {/* header links */}
                    {headerLinks.map((link, index) => (
                      <motion.li
                        variants={linkItemVariants}
                        key={index}
                        className="p-2 bg-white rounded-md"
                        whileHover={{ scale: 1.1, color: "#A426C7" }}
                      >
                        <Link
                          href={link.url}
                          onClick={() => setMobileMenuOpen(false)}
                          className={cn(
                            " relative w-full block ",
                            link.url === selectedPage ? "font-bold" : ""
                          )}
                        >
                          {link.title.toUpperCase()}
                        </Link>
                      </motion.li>
                    ))}
                    <motion.div variants={linkItemVariants}>
                      <button
                        onClick={() => handleScrollTo("contact-section")}
                        className=" w-40 place-self-end hover:text-white text-primary hover:bg-primary transition-all ease-in border rounded-lg border-primary p-3"
                      >
                        <FormattedMessage id="public.landingpage.cta.bookademo.button" />
                      </button>
                    </motion.div>
                  </motion.ul>
                </div>
              )}
            </AnimatePresence>
          </>
        ) : (
          <>
            {/* desktop menu */}
            <div className={`items-center justify-between flex w-auto order-1`}>
              <motion.ul className="flex font-medium p-0  space-x-4 lg:space-x-8 rtl:space-x-reverse flex-row mt-0 static z-50 left-0 bg-white w-full gap-0 ">
                {/* header links */}
                {headerLinks.map((link, index) => (
                  <motion.li
                    variants={linkItemVariants}
                    initial="hidden"
                    animate="visible"
                    whileHover={{ scale: 1.1, color: "#A426C7" }}
                    key={index}
                    className="p-2 hover:bg-secondary hover:bg-transparent bg-white rounded-md"
                  >
                    <Link
                      href={link.url}
                      onClick={() => setMobileMenuOpen(false)}
                      className={cn(
                        " relative w-full block ",
                        link.url === selectedPage ? "font-bold" : ""
                      )}
                    >
                      {link.title}
                    </Link>
                  </motion.li>
                ))}
              </motion.ul>
            </div>
          </>
        )}
      </div>
    </nav>
  );
}
