import React from "react";

interface Props {
  onChange: (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => void;
  value?: string;
  name?: string;
  type?: string;
  placeholder?: string;
  classname?: string;
  required?: boolean;
  label?: string;
  error?: string;
  touched?: boolean;
  icon?: any;
}
export default function InputField({
  onChange,
  value,
  name,
  type,
  placeholder,
  classname,
  required,
  label,
  error,
  touched,
  icon,
}: Props) {
  return (
    <div className="relative mt-4">
      <div className="absolute top-2 text-slate-400">{icon}</div>
      {type == "textarea" ? (
        <textarea
          value={value}
          onChange={onChange}
          name={name}
          placeholder={placeholder}
          className={`pt-3 pl-1 pb-1 w-full border-b border-slate-300 text-gray ${classname}`}
          required={required}
          rows={3}
        />
      ) : (
        <input
          type={type}
          value={value}
          onChange={onChange}
          name={name}
          placeholder={placeholder}
          className={`pt-3 pb-1  pl-8 border-b border-slate-300 text-gray w-full outline-none ${classname}`}
          required={required}
        />
      )}

      {error && touched && (
        <div className="text-red-400 mt-2 text-xs ">{error}</div>
      )}
    </div>
  );
}
