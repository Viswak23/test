"use client";
import React from "react";
import Form from "./Form";
import { FormattedMessage } from "react-intl";
import { motion } from "framer-motion";
import { leftSideVariants, rightSideVariants } from "../globalVariants";

export default function ContactSection() {
  return (
    <div className="bg-violete py-28" id="contact-section">
      <div className="container mx-auto flex md:flex-row flex-col md:items-start md:justify-between items-center md:text-start text-center md:gap-0 gap-8">
        <motion.div
          variants={leftSideVariants}
          initial="hidden"
          whileInView={"visible"}
          viewport={{ once: true }}
        >
          <motion.h2
            variants={leftSideVariants}
            className="text-3xl text-white font-bold"
          >
            <FormattedMessage id="public.landingpage.contact.section.header" />
          </motion.h2>
          <motion.p
            variants={leftSideVariants}
            className="text-lg font-normal text-white mt-6"
          >
            <FormattedMessage id="public.landingpage.contact.section.body" />
          </motion.p>
        </motion.div>
        <motion.div
          variants={rightSideVariants}
          initial="hidden"
          whileInView={"visible"}
          viewport={{ once: true }}
          className="md:ml-10 lg:min-w-[450px] md:w-[400px] w-full"
        >
          <Form />
        </motion.div>
      </div>
    </div>
  );
}
