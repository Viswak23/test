"use client";
import { FormikValues, useFormik } from "formik";
import React from "react";
import InputField from "./InputField";
import { Briefcase, Building2, MailIcon, Pencil, UserIcon } from "lucide-react";
import { getLocalizedPublicContactSchema } from "@/lib/webForms";
import { useIntl } from "react-intl";
import emailjs from "@emailjs/browser";
import { Alert } from "@mui/material";
import { log } from "@/lib/backend/actions/logger";
export default function Form() {
  const intl = useIntl();
  const [sending, setSending] = React.useState(false);
  const [error, setError] = React.useState("");
  const [success, setSuccess] = React.useState("");
  const handleSubmit = (values: FormikValues) => {
    setSending(true);
    setError("");

    const templateParams = {
      user_name: values.name,
      user_email: values.email,
      user_company: values.company,
      user_job: values.jobTitle,
      to_email: process.env.NEXT_PUBLIC_EMAILJS_CONTACTFORM_EMAIL || "",
    };

    emailjs
      .send(
        process.env.NEXT_PUBLIC_EMAILJS_CONTACTFORM_SERVICE_ID!,
        process.env.NEXT_PUBLIC_EMAILJS_CONTACTFORM_TEMPLATE_ID!,
        templateParams,
        process.env.NEXT_PUBLIC_EMAILJS_CONTACTFORM_PUBLIC_KEY
      )
      .then(
        (response) => {
          setSending(false);
          formik.resetForm();
          setSuccess(
            intl.formatMessage({ id: "public.contact.form.success.message" })
          );
        },
        (error) => {
          log("error in contact page: " + error.message);
          setError(
            intl.formatMessage({ id: "public.contact.form.error.message" })
          );
          setSending(false);
        }
      );
  };

  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      company: "",
      jobTitle: "",
    },
    onSubmit: handleSubmit,
    validationSchema: getLocalizedPublicContactSchema(intl),
  });
  return (
    <div className="px-8 py-4 bg-white rounded-xl ">
      <form onSubmit={formik.handleSubmit}>
        <InputField
          onChange={formik.handleChange}
          label="Name"
          name="name"
          type="text"
          value={formik.values.name}
          error={formik.errors.name}
          touched={formik.touched.name}
          placeholder={intl.formatMessage({
            id: "public.landingpage.contact.from.name",
          })}
          classname=""
          required={true}
          icon={<UserIcon />}
        />
        <InputField
          onChange={formik.handleChange}
          label="Email"
          name="email"
          type="Email Address"
          value={formik.values.email}
          error={formik.errors.email}
          touched={formik.touched.email}
          placeholder={intl.formatMessage({
            id: "public.landingpage.contact.from.email",
          })}
          classname=""
          required={true}
          icon={<MailIcon />}
        />
        <InputField
          onChange={formik.handleChange}
          label="Company"
          name="company"
          type="text"
          value={formik.values.company}
          error={formik.errors.company}
          touched={formik.touched.company}
          placeholder={intl.formatMessage({
            id: "public.landingpage.contact.from.company",
          })}
          classname=""
          required={true}
          icon={<Building2 />}
        />
        <InputField
          onChange={formik.handleChange}
          label="Job Title"
          name="jobTitle"
          type="text"
          value={formik.values.jobTitle}
          error={formik.errors.jobTitle}
          touched={formik.touched.jobTitle}
          placeholder={intl.formatMessage({
            id: "public.landingpage.contact.from.job",
          })}
          classname="mb-4"
          required={true}
          icon={<Briefcase />}
        />
        <button
          aria-label="Send"
          disabled={sending}
          type="submit"
          className="w-full h-12 focus:outline-none text-white bg-purple-700 hover:bg-purple-800 focus:ring-4 focus:ring-purple-300 font-medium rounded-lg text-sm px-5 py-2.5"
        >
          {intl.formatMessage({
            id: "public.landingpage.contact.from.send",
          })}
        </button>
      </form>
      {success && (
        <Alert severity="success" className="mt-5">
          {success}
        </Alert>
      )}
      {error && (
        <Alert severity="error" className="mt-5">
          {error}
        </Alert>
      )}
    </div>
  );
}
