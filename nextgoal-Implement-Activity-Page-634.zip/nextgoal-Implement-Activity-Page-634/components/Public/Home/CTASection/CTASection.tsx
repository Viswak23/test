"use client";
import React from "react";
import Image from "next/image";
import { FormattedMessage } from "react-intl";
import { motion } from "framer-motion";
import {
  buttonHoverVariants,
  leftSideButtonChild,
  leftSideVariants,
  rightSideVariants,
} from "../globalVariants";

export default function CTASection() {
  const handleScrollTo = (section: string) => {
    const element = document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };
  return (
    <div
      className="bg-gradient-to-tr from-cyan to-primary md:py-12 py-24 md:overflow-hidden"
      id="cta-section"
    >
      <div className="container mx-auto flex items-center justify-between">
        <motion.div
          variants={leftSideVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="sm:max-w-[600px] w-full"
        >
          <motion.h1 className="text-3xl lg:leading-[1.2] xl:text-6xl lg:text-5xl text-white md:text-4xl  font-bold break-words">
            <FormattedMessage id="public.landingpage.cta.section.header" />
          </motion.h1>
          <motion.div variants={leftSideButtonChild}>
            <motion.button
              aria-label="get started"
              variants={buttonHoverVariants}
              whileHover={"hover"}
              onClick={() => handleScrollTo("contact-section")}
              className=" mt-16 bg-white text-primary hover:bg-slate-50 hover:text-primary shadow-2xl hover:shadow-primary  p-2 px-4 rounded-md  font-normal   w-40 h-12 "
            >
              <FormattedMessage id="public.landingpage.cta.getstarted.button" />
            </motion.button>
          </motion.div>
        </motion.div>
        <motion.div
          variants={rightSideVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="lg:-mr-56 md:-mr-56 md:block hidden "
        >
          <Image
            src={"/CTAImg.png"}
            width={700}
            height={700}
            alt="cta picture"
          />
        </motion.div>
      </div>
    </div>
  );
}
