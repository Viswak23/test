import Image from "next/image";
import React from "react";

interface TestimonialCardProps {
  name: string;
  role: string;
  image: string;
  content: string;
}

export default function TestimonialCard({
  name,
  role,
  image,
  content,
}: TestimonialCardProps) {
  return (
    <div className="p-6 bg-slate-100 flex flex-col justify-between w-[350px] max-w-full relative rounded-2xl flex-shrink-0 px-8 py-6 md:w-[450px]">
      <div>
        <h1 className="font-limelight text-7xl font-black text-primary">“</h1>
        <p className="md:text-xl text-lg text-black">{content}</p>
      </div>
      <div className="flex items-start mt-8">
        <Image src={"/Generic avatar.png"} alt={name} width={50} height={50} />
        <div className="ml-6">
          <h3 className="font-bold text-black">{name}</h3>
          <p className="text-gray">{role}</p>
        </div>
      </div>
    </div>
  );
}
