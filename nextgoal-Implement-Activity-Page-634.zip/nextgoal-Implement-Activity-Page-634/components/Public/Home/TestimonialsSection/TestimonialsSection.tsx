"use client";
import React, { useRef } from "react";
import TestimonialCard from "./TestimonialCard";
import { FormattedMessage, useIntl } from "react-intl";
import { motion } from "framer-motion";
import { titleVariants } from "../globalVariants";

export default function TestimonialsSection() {
  const intl = useIntl();

  const testimonialsContent = [
    {
      name: intl.formatMessage({
        id: "public.landingpage.testimonials.first.name",
      }),
      role: intl.formatMessage({
        id: "public.landingpage.testimonials.first.role",
      }),
      testimonial: intl.formatMessage({
        id: "public.landingpage.testimonials.first.body",
      }),
      image: "/testimonial1.png",
    },
    {
      name: intl.formatMessage({
        id: "public.landingpage.testimonials.second.name",
      }),
      role: intl.formatMessage({
        id: "public.landingpage.testimonials.second.role",
      }),
      testimonial: intl.formatMessage({
        id: "public.landingpage.testimonials.second.body",
      }),
      image: "/testimonial2.png",
    },
    {
      name: intl.formatMessage({
        id: "public.landingpage.testimonials.third.name",
      }),
      role: intl.formatMessage({
        id: "public.landingpage.testimonials.third.role",
      }),
      testimonial: intl.formatMessage({
        id: "public.landingpage.testimonials.third.body",
      }),
      image: "/testimonial2.png",
    },
  ];

  const scrollerRef = useRef<HTMLUListElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  function addAnimation() {
    if (containerRef.current && scrollerRef.current) {
      const scrollerContent = Array.from(scrollerRef.current.children);

      scrollerContent.forEach((item) => {
        const duplicatedItem = item.cloneNode(true);
        if (scrollerRef.current) {
          scrollerRef.current.appendChild(duplicatedItem);
        }
      });
    }
  }
  React.useEffect(() => {
    addAnimation();
  }, []);
  return (
    <div
      className="bg-white md:py-24 p-16 overflow-hidden"
      id="testimonial-section"
    >
      <div className="flex flex-col mx-auto items-center justify-center">
        <motion.div
          variants={titleVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <h1 className="md:text-4xl text-2xl font-normal text-black ">
            <FormattedMessage id="public.landingpage.testimonials.title" />
          </h1>
        </motion.div>
        <div className="relative mt-16  ">
          {/* Testimonials */}
          <div
            ref={containerRef}
            className={
              "scroller relative z-20  max-w-7xl overflow-hidden  [mask-image:linear-gradient(to_right,transparent,white_20%,white_80%,transparent)]"
            }
          >
            <ul
              ref={scrollerRef}
              className={
                " flex  shrink-0 gap-4 py-4 w-max flex-nowrap animate-scroll hover:[animation-play-state:paused]"
              }
            >
              {testimonialsContent.map((test, index) => {
                return (
                  <TestimonialCard
                    key={index}
                    name={test.name}
                    role={test.role}
                    image={test.image}
                    content={test.testimonial}
                  />
                );
              })}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
