"use client";
import Link from "next/link";
import React from "react";
import { FormattedMessage } from "react-intl";
import EmailCollector from "../../Blog/EmailCollector";

const FooterLink = ({
  href,
  className,
  children,
}: {
  href: string;
  children: React.ReactNode;
  className?: string;
}) => {
  return (
    <Link
      href={href}
      className={`text-sm hover:text-white transition-all ease-in-out text-slate-300 block ${className}`}
    >
      {children}
    </Link>
  );
};

export default function Footer() {
  return (
    <div className="bg-violete py-10">
      <div className="container mx-auto">
        <div className="flex md:flex-row flex-col md:items-start items-center justify-between  md:gap-16 gap-8 md:text-start text-center">
          <div>
            <h2 className="text-xl text-white font-semibold">
              <FormattedMessage id="public.landingpage.footer.workzep" />
            </h2>
            <p className="text-slate-300 text-sm mt-3">
              <FormattedMessage id="public.landingpage.footer.description" />
            </p>
          </div>
          <div>
            <p className="text-white font-bold">
              <FormattedMessage id="public.landingpage.footer.contact" />
            </p>
            <FooterLink href={"#"} className="mt-4">
              <FormattedMessage id="public.landingpage.footer.email" />
            </FooterLink>
            <p className="text-slate-300 text-sm mt-2">
              <FormattedMessage id="public.landingpage.footer.address" />
            </p>
          </div>

          <div>
            <p className="text-white font-bold">
              <FormattedMessage id="public.landingpage.footer.stayup" />
            </p>
            <p className="text-slate-300 text-sm mt-2">
              <FormattedMessage id="public.landingpage.footer.subscribe" />
            </p>
            <div className="mt-4">
              <EmailCollector />
            </div>
          </div>
        </div>
        <div className="flex md:flex-row flex-col items-center  md:gap-16 gap-8 mt-20">
          <p className="text-sm text-slate-300 block">
            <FormattedMessage id="public.landingpage.footer.copywrite" />
          </p>
          <FooterLink href={"/terms-of-service"}>
            <FormattedMessage id="public.landingpage.footer.tos" />
          </FooterLink>
          <FooterLink href={"/privacy-policy"}>
            <FormattedMessage id="public.landingpage.footer.pp" />
          </FooterLink>
        </div>
      </div>
    </div>
  );
}
