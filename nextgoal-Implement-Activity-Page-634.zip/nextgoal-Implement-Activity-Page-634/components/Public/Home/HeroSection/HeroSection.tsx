"use client";
import React, { useState } from "react";
import Image from "next/image";
import { FormattedMessage } from "react-intl";
import { PlayArrow } from "@mui/icons-material";
import VideoPlayer from "./VideoPlayer";
import { AnimatePresence, motion } from "framer-motion";

import {
  leftSideVariants,
  rightSideVariants,
  leftSideButtonChild,
  buttonHoverVariants,
} from "../globalVariants";

export default function HeroSection() {
  const [playVideo, setPlayVideo] = useState(false);

  const handleScrollTo = (section: string) => {
    const element = document.getElementById(section);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };
  return (
    <section className="bg-secondary py-28 relative" id="hero-section">
      <AnimatePresence>
        {playVideo && (
          <div>
            <VideoPlayer onClosePlayer={() => setPlayVideo(false)} />
          </div>
        )}
      </AnimatePresence>
      <div className="container mx-auto flex justify-between items-center md:flex-row flex-col-reverse md:gap-0 gap-6">
        <motion.div
          className="flex flex-col items-start gap-5 md:max-w-[50%]"
          variants={leftSideVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {/* Hero Content */}
          <motion.h1
            variants={leftSideVariants}
            className="mb-4 text-2xl font-segoe  font-extrabold tracking-tight text-black  lg:text-4xl lg:leading-[46px]"
          >
            <FormattedMessage id="public.landingpage.hero.heading.one" />
            <FormattedMessage id="public.landingpage.hero.heading.two" />
          </motion.h1>
          <motion.p
            variants={leftSideVariants}
            className="mb-6 text-lg font-normal text-gray lg:text-xl"
          >
            <FormattedMessage id="public.landingpage.hero.body" />
          </motion.p>
          <motion.div variants={leftSideButtonChild}>
            <motion.button
              aria-label="book a demo"
              variants={buttonHoverVariants}
              whileHover="hover"
              className=" p-2 px-4 rounded-md  font-normal bg-primary  text-white  h-12 w-40 "
              onClick={() => handleScrollTo("contact-section")}
            >
              <FormattedMessage id="public.landingpage.cta.bookademo.button" />
            </motion.button>
          </motion.div>
        </motion.div>
        <motion.div
          viewport={{ once: true }}
          variants={rightSideVariants}
          initial="hidden"
          whileInView="visible"
          className="ml-6 relative md:min-w-[320px] min-w-full "
        >
          <motion.button
            variants={buttonHoverVariants}
            whileHover={"hover"}
            className="lg:p-4 p-3 absolute z-0 rounded-full bg-white  right-[49%] top-[34%] hover:bg-secondary"
            onClick={() => setPlayVideo(true)}
          >
            <PlayArrow className="text-primary rounded-lg w-[60px] h-[60px]" />
          </motion.button>
          <Image
            src={"/banner.png"}
            width={1000}
            height={1000}
            alt="Workzep banner"
            className=" w-full md:w-[400px] lg:w-[1000px]"
          />
        </motion.div>
      </div>
      {/* Video Player */}
    </section>
  );
}
