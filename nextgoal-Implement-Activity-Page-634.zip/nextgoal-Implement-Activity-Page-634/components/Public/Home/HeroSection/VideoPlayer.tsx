import { Close } from "@mui/icons-material";
import { motion } from "framer-motion";
import React from "react";
import { buttonHoverVariants, leftToRightVariants } from "../globalVariants";
import Slider from "./Slider";
export default function VideoPlayer({
  onClosePlayer,
}: {
  onClosePlayer: () => void;
}) {
  return (
    <motion.div
      initial={false}
      animate={{ backdropFilter: "blur(12px)" }}
      exit={{ backdropFilter: "blur(0px)" }}
      className="w-full h-full  absolute z-10 flex justify-center md:items-center top-0"
    >
      <motion.div
        variants={leftToRightVariants}
        initial="hidden"
        animate="visible"
        exit="exit"
        className="md:w-[60%] w-full h-fit md:mt-0 mt-32 mx-5 md:mx-auto flex md:items-center justify-center  md:p-12 p-6 backdrop-blur-md rounded-lg relative bg-primary bg-opacity-60"
      >
        <motion.button
          aria-label="play video"
          variants={buttonHoverVariants}
          whileHover={"hover"}
          className="hover:text-primary  absolute -top-4 -right-4 "
          onClick={onClosePlayer}
        >
          <Close className="w-[40px] h-[40px] bg-white rounded-full p-2" />
        </motion.button>
        {/* <ReactPlayer
          url="https://www.youtube.com/watch?v=dQw4w9WgXcQ"
          controls
          playing={true}
          width={"100%"}
        /> */}
        <Slider />
      </motion.div>
    </motion.div>
  );
}
