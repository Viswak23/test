import ContactSection from "./ContactSection/ContactSection";
import CTASection from "./CTASection/CTASection";
import FeatureSection from "./FeaturesSection/FeatureSection";
import GoUpButton from "./GoUpButton";
import HeroSection from "./HeroSection/HeroSection";
import PlanSection from "./PlanSection/PlanSection";
import TestimonialsSection from "./TestimonialsSection/TestimonialsSection";
import WorkmateSection from "./WorkmateSection/WorkmateSection";

export default function Home() {
  return (
    <div className="font-segoe overflow-hidden">
      <HeroSection />
      <FeatureSection />
      <CTASection />
      <TestimonialsSection />
      <WorkmateSection />
      <PlanSection />
      <ContactSection />
      <div className="md:h-0 h-[1px] bg-slate-300"></div>
      <GoUpButton />
    </div>
  );
}
