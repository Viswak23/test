"use client";
import React from "react";
import FeatureRow from "./FeatureRow";
import { FormattedMessage, useIntl } from "react-intl";
import { motion } from "framer-motion";
import { titleVariants } from "../globalVariants";
export default function FeatureSection() {
  const intl = useIntl();
  const featuresContent = [
    {
      title: intl.formatMessage({ id: "public.landingpage.feature.one.title" }),
      description: intl.formatMessage({
        id: "public.landingpage.feature.one.description",
      }),
      image: "/feature1.png",
      reverse: false,
    },
    {
      title: intl.formatMessage({ id: "public.landingpage.feature.two.title" }),
      description: intl.formatMessage({
        id: "public.landingpage.feature.two.description",
      }),
      image: "/feature2.png",
      reverse: true,
    },
    {
      title: intl.formatMessage({
        id: "public.landingpage.feature.three.title",
      }),
      description: intl.formatMessage({
        id: "public.landingpage.feature.three.description",
      }),
      image: "/feature3.png",
      reverse: false,
    },
  ];
  return (
    <div
      className="bg-white md:py-28 py-14 overflow-hidden"
      id="feature-section"
    >
      <div className="container mx-auto flex flex-col items-center ">
        <motion.div
          variants={titleVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <h1 className="font-normal md:text-4xl text-3xl text-black ">
            <FormattedMessage id="public.landingpage.features.header" />
          </h1>
        </motion.div>
        <div className="flex flex-col md:gap-56 gap-20 md:py-32  py-10 ">
          {featuresContent.map((feature, index) => (
            <FeatureRow
              key={index}
              title={feature.title}
              description={feature.description}
              image={feature.image}
              reverse={feature.reverse}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
