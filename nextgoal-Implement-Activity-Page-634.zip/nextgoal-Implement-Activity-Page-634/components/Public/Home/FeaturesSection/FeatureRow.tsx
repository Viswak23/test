import React from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { leftSideVariants, rightSideVariants } from "../globalVariants";

interface FeatureRowProps {
  title: string;
  description: string;
  image: string;
  reverse: boolean;
}

export default function FeatureRow({
  title,
  description,
  image,
  reverse,
}: FeatureRowProps) {
  return (
    <div
      className={`flex flex-col md:items-start items-center  md:text-start md:gap-0 gap-8  ${
        reverse == true ? "md:flex-row-reverse" : "md:flex-row"
      } `}
    >
      {/* row content */}
      <motion.div
        variants={reverse ? rightSideVariants : leftSideVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="lg:mt-24 md:w-3/4 w-full"
      >
        <motion.h2
          variants={reverse ? rightSideVariants : leftSideVariants}
          className="lg:text-4xl text-2xl text-black font-medium leading-snug"
        >
          {title}
        </motion.h2>
        <motion.p
          variants={reverse ? rightSideVariants : leftSideVariants}
          className="text-lg text-gray  ml-10 mt-4 leading-7"
        >
          {description} 
        </motion.p>
      </motion.div>
      {/* row picture */}
      <motion.div
        variants={reverse ? leftSideVariants : rightSideVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className=" lg:min-w-[600px] sm:min-w-[350px] xs:min-w-[250px] md:relative"
      >
        <div>
          <Image
            src={image}
            width={800}
            height={800}
            alt="feature one banner"
            className={`md:absolute   ${
              reverse == true
                ? "lg:-left-48 -left-24 "
                : "lg:-right-48 -right-24"
            }  lg:w-[800px] w-[400px]`}
          />
        </div>
      </motion.div>
    </div>
  );
}
