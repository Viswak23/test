"use client";
import { ArrowUpIcon } from "lucide-react";
import React, { useState } from "react";

export default function GoUpButton() {
  const [showUpButton, setShowUpButton] = useState(false);
  React.useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setShowUpButton(true);
      } else {
        setShowUpButton(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);
  return (
    <>
      {showUpButton && (
        <button
          className=" w-[50px] h-[50px] fixed top-[90vh] right-[2vw]  bg-primary z-50 rounded-full animate-bounce"
          onClick={() => {
            window.scrollTo({
              top: 0,
              behavior: "smooth",
            });
          }}
        >
          <ArrowUpIcon className="w-[80%] h-[80%] text-secondary font-bold mx-auto" />
        </button>
      )}
    </>
  );
}
