import "../Style/styles.css";
import React from "react";
import { FormattedMessage } from "react-intl";

export default function SlackIntegration() {
  return (
    <div className="md:py-24 py-24">
      <div className="container mx-auto">
        <div>
          <div data-custom-class="body">
            <div>
              <strong>
                <span style={{ fontSize: 26 }}>
                  <span data-custom-class="title">
                    <FormattedMessage id="documentations.slack.integration" />
                  </span>
                </span>
              </strong>
            </div>
            <div>
              <br />
            </div>
            <div
              className="MsoNormal"
              data-custom-class="subtitle"
              style={{ lineHeight: "1.5" }}
            >
              <strong>
                <FormattedMessage id="documentations.slack.last.updated" values={{ date: "September 27, 2024" }}/>
              </strong>
            </div>
            <div>
              <br />
            </div>
            <div style={{ lineHeight: "1.5" }}>
              <span data-custom-class="body_text">
                <FormattedMessage id="documentations.slack.intro" />
              </span>
              <br />
              <br />
              <span data-custom-class="body_text">
                <FormattedMessage id="documentations.slack.details" />
              </span>
              <ul style={{ marginLeft: "20px" }}>
                <li>
                  <span data-custom-class="body_text">
                    <FormattedMessage id="documentations.slack.notifications" />
                  </span>
                </li>
              </ul>
              <br />
              <span data-custom-class="body_text">
                <strong>
                  <FormattedMessage id="documentations.slack.steps" />
                </strong>
              </span>
              <ol style={{ marginLeft: "20px" }}>
                <li>
                  <span data-custom-class="body_text">
                    <FormattedMessage id="documentations.slack.step1" />
                  </span>
                </li>
                <li>
                  <span data-custom-class="body_text">
                    <FormattedMessage id="documentations.slack.step2" />
                  </span>
                </li>
                <li>
                  <span data-custom-class="body_text">
                    <FormattedMessage id="documentations.slack.step3" />
                  </span>
                </li>
                <li>
                  <span data-custom-class="body_text">
                    <FormattedMessage id="documentations.slack.step4" />
                  </span>
                </li>
                <li>
                  <span data-custom-class="body_text">
                    <FormattedMessage id="documentations.slack.step5" />
                  </span>
                </li>
              </ol>
              <br />
              <span data-custom-class="body_text">
                <FormattedMessage
                  id="documentations.slack.compliance"
                  values={{
                    privacyPolicy: (
                      <a href="/privacy-policy" data-custom-class="link">
                        <FormattedMessage id="documentations.slack.privacy.policy" />
                      </a>
                    ),
                    termsOfService: (
                      <a href="/terms-of-service" data-custom-class="link">
                        <FormattedMessage id="documentations.slack.terms.of.service" />
                      </a>
                    ),
                  }}
                />
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
