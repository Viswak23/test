import { Alert, Box, Button, Container } from "@mui/material";
import {
  PaymentElement,
  useElements,
  useStripe,
} from "@stripe/react-stripe-js";
import { StripeError } from "@stripe/stripe-js";
import React from "react";
import { UserDetails } from "./Register";
import { setupInitialEmployee } from "@/lib/webRegister";
import {
  cancelStripeSubscription,
  createStripeCustomer,
  deleteStripeCustomer,
} from "@/lib/webStripe";
import { createStripeSubscription } from "@/lib/backend/actions/registerServerActions";
import { CreateCompanyInput, CreateEmployeeInput } from "@/src/API";
import { addCompanyDb } from "@/lib/webCompany";
import dayjs from "dayjs";
import { FormattedMessage, useIntl } from "react-intl";
import { log } from "@/lib/backend/actions/logger";
import PageLoading from "@/components/Common/Loading/PageLoading";
import { ConfirmationDescription } from "@/components/Common/Texts/Texts";

interface CheckoutPageProps {
  handleNext: () => void;
  handleBack: () => void;
  userDetails: UserDetails;
  setConfirmationData: (data: any) => void;
}
export default function CheckoutForm({
  handleNext,
  handleBack,
  userDetails,
  setConfirmationData,
}: CheckoutPageProps) {
  const stripe = useStripe();
  const elements = useElements();
  const [errorMessage, setErrorMessage] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const intl = useIntl();

  const handleError = (error: StripeError | Error) => {
    log(`Create Subscription: ${error.message}`);
    setLoading(false);
    setErrorMessage(intl.formatMessage({ id: "general.save.error" }));
  };
  const handleSuccess = async () => {
    try {
      const userData = {
        name: userDetails.firstname + " " + userDetails.lastname,
        email: userDetails.email,
      };
      setConfirmationData(userData);
      handleNext();
    } catch (error: any) {
      handleError(error);
    }
  };
  const cleanUpStripe = async (customerId: string, subscriptionId: string) => {
    await deleteStripeCustomer(customerId);
    await cancelStripeSubscription(subscriptionId);
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!stripe || !elements) {
      // Stripe.js hasn't yet loaded.
      return;
    }
    try {
      setLoading(true);
      const { error: submitError } = await elements.submit();
      if (submitError) {
        handleError(submitError);
        return;
      }

      const { id: customerId } = await createStripeCustomer({
        name: `${userDetails.firstname} ${userDetails.lastname}`,
        email: userDetails.email,
      });

      const {
        id: subscriptionId,
        clientSecret,
        currentPeriodEnd,
      } = await createStripeSubscription(customerId);
      const companyId = userDetails.company.replaceAll(" ", "-");
      const newEmployee: CreateEmployeeInput = {
        companyId: companyId,
        name: userDetails.firstname + " " + userDetails.lastname,
        email: userDetails.email,
        creatorEmail: userDetails.email,
        disabled: false,
        isAdmin: true,
      };

      const ownerTag = await setupInitialEmployee(newEmployee);
      const newCompany: CreateCompanyInput = {
        companyId: companyId,
        owner: ownerTag,
        name: userDetails.company,
        creatorEmail: userDetails.email,
        isSubscribed: true,
        subscriptionId: subscriptionId,
        customerId: customerId,
        subscriptionExpireDate: dayjs(
          new Date(currentPeriodEnd * 1000)
        ).toISOString(),
      };

      await addCompanyDb(newCompany, false);
      // Confirm the PaymentIntent using the details collected by the Payment Element

      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        clientSecret,
        confirmParams: {
          return_url: "https://workzep.com",
        },
        redirect: "if_required", //only redirect when there is a third party auth process i.e Banking
      });

      if (error) {
        handleError(error);
        cleanUpStripe(customerId, subscriptionId);
      } else if (paymentIntent && paymentIntent.status === "succeeded") {
        handleSuccess();
      } else {
        cleanUpStripe(customerId, subscriptionId);
        setErrorMessage(
          intl.formatMessage({ id: "register.payment.failed.error" })
        );
      }
    } catch (error: any) {
      handleError(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container component="main" maxWidth="xs">
      <Box
        sx={{
          marginTop: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Box component="form" noValidate onSubmit={handleSubmit} sx={{ mt: 3 }}>
          <Box
            sx={{
              display: loading ? "none" : "block",
            }}
          >
            <PaymentElement />
            <Box
              sx={{
                display: "flex",
                flexDirection: "row-reverse",
                justifyContent: "",
                gap: 2,
              }}
            >
              <Button
                type="submit"
                variant="contained"
                sx={{ mt: 3, mb: 2, width: "50%" }}
                disabled={!stripe || loading}
              >
                <FormattedMessage id="general.next" />
              </Button>
              <Button
                variant="outlined"
                sx={{ mt: 3, mb: 2, width: "50%" }}
                onClick={handleBack}
                disabled={!stripe || loading}
              >
                <FormattedMessage id="general.previous" />
              </Button>
            </Box>
          </Box>
          {errorMessage && <Alert severity="error">{errorMessage}</Alert>}
          {loading && (
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              {/* Loading indicator */}
              <ConfirmationDescription sx={{ textAlign: "center" }}>
                <FormattedMessage id="register.loading.message" />
              </ConfirmationDescription>
              <PageLoading />
            </Box>
          )}
        </Box>
      </Box>
    </Container>
  );
}
