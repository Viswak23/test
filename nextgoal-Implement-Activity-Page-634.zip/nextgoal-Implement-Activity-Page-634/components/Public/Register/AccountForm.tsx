import * as React from "react";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Link from "next/link";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import Container from "@mui/material/Container";
import { FormikValues, useFormik } from "formik";
import { getLocalizedRegisterSchema } from "@/lib/webForms";
import { useIntl } from "react-intl";
import { getLinkWithLocale } from "@/lib/localisation";
import { FormattedMessage } from "react-intl";
import { Copyright } from "../../Common/Copyright";

import { UserDetails } from "./Register";
import { RegisterTitle } from "@/components/Common/Texts/Texts";

interface AccountFormProps {
  handleNext: () => void;
  userDetails: UserDetails;
  setUserDetails: (values: FormikValues) => void;
}

export default function AccountForm({
  handleNext,
  userDetails,
  setUserDetails,
}: AccountFormProps) {
  const intl = useIntl();
  const [loading, setLoading] = React.useState(false);
  const handleSubmit = async (values: FormikValues) => {
    setUserDetails({ ...values });
    handleNext();
    //Create Customer on stripe
  };
  const formik = useFormik({
    initialValues: {
      firstname: userDetails.firstname || "",
      lastname: userDetails.lastname || "",
      email: userDetails.email || "",
      company: userDetails.company || "",
      terms: false,
    },
    validationSchema: getLocalizedRegisterSchema(intl, setLoading),
    onSubmit: handleSubmit,
    enableReinitialize: true,
    validateOnChange: false,
    validateOnBlur: false,
  });

  return (
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      <Box
        sx={{
          marginTop: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Avatar sx={{ m: 1, bgcolor: "secondary.main" }}>
          <LockOutlinedIcon />
        </Avatar>
        <RegisterTitle>
          <FormattedMessage id="register.title" />
        </RegisterTitle>
        <Box
          component="form"
          noValidate
          onSubmit={formik.handleSubmit}
          sx={{ mt: 3 }}
        >
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                id="firstname"
                label={<FormattedMessage id="register.form.label.firstname" />}
                name="firstname"
                autoComplete="firstname"
                onChange={formik.handleChange}
                value={formik.values.firstname}
                error={
                  formik.touched.firstname && Boolean(formik.errors.firstname)
                }
                helperText={formik.touched.firstname && formik.errors.firstname}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                required
                fullWidth
                id="lastname"
                label={<FormattedMessage id="register.form.label.lastname" />}
                name="lastname"
                autoComplete="lastname"
                onChange={formik.handleChange}
                value={formik.values.lastname}
                error={
                  formik.touched.lastname && Boolean(formik.errors.lastname)
                }
                helperText={formik.touched.lastname && formik.errors.lastname}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                id="company"
                label={<FormattedMessage id="register.form.label.company" />}
                name="company"
                autoComplete="company"
                onChange={formik.handleChange}
                value={formik.values.company}
                error={formik.touched.company && Boolean(formik.errors.company)}
                helperText={formik.touched.company && formik.errors.company}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                id="email"
                label={<FormattedMessage id="register.form.label.email" />}
                name="email"
                autoComplete="email"
                onChange={formik.handleChange}
                value={formik.values.email}
                error={formik.touched.email && Boolean(formik.errors.email)}
                helperText={formik.touched.email && formik.errors.email}
              />
            </Grid>
            <Grid item xs={12}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={formik.values.terms}
                    onChange={formik.handleChange}
                    color="primary"
                    name="terms"
                    sx={{
                      color: formik.values.terms != true ? "red" : "",
                    }}
                  />
                }
                label={<FormattedMessage id="register.form.label.terms" />}
                required
                sx={{
                  color: formik.values.terms != true ? "red" : "",
                }}
              />
            </Grid>
          </Grid>
          <Box
            sx={{
              display: "flex",
              flexDirection: "row-reverse",
              justifyContent: "",
              gap: 2,
            }}
          >
            <Button
              type="submit"
              variant="contained"
              disabled={loading}
              sx={{ mt: 3, mb: 2 }}
              fullWidth
            >
              <FormattedMessage id="general.next" />
            </Button>
          </Box>
          <Grid container justifyContent="center">
            <Grid item>
              <Link href={getLinkWithLocale("/login", intl.locale)}>
                {<FormattedMessage id="register.form.label.signin" />}
              </Link>
            </Grid>
          </Grid>
        </Box>
      </Box>
      <Copyright sx={{ mt: 5 }} />
    </Container>
  );
}
