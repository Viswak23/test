import {
  ConfirmationDescription,
  ConfirmationTitle,
} from "@/components/Common/Texts/Texts";
import { getLinkWithLocale } from "@/lib/localisation";
import { MarkEmailRead, MessageOutlined } from "@mui/icons-material";
import { Button, Container, Typography, useTheme } from "@mui/material";
import { useRouter } from "next/navigation";
import React from "react";
import { FormattedMessage, useIntl } from "react-intl";

interface ConfirmationDataProps {
  confirmationData: {
    name: string;
    email: string;
  };
}
export default function Confirmation({
  confirmationData,
}: ConfirmationDataProps) {
  const theme = useTheme();
  const router = useRouter();
  const intl = useIntl();
  const handleRedirect = () => {
    router.replace(getLinkWithLocale("/login", intl.locale));
  };
  return (
    <Container component="main" sx={{ my: 10, textAlign: "center" }}>
      <MarkEmailRead
        sx={{ fontSize: "200px", color: theme.palette.primary.dark }}
      />
      <ConfirmationTitle>
        <FormattedMessage id="register.confirm.thankyou" />
        {", "}
        {confirmationData.name}
      </ConfirmationTitle>
      <ConfirmationDescription>
        <FormattedMessage
          id="register.confirm.message"
          values={{ email: confirmationData.email }}
        />
      </ConfirmationDescription>
      <Button
        variant="contained"
        onClick={handleRedirect}
        sx={{ marginY: "15px" }}
      >
        <FormattedMessage id="register.confirm.login.button" />
      </Button>
    </Container>
  );
}
