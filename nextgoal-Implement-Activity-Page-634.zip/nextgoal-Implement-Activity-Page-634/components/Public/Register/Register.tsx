"use client";
import * as React from "react";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import { Container } from "@mui/material";
import AccountForm from "./AccountForm";
import CheckoutForm from "./CheckoutForm";
import { FormikValues } from "formik";
import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import Confirmation from "./Confirmation";
import { stripeOptions } from "@/lib/webStripe";
import { redirect, useSearchParams } from "next/navigation";
import { useAuthenticator } from "@aws-amplify/ui-react";
import PageLoading from "@/components/Common/Loading/PageLoading";
import { Pages } from "@/lib/webNavigation";
const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_API_PUBLIC!);

export interface UserDetails {
  firstname: string;
  lastname: string;
  company: string;
  email: string;
  terms: boolean;
}
const steps = ["Account Details", "Payment Details", "Confirmation"];
export default function Register() {
  const authstatus = useAuthenticator((context) => [context.user]).authStatus;
  const [activeStep, setActiveStep] = React.useState(0);
  const searchParams = useSearchParams();
  const redirectedEmail = searchParams.get("email");
  const [userDetails, setUserDetails] = React.useState({
    firstname: "",
    lastname: "",
    email: redirectedEmail || "",
    company: "",
    terms: false,
  });
  const [confirmationData, setConfirmationData] = React.useState(null);
  const handleSetConfirmationData = (data: any) => {
    setConfirmationData(data);
  };
  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleSetUserDetails = (values: FormikValues) => {
    setUserDetails({
      firstname: values.firstname,
      lastname: values.lastname,
      company: values.company,
      email: values.email,
      terms: values.terms,
    });
  };

  const getStepContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <AccountForm
            handleNext={handleNext}
            userDetails={userDetails}
            setUserDetails={handleSetUserDetails}
          />
        );
      case 1:
        return (
          <CheckoutForm
            handleNext={handleNext}
            handleBack={handleBack}
            userDetails={userDetails}
            setConfirmationData={handleSetConfirmationData}
          />
        );
      case 2:
        if (!confirmationData) return;
        return <Confirmation confirmationData={confirmationData} />;
      default:
        throw new Error("Unknown step");
    }
  };
  //redirect user to main if already authenticated
  React.useEffect(() => {
    if (authstatus === "authenticated") {
      redirect(Pages.appDashboard);
    }
  }, [authstatus]);
  //render loading while user is being redirected
  if (authstatus === "authenticated") return <PageLoading />;

  return (
    //Elements is stripe's context Provider
    <Elements stripe={stripePromise} options={stripeOptions}>
      <Container maxWidth="md" sx={{ my: 10 }}>
        <Box sx={{ width: "100%" }}>
          <Stepper activeStep={activeStep}>
            {steps.map((label, index) => {
              const stepProps: { completed?: boolean } = {};
              const labelProps: {
                optional?: React.ReactNode;
              } = {};
              return (
                <Step key={label} {...stepProps}>
                  <StepLabel {...labelProps}>{label}</StepLabel>
                </Step>
              );
            })}
          </Stepper>
          {activeStep <= steps.length && (
            <React.Fragment>{getStepContent(activeStep)}</React.Fragment>
          )}
        </Box>
      </Container>
    </Elements>
  );
}
