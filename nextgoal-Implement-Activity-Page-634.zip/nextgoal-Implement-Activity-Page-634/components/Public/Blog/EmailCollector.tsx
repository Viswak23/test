"use client";
import { log } from "@/lib/backend/actions/logger";
import MailerLite from "@mailerlite/mailerlite-nodejs";
import { ArrowForward } from "@mui/icons-material";
import { Snackbar, Alert } from "@mui/material";
import React from "react";
import { useIntl } from "react-intl";
const mailerlite = new MailerLite({
  api_key: process.env.NEXT_PUBLIC_MAILERLITE_APIKEY!,
});

export default function EmailCollector() {
  const [email, setEmail] = React.useState("");
  const [error, setError] = React.useState("");
  const [success, setSuccess] = React.useState("");
  const intl = useIntl();
  const onSubmit = async () => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!email || !emailRegex.test(email)) {
      setError(
        intl.formatMessage({ id: "register.form.validation.email.invalid" })
      );
      return;
    }
    try {
      const params = {
        email: email,
      };
      await mailerlite.subscribers.createOrUpdate(params);
      setSuccess(
        intl.formatMessage({ id: "public.subscribe.form.success.message" })
      );
      setEmail("");
    } catch (e: any) {
      log("Error in the Email Collector: " + e.message);
      setError(intl.formatMessage({ id: "public.popup.email.alert.fail" }));
    }
  };
  return (
    <>
      {/* Email input and submit button */}
      <div className="relative">
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder={intl.formatMessage({
            id: "public.landingpage.footer.subscribe.form.email",
          })}
          className="py-2 px-4 rounded-md max-w-[350px] w-full outline-none  drop-shadow-xl "
        />
        <button onClick={onSubmit}>
          <ArrowForward className="text-primary absolute top-2 right-2 hover:bg-secondary rounded-md transition-all ease-in " />
        </button>
      </div>
      {error && (
        <Snackbar
          open={error.length > 0}
          autoHideDuration={5000}
          onClose={() => setError("")}
        >
          <Alert
            severity="error"
            onClose={() => setError("")}
            sx={{ width: "100%" }}
          >
            {error}
          </Alert>
        </Snackbar>
      )}
      {success && (
        <Snackbar
          anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
          open={success.length > 0}
          autoHideDuration={5000}
          onClose={() => setSuccess("")}
        >
          <Alert
            severity="success"
            onClose={() => setSuccess("")}
            sx={{ width: "100%" }}
          >
            {success}
          </Alert>
        </Snackbar>
      )}
    </>
  );
}
