"use client";
import React from "react";
import Header from "../Home/Header/Header";
import EmailCollector from "./EmailCollector";
import Footer from "../Home/Footer/Footer";
import { FormattedMessage } from "react-intl";
import { motion } from "framer-motion";
import { titleVariants } from "../Home/globalVariants";

export default function BlogPage() {
  return (
    <div className="bg-slate-50 font-segoe h-[80vh]">
      {/* Coming soon Title */}
      <motion.div
        variants={titleVariants}
        initial="hidden"
        whileInView={"visible"}
        viewport={{ once: true }}
        className=" container mx-auto flex flex-col justify-center items-center py-28 text-center"
      >
        <motion.h1
          variants={titleVariants}
          className="text-4xl md:text-5xl font-black bg-gradient-to-r from-primary to-cyan bg-clip-text text-transparent mb-6 p-2"
        >
          <FormattedMessage id="public.blog.comingsoon" />
        </motion.h1>
        <motion.p
          variants={titleVariants}
          className="text-gray md:w-1/2 w-full"
        >
          <FormattedMessage id="public.blog.description" />
        </motion.p>
        <motion.div variants={titleVariants} className="mt-10">
          <EmailCollector />
        </motion.div>
      </motion.div>
    </div>
  );
}
