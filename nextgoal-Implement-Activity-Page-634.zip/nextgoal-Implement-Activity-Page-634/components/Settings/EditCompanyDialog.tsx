import * as React from "react";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import { FormattedMessage, useIntl } from "react-intl";
import { Alert, Stack } from "@mui/material";
import { useSettings } from "@/contexts/SettingsInfo";
import { useEmployees } from "@/contexts/EmployeesContext";
import { log } from "@/lib/backend/actions/logger";
import { updateCompanyDb } from "@/lib/webCompany";
import { UpdateCompanyInput } from "@/src/API";
import EditButton from "../Common/Buttons/EditButton";
import { FormTitle } from "../Common/Texts/Texts";

const MIN_DESCRIPTION_LENGTH = 2;

export default function EditCompanyDialog() {
  const [open, setOpen] = React.useState(false);
  const { companyDetails } = useSettings()!;
  const [companyDescription, setCompanyDescription] = React.useState(
    companyDetails?.description || ""
  );

  const [error, setError] = React.useState({
    component: "",
    message: "",
  });
  const [saving, setSaving] = React.useState(false);
  const employees = useEmployees()?.employees;
  const intl = useIntl();

  const handleDescriptionChange = (event: any) => {
    const description = event.target.value;
    setCompanyDescription(description);
  };

  const handleError = (error: string, component: string) => {
    setError({
      component: component,
      message: error,
    });
    setSaving(false);
  };
  const handleSave = async () => {
    if (companyDescription.trim().length < MIN_DESCRIPTION_LENGTH) {
      handleError(
        intl.formatMessage({
          id: "settings.company.edit.description.min.error",
        }),
        "description"
      );
      return;
    }
    try {
      setSaving(true);
      const updatedCompany = {
        ...companyDetails,
        description: companyDescription,
      } as UpdateCompanyInput;
      await updateCompanyDb(updatedCompany);

      setOpen(false);
    } catch (error: any) {
      log(error);
      handleError(
        intl.formatMessage({ id: "settings.saving.error" }),
        "saving"
      );
    } finally {
      handleError("", "");
      setOpen(false);
    }
  };

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setError({ component: "", message: "" });
    setOpen(false);
  };

  return (
    <React.Fragment>
      <EditButton
        onClick={handleClickOpen}
        tooltip={intl.formatMessage({ id: "settings.company.edit.title" })}
        dataCy="edit-company-button"
      />
      {open && (
        <Dialog open={open} onClose={handleClose}>
          <DialogTitle>
            {/* The below div element is an alternative way to prevent the error "<h6> cannot be child of <h2>" */}
            <div>
              <FormTitle>
                <FormattedMessage id="settings.company.edit.title" />
              </FormTitle>
            </div>
          </DialogTitle>
          <DialogContent>
            <Stack
              mt={"16px"}
              direction={"row"}
              justifyContent={"space-between"}
              spacing={2}
            >
              <TextField
                sx={{ width: "60%" }}
                disabled
                label={<FormattedMessage id="settings.company.name" />}
                defaultValue={companyDetails?.name}
                variant="standard"
              />
              <TextField
                disabled
                label={<FormattedMessage id="settings.company.employees" />}
                defaultValue={employees?.length}
                variant="standard"
              />
            </Stack>
            <TextField
              error={error.component === "description"}
              label={<FormattedMessage id="settings.company.description" />}
              value={companyDescription}
              onChange={handleDescriptionChange}
              variant="standard"
              sx={{ width: "100%", mt: "16px" }}
              multiline
              helperText={
                <FormattedMessage id="settings.company.description.help" />
              }
            />
          </DialogContent>
          {error.component && <Alert severity="error">{error.message}</Alert>}
          <EditDialogActions
            saving={saving}
            onSave={handleSave}
            onCancel={handleClose}
          />
        </Dialog>
      )}
    </React.Fragment>
  );
}
