import { Stack, Button, Typography, Box } from "@mui/material";
import React, { useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import {
  HeadingCard,
  StrongText,
  LightText,
  SettingsParagraph,
} from "../Common/Texts/Texts";
import { useSettings } from "@/contexts/SettingsInfo";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import { createPortalSession } from "@/lib/webStripe";
import { getCompanyDb } from "@/lib/webCompany";
import ErrorSnackbar from "../Common/Message/ErrorSnackbar";
import { log } from "@/lib/backend/actions/logger";
import { getSubscriptionCurrency } from "@/lib/currency";

export default function BillingInfo() {
  const intl = useIntl();
  const [open, setOpen] = useState(false);
  const { billingDetails, subscriptionDetails } = useSettings()!;
  const [generating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleError = (message: any) => {
    setError(message);
  };
  const handleOpenEdit = () => {
    setOpen(true);
  };
  //rediret to customer portal
  const handleGenerate = async () => {
    try {
      setIsGenerating(true);
      const { customerId } = await getCompanyDb();
      const session = await createPortalSession(customerId);
      window.open(session.url);
      setOpen(false);
    } catch (error: any) {
      log(`Customer Portal: ${error.message}`);
      handleError(error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Stack gap={3}>
      <Stack direction={{ xs: "column", sm: "row" }} spacing={{ xs: 2, sm: 4 }}>
        <Stack
          direction={{ xs: "column", sm: "row" }}
          width={{ xs: "100%", sm: "30%" }}
        >
          <HeadingCard style={{ paddingLeft: "0px" }}>
            <FormattedMessage id="settings.billing.card.info.title" />
          </HeadingCard>
          <ConfirmationDialog
            title={intl.formatMessage({
              id: "settings.billing.confirm.title",
            })}
            message={intl.formatMessage({
              id: "settings.billing.confirm.message",
            })}
            messageItem=""
            open={open}
            saving={generating}
            onConfirm={handleGenerate}
            onCancel={() => setOpen(false)}
          />
        </Stack>
        <Stack spacing={1}>
          <Box>
            <LightText>
              <FormattedMessage id="settings.billing.card.info.name" />
            </LightText>
            <SettingsParagraph>{billingDetails?.name}</SettingsParagraph>
          </Box>
          <Box>
            <LightText>
              <FormattedMessage id="settings.billing.card.info.number" />
            </LightText>
            <SettingsParagraph>
              **** **** **** {billingDetails?.number}
            </SettingsParagraph>
          </Box>
          <Box>
            <LightText>
              <FormattedMessage id="settings.billing.card.info.expire" />
            </LightText>
            <SettingsParagraph>{billingDetails?.expire}</SettingsParagraph>
          </Box>
        </Stack>
      </Stack>
      <Stack direction={{ xs: "column", sm: "row" }} spacing={{ xs: 2, sm: 4 }}>
        <Stack width={{ xs: "100%", sm: "30%" }}>
          <HeadingCard style={{ paddingLeft: "0px" }}>
            <FormattedMessage id="settings.billing.subscription.title" />
          </HeadingCard>
        </Stack>
        <Stack spacing={1}>
          <Box>
            <LightText>
              <FormattedMessage id="settings.billing.subscription.status" />
            </LightText>

            <StrongText
              sx={{
                color:
                  subscriptionDetails?.status === "active" ? "green" : "orange",
              }}
            >
              {subscriptionDetails?.status}
            </StrongText>
          </Box>
          <Box>
            <LightText>
              <FormattedMessage id="settings.billing.subscription.next.billing" />
            </LightText>
            <SettingsParagraph>
              {subscriptionDetails?.nextBilling}
            </SettingsParagraph>
          </Box>
          <Box>
            <LightText>
              <FormattedMessage id="settings.billing.subscription.amount" />
            </LightText>
            <SettingsParagraph>
              {getSubscriptionCurrency(subscriptionDetails!, intl.locale)}
            </SettingsParagraph>
          </Box>
          <Box>
            <LightText>
              <FormattedMessage id="settings.billing.subscription.quantity" />
            </LightText>
            <SettingsParagraph>
              {"x"}
              {subscriptionDetails?.quantity}
            </SettingsParagraph>
          </Box>
          <Button
            onClick={handleOpenEdit}
            variant="outlined"
            sx={{ my: "10px", width: { xs: "100%", sm: "auto" } }}
          >
            <FormattedMessage id="general.edit" />
          </Button>
        </Stack>
      </Stack>
      <ErrorSnackbar error={error} setError={handleError} />
    </Stack>
  );
}
