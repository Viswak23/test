import { Stack, Box, Button } from "@mui/material";
import React, { useState, memo } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import {
  HeadingCard,
  LightText,
  SettingsParagraph,
} from "../Common/Texts/Texts";
import EditCompanyDialog from "./EditCompanyDialog";
import { useSettings } from "@/contexts/SettingsInfo";
import PageLoading from "../Common/Loading/PageLoading";
import { useEmployees } from "@/contexts/EmployeesContext";
import { useNorthStars } from "@/contexts/NorthStarsContext";
import NorthStarItem from "../NorthStars/NorthStarItem";
import { deleteNorthStarDb } from "@/lib/webNorthStars";
import { log } from "@/lib/backend/actions/logger";
import ErrorSnackbar from "../Common/Message/ErrorSnackbar";
import EditNorthStar from "../NorthStars/EditNorthStar";
import AddButton from "../Common/Buttons/AddButton";
import AddToSlackButton from "../Common/Buttons/AddToSlack";
export default memo(function CompanyTab() {
  const { companyDetails } = useSettings()!;
  const [addingNorthStar, setAddingNorthStar] = useState(false);
  const [error, setError] = useState<string | null>("");
  const intl = useIntl();
  const northStarsState = useNorthStars()!;

  const employeesData = useEmployees();
  const handleDelete = async (id: string) => {
    try {
      await deleteNorthStarDb(id);
    } catch (error: any) {
      log(error.message);
      setError(intl.formatMessage({ id: "general.save.error" }));
    }
  };

  const handleOpenAddNorthStar = () => {
    setAddingNorthStar(true);
  };
  const handleCloseAddNorthStar = () => {
    setAddingNorthStar(false);
  };
  if (!companyDetails) return <PageLoading />;

  return (
    <>
      <ErrorSnackbar error={error} setError={(message) => setError(message)} />
      <Stack spacing={3}>
        <Stack
          spacing={2}
          direction={{ xs: "column", sm: "row" }}
          gap={{ xs: 2, sm: 4 }}
        >
          <Stack
            minWidth={{ xs: "100%", sm: "30%" }}
            sx={{
              alignItems: "start",
              justifyContent: "space-between",
            }}
            direction={"row"}
          >
            <HeadingCard style={{ paddingLeft: "0px" }}>
              <FormattedMessage id="settings.company.info" />
            </HeadingCard>
            <EditCompanyDialog />
          </Stack>

          <Stack spacing={2}>
            <Box>
              <LightText>
                <FormattedMessage id="settings.company.name" />
              </LightText>
              <SettingsParagraph>{companyDetails.name}</SettingsParagraph>
            </Box>
            <Box>
              <LightText>
                <FormattedMessage id="settings.company.employees" />
              </LightText>
              <SettingsParagraph>
                {employeesData?.employees?.length}
              </SettingsParagraph>
            </Box>
            <Box width={{ xs: "100%", sm: "80%" }}>
              <LightText>
                <FormattedMessage id="settings.company.description" />
              </LightText>
              <SettingsParagraph
                sx={{
                  wordBreak: "break-word",
                }}
              >
                {companyDetails?.description?.length! > 0 ? (
                  companyDetails.description
                ) : (
                  <FormattedMessage id="settings.info.description.empty" />
                )}
              </SettingsParagraph>
            </Box>
          </Stack>
        </Stack>
        <Stack
          spacing={2}
          direction={{ xs: "column", sm: "row" }}
          gap={{ xs: 2, sm: 4 }}
        >
          <Stack
            minWidth={{ xs: "100%", sm: "30%" }}
            sx={{
              alignItems: "start",
              justifyContent: "space-between",
            }}
            direction={"row"}
          >
            <HeadingCard
              style={{ paddingLeft: "0px" }}
              sx={{
                display: "flex",
                alignItems: "start",
                justifyContent: "space-between",
              }}
            >
              <FormattedMessage id="settings.company.northstars" />
            </HeadingCard>
            <AddButton
              onClick={handleOpenAddNorthStar}
              tooltip={intl.formatMessage({ id: "northstars.add.caption" })}
              data-cy="add-northstar-button"
              sx={{
                padding: "4px",
              }}
            />
          </Stack>
          <Stack gap={3}>
            {northStarsState.northStars?.map((star) => (
              <NorthStarItem
                isEditable={true}
                key={star.id}
                northStar={star}
                onDelete={handleDelete}
                sx={{
                  marginLeft: "0px",
                  padding: "0px",
                }}
              />
            ))}
            {addingNorthStar && (
              <EditNorthStar
                open={addingNorthStar}
                onClose={handleCloseAddNorthStar}
              />
            )}
          </Stack>
        </Stack>
        <AddToSlackButton />
      </Stack>
    </>
  );
});
