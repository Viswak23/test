"use client";
import React, { useEffect, useState } from "react";
import { Tabs, Tab } from "@mui/material";
import { FormattedMessage, useIntl } from "react-intl";
import LocaleTab from "@/components/Settings/LocaleTab";
import { TabPanel } from "@/components/Settings/TabPanel";
import BillingTab from "@/components/Settings/BillingTab";
import { useSettingsDispatch } from "@/contexts/SettingsInfo";
import {
  getCustomerInfo,
  getPaymentMethodById,
  getSubscriptionInfo,
} from "@/lib/webStripe";
import { getCompanyDb } from "@/lib/webCompany";
import { isAdmin } from "@/lib/webHelpers";
import CompanyTab from "./CompanyTab";
import { useEmployees } from "@/contexts/EmployeesContext";
import { log } from "@/lib/backend/actions/logger";
import PageBackgroundPaper from "../Common/Layout/PageBackgroundPaper";
import { HeadingMain } from "../Common/Texts/Texts";

export default function SettingsPage() {
  const intl = useIntl();

  const [tabValue, setTabValue] = useState(0);
  const settingsDispatch = useSettingsDispatch()!;
  const employeesData = useEmployees();

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  useEffect(() => {
    const dispatchData = (type: string, payload: any) => {
      settingsDispatch({
        type,
        payload,
      });
    };

    const fetchData = async () => {
      try {
        const company = await getCompanyDb();
        const subscriptionInfo = await getSubscriptionInfo(
          company.subscriptionId
        );
        const subscription = {
          status: subscriptionInfo.status,
          nextBilling: new Date(
            subscriptionInfo.current_period_end * 1000
          ).toLocaleDateString(),
          amount: (subscriptionInfo.plan.amount / 100).toFixed(2),
          quantity: subscriptionInfo.items.data[0].quantity,
          subscriptionId: company.subscriptionId,
          customerId: company.customerId,
          currency: subscriptionInfo.plan.currency,
        };
        const { card } = await getPaymentMethodById(
          subscriptionInfo.default_payment_method
        );
        const { name } = await getCustomerInfo(company.customerId);
        const billingDetails = {
          name: name,
          number: card.last4,
          expire: `${card.exp_month}/${card.exp_year}`,
        };
        const companyInfo = {
          id: company?.id,
          owner: company?.owner,
          companyId: company?.companyId,
          name: company?.name,
          creatorEmail: company?.creatorEmail,
          isSubscribed: company?.isSubscribed,
          subscriptionId: company?.subscriptionId,
          customerId: company?.customerId,
          subscriptionExpireDate: company?.subscriptionExpireDate,
          description: company?.description,
        };
        dispatchData("set_subscription_details", subscription);
        dispatchData("set_billing_details", billingDetails);
        dispatchData("set_company_details", companyInfo);
      } catch (error: any) {
        log(error.message);
      }
    };
    fetchData();
  }, [settingsDispatch, employeesData?.employees]);

  return (
    <PageBackgroundPaper>
      <HeadingMain>
        <FormattedMessage id="general.settings" />
      </HeadingMain>
      {isAdmin() && (
        <Tabs value={tabValue} onChange={handleTabChange} centered>
          <Tab label={intl.formatMessage({ id: "settings.preferences" })} />
          <Tab label={intl.formatMessage({ id: "settings.billing" })} />
          <Tab label={intl.formatMessage({ id: "settings.company" })} />
        </Tabs>
      )}
      <TabPanel value={tabValue} index={0}>
        <LocaleTab />
      </TabPanel>
      {isAdmin() && (
        <>
          <TabPanel value={tabValue} index={1}>
            <BillingTab />
          </TabPanel>
          <TabPanel value={tabValue} index={2}>
            <CompanyTab />
          </TabPanel>
        </>
      )}
    </PageBackgroundPaper>
  );
}
