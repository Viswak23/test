import {
  FormControl,
  FormLabel,
  Select,
  MenuItem,
  Button,
  Box,
  Stack,
  TextField,
} from "@mui/material";
import { usePathname, useRouter } from "next/navigation";
import React, { useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import ErrorSnackbar from "../Common/Message/ErrorSnackbar";
import { log } from "@/lib/backend/actions/logger";
import { DetailsLabel, DetailsText, HeadingCard } from "../Common/Texts/Texts";
import { useSettings, useSettingsDispatch } from "@/contexts/SettingsInfo";
import { SupportedLanguages, SupportedLocales } from "@/lib/localisation";
import { getLanguageEnum, updateEmployeeDb } from "@/lib/webEmployee";
import { setPreferredLanguage } from "@/lib/cookies";

export default function LocaleTab() {
  const intl = useIntl();
  const dbUser = useSettings()?.dbUser;
  const pathname = usePathname();
  const router = useRouter();
  const currentLanguage =
    dbUser?.language || getLanguageEnum(intl.locale) || SupportedLanguages.EN;
  const [language, setLanguage] = useState<string>(currentLanguage);
  let currentLocale = dbUser?.locale;
  if (currentLocale == null) {
    currentLocale =
      intl.locale === "fi" ? SupportedLocales.FI : SupportedLocales.ENUS;
  }
  const [locale, setLocale] = useState<string>(currentLocale);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState<boolean>(false);
  const [career, setCareer] = useState<string>(dbUser?.career ?? "");
  const [interest, setInterest] = useState<string>(dbUser?.interest ?? "");
  const changeLanguage = () => {
    if (language !== intl.locale) {
      setPreferredLanguage(language);
      const newPath = pathname.replace(`/${intl.locale}`, `/${language}`);
      router.push(newPath);
      router.refresh();
    }
  };

  const handleLanguageChange = (value: string) => {
    setLanguage(value);
  };

  const handleLocaleChange = (value: string) => {
    setLocale(value);
  };

  const handleInterestChange = (value: string) => {
    setInterest(value);
  };

  const handleCareerChange = (value: string) => {
    setCareer(value);
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      if (!dbUser) {
        throw Error(intl.formatMessage({ id: "general.save.error" }));
      }
      const updatedUser = {
        ...dbUser,
        language: language,
        locale: locale,
        career: career,
        interest: interest,
      };
      await updateEmployeeDb(updatedUser);
      changeLanguage();
    } catch (error: any) {
      log(`Update Preferences: ${error.message}`);
      setError(intl.formatMessage({ id: "settings.saving.error" }));
    } finally {
      setSaving(false);
    }
  };

  const getFormattedDate = (date: Date) => {
    switch (locale) {
      case SupportedLocales.FI:
        return new Intl.DateTimeFormat("fi-FI").format(date);
      case SupportedLocales.ENGB:
        return new Intl.DateTimeFormat("en-GB").format(date);
      case SupportedLocales.ENUS:
      default:
        return new Intl.DateTimeFormat("en-US").format(date);
    }
  };

  const getFormattedTime = (date: Date) => {
    switch (locale) {
      case SupportedLocales.FI:
        return new Intl.DateTimeFormat("fi-FI", { timeStyle: "short" }).format(
          date
        );
      case SupportedLocales.ENGB:
        return new Intl.DateTimeFormat("en-GB", { timeStyle: "short" }).format(
          date
        );
      case SupportedLocales.ENUS:
      default:
        return new Intl.DateTimeFormat("en-US", { timeStyle: "short" }).format(
          date
        );
    }
  };

  return (
    <Stack
      direction="column"
      spacing={2}
      sx={{
        flexDirection: "column",
        alignItems: "center",
        paddingBottom: "12px",
      }}
    >
      <HeadingCard>
        {intl.formatMessage({ id: "settings.user.preferences" })}
      </HeadingCard>

      {/* Language */}
      <FormControl sx={{ width: "240px" }}>
        <FormLabel>{intl.formatMessage({ id: "settings.language" })}</FormLabel>
        <Select
          value={language}
          onChange={(e) => handleLanguageChange(e.target.value)}
        >
          <MenuItem value={SupportedLanguages.EN}>
            {intl.formatMessage({ id: "languages.en" })}
          </MenuItem>
          <MenuItem value={SupportedLanguages.FI}>
            {intl.formatMessage({ id: "languages.fi" })}
          </MenuItem>
        </Select>
      </FormControl>

      {/* Time formats */}
      <FormControl sx={{ width: "240px" }}>
        <FormLabel>{intl.formatMessage({ id: "settings.locale" })}</FormLabel>
        <Select
          value={locale}
          onChange={(e) => handleLocaleChange(e.target.value)}
        >
          <MenuItem value={SupportedLocales.ENUS}>
            {intl.formatMessage({ id: "settings.locale.en.us" })}
          </MenuItem>
          <MenuItem value={SupportedLocales.ENGB}>
            {intl.formatMessage({ id: "settings.locale.en.gb" })}
          </MenuItem>
          <MenuItem value={SupportedLocales.FI}>
            {intl.formatMessage({ id: "settings.locale.fi" })}
          </MenuItem>
        </Select>
      </FormControl>

      <Box
        sx={{
          width: "240px",
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-start",
        }}
      >
        {/* Time */}
        <DetailsLabel>
          <FormattedMessage id="settings.time.format" />
        </DetailsLabel>
        <DetailsText>{getFormattedDate(new Date())}</DetailsText>

        {/* Date */}
        <DetailsLabel sx={{ paddingTop: "12px" }}>
          <FormattedMessage id="settings.date.format" />
        </DetailsLabel>
        <DetailsText>{getFormattedTime(new Date())}</DetailsText>
      </Box>

      <Stack
        direction="column"
        spacing={2}
        sx={{
          width: "240px",
          alignItems: "flex-start",
        }}
      >
        {/* Career Expectation */}
        <TextField
          sx={{ marginTop: "12px" }}
          label={intl.formatMessage({ id: "settings.personal.career" })}
          value={career}
          onChange={(e) => handleCareerChange(e.target.value)}
          fullWidth
          multiline
          maxRows={3}
        />
        {/* Interest */}
        <TextField
          sx={{ marginTop: "12px" }}
          label={intl.formatMessage({ id: "settings.personal.interest" })}
          value={interest}
          onChange={(e) => handleInterestChange(e.target.value)}
          fullWidth
          multiline
          maxRows={3}
          helperText={<FormattedMessage id="settings.personal.caption" />}
        />
      </Stack>

      {/* Submit btn */}
      <Button
        variant="contained"
        color="primary"
        onClick={() => handleSave()}
        sx={{ width: "240px" }}
        disabled={saving}
      >
        {saving ? (
          <FormattedMessage id="general.saving" />
        ) : (
          intl.formatMessage({ id: "general.save" })
        )}
      </Button>
      {error && <ErrorSnackbar error={error} setError={setError} />}
    </Stack>
  );
}
