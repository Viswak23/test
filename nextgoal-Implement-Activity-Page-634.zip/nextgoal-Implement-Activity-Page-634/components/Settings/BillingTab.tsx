import React from "react";

import BillingInfo from "./BillingInfo";
import { useSettings } from "@/contexts/SettingsInfo";
import PageLoading from "../Common/Loading/PageLoading";

export default function BillingTab() {
  const { subscriptionDetails } = useSettings()!;

  if (subscriptionDetails === null) {
    return <PageLoading />;
  }
  return <BillingInfo />;
}
