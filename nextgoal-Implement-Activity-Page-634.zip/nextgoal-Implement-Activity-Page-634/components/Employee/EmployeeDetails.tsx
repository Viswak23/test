import { useState, useMemo } from "react";
import {
  DetailsLabel,
  EmailDetailsText,
  HeadingMain2,
} from "../Common/Texts/Texts";
import {
  Avatar,
  Box,
  IconButton,
  Stack,
  Tooltip,
  useTheme,
} from "@mui/material";
import { Edit } from "@mui/icons-material";
import EditEmployee from "./EditEmployee";
import {
  EmployeeWithAvatarUrl,
  useEmployees,
} from "@/contexts/EmployeesContext";
import { useOrganization } from "@/contexts/OrganizationContext";
import Breadcrumb, { BreadcrumbType } from "../Common/Breadcrumb/Breadcrumb";
import { useAuthContext } from "@/contexts/AuthContext";
import EmployeeTabs from "./EmployeeTabs";
import { useGoals } from "@/contexts/GoalsContext";
import { FormattedMessage, useIntl } from "react-intl";
import GridContainer from "../Common/Layout/GridContainer";
import PageBackgroundPaper from "../Common/Layout/PageBackgroundPaper";
import { hoverLighterToMain } from "@/config/styling";

interface EmployeeDetailsProps {
  employee: EmployeeWithAvatarUrl;
}

export default function EmployeeDetails({ employee }: EmployeeDetailsProps) {
  const [editAvatar, setEditAvatar] = useState(false);
  const employeeState = useEmployees();
  const goals = useGoals()?.goals;
  const organizationEmployeeJoins =
    employeeState?.organizationUnitEmployeeJoins;
  const organization = useOrganization()?.organization;
  const authUser = useAuthContext()?.currentUser;

  const ownDetails = authUser.attributes.email === employee?.email;

  const handleEditAvatar = () => {
    setEditAvatar(true);
  };

  const handleCloseEditAvatar = () => {
    setEditAvatar(false);
  };

  const employeeOrganizations = useMemo(() => {
    return organizationEmployeeJoins
      ?.filter((join) => join.employeeId === employee?.id)
      .map((join) =>
        organization?.find(
          (organization) => organization?.id === join?.organizationUnitId
        )
      );
  }, [employee, organizationEmployeeJoins, organization]);

  const [hovered, setHovered] = useState(false);
  const theme = useTheme();
  const intl = useIntl();
  const editLabel = intl.formatMessage({ id: "general.edit" });

  // EditAvatar uses resolvedavatarurl as a key while resolving avatar url is async and can change.
  // position: "relative" is needed for the edit button to be positioned correctly
  return (
    <PageBackgroundPaper
      style={{ position: "relative", margin: "0px 0 24px 0" }}
    >
      {/* The edit button */}
      {ownDetails && (
        <Tooltip title={<FormattedMessage id="general.edit" />}>
          <IconButton
            aria-label={editLabel}
            onClick={handleEditAvatar}
            onMouseEnter={() => setHovered(true)}
            onMouseLeave={() => setHovered(false)}
            sx={{
              position: "absolute",
              top: "90px",
              right: "24px",
              ...hoverLighterToMain(theme),
            }}
          >
            <Edit />
          </IconButton>
        </Tooltip>
      )}

      <Stack direction="column" spacing={1} whiteSpace={"normal"}>
        <Stack
          spacing={1}
          direction="row"
          alignItems={"center"}
          style={{ marginBottom: 0 }}
          sx={{ flexGrow: 1 }}
        >
          <Box flexGrow={1}>
            <Stack direction="column">
              <Avatar
                src={employee?.resolvedAvatarUrl}
                onClick={() => (ownDetails ? handleEditAvatar() : null)}
                style={{
                  margin: "20px auto", // centers the avatar WITH margins!
                  width: "100px",
                  height: "100px",
                  border: "1px solid",
                  borderColor: theme.palette.customColors?.lighterer,
                }}
                sx={
                  ownDetails
                    ? {
                        "&:hover": {
                          opacity: 0.8,
                          cursor: "pointer",
                        },
                      }
                    : {}
                }
              />
              <HeadingMain2 sx={{ paddingBottom: { md: "18px" } }}>
                {employee?.name || <FormattedMessage id="employee.not.found" />}
              </HeadingMain2>
              <GridContainer
                sx={{
                  alignItems: "center",
                  margin: "auto",
                }}
              >
                <EmailDetailsText>{employee?.email}</EmailDetailsText>
              </GridContainer>
            </Stack>
          </Box>
        </Stack>

        {/* Org. label & breadcrumb column */}
        <Stack direction="column" sx={{ justifyContent: "flex-start" }}>
          {/* First row for the label */}
          <GridContainer
            sx={{
              marginTop: "20px",
              justifyContent: "flex-start",
            }}
          >
            <DetailsLabel
              sx={{
                width: "140px",
                textAlign: "left",
                marginLeft: {
                  xs: "20px",
                  md: "50px",
                },
              }}
            >
              <FormattedMessage id="employees.organization.units" />
            </DetailsLabel>
          </GridContainer>

          {/* Second row for the Breadcrumb */}
          <Stack
            sx={{
              marginLeft: {
                xs: "20px",
                md: "50px",
              },
              alignItems: "flex-start",
            }}
          >
            {employeeOrganizations?.map((organization) => (
              <Breadcrumb
                key={organization?.id}
                organizationUnitId={organization?.id}
                showMainPage={false}
                showLastAsaLink={true}
                type={BreadcrumbType.LIST}
              />
            ))}
          </Stack>
        </Stack>

        <br />
        {employee && (
          <EmployeeTabs
            employee={employee}
            goals={goals}
            ownDetails={ownDetails}
          />
        )}
      </Stack>
      {ownDetails && (
        <EditEmployee
          key={`${employee?.resolvedAvatarUrl}`}
          employee={employee || undefined}
          open={editAvatar}
          onClose={handleCloseEditAvatar}
        />
      )}
    </PageBackgroundPaper>
  );
}
