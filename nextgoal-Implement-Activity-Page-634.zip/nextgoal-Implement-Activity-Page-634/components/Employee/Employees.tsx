import { useState, useMemo } from "react";
import {
  Alert,
  Button,
  List,
  ListItem,
  ListItemText,
  Stack,
  TextField,
  Tooltip,
} from "@mui/material";
import { HeadingMain } from "../Common/Texts/Texts";
import {
  EmployeeWithAvatarUrl,
  useEmployees,
} from "@/contexts/EmployeesContext";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import {
  deleteEmployeeDb,
  toggleAdminRole,
  toggleEmployeeDb,
} from "@/lib/webEmployee";
import { useGoals } from "@/contexts/GoalsContext";
import DeleteButton from "../Common/Buttons/DeleteButton";
import { isAdmin } from "@/lib/webHelpers";
import { FormattedMessage, useIntl } from "react-intl";
import AddEmployee from "./AddEmployee";
import { log } from "@/lib/backend/actions/logger";
import { useEvents } from "@/contexts/EventsContext";
import { updateSubscriptionQuantity } from "@/lib/webStripe";
import { getCompanyDb } from "@/lib/webCompany";
import PageBackgroundPaper from "../Common/Layout/PageBackgroundPaper";

export default function Employees() {
  const [search, setSearch] = useState("");
  const [addingEmployee, setAddingEmployee] = useState(false);
  const [deleteEmployee, setDeleteEmployee] = useState<
    EmployeeWithAvatarUrl | undefined
  >(undefined);
  const [toggleEmployee, setToggleEmployee] = useState<
    EmployeeWithAvatarUrl | undefined
  >(undefined);
  const [toggleAdminEmployee, setToggleAdminEmployee] = useState<
    EmployeeWithAvatarUrl | undefined
  >(undefined);
  const employeesState = useEmployees();
  const [saving, setSaving] = useState(false);
  const goals = useGoals()?.goals;
  const events = useEvents()?.events;
  const intl = useIntl();
  const [saveError, setSaveError] = useState("");

  const filteredEmployees = useMemo(() => {
    let employees = [...employeesState?.employees!];
    return employees
      ?.sort((a, b) => {
        return a.name.localeCompare(b.name);
      })
      .filter(
        (employee) =>
          employee.name.toLowerCase().includes(search.toLowerCase()) ||
          employee.email.toLowerCase().includes(search.toLowerCase())
      );
  }, [employeesState?.employees, search]);

  const resetState = () => {
    setAddingEmployee(false);
    setSaving(false);
    setDeleteEmployee(undefined);
    setToggleEmployee(undefined);
    setSaveError("");
  };

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(event.target.value);
  };

  const handleSearchKeyDown = (
    event: React.KeyboardEvent<HTMLInputElement>
  ) => {
    if (event.key === "Escape") {
      setSearch("");
    }
  };

  const handleAddEmployee = () => {
    setAddingEmployee(true);
  };

  const handleAddEmployeeClose = () => {
    resetState();
  };

  const handleSetDeleteEmployee = (employee: EmployeeWithAvatarUrl) => {
    setDeleteEmployee(employee);
  };

  const handleCancelDeleteEmployee = () => {
    setDeleteEmployee(undefined);
  };

  const handleConfirmDeleteEmployee = async () => {
    setSaving(true);
    try {
      await deleteEmployeeDb(
        intl,
        deleteEmployee,
        goals,
        events,
        employeesState?.organizationUnitEmployeeJoins
      );
      //if the employee is already disabled, that means we already decremented their subscription from the quantity when disabling them. thus no need to decrement again
      if (!deleteEmployee?.disabled) {
        const company = await getCompanyDb();
        await updateSubscriptionQuantity(company?.subscriptionId!, "decrement");
      }
    } catch (error: any) {
      log(`Delete Employee: ${error.message}`);
      setSaveError(String(error));
      resetState();
      setSaving(false);
    }
    resetState();
    setSaving(false);
  };

  const handleCancelToggleEmployee = () => {
    setToggleEmployee(undefined);
  };

  const handleConfirmToggleEmployee = async () => {
    const action = toggleEmployee?.disabled ? "increment" : "decrement";
    setSaving(true);
    try {
      await toggleEmployeeDb(toggleEmployee!);

      const company = await getCompanyDb();
      await updateSubscriptionQuantity(company?.subscriptionId!, action);
    } catch (error: any) {
      log(`Toggle Employee: ${error.message}`);
      resetState();
      setSaveError(error.message);
      setSaving(false);
    }
    resetState();
    setSaving(false);
  };

  const handleConfirmToggleAdminRole = async () => {
    setSaving(true);
    try {
      await toggleAdminRole(toggleAdminEmployee!, false);
    } catch (error: any) {
      log(`Toggle Admin Role: ${error.message}`);
      setSaveError(error.errors.message);
      setSaving(false);
    }
    setToggleAdminEmployee(undefined);
    setSaving(false);
  };

  const handleCancelToggleAdminRole = () => {
    setToggleAdminEmployee(undefined);
  };

  return (
    <PageBackgroundPaper>
      <HeadingMain>
        <FormattedMessage id="employees.title" />
      </HeadingMain>
      <TextField
        label={<FormattedMessage id="general.search" />}
        variant="outlined"
        style={{ marginTop: "1rem", marginBottom: "1rem" }}
        autoFocus
        value={search}
        onChange={handleSearchChange}
        onKeyDown={handleSearchKeyDown}
        sx={{ width: { xs: "100%", sm: "24rem" } }}
      />
      <List dense style={{ maxHeight: "400px", overflow: "auto" }}>
        {filteredEmployees?.map((employee) => (
          <ListItem
            key={employee.id}
            data-cy="employee-card"
            secondaryAction={
              <Stack direction={{ xs: "column", sm: "row" }}>
                {employee.isAdmin !== null && (
                  <Button
                    disabled={!isAdmin()}
                    variant="outlined"
                    data-cy={
                      employee.isAdmin ? "disable-admin" : "enable-admin"
                    }
                    onClick={() => setToggleAdminEmployee(employee)}
                  >
                    {employee.isAdmin ? (
                      <FormattedMessage id="employees.disable.admin" />
                    ) : (
                      <FormattedMessage id="employees.enable.admin" />
                    )}
                  </Button>
                )}
                <Button
                  disabled={!isAdmin()}
                  variant="outlined"
                  data-cy={
                    employee.disabled ? "enable-employee" : "disable-employee"
                  }
                  onClick={() => setToggleEmployee(employee)}
                  style={{
                    marginLeft: "0.5rem",
                    marginRight: "0.5 rem",
                  }}
                >
                  {employee.disabled ? (
                    <FormattedMessage id="employees.enable" />
                  ) : (
                    <FormattedMessage id="employees.disable" />
                  )}
                </Button>
                <DeleteButton
                  disabled={!isAdmin()}
                  onClick={() => handleSetDeleteEmployee(employee)}
                  tooltip={intl.formatMessage({
                    id: "employees.delete.caption",
                  })}
                  disabledTooltip={intl.formatMessage({
                    id: "employees.delete.disabled.tooltip",
                  })}
                  dataCy="delete-employee-button"
                />
              </Stack>
            }
          >
            {/* Style is trying to fix overflow in very small screen: https://stackoverflow.com/questions/76809844/mui-listitemtext-primary-text-overflow-the-listitems-secondary-action */}
            <ListItemText
              primaryTypographyProps={{
                paddingRight: 8,
              }}
              style={{ maxWidth: "fit-content", wordBreak: "break-all" }}
              primary={employee.name}
              secondary={employee.email}
            />
          </ListItem>
        ))}
      </List>
      {isAdmin() && (
        <Button
          variant="outlined"
          onClick={handleAddEmployee}
          data-cy="add-employee-button"
          sx={{marginTop: "8px"}}
        >
          <FormattedMessage id="employees.add" />
        </Button>
      )}
      {addingEmployee && (
        <AddEmployee open={addingEmployee} onClose={handleAddEmployeeClose} />
      )}
      {isAdmin() && deleteEmployee && (
        <ConfirmationDialog
          title={intl.formatMessage({ id: "employees.delete.caption" })}
          message={intl.formatMessage({ id: "employees.delete.confirmation" })}
          messageItem={deleteEmployee?.name || ""}
          open={deleteEmployee != null}
          saving={saving}
          onConfirm={handleConfirmDeleteEmployee}
          onCancel={handleCancelDeleteEmployee}
        />
      )}
      {isAdmin() && toggleEmployee && (
        <ConfirmationDialog
          title={intl.formatMessage({
            id: toggleEmployee.disabled
              ? "employees.enable.caption"
              : "employees.disable.caption",
          })}
          message={intl.formatMessage({
            id: toggleEmployee.disabled
              ? "employees.enable.confirmation"
              : "employees.disable.confirmation",
          })}
          messageItem={toggleEmployee?.name || ""}
          open={toggleEmployee != null}
          saving={saving}
          onConfirm={handleConfirmToggleEmployee}
          onCancel={handleCancelToggleEmployee}
        />
      )}
      {isAdmin() && toggleAdminEmployee && (
        <ConfirmationDialog
          title={intl.formatMessage({
            id: !toggleAdminEmployee.isAdmin
              ? "employees.enable.admin"
              : "employees.disable.admin",
          })}
          message={intl.formatMessage({
            id: !toggleAdminEmployee.isAdmin
              ? "employees.enable.admin.confirmation"
              : "employees.disable.admin.confirmation",
          })}
          messageItem={toggleAdminEmployee?.name || ""}
          open={toggleAdminEmployee != null}
          saving={saving}
          onConfirm={handleConfirmToggleAdminRole}
          onCancel={handleCancelToggleAdminRole}
        />
      )}
      {saveError && <Alert severity="error">{saveError}</Alert>}
    </PageBackgroundPaper>
  );
}
