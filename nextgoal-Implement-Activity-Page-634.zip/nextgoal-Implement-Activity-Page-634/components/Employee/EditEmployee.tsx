import { useRef, useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import Button from "@mui/material/Button";
import { saveAvatarImage, updateEmployeeDb } from "@/lib/webEmployee";
import { deleteAttachment } from "@/lib/webAttachment";
import { UpdateEmployeeInput, CreateEmployeeInput } from "@/src/API";
import { useImmer } from "use-immer";
import { useAuthStatus } from "@/lib/customHooks";
import { Alert, Avatar, Stack } from "@mui/material";
import { EmployeeWithAvatarUrl } from "@/contexts/EmployeesContext";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import { FormattedMessage, useIntl } from "react-intl";
import { log } from "@/lib/backend/actions/logger";
import { FormTitle } from "../Common/Texts/Texts";

interface EditEmployeeProps {
  employee?: EmployeeWithAvatarUrl;
  open: boolean;
  onClose: () => void;
}

export default function EditEmployee({
  employee,
  open,
  onClose,
}: EditEmployeeProps) {
  // Companyid is filled in webEmployee.ts when doing the mutation. Placeholder is used so that defaultInput can be used as an UpdateEmployeeInput.
  const defaultEmployee = {
    name: "",
    email: "",
    companyId: "placeholder",
    creatorEmail: "placeholder",
  };
  const [editEmployee, setEditEmployee] = useImmer<
    CreateEmployeeInput | UpdateEmployeeInput
  >(employee || { ...defaultEmployee });
  const [avatar, setAvatar] = useImmer<File | null>(null);
  const [previewAvatar, setPreviewAvatar] = useState(
    employee?.resolvedAvatarUrl
  );

  const [saving, setSaving] = useState(false);
  const [savingError, setSavingError] = useState("");

  const currentUser = useAuthStatus();
  const fileInput = useRef<HTMLInputElement>(null);
  const intl = useIntl();

  const resetStates = () => {
    setEditEmployee(employee || { ...defaultEmployee });
    setAvatar(null);
    setPreviewAvatar(employee?.resolvedAvatarUrl);
    setSaving(false);
    setSavingError("");
  };

  const handleCancel = () => {
    resetStates();
    onClose();
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      let avatarUrl = null;
      // If avatar has changed, upload it to S3 and get the url. New file uses the same name as the old one, so the old one is overwritten.
      if (avatar && employee?.id) {
        avatarUrl = await saveAvatarImage(avatar, employee?.id);
      }
      // If avatar has been removed, delete old photo from S3 and set avatarUrl to null.
      if (!previewAvatar && employee?.avatarUrl) {
        await deleteAttachment(employee.avatarUrl);
        avatarUrl = null;
      }
      await updateEmployeeDb({
        id: employee?.id,
        avatarUrl,
      } as UpdateEmployeeInput);
      resetStates();
      onClose();
    } catch (error: any) {
      log(`Edit Employee: ${error.message}`);
      setSaving(false);
      setSavingError(intl.formatMessage({ id: "general.save.error" }));
    }
  };

  const handleSaveAvatar = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    const target = e.target as HTMLInputElement;
    const file = target.files?.[0];
    if (!file) {
      return;
    }

    setAvatar(file);
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = () => {
      setPreviewAvatar(reader.result as string);
    };
  };

  const handleOpenFileInput = () => {
    fileInput.current?.click();
  };

  const handleRemoveAvatar = () => {
    setAvatar(null);
    setPreviewAvatar(undefined);
  };

  const dialogTitle = employee ? (
    <FormTitle>
      <FormattedMessage id="employees.edit.avatar" />
    </FormTitle>
  ) : (
    <FormTitle>
      <FormattedMessage id="employees.add" />
    </FormTitle>
  );

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      disableRestoreFocus
      onKeyUp={(e) => {
        if (e.key === "Enter") handleSave();
      }}
    >
      <DialogTitle>{dialogTitle}</DialogTitle>
      <DialogContent>
        <Stack direction="row" spacing={1}>
          {employee && currentUser?.attributes.email === employee.email && (
            <Stack direction="column" spacing={1} alignItems="center">
              <Avatar
                style={{ width: "120px", height: "120px" }}
                src={previewAvatar || undefined}
              />
              <input
                accept="image/*"
                id="icon-button-file"
                type="file"
                ref={fileInput}
                hidden={true}
                onChange={handleSaveAvatar}
              />
              <Stack
                direction="row"
                spacing={1}
                alignItems="center"
                style={{ marginTop: "12px" }}
              >
                <Button variant="outlined" onClick={handleOpenFileInput}>
                  {employee?.avatarUrl ? (
                    <FormattedMessage id="employees.change.photo" />
                  ) : (
                    <FormattedMessage id="employees.add.photo" />
                  )}
                </Button>
                <Button onClick={handleRemoveAvatar}>
                  <FormattedMessage id="employees.remove.photo" />
                </Button>
              </Stack>
            </Stack>
          )}
        </Stack>
        {savingError && <Alert severity="error">{savingError}</Alert>}
      </DialogContent>
      <EditDialogActions
        saving={saving}
        onSave={handleSave}
        onCancel={handleCancel}
      />
    </Dialog>
  );
}
