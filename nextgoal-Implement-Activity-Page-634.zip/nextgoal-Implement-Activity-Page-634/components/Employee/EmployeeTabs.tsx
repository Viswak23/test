import { useState, useMemo } from "react";
import { Employee, Goal, HelpRequest } from "@/src/API";
import { Tab, Tabs } from "@mui/material";
import RedFlags from "../RedFlags/RedFlags";
import { Flag } from "lucide-react";
import Contributions from "../Contributions/Contributions";
import HelpRequests from "../HelpRequests/HelpRequests";
import Ideas from "../Ideas/Ideas";
import SuccessStories from "../SuccessStories/SuccessStories";
import {
  getEmployeeSubItems,
  getOpenHelpRequestsForEmployee,
} from "@/lib/webEmployee";
import { FormattedMessage } from "react-intl";

enum TabIndex {
  MY_RED_FLAGS = 1,
  MY_OFFER_FOR_HELP = 2,
  MY_IDEAS = 3,
  MY_SUCCESS_STORIES = 4,
  MY_CONTRIBUTIONS = 5,
  OPEN_HELP_REQUESTS = 6,
}

interface EmployeeTabsProps {
  employee?: Employee | null;
  goals?: Goal[];
  ownDetails: boolean;
}

export default function EmployeeTabs({
  employee,
  goals,
  ownDetails,
}: EmployeeTabsProps) {
  const [selectedTab, setSelectedTab] = useState(TabIndex.MY_RED_FLAGS);
  // Get all the information from the goals list while that list is updated with websockets. We can't just fetch
  // the information in the page load.
  const employeeSubItems = useMemo(
    () => getEmployeeSubItems(employee, goals),
    [employee, goals]
  );
  const openHelpRequests = useMemo(() => {
    if (ownDetails) {
      return getOpenHelpRequestsForEmployee(employee, goals);
    }
    return {
      openHelpRequests: [] as HelpRequest[],
      notRelevantHelpRequests: [] as HelpRequest[],
    };
  }, [goals, employee, ownDetails]);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setSelectedTab(newValue);
  };

  if (!employee) {
    return (
      <div>
        <FormattedMessage id="employees.error.could.not.find" />
      </div>
    );
  }

  function getTabContext(tabIndex: number) {
    switch (tabIndex) {
      case TabIndex.MY_RED_FLAGS:
        return <RedFlags redFlags={employeeSubItems.redFlags} canAdd={false} />;
      case TabIndex.MY_OFFER_FOR_HELP:
        return (
          <HelpRequests
            helpRequests={employeeSubItems.offersForHelp}
            canAdd={false}
          />
        );
      case TabIndex.MY_IDEAS:
        return <Ideas ideas={employeeSubItems.ideas} canAdd={false} />;
      case TabIndex.MY_SUCCESS_STORIES:
        return (
          <SuccessStories
            successStories={employeeSubItems.successStories}
            canAdd={false}
          />
        );
      case TabIndex.MY_CONTRIBUTIONS:
        return (
          <Contributions
            contributions={employeeSubItems.contributions}
            canAdd={false}
          />
        );
      case TabIndex.OPEN_HELP_REQUESTS:
        return (
          <HelpRequests
            helpRequests={openHelpRequests?.openHelpRequests}
            notRelevantRequests={openHelpRequests?.notRelevantHelpRequests}
            showResolved={false}
            canHide={true}
          />
        );
      default:
        return <div>Unknown tab</div>;
    }
  }

  const notResolvedRedFlags = ["placeholder"];

  return (
    <>
      <Tabs
        value={selectedTab}
        onChange={handleTabChange}
        variant="scrollable"
        scrollButtons="auto"
        data-cy="goal-tabs"
      >
        <Tab
          value={TabIndex.MY_RED_FLAGS}
          label={<FormattedMessage id="redflags.employee.red.flags" />}
          icon={
            notResolvedRedFlags && notResolvedRedFlags.length > 0 ? (
              <Flag style={{ color: "red" }} />
            ) : undefined
          }
          iconPosition="start"
          data-cy="my-red-flags-tab"
        />
        <Tab
          value={TabIndex.MY_OFFER_FOR_HELP}
          label={
            <FormattedMessage id="helprequests.employee.offers.for.help" />
          }
          data-cy="my-offers-for-help-tab"
        />
        <Tab value={TabIndex.MY_IDEAS} label="Ideas" data-cy="ideas-tab" />
        <Tab
          value={TabIndex.MY_SUCCESS_STORIES}
          label={
            <FormattedMessage id="successstories.employee.success.stories" />
          }
          data-cy="my-success-stories-tab"
        />
        <Tab
          value={TabIndex.MY_CONTRIBUTIONS}
          label={<FormattedMessage id="contributions.employee.contributions" />}
          data-cy="my-contributions-tab"
        />
        {ownDetails && (
          <Tab
            value={TabIndex.OPEN_HELP_REQUESTS}
            label={
              <FormattedMessage
                id="helprequests.open.helprequests"
                values={{
                  count: openHelpRequests?.openHelpRequests?.length || 0,
                }}
              />
            }
            data-cy="open-help-requests-tab"
          />
        )}
      </Tabs>
      {getTabContext(selectedTab)}
    </>
  );
}
