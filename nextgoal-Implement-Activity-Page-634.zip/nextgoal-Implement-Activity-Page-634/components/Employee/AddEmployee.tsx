import {
  Alert,
  Box,
  Checkbox,
  Dialog,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  Stack,
  TextField,
} from "@mui/material";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import { FormattedMessage, useIntl } from "react-intl";
import { useImmer } from "use-immer";
import { CreateEmployeeInput, Employee } from "@/src/API";
import { useState } from "react";
import { useEmployees } from "@/contexts/EmployeesContext";
import { useAuthStatus } from "@/lib/customHooks";
import { addEmployeeDb, toggleAdminRole } from "@/lib/webEmployee";
import { updateSubscriptionQuantity } from "@/lib/webStripe";
import { getCompanyDb } from "@/lib/webCompany";
import { log } from "@/lib/backend/actions/logger";
import HelpButton from "../Common/Buttons/HelpButton";
import { FormTitle } from "../Common/Texts/Texts";
import HelpCollapse from "../Common/Dialog/HelpCollapse";
import { getLocalizedAddEmployeeSchema, validateEmail } from "@/lib/webForms";
import { FormikValues, useFormik } from "formik";

interface AddEmployeeProps {
  open: boolean;
  onClose: () => void;
}

export default function AddEmployee({ open, onClose }: AddEmployeeProps) {
  const [saving, setSaving] = useState(false);
  const [savingError, setSavingError] = useState("");
  const [showHelp, setShowHelp] = useState(false);

  const currentUser = useAuthStatus();
  const intl = useIntl();
  const handleSave = async (value: FormikValues) => {

    try {
      const newEmployee = {
        name: formik.values.name,
        email: formik.values.email,
        isAdmin: formik.values.isAdmin,
        companyId: "placeholder",
        creatorEmail: currentUser?.attributes.email,
        disabled: false,
      } as CreateEmployeeInput;
      setSaving(true);
      await addEmployeeDb(newEmployee);
      if (newEmployee.isAdmin) {
        await toggleAdminRole(newEmployee as Employee, true);
      }
      const company = await getCompanyDb();
      await updateSubscriptionQuantity(company?.subscriptionId!, "increment");
      resetStates();
      onClose();
    } catch (error: any) {
      log(`Add Employee: ${error.message}`);

      setSaving(false);
      setSavingError(intl.formatMessage({ id: "general.save.error" }));
    }
  };
  const formik = useFormik({
    initialValues: {
      name: "",
      email: "",
      isAdmin: false,
    },
    validationSchema: getLocalizedAddEmployeeSchema(intl),
    onSubmit: handleSave,
    enableReinitialize: true,
    validateOnBlur: false,
    validateOnChange: false,
  });

  const resetStates = () => {
    setSaving(false);
    setSavingError("");
    formik.resetForm();
  };

  const handleCancel = () => {
    resetStates();
    onClose();
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      fullWidth={true}
      maxWidth="lg"
      disableRestoreFocus
      onKeyUp={(e) => {
        if (e.key === "Enter") {
          formik.handleSubmit();
        }
      }}
    >
      <DialogTitle>
        <Stack direction="row" spacing={1} alignItems={"center"}>
          <FormTitle>
            <FormattedMessage id="employees.add" />
          </FormTitle>
          <HelpButton
            onClick={handleToggleHelp}
            data-cy="show-add-employee-help"
          />
        </Stack>
      </DialogTitle>
      <DialogContent>
        <HelpCollapse
          showHelp={showHelp}
          helpText={intl.formatMessage({ id: "employee.help.text" })}
        />
        <Stack direction="row" spacing={1}>
          <Box flexGrow={1} style={{ paddingRight: "24px" }}>
            <TextField
              autoFocus={true}
              margin="dense"
              id="name"
              label={<FormattedMessage id="employee.name" />}
              type="text"
              fullWidth
              variant="standard"
              autoComplete="off"
              data-cy="edit-employee-name-input"
              required
              helperText={formik.errors.name}
              error={formik.touched.name && Boolean(formik.errors.name)}
              value={formik.touched.name && formik.values.name}
              onChange={formik.handleChange}
            />
            <TextField
              margin="dense"
              id="email"
              label={<FormattedMessage id="employee.email" />}
              type="email"
              fullWidth
              variant="standard"
              autoComplete="off"
              data-cy="edit-employee-email-input"
              required
              helperText={formik.touched.email && formik.errors.email}
              error={formik.touched.email && Boolean(formik.errors.email)}
              value={formik.values.email}
              onChange={formik.handleChange}
            />
            <FormControlLabel
              control={
                <Checkbox
                  checked={formik.values.isAdmin}
                  onChange={(event) =>
                    formik.setFieldValue("isAdmin", event.target.checked)
                  }
                  name="isAdmin"
                />
              }
              label={<FormattedMessage id="employees.admin" />}
              labelPlacement="start"
            />
          </Box>
        </Stack>
        {savingError && <Alert severity="error">{savingError}</Alert>}
      </DialogContent>
      <EditDialogActions
        saving={saving}
        onSave={formik.handleSubmit}
        onCancel={handleCancel}
      />
    </Dialog>
  );
}
