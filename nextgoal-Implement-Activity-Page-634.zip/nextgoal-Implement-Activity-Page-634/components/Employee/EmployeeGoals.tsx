import React, { useMemo } from "react";
import { useOrganization } from "@/contexts/OrganizationContext";
import { useEmployees } from "@/contexts/EmployeesContext";
import EmployeeGoalList from "../GoalList/EmployeeGoalList";
import { Employee } from "@/src/API";

interface EmployeeGoalsProps {
  employee: Employee;
}

export default function EmployeeGoals({ employee }: EmployeeGoalsProps) {
  const employeeState = useEmployees();
  const organizationEmployeeJoins =
    employeeState?.organizationUnitEmployeeJoins;
  const organization = useOrganization()?.organization;

  const employeeOrganizations = useMemo(() => {
    return organizationEmployeeJoins
      ?.filter((join) => join.employeeId === employee?.id)
      .map((join) =>
        organization?.find(
          (organization) => organization?.id === join?.organizationUnitId
        )
      );
  }, [employee, organizationEmployeeJoins, organization]);

  if (!employee) return null;

  return (
    <>
      {employeeOrganizations?.map((organization) => {
        if (!organization) return null;
        return (
          <EmployeeGoalList
            key={organization?.id}
            employee={employee}
            employeeOrganizationUnit={organization}
          />
        );
      })}
      <EmployeeGoalList employee={employee} internalGoals />
    </>
  );
}
