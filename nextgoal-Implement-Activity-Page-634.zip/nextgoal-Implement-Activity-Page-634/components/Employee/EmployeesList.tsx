import { useMemo } from "react";
import { OrganizationUnit } from "@/src/API";
import { Avatar, Card, CardHeader, Grid, Stack, Tooltip } from "@mui/material";
import Link from "next/link";
import { Link as MUILink } from "@mui/material";
import { useEmployees } from "@/contexts/EmployeesContext";
import { FormattedMessage, useIntl } from "react-intl";
import { getLinkWithLocale } from "@/lib/localisation";
import { HeadingCard } from "../Common/Texts/Texts";

interface EmployeesListProps {
  organizationUnit?: OrganizationUnit;
}

export default function EmployeesList({
  organizationUnit,
}: EmployeesListProps) {
  const employeeState = useEmployees();
  const intl = useIntl();

  const employees = employeeState?.employees;
  const organizationEmployeeJoins =
    employeeState?.organizationUnitEmployeeJoins;

  const organizationUnitEmployees = useMemo(() => {
    return organizationEmployeeJoins
      ?.filter((join) => join.organizationUnitId === organizationUnit?.id)
      .map((join) =>
        employees?.find((employee) => employee?.id === join?.employeeId)
      );
  }, [employees, organizationEmployeeJoins, organizationUnit?.id]);

  if (!organizationUnitEmployees || organizationUnitEmployees.length === 0)
    return null;

  return (
    <Card
      sx={{ minWidth: { xs: "100%", md: "240px" } }}
      style={{ padding: "1.5rem" }}
    >
      <Stack direction="column" spacing={1} style={{ width: "100%" }}>
        <HeadingCard sx={{ paddingBottom: "18px" }}>
          <FormattedMessage id="employees.title" />
        </HeadingCard>
        <Stack
          direction="row"
          spacing={1}
          useFlexGap
          sx={{
            flexWrap: "wrap",
            padding: "0px 12px 0px 12px",
          }}
        >
          {organizationUnitEmployees?.map((employee) => (
            <MUILink
              key={employee?.id}
              underline="hover"
              color="inherit"
              href={getLinkWithLocale(
                "/employees/" + employee?.email,
                intl.locale
              )}
              locale={intl.locale}
              data-cy={`employee-link-${employee?.name}`}
              component={Link}
            >
              <Tooltip title={employee?.name} arrow>
                <Avatar src={employee?.resolvedAvatarUrl}></Avatar>
              </Tooltip>
            </MUILink>
          ))}
        </Stack>
      </Stack>
    </Card>
  );
}
