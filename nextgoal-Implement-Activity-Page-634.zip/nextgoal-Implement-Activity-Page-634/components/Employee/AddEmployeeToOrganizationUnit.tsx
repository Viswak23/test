import {
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
  List,
  ListItem,
  ListItemText,
  Stack,
  TextField,
  Tooltip,
  useTheme,
  Typography,
} from "@mui/material";
import { AddBox } from "@mui/icons-material";
import { useMemo, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import {
  EmployeeWithAvatarUrl,
  useEmployees,
} from "@/contexts/EmployeesContext";
import { OrganizationUnit, OrganizationUnitEmployeeJoin } from "@/src/API";
import {
  addEmployeeToOrganizationUnit,
  removeEmployeeFromOrganizationUnit,
} from "@/lib/webEmployee";
import DeleteButton from "../Common/Buttons/DeleteButton";
import HelpButton from "../Common/Buttons/HelpButton";
import HelpCollapse from "../Common/Dialog/HelpCollapse";
import { FormTitle } from "../Common/Texts/Texts";

interface AddEmployeeToOrganizationUnitProps {
  organizationUnit: OrganizationUnit;
  open: boolean;
  onClose: () => void;
}

export default function AddEmployeeToOrganizationUnit({
  organizationUnit,
  open,
  onClose,
}: AddEmployeeToOrganizationUnitProps) {
  const [saving, setSaving] = useState<EmployeeWithAvatarUrl | undefined>(
    undefined
  );
  const [search, setSearch] = useState("");
  const [showHelp, setShowHelp] = useState(false);
  const employees = useEmployees()?.employees;
  const joins = useEmployees()?.organizationUnitEmployeeJoins;
  const intl = useIntl();
  const theme = useTheme();

  const filteredEmployees = useMemo(
    () =>
      employees
        ?.filter(
          (employee) =>
            employee.name.toLowerCase().includes(search.toLowerCase()) ||
            employee.email.toLowerCase().includes(search.toLowerCase())
        )
        .sort((a, b) => {
          return a.name.localeCompare(b.name);
        }),
    [employees, search]
  );

  const [employeesInsideUnit, employeesOutsideUnit] = useMemo(() => {
    const inside: EmployeeWithAvatarUrl[] = [];
    const outside: EmployeeWithAvatarUrl[] = [];
    filteredEmployees?.forEach((employee) => {
      const isInUnit = joins?.some(
        (join) =>
          join.employeeId === employee.id &&
          join.organizationUnitId === organizationUnit?.id
      );
      if (isInUnit) {
        inside.push(employee);
      } else {
        outside.push(employee);
      }
    });
    return [inside, outside];
  }, [filteredEmployees, joins, organizationUnit?.id]);

  const resetState = () => {
    setSaving(undefined);
  };

  const handleClose = () => {
    resetState();
    onClose();
  };

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(event.target.value);
  };

  const handleSearchKeyDown = (
    event: React.KeyboardEvent<HTMLInputElement>
  ) => {
    if (event.key === "Escape") {
      setSearch("");
    }
  };

  const handleAddEmployee = async (employee: EmployeeWithAvatarUrl) => {
    setSaving(employee);
    await addEmployeeToOrganizationUnit(employee.id, organizationUnit.id);
    resetState();
  };

  const handleRemoveEmployee = async (
    existingJoin?: OrganizationUnitEmployeeJoin,
    employee?: EmployeeWithAvatarUrl
  ) => {
    if (!existingJoin) return;

    setSaving(employee);
    await removeEmployeeFromOrganizationUnit(existingJoin);
    resetState();
  };

  const renderSecondaryAction = (employee: EmployeeWithAvatarUrl) => {
    if (saving?.id === employee.id) {
      return <CircularProgress size={20} style={{ marginRight: "10px" }} />;
    }

    const existingJoin = joins?.find(
      (join) =>
        join.employeeId === employee.id &&
        join.organizationUnitId === organizationUnit?.id
    );

    if (existingJoin) {
      return (
        <DeleteButton
          onClick={() => handleRemoveEmployee(existingJoin, employee)}
          tooltip={intl.formatMessage({
            id: "employees.remove.from.organization.unit.tooltip",
          })}
        />
      );
    }

    return (
      <IconButton
        onClick={() => handleAddEmployee(employee)}
        style={{ color: theme.palette.primary.main }}
      >
        <Tooltip
          title={<FormattedMessage id="employees.add.to.organization.unit" />}
        >
          <AddBox />
        </Tooltip>
      </IconButton>
    );
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };
  const renderEmployeeList = (list: EmployeeWithAvatarUrl[] | undefined) => {
    if (list?.length === 0) {
      return (
        <p>
          <FormattedMessage id="employees.organization.unit.employees.no.one" />
        </p>
      );
    }
    return (
      <List
        dense
        sx={{
          width: "100%",
        }}
      >
        {list!.map((employee) => (
          <ListItem
            key={employee.id}
            secondaryAction={renderSecondaryAction(employee)}
          >
            <ListItemText primary={employee.name} secondary={employee.email} />
          </ListItem>
        ))}
      </List>
    );
  };

  return (
    <Dialog
      open={open}
      onClose={handleClose}
      fullWidth={true}
      maxWidth="lg"
      disableRestoreFocus
    >
      <DialogTitle>
        <Stack direction="row" spacing={1} alignItems={"center"}>
          <FormTitle>
            <FormattedMessage id="employees.organization.unit.employees" />
          </FormTitle>
          <HelpButton
            onClick={handleToggleHelp}
            data-cy="show-add-employee-to-organization-help"
          />
        </Stack>
      </DialogTitle>
      <DialogContent>
        <HelpCollapse
          showHelp={showHelp}
          helpText={intl.formatMessage({
            id: "employees.organization.unit.employees.help.text",
          })}
        />
        <TextField
          label={<FormattedMessage id="general.search" />}
          variant="outlined"
          style={{ marginTop: "1rem", marginBottom: "1rem" }}
          sx={{ width: { xs: "100%", sm: "24rem" } }}
          value={search}
          onChange={handleSearchChange}
          onKeyDown={handleSearchKeyDown}
        />
        <Stack
          direction={{ xs: "column", sm: "row" }}
          spacing={2}
          alignItems="flex-start"
        >
          <Stack
            flex={1}
            alignItems="center"
            sx={{ width: { xs: "100%", sm: "50%" } }}
          >
            <Typography variant="h6" textAlign="center">
              <FormattedMessage id="employees.organization.unit.employees.inside" />
            </Typography>

            {renderEmployeeList(employeesInsideUnit)}
          </Stack>
          <Divider
            flexItem
            sx={{
              display: "block",
              orientation: { xs: "horizontal", sm: "vertical" },
              my: { xs: 2, sm: 0 },
              mx: { xs: 0, sm: 2 },
            }}
          />

          <Stack
            flex={1}
            alignItems="center"
            sx={{ width: { xs: "100%", sm: "50%" } }}
          >
            <Typography variant="h6" textAlign="center">
              <FormattedMessage id="employees.organization.unit.employees.outside" />
            </Typography>
            {renderEmployeeList(employeesOutsideUnit)}
          </Stack>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button
          onClick={handleClose}
          disabled={saving != null}
          data-cy="dialog-button-cancel"
        >
          <FormattedMessage id="general.close" />
        </Button>
      </DialogActions>
    </Dialog>
  );
}
