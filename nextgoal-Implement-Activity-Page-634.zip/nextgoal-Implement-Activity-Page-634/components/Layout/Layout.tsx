import theme from "@/config/theme";
import { Stack, useMediaQuery } from "@mui/material";
import Container from "@mui/material/Container";
import Head from "next/head";
import { ReactNode } from "react";
import { useIntl } from "react-intl";
import Sidebar from "../Sidebar/Sidebar";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const intl = useIntl();
  const isMdScreen = useMediaQuery(theme.breakpoints.up("md")); // Check if screen is sized md or larger

  return (
    <>
      <Head>
        <title>{intl.formatMessage({ id: "application.title" })}</title>
      </Head>
      <Stack direction={isMdScreen ? "row" : "column"} minHeight={"100vh"}>
        <Sidebar />
        <Container maxWidth="lg" style={{ marginTop: '16px', overflowY: "auto" }}>
          <main>{children}</main>
        </Container>
      </Stack>
    </>
  );
}
