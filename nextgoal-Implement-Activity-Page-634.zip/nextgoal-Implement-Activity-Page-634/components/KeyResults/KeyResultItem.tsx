import { CSSProperties, useState } from "react";
import { Box, Stack } from "@mui/material";
import {
  getKeyResultStatusAndProgress,
  showKeyResultGraph,
} from "@/lib/webKeyResults";
import BreadcrumbList from "../Common/Breadcrumb/BreadcrumbList";
import { ListSecondaryText, ListText } from "../Common/Texts/Texts";
import { Goal, KeyResult } from "@/src/API";
import KeyResultUpdateRow from "./KeyResultUpdateRow";
import SubItemComments from "../Comments/SubitemComments";
import CommentsIcons from "../Comments/CommentsIcons";
import KeyResultIcon from "./KeyResultIcon";
import DeleteButton from "../Common/Buttons/DeleteButton";
import { canDeleteDbItem } from "@/lib/webHelpers";
import { FormattedMessage, useIntl } from "react-intl";
import KeyResultProgressGraph from "../Graphs/KeyResultProgressGraph";
import ListButton from "../Common/Buttons/ListButton";
import EditButton from "../Common/Buttons/EditButton";
import UpdateButton from "../Common/Buttons/UpdateButton";

interface KeyResultItemProps {
  keyResult: KeyResult;
  title?: string;
  goal?: Goal | null;
  showLocation?: boolean;
  last?: boolean;
  style?: CSSProperties;
  canEdit?: boolean;
  onEdit?: (keyResult: KeyResult) => void;
  onDeleteKeyResult?: (keyResult: KeyResult) => void;
  onAddUpdate?: (keyResult: KeyResult) => void;
  onShowUpdates?: (keyResultId: string) => void;
}

export default function KeyResultItem({
  keyResult,
  title,
  goal,
  style,
  showLocation = false,
  last = false,
  canEdit = true,
  onDeleteKeyResult,
  onEdit,
  onAddUpdate,
  onShowUpdates,
}: KeyResultItemProps) {
  const [addingComment, setAddingComment] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const intl = useIntl();

  const handleEdit = () => {
    if (onEdit) {
      onEdit(keyResult);
    }
  };

  const handleAddUpdate = () => {
    if (onAddUpdate) {
      onAddUpdate(keyResult);
    }
  };

  const handleShowUpdates = () => {
    if (onShowUpdates) {
      onShowUpdates(keyResult.id);
    }
  };

  const handleDeleteKeyResult = () => {
    if (onDeleteKeyResult) {
      onDeleteKeyResult(keyResult);
    }
  };

  const handleAddComment = () => {
    setShowComments(true);
    setAddingComment(true);
  };

  const handleCloseAddComment = (saved: boolean) => {
    if (!saved && keyResult.comments?.items?.length === 0) {
      setShowComments(false);
    }
    setAddingComment(false);
  };

  const handleShowComments = () => {
    setShowComments(true);
  };

  const handleHideComments = () => {
    setShowComments(false);
  };

  const commentsCount = keyResult.comments?.items?.length || 0;

  const containerStyle: CSSProperties | undefined = !last
    ? {
        borderBottom: "1px solid #e0e0e0",
        marginBottom: "12px",
      }
    : undefined;
  const latestUpdate = keyResult.updates?.items?.[0];
  const keyResultStatus = getKeyResultStatusAndProgress(intl, keyResult);

  return (
    <Box
      style={containerStyle}
      textAlign={"left"}
      data-cy={`key-result-${keyResult.description}`}
    >
      <Stack
        direction={{ xs: "column", md: "row" }}
        spacing={2}
        alignItems={"center"}
      >
        {/* Key result icon, its state */}
        <Stack direction="row" spacing={1} alignItems={"center"}>
          <KeyResultIcon keyResult={keyResult} />
          <ListText>{keyResultStatus}</ListText>
        </Stack>

        {/* Key result description */}
        <Box flexGrow={1} sx={{ wordBreak: "break-word" }}>
          <ListText sx={{ opacity: 1.0, fontStyle: "italic" }}>
            {keyResult.description || ""}
          </ListText>
        </Box>

        {/* All the buttons: */}
        {canEdit && (
          <Stack
            direction="row"
            spacing={{ xs: 2, md: 1 }}
            style={style}
            alignItems="center"
          >
            {/* Edit btn */}
            <EditButton
              onClick={handleEdit}
              tooltip={intl.formatMessage({ id: "keyresults.edit" })}
            />

            {/* Update btn */}
            <UpdateButton
              onClick={handleAddUpdate}
              tooltip={intl.formatMessage({ id: "keyresults.add.update" })}
            />

            {/* Show updates btn */}
            <ListButton
              onClick={handleShowUpdates}
              dataCy="show-keyresults-updates-button"
              tooltip={intl.formatMessage({ id: "keyresults.show.updates" })}
            />

            {/* Delete btn */}
            <DeleteButton
              disabled={!canDeleteDbItem(keyResult)}
              onClick={handleDeleteKeyResult}
              tooltip={intl.formatMessage({
                id: "keyresults.delete.caption",
              })}
              disabledTooltip={intl.formatMessage({
                id: "keyresults.delete.disabled.tooltip",
              })}
            />

            <CommentsIcons
              showComments={showComments}
              addingComment={addingComment}
              commentsCount={commentsCount}
              onShowComments={handleShowComments}
              onHideComments={handleHideComments}
              onAddComment={handleAddComment}
            />
          </Stack>
        )}
      </Stack>

      {/* Latest update */}
      <Stack direction="column" spacing={0} style={{ width: "100%" }}>
        {!latestUpdate && (
          <ListSecondaryText sx={{ marginTop: "6px" }}>
            <FormattedMessage id="keyresults.no.updates" />
          </ListSecondaryText>
        )}
        {latestUpdate && (
          <Box sx={{ paddingLeft: { xs: 0, md: "32px" } }}>
            <KeyResultUpdateRow keyResultUpdate={latestUpdate} />
          </Box>
        )}
        {showLocation && (
          <Box
            sx={{
              paddingLeft: { xs: 0, md: "26px" },
              marginLeft: { xs: "auto", md: "0" },
              marginRight: { xs: "auto", md: "0" },
            }}
          >
            <BreadcrumbList
              organizationUnitId={keyResult.goal?.organizationUnitGoalsId}
              showMainPage={false}
              showLastAsaLink
              extraElement={{
                title: keyResult.goal?.title || "",
                link: `/goals/${keyResult.goal?.id}`,
              }}
            />
          </Box>
        )}
      </Stack>

      <Stack direction="row" spacing={2} sx={{ justifyContent: "center" }}>
        {showKeyResultGraph(keyResult) && (
          <KeyResultProgressGraph keyResult={keyResult} goal={goal} />
        )}
      </Stack>
      {showComments && (
        <Box style={{ paddingLeft: "24px" }}>
          <SubItemComments
            comments={keyResult.comments?.items}
            parentGoalId={keyResult.goalKeyResultsId || undefined}
            addingComment={addingComment}
            onCloseAddComment={handleCloseAddComment}
            keyResultId={keyResult.id}
          />
        </Box>
      )}
    </Box>
  );
}
