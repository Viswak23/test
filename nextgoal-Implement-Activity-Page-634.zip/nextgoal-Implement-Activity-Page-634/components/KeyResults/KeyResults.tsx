import { useState } from "react";
import EditKeyResult from "./EditKeyResult";
import KeyResultItem from "./KeyResultItem";
import { Goal, KeyResult } from "@/src/API";
import KeyResultsContainer from "./KeyResultsContainer";
import KeyResultUpdates from "./KeyResultUpdates";
import UpdateKeyResult from "./UpdateKeyResult";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import { deleteKeyResultDb } from "@/lib/webKeyResults";
import { useIntl } from "react-intl";
import { useEvents } from "@/contexts/EventsContext";
import { sortCreatedAtDescending } from "@/lib/time";

interface KeyResultsProps {
  goal?: Goal | null;
  showLocation?: boolean;
  showTitle?: boolean;
  showNoKeyResults?: boolean;
  keyResultsList?: (KeyResult | null)[];
  canAdd?: boolean;
  canEdit?: boolean;
  inTab?: boolean;
}

export default function KeyResults({
  goal,
  showLocation = false,
  showTitle = true,
  showNoKeyResults = true,
  keyResultsList,
  canAdd = true,
  canEdit = true,
  inTab = false,
}: KeyResultsProps) {
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<KeyResult | undefined>();
  const [deleteKeyResult, setDeleteKeyResult] = useState<
    KeyResult | undefined
  >();
  const [addingUpdate, setAddingUpdate] = useState<KeyResult | undefined>();
  const [showUpdates, setShowUpdates] = useState<string | undefined>();
  const [saving, setSaving] = useState(false);
  const intl = useIntl();
  const events = useEvents()?.events;

  const keyResults = keyResultsList
    ? [...keyResultsList]
    : [...(goal?.keyResults?.items || [])];

  keyResults.sort(sortCreatedAtDescending);

  const handleAdd = () => {
    setAdding(true);
  };

  const handleCloseEdit = () => {
    setAdding(false);
    setEditing(undefined);
  };

  const handleEdit = (keyResult: KeyResult) => {
    setEditing(keyResult);
  };

  const handleDelete = (keyResult: KeyResult) => {
    setDeleteKeyResult(keyResult);
  };

  const handleCancelDelete = () => {
    setDeleteKeyResult(undefined);
  };

  const handleDeleteConfirmed = async () => {
    if (!deleteKeyResult) {
      return;
    }

    setSaving(true);
    await deleteKeyResultDb(deleteKeyResult, events);
    setDeleteKeyResult(undefined);
    setSaving(false);
  };

  const handleAddUpdate = (keyResult: KeyResult) => {
    setAddingUpdate(keyResult);
  };

  const handleUpdateClose = () => {
    setAddingUpdate(undefined);
  };

  const handleShowUpdates = (keyResultId: string) => {
    setShowUpdates(keyResultId);
  };

  const handleHideUpdates = () => {
    setShowUpdates(undefined);
  };

  return (
    <>
      <div style={{ paddingTop: "18px" }}>
        <KeyResultsContainer
          inTab={inTab}
          title={
            showTitle
              ? intl.formatMessage({ id: "keyresults.title" })
              : undefined
          }
          canAdd={canAdd}
          showNoKeyResults={showNoKeyResults}
          onAddNewKeyResult={handleAdd}
        >
          {keyResults.length > 0 &&
            keyResults?.map((kr, index) => {
              return (
                <KeyResultItem
                  key={kr!.id}
                  keyResult={kr!}
                  goal={goal}
                  showLocation={showLocation}
                  last={index === keyResults!.length - 1}
                  canEdit={canEdit}
                  onEdit={handleEdit}
                  onDeleteKeyResult={handleDelete}
                  onAddUpdate={handleAddUpdate}
                  onShowUpdates={handleShowUpdates}
                />
              );
            })}
        </KeyResultsContainer>
        {goal && (
          <EditKeyResult
            open={adding || !!editing}
            key={editing?.id || "newkeyresult"}
            keyResult={editing}
            goalId={goal!.id}
            onClose={handleCloseEdit}
          />
        )}
        {addingUpdate && goal && (
          <UpdateKeyResult
            goal={goal}
            keyResult={addingUpdate}
            open={!!addingUpdate}
            onClose={handleUpdateClose}
          />
        )}
        {showUpdates && goal && (
          <KeyResultUpdates
            goal={goal}
            keyResult={keyResults.find((kr) => kr?.id === showUpdates)!}
            open={!!showUpdates}
            onClose={handleHideUpdates}
          />
        )}
        <ConfirmationDialog
          title={intl.formatMessage({ id: "keyresults.delete" })}
          message={intl.formatMessage({ id: "keyresults.delete.confirmation" })}
          messageItem={deleteKeyResult?.description || ""}
          open={!!deleteKeyResult}
          saving={saving}
          onCancel={handleCancelDelete}
          onConfirm={handleDeleteConfirmed}
        />
      </div>
    </>
  );
}
