import {
  getKeyResultStatusAndProgress,
  showKeyResultGraph,
} from "@/lib/webKeyResults";
import { KeyResult, KeyResultUpdate } from "@/src/API";
import { Stack } from "@mui/material";
import KeyResultIcon from "./KeyResultIcon";
import { ListSecondaryText, ListText } from "../Common/Texts/Texts";
import KeyResultUpdateRow from "./KeyResultUpdateRow";
import { useIntl } from "react-intl";
import KeyResultProgressGraph from "../Graphs/KeyResultProgressGraph";
import { useGoals } from "@/contexts/GoalsContext";
import { useMemo } from "react";

interface KeyResultFeedDescriptionProps {
  keyResult?: KeyResult | null;
  keyResultUpdate?: KeyResultUpdate | null;
}

export default function KeyResultFeedDescription({
  keyResult,
  keyResultUpdate,
}: KeyResultFeedDescriptionProps) {
  const intl = useIntl();
  const goals = useGoals()?.goals;
  const keyResultGoal = useMemo(
    () => goals?.find((goal) => goal.id === keyResult?.goal?.id),
    [goals, keyResult]
  );
  const keyResultStatus = getKeyResultStatusAndProgress(
    intl,
    keyResult || null
  );

  return (
    <Stack direction="row" spacing={1} style={{ width: "100%" }}>
      <KeyResultIcon keyResult={keyResult} />
      <Stack direction="column" spacing={0} sx={{ width: "100%" }}>
        <ListText>{keyResult?.description}</ListText>
        <ListSecondaryText>{keyResultStatus}</ListSecondaryText>
        {keyResult && showKeyResultGraph(keyResult) && (
          <KeyResultProgressGraph keyResult={keyResult} goal={keyResultGoal} />
        )}
        {keyResultUpdate && (
          <KeyResultUpdateRow keyResultUpdate={keyResultUpdate} />
        )}
      </Stack>
    </Stack>
  );
}
