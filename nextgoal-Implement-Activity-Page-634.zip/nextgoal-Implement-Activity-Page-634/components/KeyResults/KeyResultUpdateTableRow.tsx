import { showDate } from "@/lib/time";
import { getStatusFlagText } from "@/lib/webKeyResults";
import { KeyResultUpdate } from "@/src/API";
import { Update } from "@mui/icons-material";
import { Box, IconButton, TableCell, TableRow, Tooltip } from "@mui/material";
import { FormattedMessage, useIntl } from "react-intl";
import DeleteButton from "../Common/Buttons/DeleteButton";
import { canDeleteDbItem } from "@/lib/webHelpers";
import { useSettings } from "@/contexts/SettingsInfo";

interface KeyResultUpdateTableRowProps {
  keyResultUpdate: KeyResultUpdate;
  handleEdit: (keyResultUpdate: KeyResultUpdate) => void;
  handleDelete: (keyResultUpdate: KeyResultUpdate) => void;
}

export default function KeyResultUpdateTableRow({
  keyResultUpdate,
  handleEdit,
  handleDelete,
}: KeyResultUpdateTableRowProps) {
  const intl = useIntl();
  const dbUser = useSettings()?.dbUser;

  return (
    <TableRow
      sx={{
        wordBreak: "break-word",
      }}
    >
      <TableCell>{showDate(keyResultUpdate.dateOfUpdate, dbUser)}</TableCell>
      <TableCell>{keyResultUpdate.currentValueBefore}</TableCell>
      <TableCell>{keyResultUpdate.currentValueAfter}</TableCell>
      <TableCell>
        {getStatusFlagText(intl, keyResultUpdate.statusFlagBefore)}
      </TableCell>
      <TableCell>
        {getStatusFlagText(intl, keyResultUpdate.statusFlagAfter)}
      </TableCell>
      <TableCell>{keyResultUpdate.text}</TableCell>
      <TableCell>
        <Box display="flex" alignItems="center">
          <IconButton
            aria-label={intl.formatMessage({ id: "general.update" })}
            onClick={() => handleEdit(keyResultUpdate)}
            size="small"
            sx={{ color: "primary.main" }}
          >
            <Tooltip title={<FormattedMessage id="keyresults.add.update" />}>
              <Update />
            </Tooltip>
          </IconButton>
          <DeleteButton
            disabled={!canDeleteDbItem(keyResultUpdate)}
            onClick={() => handleDelete(keyResultUpdate)}
            tooltip={intl.formatMessage({
              id: "keyresult.update.delete.caption",
            })}
            disabledTooltip={intl.formatMessage({
              id: "keyresult.update.delete.disabled.tooltip",
            })}
          />
        </Box>
      </TableCell>
    </TableRow>
  );
}
