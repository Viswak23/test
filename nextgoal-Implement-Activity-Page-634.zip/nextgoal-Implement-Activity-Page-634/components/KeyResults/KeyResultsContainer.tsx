import { ReactNode } from "react";
import GTabPanel from "@/components/Common/GTabPanel/GTabPanel";
import GList, { GoalListTitleStyle } from "@/components/Common/GList/GList";
import { useIntl } from "react-intl";

interface KeyResultsContainerProps {
  children: ReactNode;
  inTab?: boolean;
  title?: string;
  showNoKeyResults?: boolean;
  canAdd?: boolean;
  onAddNewKeyResult?: () => void;
}

export default function KeyResultsContainer({
  children,
  inTab = false,
  title,
  showNoKeyResults,
  canAdd,
  onAddNewKeyResult,
}: KeyResultsContainerProps) {
  const intl = useIntl();

  if (inTab) {
    return <GTabPanel onAdd={onAddNewKeyResult}>{children}</GTabPanel>;
  } else {
    return (
      <GList
        title={title}
        titleStyle={GoalListTitleStyle.DETAILS}
        noResultsText={
          showNoKeyResults
            ? intl.formatMessage({ id: "keyresults.no.key.results" })
            : undefined
        }
        marginTop={false}
        onAdd={canAdd ? onAddNewKeyResult : undefined}
      >
        {children}
      </GList>
    );
  }
}
