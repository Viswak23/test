import { CSSProperties } from "react";
import { KeyResultStatus, getKeyResultColor } from "@/lib/webKeyResults";
import { KeyResult } from "@/src/API";
import { OfflineBolt } from "@mui/icons-material";

interface KeyResultIconProps {
  keyResult?: KeyResult | null;
  statusFlag?: KeyResultStatus | null;
  style?: CSSProperties;
}

export default function KeyResultIcon({
  keyResult,
  statusFlag,
  style,
}: KeyResultIconProps) {
  if (!keyResult && !statusFlag) {
    return null;
  }

  const status = statusFlag || (keyResult?.statusFlag as KeyResultStatus);

  return (
    <OfflineBolt
      style={{
        ...style,
        color: getKeyResultColor(status),
      }}
    />
  );
}
