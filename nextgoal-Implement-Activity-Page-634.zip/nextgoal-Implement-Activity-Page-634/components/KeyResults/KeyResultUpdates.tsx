import { Goal, KeyResult, KeyResultUpdate } from "@/src/API";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Button,
  Table,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
  Stack,
} from "@mui/material";
import KeyResultUpdateTableRow from "./KeyResultUpdateTableRow";
import { sortUpdateDate } from "@/lib/time";
import { FormattedMessage, useIntl } from "react-intl";
import UpdateKeyResult from "./UpdateKeyResult";
import { useState } from "react";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import {
  deleteKeyResultUpdateDb,
  updateKeyResultDb,
} from "@/lib/webKeyResults";
import dayjs from "dayjs";
import { useEvents } from "@/contexts/EventsContext";
import { FormTitle } from "../Common/Texts/Texts";
import HelpButton from "../Common/Buttons/HelpButton";
import HelpCollapse from "../Common/Dialog/HelpCollapse";

interface KeyResultUpdatesProps {
  goal: Goal | null;
  keyResult: KeyResult;
  open: boolean;
  onClose: () => void;
}

export default function KeyResultUpdates({
  goal,
  keyResult,
  open,
  onClose,
}: KeyResultUpdatesProps) {
  const [editKeyResultUpdate, setEditKeyResultUpdate] = useState<
    KeyResultUpdate | undefined
  >();
  const intl = useIntl();
  const events = useEvents()?.events;
  const [showHelp, setShowHelp] = useState(false);
  const [saving, setSaving] = useState<boolean>(false);
  const [deleteKeyResultUpdate, setDeleteKeyResultUpdate] = useState<
    KeyResultUpdate | undefined
  >();
  const updatesExist =
    keyResult.updates?.items != null && keyResult.updates?.items.length > 0;

  //if there are updates, sort them descending
  //sort mutates the array in place, so we constract a new array out of the original and sort it. otherwise gives error,
  // using the ! in the updates we insist that updates will defenitly exist. because of the updatesExist variable
  const sortedUpdates = updatesExist
    ? [...keyResult.updates!.items].sort((a, b) => sortUpdateDate(a, b, "des"))
    : [];

  const handleDeleteKeyResultUpdate = async (
    keyResultUpdate: KeyResultUpdate
  ) => {
    setDeleteKeyResultUpdate(keyResultUpdate);
  };

  const handleEditKeyResultUpdate = (keyResultUpdate: KeyResultUpdate) => {
    setEditKeyResultUpdate(keyResultUpdate);
  };

  const handleEditClose = () => {
    setEditKeyResultUpdate(undefined);
  };

  const handleCancelDeleteKeyResultUpdate = () => {
    setDeleteKeyResultUpdate(undefined);
  };
  const handleConfirmDeleteKeyResultUpdate = async () => {
    if (!deleteKeyResultUpdate) {
      return;
    }
    setSaving(true);
    if (keyResult.updates?.items.indexOf(deleteKeyResultUpdate) === 0) {
      // check if the deleted KR update's value before is different from previous KR update's value after
      // or KR's intial value if there is only one KR update
      let currentValueAfterDeletion = deleteKeyResultUpdate.currentValueBefore;
      let originalValue =
        keyResult.updates.items.length > 1
          ? keyResult.updates.items[1]?.currentValueAfter
          : keyResult.initialValue;
      if (currentValueAfterDeletion !== originalValue) {
        currentValueAfterDeletion = originalValue;
      }

      const updatedKeyResult = {
        id: keyResult.id,
        currentValue: currentValueAfterDeletion,
        statusFlag: deleteKeyResultUpdate.statusFlagBefore,
        dateOfUpdate: dayjs().toISOString(),
      };
      await updateKeyResultDb(updatedKeyResult);
    }
    await deleteKeyResultUpdateDb(deleteKeyResultUpdate.id, events);

    setDeleteKeyResultUpdate(undefined);
    setSaving(false);
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullWidth={true}
      maxWidth="lg"
      onKeyUp={(e) => {
        if (e.key === "Enter") onClose();
      }}
    >
      <DialogTitle>
        <Stack direction="row" spacing={1} alignItems={"center"}>
          <FormTitle>
            <FormattedMessage id="keyresults.updates.title" />
          </FormTitle>
          <HelpButton
            onClick={handleToggleHelp}
            data-cy="show-key-result-updates-help"
          />
        </Stack>
      </DialogTitle>
      <DialogContent>
        <HelpCollapse
          showHelp={showHelp}
          helpText={intl.formatMessage({ id: "keyresults.update.help.text" })}
        />
        {!updatesExist && <FormattedMessage id="keyresults.no.updates" />}
        {updatesExist && (
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>
                  <FormattedMessage id="keyresults.update.created" />
                </TableCell>
                <TableCell>
                  <FormattedMessage id="keyresults.update.current.value.before" />
                </TableCell>
                <TableCell>
                  <FormattedMessage id="keyresults.update.current.value.after" />
                </TableCell>
                <TableCell>
                  <FormattedMessage id="keyresults.update.status.before" />
                </TableCell>
                <TableCell>
                  <FormattedMessage id="keyresults.update.status.after" />
                </TableCell>
                <TableCell>
                  <FormattedMessage id="keyresults.update.description" />
                </TableCell>
                <TableCell>
                  <FormattedMessage id="keyresults.update.actions" />
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {sortedUpdates?.map((update) => (
                <KeyResultUpdateTableRow
                  key={update?.id}
                  keyResultUpdate={update as KeyResultUpdate}
                  handleEdit={handleEditKeyResultUpdate}
                  handleDelete={handleDeleteKeyResultUpdate}
                />
              ))}
            </TableBody>
          </Table>
        )}
        {editKeyResultUpdate && goal && (
          <UpdateKeyResult
            goal={goal}
            keyResult={keyResult}
            keyResultUpdate={editKeyResultUpdate}
            isLatestKeyResultUpdate={
              sortedUpdates.indexOf(editKeyResultUpdate) === 0
            }
            open={!!editKeyResultUpdate}
            onClose={handleEditClose}
          />
        )}
        {deleteKeyResultUpdate && (
          <ConfirmationDialog
            title={intl.formatMessage({
              id: "keyresult.update.delete.caption",
            })}
            message={intl.formatMessage({
              id: "keyresult.update.delete.confirmation",
            })}
            messageItem={deleteKeyResultUpdate?.text || ""}
            open={!!deleteKeyResultUpdate}
            saving={saving}
            onConfirm={handleConfirmDeleteKeyResultUpdate}
            onCancel={handleCancelDeleteKeyResultUpdate}
          />
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} data-cy="key-results-update-close-button">
          <FormattedMessage id="general.close" />
        </Button>
      </DialogActions>
    </Dialog>
  );
}
