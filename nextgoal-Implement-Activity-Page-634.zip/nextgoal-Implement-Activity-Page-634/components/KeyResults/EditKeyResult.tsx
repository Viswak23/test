import { useEffect, useMemo, useState } from "react";
import {
  Stack,
  InputLabel,
  TextField,
  MenuItem,
  FormControl,
  Dialog,
  DialogContent,
  Alert,
} from "@mui/material";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import { useImmer } from "use-immer";
import {
  CreateKeyResultInput,
  Employee,
  KeyResult,
  UpdateKeyResultInput,
} from "@/src/API";
import {
  KeyResultStatus,
  addKeyResultDb,
  getStatusFlagText,
  updateKeyResultDb,
} from "@/lib/webKeyResults";
import { useAuthStatus } from "@/lib/customHooks";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import { FormattedMessage, useIntl } from "react-intl";
import { useGoals } from "@/contexts/GoalsContext";
import { isEmployeeGoal } from "@/lib/webEmployee";
import { log } from "@/lib/backend/actions/logger";
import { TabPanel } from "../Settings/TabPanel";
import DialogChat from "../Chat/ChatInDialog";
import { getGoalBackgroundInfo } from "@/lib/webGoals";
import { useNorthStars } from "@/contexts/NorthStarsContext";
import { useOrganization } from "@/contexts/OrganizationContext";
import HelpCollapse from "../Common/Dialog/HelpCollapse";
import { useEmployees } from "@/contexts/EmployeesContext";
import DialogTabTitle from "../Common/Dialog/DialogTabTitle";
import {
  ChatDialogState,
  defaultChatDialogState,
} from "../Chat/ChatDialogState";

interface EditKeyResultProps {
  goalId?: string;
  keyResult?: KeyResult;
  open: boolean;
  onClose: () => void;
}

const defaultKeyResult: CreateKeyResultInput = {
  statusFlag: KeyResultStatus.UNKNOWN,
  description: "",
  companyId: "placeholder",
  creatorEmail: "placeholder",
};

export default function EditKeyResult({
  goalId,
  keyResult,
  open,
  onClose,
}: EditKeyResultProps) {
  const [editKeyResult, setEditKeyResult] = useImmer<
    CreateKeyResultInput | UpdateKeyResultInput
  >(keyResult ? keyResult : { ...defaultKeyResult });
  const [showHelp, setShowHelp] = useState(false);
  const [saving, setSaving] = useState(false);
  const [decriptionError, setDescriptionError] = useState("");
  const [savingError, setSavingError] = useState("");
  const [tabValue, setTabValue] = useState(0);
  const [chatDialogState, setChatDialogState] = useImmer<ChatDialogState>(
    defaultChatDialogState
  );
  const currentUser = useAuthStatus();
  const intl = useIntl();
  const { goals: fetchedGoals } = useGoals()!;

  const goals = useMemo(() => fetchedGoals || [], [fetchedGoals]);
  const northStars = useNorthStars()?.northStars;
  const currentGoal = goals.find((goal) => goal.id === goalId);
  const organization = useOrganization()?.organization;
  const employeeContext = useEmployees();
  const employee = employeeContext?.employees?.find(
    (employee: Employee) => employee?.id === currentGoal?.employeeGoalsId
  );

  const resetState = () => {
    setEditKeyResult(keyResult ? keyResult : { ...defaultKeyResult });
    setShowHelp(false);
    setSaving(false);
    setDescriptionError("");
    setSavingError("");
  };

  const handleDescriptionChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setDescriptionError("");
    setEditKeyResult((draft) => {
      draft.description = event.target.value;
    });
  };

  const handleStatusFlagChange = (event: SelectChangeEvent) => {
    setEditKeyResult((draft) => {
      draft.statusFlag = event.target.value as KeyResultStatus;
    });
  };

  const handleInitialValueChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditKeyResult((draft) => {
      if (event.target.value === "") {
        draft.initialValue = null;
        return;
      }
      draft.initialValue = parseFloat(event.target.value);
    });
  };

  const handleTargetValueChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditKeyResult((draft) => {
      if (event.target.value === "") {
        draft.targetValue = null;
        return;
      }
      draft.targetValue = parseFloat(event.target.value);
    });
  };
  useEffect(() => {
    (async () => {
      let info = await getGoalBackgroundInfo(
        intl,
        currentGoal?.organizationUnitGoalsId!,
        employee ?? undefined,
        goals,
        organization,
        northStars,
        employeeContext?.organizationUnitEmployeeJoins,
        currentGoal
      );
      setChatDialogState((draft) => {
        draft.backgroundInfo = info.info;
        draft.hint = info.hint;
      });
    })();
    if (!keyResult) {
      setChatDialogState((draft) => {
        draft.question = intl.formatMessage({
          id: "chat.prefilled.question.keyresult",
        });
      });
    }
  }, [
    currentGoal,
    employee,
    goals,
    intl,
    keyResult,
    northStars,
    organization,
    setChatDialogState,
    employeeContext,
  ]);

  const handleSave = async () => {
    if (!editKeyResult.description) {
      setDescriptionError(
        intl.formatMessage({ id: "keyresults.error.description.required" })
      );
      return;
    }
    try {
      setSaving(true);
      const employeeGoal = isEmployeeGoal(goals, goalId);
      if (!keyResult) {
        await addKeyResultDb(
          {
            ...editKeyResult,
            goalKeyResultsId: goalId,
            creatorEmail: currentUser?.attributes.email,
          } as CreateKeyResultInput,
          employeeGoal,
          employeeContext?.employees
        );
      } else {
        await updateKeyResultDb(editKeyResult as UpdateKeyResultInput);
      }
      resetState();
      onClose();
    } catch (error: any) {
      log(`Add/Edit KeyResult: ${error.message}`);
      setSavingError(intl.formatMessage({ id: "general.save.error" }));
      setSaving(false);
    }
  };

  const handleCancel = (event?: object, reason?: string) => {
    if (reason === "backdropClick") {
      // Don't do anything. Accidental click can't delete all the information.
      return;
    }

    resetState();
    onClose();
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  return (
    <Dialog
      open={open}
      onClose={handleCancel}
      fullWidth={true}
      maxWidth="lg"
      disableRestoreFocus
      onKeyUp={(e) => {
        if (e.key === "Enter") handleSave();
      }}
    >
      <DialogTabTitle
        tabValue={tabValue}
        setTabValue={setTabValue}
        dialogTitle={intl.formatMessage({
          id: keyResult ? "keyresults.edit" : "keyresults.add",
        })}
        handleToggleHelp={handleToggleHelp}
      />
      <DialogContent>
        <TabPanel value={tabValue} index={0}>
          <HelpCollapse
            showHelp={showHelp}
            helpText={intl.formatMessage({ id: "keyresults.edit.help.text" })}
          />
          {/* Description */}
          <TextField
            sx={{ marginBottom: "18px" }}
            autoFocus
            id="title"
            data-cy="edit-keyresult-title"
            label={<FormattedMessage id="keyresults.keyresult.description" />}
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            helperText={decriptionError}
            error={decriptionError !== ""}
            value={editKeyResult.description}
            onChange={handleDescriptionChange}
          />
          <Stack direction="row" spacing={2} alignItems={"center"}>
            <FormControl
              variant="standard"
              sx={{ m: 1, minWidth: 120 }}
              onKeyUp={(e) => {
                if (e.key === "Enter") {
                  e.stopPropagation(); // Prevent closing the dialog when enter is used to select an item.
                }
              }}
            >
              <InputLabel id="select-statusflag-label">
                {<FormattedMessage id="keyresults.keyresult.status" />}
              </InputLabel>
              <Select
                labelId="select-statusflag-label"
                value={editKeyResult.statusFlag?.toString()}
                label={<FormattedMessage id="keyresults.keyresult.status" />}
                onChange={handleStatusFlagChange}
                data-cy="keyresult-status-dropdown"
              >
                <MenuItem value={KeyResultStatus.UNKNOWN}>
                  {getStatusFlagText(intl, KeyResultStatus.UNKNOWN)}
                </MenuItem>
                <MenuItem value={KeyResultStatus.COMPLETED}>
                  {getStatusFlagText(intl, KeyResultStatus.COMPLETED)}
                </MenuItem>
                <MenuItem value={KeyResultStatus.ON_TRACK}>
                  {getStatusFlagText(intl, KeyResultStatus.ON_TRACK)}
                </MenuItem>
                <MenuItem value={KeyResultStatus.BEHIND}>
                  {getStatusFlagText(intl, KeyResultStatus.BEHIND)}
                </MenuItem>
                <MenuItem value={KeyResultStatus.AT_RISK}>
                  {getStatusFlagText(intl, KeyResultStatus.AT_RISK)}
                </MenuItem>
                <MenuItem value={KeyResultStatus.FAILED}>
                  {getStatusFlagText(intl, KeyResultStatus.FAILED)}
                </MenuItem>
              </Select>
            </FormControl>
            <TextField
              label={
                <FormattedMessage id="keyresults.keyresult.initial.value" />
              }
              type="number"
              variant="standard"
              autoComplete="off"
              value={
                editKeyResult.initialValue != null
                  ? editKeyResult.initialValue
                  : ""
              }
              onChange={handleInitialValueChange}
              data-cy="keyresult-initial-value-field"
            />
            <TextField
              label={
                <FormattedMessage id="keyresults.keyresult.target.value" />
              }
              type="number"
              variant="standard"
              autoComplete="off"
              value={
                editKeyResult.targetValue != null
                  ? editKeyResult.targetValue
                  : ""
              }
              onChange={handleTargetValueChange}
              data-cy="keyresult-target-value-field"
            />
          </Stack>

          {savingError && <Alert severity="error">{savingError}</Alert>}
        </TabPanel>
        <TabPanel value={tabValue} index={1}>
          <DialogChat
            chatDialogState={chatDialogState}
            setChatDialogState={setChatDialogState}
          />
        </TabPanel>
      </DialogContent>

      <EditDialogActions
        saving={saving}
        onSave={handleSave}
        onCancel={handleCancel}
      />
    </Dialog>
  );
}
