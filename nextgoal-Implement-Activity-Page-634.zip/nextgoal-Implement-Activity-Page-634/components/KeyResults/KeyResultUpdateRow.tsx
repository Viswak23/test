import { KeyResultUpdate } from "@/src/API";
import { Stack } from "@mui/material";
import { ListSecondaryText } from "../Common/Texts/Texts";
import { showDate } from "@/lib/time";
import { getStatusFlagText } from "@/lib/webKeyResults";
import { FormattedMessage, useIntl } from "react-intl";
import { useSettings } from "@/contexts/SettingsInfo";

interface KeyResultUpdateRowProps {
  keyResultUpdate: KeyResultUpdate;
}

export default function KeyResultUpdateRow({
  keyResultUpdate,
}: KeyResultUpdateRowProps) {
  const intl = useIntl();
  const dbUser = useSettings()?.dbUser;

  let currentValueChange = (
    <FormattedMessage id="keyresults.update.no.change.to.current.value" />
  );

  if (keyResultUpdate.currentValueAfter) {
    const before = keyResultUpdate.currentValueBefore || 0;
    if (keyResultUpdate.currentValueAfter > before) {
      currentValueChange = (
        <FormattedMessage
          id="keyresults.update.current.value.increased"
          values={{ value: keyResultUpdate.currentValueAfter - before }}
        />
      );
    } else {
      currentValueChange = (
        <FormattedMessage
          id="keyresults.update.current.value.decreased"
          values={{ value: before - keyResultUpdate.currentValueAfter }}
        />
      );
    }
  } else if (!keyResultUpdate.currentValueAfter) {
    currentValueChange = (
      <FormattedMessage id="keyresults.update.current.value.removed" />
    );
  }

  return (
    <Stack
      direction={{ xs: "column", md: "row" }}
      spacing={{ xs: 1, md: 2 }}
      alignItems="center"
      sx={{ marginTop: "6px", marginBottom: "4px" }}
    >
      {/* Days ago label */}
      <ListSecondaryText>
        <FormattedMessage
          id="keyresults.updated"
          values={{ date: showDate(keyResultUpdate.dateOfUpdate, dbUser) }}
        />
      </ListSecondaryText>
      {/* Current value went up... */}
      <ListSecondaryText>{currentValueChange}</ListSecondaryText>
      {/* Status before: */}
      <ListSecondaryText>
        <FormattedMessage
          id="keyresults.update.status.before.with.value"
          values={{
            status: getStatusFlagText(intl, keyResultUpdate.statusFlagBefore),
          }}
        />
      </ListSecondaryText>
      <ListSecondaryText
        sx={{
          wordBreak: "break-word",
        }}
      >
        {keyResultUpdate.text}
      </ListSecondaryText>
    </Stack>
  );
}
