import React, { useState } from "react";
import {
  InputLabel,
  TextField,
  MenuItem,
  FormControl,
  Dialog,
  DialogContent,
  DialogTitle,
  Stack,
  Alert,
} from "@mui/material";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import { useImmer } from "use-immer";
import {
  CreateKeyResultUpdateInput,
  Goal,
  KeyResult,
  KeyResultUpdate,
  UpdateKeyResultUpdateInput,
} from "@/src/API";
import {
  KeyResultStatus,
  addKeyResultUpdateDb,
  getStatusFlagText,
  updateKeyResultDb,
  updateKeyResultUpdateDb,
} from "@/lib/webKeyResults";
import { useAuthStatus } from "@/lib/customHooks";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import dayjs, { Dayjs } from "dayjs";
import { showDate } from "@/lib/time";
import { FormattedMessage, useIntl } from "react-intl";
import { log } from "@/lib/backend/actions/logger";
import { useSettings } from "@/contexts/SettingsInfo";
import LocalizeDatePicker from "../LocalizeDatePicker/LocalizeDatePicker";
import { FormTitle } from "../Common/Texts/Texts";
import HelpButton from "../Common/Buttons/HelpButton";
import HelpCollapse from "../Common/Dialog/HelpCollapse";
import { useEmployees } from "@/contexts/EmployeesContext";

interface UpdateKeyResultProps {
  goal: Goal | null;
  keyResult: KeyResult;
  keyResultUpdate?: KeyResultUpdate;
  isLatestKeyResultUpdate?: boolean;
  open: boolean;
  onClose: () => void;
}

export default function UpdateKeyResult({
  goal,
  keyResult,
  keyResultUpdate,
  isLatestKeyResultUpdate,
  open,
  onClose,
}: UpdateKeyResultProps) {
  const keyResultDefault = {
    companyId: keyResult.companyId,
    currentValueBefore: keyResult.currentValue || keyResult.initialValue,
    currentValueAfter: keyResult.currentValue || keyResult.initialValue,
    statusFlagBefore: keyResult.statusFlag,
    statusFlagAfter: keyResult.statusFlag,
    keyResultUpdatesId: keyResult.id,
    text: "",
    creatorEmail: "placeholder",
    dateOfUpdate: dayjs().toISOString(),
  };

  const [inputKeyResultUpdate, setInputKeyResultUpdate] = useImmer<
    UpdateKeyResultUpdateInput | CreateKeyResultUpdateInput
  >(keyResultUpdate ? { ...keyResultUpdate } : { ...keyResultDefault });

  const [saving, setSaving] = React.useState(false);
  const [error, setError] = React.useState<string | null>("");
  const [saveError, setSaveError] = React.useState<string | null>("");
  const [dateError, setDateError] = React.useState<string | null>("");
  const [showHelp, setShowHelp] = useState(false);
  const currentUser = useAuthStatus();
  const intl = useIntl();
  const dbUser = useSettings()?.dbUser;
  const employees = useEmployees()?.employees;

  const resetState = () => {
    setSaving(false);
    setInputKeyResultUpdate(
      keyResultUpdate ? { ...keyResultUpdate } : { ...keyResultDefault }
    );
    setError("");
    setSaveError("");
    setDateError("");
  };

  const handleCurrentValueChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setError("");
    setInputKeyResultUpdate((draft) => {
      draft.currentValueAfter = parseFloat(event.target.value);
    });
  };

  const handleStatusFlagChange = (event: SelectChangeEvent) => {
    setInputKeyResultUpdate((draft) => {
      draft.statusFlagAfter = event.target.value as KeyResultStatus;
    });
  };

  const handleStatusTextChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setError("");
    setInputKeyResultUpdate((draft) => {
      draft.text = event.target.value;
    });
  };
  const handleUpdateDateChange = (value: Dayjs) => {
    setError("");
    setDateError("");
    setInputKeyResultUpdate((draft) => {
      draft.dateOfUpdate = value?.toISOString();
    });
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  const handleSave = async () => {
    if (
      inputKeyResultUpdate.currentValueAfter == null &&
      inputKeyResultUpdate.text === ""
    ) {
      setError(
        intl.formatMessage({
          id: "keyresults.update.error.status.or.value.required",
        })
      );
      return;
    }
    //extra Check for date
    //check of the date is in the future or before the keyresult is created
    if (
      dayjs(inputKeyResultUpdate.dateOfUpdate).isBefore(keyResult.createdAt) ||
      dayjs(inputKeyResultUpdate.dateOfUpdate).isAfter(dayjs()) //today
    ) {
      setDateError(
        intl.formatMessage(
          { id: "keyresults.update.error.date.between.values" },
          {
            startDate: showDate(
              dayjs(keyResult.createdAt).toISOString(),
              dbUser
            ),
            endDate: showDate(dayjs().toISOString(), dbUser),
          }
        )
      );
      return;
    }

    try {
      setSaving(true);
      const updatedKeyResult = {
        id: keyResult.id,
        currentValue: inputKeyResultUpdate.currentValueAfter,
        statusFlag: inputKeyResultUpdate.statusFlagAfter,
        dateOfUpdate: inputKeyResultUpdate.dateOfUpdate,
      };
      if (keyResultUpdate) {
        await updateKeyResultUpdateDb(
          inputKeyResultUpdate as UpdateKeyResultUpdateInput
        );

        if (isLatestKeyResultUpdate) {
          await updateKeyResultDb(updatedKeyResult);
        }
      } else {
        await updateKeyResultDb(updatedKeyResult);
        await addKeyResultUpdateDb(
          {
            ...inputKeyResultUpdate,
            creatorEmail: currentUser?.attributes.email,
          } as CreateKeyResultUpdateInput,
          goal?.employeeGoalsId != null,
          goal?.id || "",
          employees
        );
      }

      // Cannot reset state while it would bring the value of the old key result, thus clearing only the text.
      // This is seen in a small corner case when user does the key result update and then starts a new update right after that.
      setInputKeyResultUpdate((draft) => {
        draft.text = "";
      });
      onClose();
    } catch (error: any) {
      log(`Update KeyResult: ${error.message}`);
      setSaveError(intl.formatMessage({ id: "general.save.error" }));
      setSaving(false);
    }
  };

  const handleCancel = () => {
    resetState();
    onClose();
  };

  return (
    <LocalizeDatePicker dbUser={dbUser}>
      <Dialog
        open={open}
        onClose={handleCancel}
        fullWidth={true}
        maxWidth="lg"
        disableRestoreFocus
        onKeyUp={(e) => {
          if (e.key === "Enter") handleSave();
        }}
      >
        <DialogTitle>
          <Stack direction="row" spacing={1} alignItems={"center"}>
            <FormTitle>
              <FormattedMessage id="keyresults.update.caption" />
            </FormTitle>
            <HelpButton
              onClick={handleToggleHelp}
              data-cy="show-update-key-result-help"
            />
          </Stack>
        </DialogTitle>
        <DialogContent>
          <HelpCollapse
            showHelp={showHelp}
            helpText={intl.formatMessage({
              id: "keyresults.updates.help.text",
            })}
          />
          <Stack
            direction="row"
            spacing={3}
            alignItems={"center"}
            paddingTop={1}
          >
            <TextField
              autoFocus
              label={<FormattedMessage id="keyresults.update.current.value" />}
              type="number"
              variant="standard"
              autoComplete="off"
              helperText={error}
              error={error !== ""}
              value={inputKeyResultUpdate.currentValueAfter || ""}
              onChange={handleCurrentValueChange}
              data-cy="keyresults-update-current-value"
            />
            <TextField
              label={<FormattedMessage id="keyresults.update.target.value" />}
              type="number"
              variant="standard"
              autoComplete="off"
              value={keyResult.targetValue || ""}
              data-cy="keyresults-update-target-value"
              disabled
            />
            <FormControl
              variant="standard"
              sx={{ m: 1, minWidth: 120 }}
              onKeyUp={(e) => {
                if (e.key === "Enter") {
                  e.stopPropagation(); // Prevent closing the dialog when enter is used to select an item.
                }
              }}
              data-cy="keyresults-update-status"
            >
              <InputLabel id="select-statusflag-label">Status</InputLabel>
              <Select
                labelId="select-statusflag-label"
                value={inputKeyResultUpdate.statusFlagAfter?.toString()}
                label={
                  <FormattedMessage id="keyresults.update.current.status" />
                }
                onChange={handleStatusFlagChange}
              >
                <MenuItem value={KeyResultStatus.UNKNOWN}>
                  {getStatusFlagText(intl, KeyResultStatus.UNKNOWN)}
                </MenuItem>
                <MenuItem value={KeyResultStatus.COMPLETED}>
                  {getStatusFlagText(intl, KeyResultStatus.COMPLETED)}
                </MenuItem>
                <MenuItem value={KeyResultStatus.ON_TRACK}>
                  {getStatusFlagText(intl, KeyResultStatus.ON_TRACK)}
                </MenuItem>
                <MenuItem value={KeyResultStatus.BEHIND}>
                  {getStatusFlagText(intl, KeyResultStatus.BEHIND)}
                </MenuItem>
                <MenuItem value={KeyResultStatus.AT_RISK}>
                  {getStatusFlagText(intl, KeyResultStatus.AT_RISK)}
                </MenuItem>
                <MenuItem value={KeyResultStatus.FAILED}>
                  {getStatusFlagText(intl, KeyResultStatus.FAILED)}
                </MenuItem>
              </Select>
            </FormControl>

            <DatePicker
              value={dayjs(inputKeyResultUpdate.dateOfUpdate)}
              onChange={(value) => {
                handleUpdateDateChange(dayjs(value));
                {
                  /* the only way i found to get around types  */
                }
                // arrow function inside onChange : this will ensure that the handler function will always get Dayjs data type.
              }}
              label="Update date"
              disableFuture
              minDate={dayjs(keyResult.createdAt)}
              // minDate prevents the user from choosing an update date that is before the keyresult last update date.
              onError={(newError) => setDateError(newError)}
              slotProps={{
                textField: {
                  helperText: dateError,
                  error: dateError !== "",
                },
              }}
            />
          </Stack>

          <TextField
            id="Description"
            label={<FormattedMessage id="keyresults.update.description" />}
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            helperText={error}
            error={error !== ""}
            value={inputKeyResultUpdate.text}
            onChange={handleStatusTextChange}
            data-cy="keyresults-update-description"
          />
          {saveError && <Alert severity="error">{saveError}</Alert>}
        </DialogContent>
        <EditDialogActions
          saving={saving}
          onSave={handleSave}
          onCancel={handleCancel}
        />
      </Dialog>
    </LocalizeDatePicker>
  );
}
