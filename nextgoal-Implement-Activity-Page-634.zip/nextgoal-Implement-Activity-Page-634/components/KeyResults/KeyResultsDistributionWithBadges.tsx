import {
  calculateKeyResultsSummary,
  getKeyResultColor,
  getKeyResultFlagByIndex,
  getStatusFlagText,
} from "@/lib/webKeyResults";
import { KeyResult } from "@/src/API";
import Stack from "@mui/material/Stack";
import { useMemo } from "react";
import KeyResultIcon from "./KeyResultIcon";
import {
  DetailsText,
  DetailsTextWithoutCustomBox,
} from "../Common/Texts/Texts";
import { FormattedMessage, useIntl } from "react-intl";

interface KeyResultsDistributionWithBadgesProps {
  keyResults?: (KeyResult | null)[];
}

export default function KeyResultsDistributionWithBadges({
  keyResults,
}: KeyResultsDistributionWithBadgesProps) {
  const intl = useIntl();
  const krDistributionData = useMemo(() => {
    const summary = calculateKeyResultsSummary(
      undefined,
      undefined,
      keyResults
    );
    return summary.map((item, index) => ({
      name: getStatusFlagText(intl, getKeyResultFlagByIndex(index)),
      count: item,
      fill: getKeyResultColor(getKeyResultFlagByIndex(index)),
    }));
  }, [keyResults, intl]);

  return (
    <Stack>
      <Stack
        direction={{ xs: "column", md: "row" }}
        spacing={{ xs: 2, lg: 6 }}
        sx={{
          paddingTop: { xs: "20px" },
          paddingBottom: { xs: "10px" },
          overflow: "visible",
        }}
      >
        {krDistributionData.map((item, index) => {
          return (
            <Stack
              key={item.name}
              direction="row"
              spacing={0}
              alignItems="center"
            >
              <KeyResultIcon statusFlag={getKeyResultFlagByIndex(index)} />
              <DetailsTextWithoutCustomBox
                style={{ paddingLeft: "6px", whiteSpace: "nowrap" }}
              >
                {item.name}
              </DetailsTextWithoutCustomBox>
              <DetailsTextWithoutCustomBox style={{ paddingLeft: "6px" }}>
                {item.count}
              </DetailsTextWithoutCustomBox>
            </Stack>
          );
        })}
      </Stack>
      <Stack sx={{ alignItems: { xs: "center", md: "flex-start" } }}>
        <DetailsText
          sx={{
            marginTop: { sx: "12px", sm: "6px" },
          }}
        >
          <FormattedMessage
            id="keyresults.total.number.of.key.results"
            values={{ count: keyResults?.length || 0 }}
          />
        </DetailsText>
      </Stack>
    </Stack>
  );
}
