import { useMemo } from "react";
import { useGoals } from "@/contexts/GoalsContext";
import {
  getAllGoalsKeyResults,
  getKeyResults,
  calculateKeyResultsProgress,
} from "@/lib/webKeyResults";
import { Box, Grid } from "@mui/material";
import { Goal, KeyResult } from "@/src/API";
import GoalDetailRow from "../Goal/GoalDetailRow";
import { DetailsText, TabSubTitle } from "../Common/Texts/Texts";
import { FormattedMessage, useIntl } from "react-intl";
import KeyResultsDistGraph from "../Graphs/KeyResultsDistGraph";
interface AllKeyResultsProps {
  goalId?: string;
  organizationUnitGoals?: (Goal | null)[];
}
export default function AllKeyResults({
  goalId,
  organizationUnitGoals,
}: AllKeyResultsProps) {
  const goals = useGoals()?.goals;
  const intl = useIntl();
  const subgoalsKeyResults = useMemo(() => {
    const result = [] as (KeyResult | null)[];
    if (organizationUnitGoals) {
      organizationUnitGoals.forEach((goal) => {
        if (goal) {
          result.push(...getAllGoalsKeyResults(goal.id, goals));
        }
      });
    } else if (goalId) {
      result.push(...getAllGoalsKeyResults(goalId, goals));
    } else {
      result.push(...getKeyResults(goals));
    }
    return result;
  }, [goalId, goals, organizationUnitGoals]);
  const keyResultsProgress = useMemo(
    () => calculateKeyResultsProgress(subgoalsKeyResults),
    [subgoalsKeyResults]
  );
  return (
    <Box style={{ marginLeft: "9px", marginRight: "12px" }}>
      <Grid container spacing={1} alignItems="center" justifyContent="center">
        {/* Key results label */}
        <Grid item>
          <TabSubTitle>
            <FormattedMessage id="keyresults.title" />
          </TabSubTitle>
        </Grid>

        {/* Number of key results */}
        <Grid item>
          <DetailsText style={{ padding: "15px" }}>
            {subgoalsKeyResults?.length || 0}
          </DetailsText>
        </Grid>
      </Grid>
      <KeyResultsDistGraph keyResults={subgoalsKeyResults} />
    </Box>
  );
}
