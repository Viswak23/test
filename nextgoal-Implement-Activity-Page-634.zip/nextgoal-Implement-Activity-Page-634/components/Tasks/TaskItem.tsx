import React, { CSSProperties, useState } from "react";
import Stack from "@mui/material/Stack";
import { Box, IconButton, Tooltip } from "@mui/material";
import { Goal } from "@/src/API";
import Edit from "@mui/icons-material/Edit";
import GListItem from "../Common/GList/GListItem";
import { Task } from "@/src/API";
import { DetailsText } from "../Common/Texts/Texts";
import {
  TaskStatus,
  getTaskStatusColor,
  getTaskStatusString,
} from "@/lib/webTasks";
import { SportsScore } from "@mui/icons-material";
import { showDate } from "@/lib/time";
import SubItemComments from "../Comments/SubitemComments";
import CommentsIcons from "../Comments/CommentsIcons";
import DeleteButton from "../Common/Buttons/DeleteButton";
import { canDeleteDbItem } from "@/lib/webHelpers";
import { FormattedMessage, useIntl } from "react-intl";
import { useSettings } from "@/contexts/SettingsInfo";
import EditButton from "../Common/Buttons/EditButton";

interface TaskItemProps {
  currentGoal: Goal;
  task?: Task;
  canEdit?: boolean;
  onEdit?: (task: Task) => void;
  onDelete?: (task: Task) => void;
}

export default function TaskItem({
  currentGoal,
  task,
  canEdit = false,
  onEdit,
  onDelete,
}: TaskItemProps) {
  const [addingComment, setAddingComment] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const intl = useIntl();
  const dbUser = useSettings()?.dbUser;

  if (!task) {
    return null;
  }

  const handleEdit = () => {
    if (onEdit) {
      onEdit(task);
    }
  };

  const handleDelete = () => {
    if (onDelete) {
      onDelete(task);
    }
  };

  const handleAddComment = () => {
    setShowComments(true);
    setAddingComment(true);
  };

  const handleCloseAddComment = (saved: boolean) => {
    if (!saved && task.comments?.items?.length === 0) {
      setShowComments(false);
    }
    setAddingComment(false);
  };

  const handleShowComments = () => {
    setShowComments(true);
  };

  const handleHideComments = () => {
    setShowComments(false);
  };

  const rowStyle: CSSProperties | undefined =
    task.status === TaskStatus.COMPLETED || task.status === TaskStatus.CANCELLED
      ? { opacity: 0.6 }
      : undefined;

  if (rowStyle && task.status === TaskStatus.CANCELLED) {
    rowStyle.textDecoration = "line-through";
  }

  const commentsCount = task.comments?.items?.length || 0;

  return (
    <>
      <GListItem
        style={{ width: "100%" }}
        avatarEmail={task?.employee?.email}
        showNoAvatar
      >
        <Stack
          direction={"row"}
          spacing={1}
          alignItems={"center"}
          justifyContent={"space-between"}
          style={rowStyle}
        >
          <Stack direction="row" alignItems={"center"} spacing={1}>
            <DetailsText style={{ color: getTaskStatusColor(task.status) }}>
              {getTaskStatusString(intl, task.status)}
            </DetailsText>
            <DetailsText>{task.title}</DetailsText>
          </Stack>
          <Stack direction="row" spacing={1} alignItems={"center"}>
            <SportsScore />
            <DetailsText>
              {task.targetDate ? (
                showDate(task.targetDate, dbUser)
              ) : (
                <FormattedMessage id="tasks.no.target.date" />
              )}
            </DetailsText>
            {canEdit && (
              <Tooltip title={<FormattedMessage id="tasks.edit" />}>
                <EditButton onClick={handleEdit} />
              </Tooltip>
            )}
            <CommentsIcons
              showComments={showComments}
              addingComment={addingComment}
              commentsCount={commentsCount}
              onShowComments={handleShowComments}
              onHideComments={handleHideComments}
              onAddComment={handleAddComment}
            />
            {canEdit && (
              <DeleteButton
                disabled={!canDeleteDbItem(task)}
                onClick={handleDelete}
                tooltip={intl.formatMessage({ id: "tasks.delete.caption" })}
                disabledTooltip={intl.formatMessage({
                  id: "tasks.delete.disabled.tooltip",
                })}
              />
            )}
          </Stack>
        </Stack>
      </GListItem>
      {showComments && (
        <Box style={{ paddingLeft: "24px" }}>
          <SubItemComments
            comments={task.comments?.items}
            parentGoalId={currentGoal.id}
            addingComment={addingComment}
            onCloseAddComment={handleCloseAddComment}
            taskId={task.id}
          />
        </Box>
      )}
    </>
  );
}
