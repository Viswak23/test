import { SyntheticEvent, useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import TextField from "@mui/material/TextField";
import {
  Goal,
  Task,
  CreateTaskInput,
  UpdateTaskInput,
  Employee,
} from "@/src/API";
import {
  Alert,
  Autocomplete,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  SelectChangeEvent,
  Stack,
} from "@mui/material";
import { useImmer } from "use-immer";
import dayjs, { Dayjs } from "dayjs";
import {
  addTaskDb,
  updateTaskDb,
  getTaskStatusString,
  TaskStatus,
} from "@/lib/webTasks";
import { Label } from "@/components/Common/Texts/Texts";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { useEmployees } from "@/contexts/EmployeesContext";
import { useAuthStatus } from "@/lib/customHooks";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import { FormattedMessage, useIntl } from "react-intl";
import { log } from "@/lib/backend/actions/logger";
import LocalizeDatePicker from "../LocalizeDatePicker/LocalizeDatePicker";
import { useSettings } from "@/contexts/SettingsInfo";

interface EditTaskProps {
  currentGoal: Goal;
  task?: Task;
  open: boolean;
  onClose: () => void;
}

const defaultTask = {
  title: "",
  description: "",
  companyId: "placeholder",
  status: TaskStatus.NOT_STARTED,
  creatorEmail: "placeholder",
};

export default function EditTask({
  currentGoal,
  task,
  open,
  onClose,
}: EditTaskProps) {
  const [editTask, setEditTask] = useImmer<CreateTaskInput | UpdateTaskInput>(
    task || { ...defaultTask }
  );
  // Datepicker uses dayjs values, save that and in save convert toISOString for dynamo
  const [startDate, setStartDate] = useState<Dayjs | null>(
    task?.startDate ? dayjs(task.startDate) : null
  );
  const [targetDate, setTargetDate] = useState<Dayjs | null>(
    task?.targetDate ? dayjs(task.targetDate) : null
  );
  const [assignedTo, setAssignedTo] = useState<Employee | null>(
    task?.employee || null
  );
  const [saving, setSaving] = useState(false);
  const [savingError, setSavingError] = useState("");
  const employees = useEmployees()?.employees;
  const currentUser = useAuthStatus();
  const intl = useIntl();
  const dbUser = useSettings()?.dbUser;

  const handleTitleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setEditTask((draft) => {
      draft.title = event.target.value;
    });
  };

  const handleDescriptionChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditTask((draft) => {
      draft.description = event.target.value;
    });
  };

  const handleStatusChange = (event: SelectChangeEvent) => {
    setEditTask((draft) => {
      draft.status = event.target.value as TaskStatus;
    });
  };

  const handleStartDateChange = (value: Dayjs | null) => {
    setStartDate(value);
  };

  const handleTargetDateChange = (value: Dayjs | null) => {
    setTargetDate(value);
  };

  const handleAssignedToChange = (
    event: SyntheticEvent<Element, Event> | null,
    selectedEmployee: Employee | null
  ) => {
    setAssignedTo(selectedEmployee);
  };

  const resetState = () => {
    setEditTask(task || { ...defaultTask });
    setStartDate(task?.startDate ? dayjs(task.startDate) : null);
    setTargetDate(task?.targetDate ? dayjs(task.targetDate) : null);
    setAssignedTo(task?.employee || null);
    setSaving(false);
    setSavingError("");
  };

  const handleCancel = () => {
    resetState();
    onClose();
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      const updateObject = {
        ...editTask,
        employeeTasksId: assignedTo?.id,
      };

      // Dates must be separately handled.
      if (startDate) {
        updateObject.startDate = startDate.toISOString();
      }
      if (targetDate) {
        updateObject.targetDate = targetDate.toISOString();
      }

      if (!task) {
        await addTaskDb({
          ...updateObject,
          goalTasksId: currentGoal.id,
          creatorEmail: currentUser?.attributes.email,
        } as CreateTaskInput);
        resetState();
      } else {
        await updateTaskDb(updateObject as UpdateTaskInput);
      }

      onClose();
    } catch (error: any) {
      log(`Add/Edit Task: ${error.message}`);
      setSaving(false);
      setSavingError(intl.formatMessage({ id: "general.save.error" }));
    }
  };

  const dialogTitle = task ? (
    <FormattedMessage id="tasks.edit" />
  ) : (
    <FormattedMessage id="tasks.add" />
  );

  return (
    <LocalizeDatePicker dbUser={dbUser}>
      <Dialog
        open={open}
        onClose={handleCancel}
        fullWidth={true}
        maxWidth="lg"
        disableRestoreFocus
      >
        <DialogTitle>{dialogTitle}</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            id="title"
            label={<FormattedMessage id="tasks.task.title" />}
            type="title"
            fullWidth
            variant="standard"
            autoComplete="off"
            value={editTask.title || ""}
            onChange={handleTitleChange}
          />
          <TextField
            margin="dense"
            id="description"
            label={<FormattedMessage id="tasks.task.description" />}
            type="description"
            fullWidth
            variant="standard"
            autoComplete="off"
            value={editTask.description || ""}
            onChange={handleDescriptionChange}
          />
          <Stack
            direction="row"
            spacing={2}
            style={{ marginTop: "6px", marginBottom: "12px" }}
            alignItems="center"
          >
            <Stack direction="column" spacing={1}>
              <Label>
                <FormattedMessage id="tasks.task.start.date" />
              </Label>
              <DatePicker value={startDate} onChange={handleStartDateChange} />
            </Stack>
            <Stack direction="column" spacing={1}>
              <Label>
                <FormattedMessage id="tasks.task.target.date" />
              </Label>
              <DatePicker
                value={targetDate}
                onChange={handleTargetDateChange}
              />
            </Stack>
            <FormControl
              variant="standard"
              sx={{ m: 1, minWidth: 120 }}
              onKeyUp={(e) => {
                if (e.key === "Enter") {
                  e.stopPropagation(); // Prevent closing the dialog when enter is used to select an item.
                }
              }}
            >
              <InputLabel id="select-status-label">
                <FormattedMessage id="tasks.task.status" />
              </InputLabel>
              <Select
                labelId="select-status-label"
                value={editTask.status?.toString()}
                label="Status"
                onChange={handleStatusChange}
              >
                <MenuItem value={TaskStatus.NOT_STARTED}>
                  {getTaskStatusString(intl, TaskStatus.NOT_STARTED)}
                </MenuItem>
                <MenuItem value={TaskStatus.IN_PROGRESS}>
                  {getTaskStatusString(intl, TaskStatus.IN_PROGRESS)}
                </MenuItem>
                <MenuItem value={TaskStatus.ON_HOLD}>
                  {getTaskStatusString(intl, TaskStatus.ON_HOLD)}
                </MenuItem>
                <MenuItem value={TaskStatus.COMPLETED}>
                  {getTaskStatusString(intl, TaskStatus.COMPLETED)}
                </MenuItem>
                <MenuItem value={TaskStatus.CANCELLED}>
                  {getTaskStatusString(intl, TaskStatus.CANCELLED)}
                </MenuItem>
              </Select>
            </FormControl>
            <Autocomplete
              id="employee-select"
              options={employees || []}
              getOptionLabel={(option) => option?.name || ""}
              isOptionEqualToValue={(option, value) => option?.id === value?.id}
              sx={{ width: 300 }}
              value={assignedTo}
              onChange={handleAssignedToChange}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label={<FormattedMessage id="tasks.task.assigned.to" />}
                />
              )}
            />
          </Stack>
          {savingError && <Alert severity="error">{savingError}</Alert>}
        </DialogContent>
        <EditDialogActions
          saving={saving}
          onSave={handleSave}
          onCancel={handleCancel}
        />
      </Dialog>
    </LocalizeDatePicker>
  );
}
