import { useState } from "react";
import TaskItem from "./TaskItem";
import EditTask from "./EditTask";
import GTabPanel from "../Common/GTabPanel/GTabPanel";
import { Goal, Task } from "@/src/API";
import { compareTasksByStatus, deleteTaskDb } from "@/lib/webTasks";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import { useIntl } from "react-intl";

interface TasksProps {
  goal: Goal;
  canAdd?: boolean;
  canEdit?: boolean;
}

export default function Tasks({
  goal,
  canAdd = false,
  canEdit = false,
}: TasksProps) {
  const [addingTask, setAddingTask] = useState(false);
  const [editing, setEditing] = useState<Task | undefined>();
  const [deleteTask, setDeleteTask] = useState<Task | undefined>();
  const [saving, setSaving] = useState(false);
  const intl = useIntl();

  const handleAdd = () => {
    setAddingTask(true);
  };

  const handleEdit = (task: Task) => {
    setEditing(task);
  };

  const handleCloseEdit = () => {
    setAddingTask(false);
    setEditing(undefined);
  };

  const handleDelete = (task: Task) => {
    setDeleteTask(task);
  };

  const handleDeleteConfirmed = async () => {
    if (!deleteTask) {
      return;
    }

    setSaving(true);
    await deleteTaskDb(deleteTask.id);
    setDeleteTask(undefined);
    setSaving(false);
  };

  const handleCancelDelete = () => {
    setDeleteTask(undefined);
  };

  const tasks = [...(goal?.tasks?.items || [])].sort(compareTasksByStatus);

  return (
    <>
      <GTabPanel
        onAdd={canAdd ? handleAdd : undefined}
        addDisabled={addingTask}
        addLabel={intl.formatMessage({ id: "general.add" })}
      >
        {tasks.map(
          (task) =>
            task && (
              <TaskItem
                key={task.id}
                currentGoal={goal}
                task={task}
                canEdit={canEdit}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            )
        )}
      </GTabPanel>
      <EditTask
        key={editing?.id || "newTask"}
        currentGoal={goal}
        open={addingTask || !!editing}
        task={editing}
        onClose={handleCloseEdit}
      />
      <ConfirmationDialog
        title={intl.formatMessage({ id: "tasks.delete.caption" })}
        message={intl.formatMessage({ id: "tasks.delete.confirmation" })}
        messageItem={`${deleteTask?.title || ""}?`}
        open={deleteTask !== undefined}
        saving={saving}
        onCancel={handleCancelDelete}
        onConfirm={handleDeleteConfirmed}
      />
    </>
  );
}
