import { useNotifications } from "@/contexts/NotificationContext";
import React from "react";
import NotificationItem from "./NotificationItem";
import { Box, Button, Modal, Stack, Typography } from "@mui/material";
import theme from "@/config/theme";
import { ClickableText, LightText } from "../Common/Texts/Texts";
import { FormattedMessage } from "react-intl";

export default function AllNotificationsModal({
  handleCloseDropdown,
  updateReadStatus,
}: {
  handleCloseDropdown: () => void;
  updateReadStatus: () => void;
}) {
  const [showModal, setShowModal] = React.useState(false);
  const notifications = useNotifications()?.notifications!;
  const unReadNotificationsCount =
    notifications.filter((n) => !n.isRead).length || 0;

  const handleShowModal = () => {
    handleCloseDropdown(); // this closes the dropdown of the notification.
    setShowModal((prev) => !prev);
  };
  return (
    <>
      <Button
        fullWidth
        sx={{
          color: theme.palette.primary.light,
          borderTop: `1px solid ${theme.palette.grey[300]}`,
          borderRadius: " 0px 0px 10px 10px ",
          backgroundColor: theme.palette.common.white,
        }}
        onClick={handleShowModal}
      >
        <FormattedMessage id="notifications.viewall" />
      </Button>

      <Modal
        open={showModal}
        onClose={handleShowModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
        sx={{
          display: "flex",
          justifyContent: { xs: "center", sm: "center" },
          alignItems: { xs: "center", sm: "center" },
        }}
      >
        <Stack
          justifyContent={"space-between"}
          sx={{
            padding: "20px",
            width: {
              sm: "400px",
              xs: "80%",
            },
            maxHeight: "500px",
            backgroundColor: theme.palette.common.white,
            borderRadius: "10px ",
          }}
        >
          {unReadNotificationsCount > 0 && (
            <Box onClick={updateReadStatus}>
              <ClickableText>
                <FormattedMessage id="notifications.markall" />
              </ClickableText>
            </Box>
          )}
          <Stack height={"100%"} overflow={"auto"} alignItems={"center"}>
            {notifications?.length == 0 && (
              <LightText
                sx={{
                  fontSize: "14px",
                  color: theme.palette.common.black,
                  padding: "20px",
                  textAlign: "center",
                  opacity: 0.5,
                }}
              >
                <FormattedMessage id="notifications.no.notifications" />
              </LightText>
            )}
            {notifications?.map((notification) => {
              return (
                <NotificationItem
                  notification={notification}
                  key={notification.id}
                />
              );
            })}
            <Button disabled>
              <FormattedMessage id="notifications.show.more" />
            </Button>
          </Stack>
          <Button onClick={handleShowModal}>
            <FormattedMessage id="general.close" />
          </Button>
        </Stack>
      </Modal>
    </>
  );
}
