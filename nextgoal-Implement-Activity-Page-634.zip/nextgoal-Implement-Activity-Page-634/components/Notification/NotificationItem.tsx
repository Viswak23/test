import { Avatar, Box, Stack } from "@mui/material";
import React, { useEffect } from "react";
import {
  FeedDaysAgoTxt,
  NotificationBody,
  NotificationTitle,
} from "../Common/Texts/Texts";
import theme from "@/config/theme";
import { getEmployeeByEmail } from "@/lib/webEmployee";
import { Event, Notification } from "@/src/API";
import { useEmployees } from "@/contexts/EmployeesContext";
import {
  getNotificationInfo,
  NotificationType,
  updateReadStatusDb,
} from "@/lib/webNotifications";
import { EventType, getEventById } from "@/lib/webEvents";
import { useIntl } from "react-intl";
import { NotificationTimeAgo } from "@/lib/time";
import { log } from "@/lib/backend/actions/logger";
import { useRouter } from "next/navigation";
import { hoverWhiteToGray } from "@/config/styling";
export default function NotificationItem({
  notification,
  onClose,
}: {
  notification: Notification;
  onClose?: () => void;
}) {
  const employees = useEmployees()?.employees;
  const employee = getEmployeeByEmail(employees, notification?.owner);

  const router = useRouter();
  const intl = useIntl();

  if (!employee) return null;

  const notificationInfo = getNotificationInfo(
    notification.notificationType as NotificationType | EventType,
    employee!,
    intl.locale
  );
  const handleRedirect = async () => {
    await updateReadStatus();
    if (notification.eventId) {
      router.replace(`/feeds/${notification.eventId}`);
    } else if (notification.goalId) {
      router.replace(`/goals/${notification.goalId}`);
    } else return;
    if (onClose) onClose();
  };

  const updateReadStatus = async () => {
    if (!notification || notification.isRead === true) return;
    const newNotification = {
      id: notification.id,
      owner: notification.owner,
      type: notification.type,
      toEmployeeEmail: notification.toEmployeeEmail,
      isRead: true,
    };
    try {
      await updateReadStatusDb(newNotification);
    } catch (error: any) {
      log("Error updating notification read status" + error.message);
    }
  };
  if (notificationInfo.title.length <= 0) {
    return null;
  }
  return (
    <Stack
      direction={"row"}
      alignItems={"center"}
      sx={{
        backgroundColor: "common.white",
        color: "black",
        padding: "10px 5px",
        width: "100%",

        ...hoverWhiteToGray(theme),
      }}
      onClick={handleRedirect}
    >
      {/* Notification item */}
      <Box position={"relative"}>
        <Avatar
          src={employee?.resolvedAvatarUrl}
          sx={{
            width: "30px",
            height: "30px",
            marginX: "5px",
          }}
        />
        {notification.isRead === false && (
          <Box
            sx={{
              width: "8px",
              height: "8px",
              borderRadius: "30px",
              backgroundColor: "customColors.lightred",
            }}
            position={"absolute"}
            top={0}
            right={6}
          />
        )}
      </Box>
      <Stack px={1} width={"100%"}>
        <Stack
          direction={"row"}
          justifyContent={"space-between"}
          alignItems={"end"}
        >
          <NotificationTitle
            sx={{ display: "flex", justifyContent: "space-between" }}
          >
            {notificationInfo.title}
          </NotificationTitle>
          <FeedDaysAgoTxt>
            {NotificationTimeAgo(notification.createdAt, intl)}
          </FeedDaysAgoTxt>
        </Stack>
        <NotificationBody>{notificationInfo.description}</NotificationBody>
      </Stack>
    </Stack>
  );
}
