import { Box, IconButton, Slide, Stack, Typography } from "@mui/material";
import NotificationsIcon from "@mui/icons-material/Notifications";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";

import { LightText, NotificationHeader } from "../Common/Texts/Texts";
import { memo, useCallback, useEffect, useRef, useState } from "react";
import { hoverMenuItem } from "@/config/styling";
import theme from "@/config/theme";
import { FormattedMessage, useIntl } from "react-intl";
import NotificationItem from "./NotificationItem";
import { useNotifications } from "@/contexts/NotificationContext";
import { updateReadStatusDb } from "@/lib/webNotifications";
import { log } from "@/lib/backend/actions/logger";
import AllNotificationsModal from "./AllNotificationsModal";

export default memo(function NotificationMenu() {
  const [showNotifications, setShowNotifications] = useState(false);
  const notifications = useNotifications()?.notifications!;
  const unReadNotificationsCount =
    notifications.filter((n) => !n.isRead).length || 0;
  const buttonRef = useRef<HTMLButtonElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const intl = useIntl();
  const notificationLabel = intl.formatMessage({
    id: "general.notification",
  });

  const updateReadStatus = async () => {
    if (notifications?.length == 0 || unReadNotificationsCount == 0) return;

    await Promise.all(
      notifications?.map(async (notification) => {
        if (notification.isRead) return;
        const newNotification = {
          id: notification.id,
          owner: notification.owner,
          type: notification.type,
          toEmployeeEmail: notification.toEmployeeEmail,
          isRead: true,
        };
        try {
          await updateReadStatusDb(newNotification);
        } catch (error: any) {
          log("Error updating notification read status" + error.message);
        }
      })
    );
  };
  const handleMarkAll = async () => {
    toggleShowNotifications();
    await updateReadStatus();
  };
  const toggleShowNotifications = useCallback(async () => {
    setShowNotifications(!showNotifications);
  }, [showNotifications]);
  const handleClose = () => {
    setShowNotifications(false);
  };
  useEffect(() => {
    if (!showNotifications) return;
    const handleClickOutside = async (event: any) => {
      if (
        !containerRef.current ||
        !containerRef.current.contains(event.target)
      ) {
        await toggleShowNotifications();
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [toggleShowNotifications, showNotifications]);
  return (
    <>
      <IconButton
        ref={buttonRef}
        size="large"
        aria-label={notificationLabel}
        onClick={toggleShowNotifications}
        color="inherit"
        sx={{ ...hoverMenuItem(theme), position: "relative" }}
      >
        {showNotifications ? <NotificationsIcon /> : <NotificationsNoneIcon />}
        {unReadNotificationsCount > 0 && (
          <Box
            sx={{
              width: "8px",
              height: "8px",
              fontSize: "10px",
              borderRadius: "30px",
              backgroundColor: "customColors.lightred",
            }}
            position={"absolute"}
            top={15}
            right={15}
          />
        )}
      </IconButton>
      <Slide in={showNotifications} container={containerRef.current}>
        <Stack
          ref={containerRef}
          display={showNotifications ? "block" : "none"}
          position={"absolute"}
          zIndex={10}
          right={{ sm: 80, xs: 0 }}
          left={{ xs: 0, sm: "auto" }}
          mx={{ xs: "auto", sm: 0 }}
          top={75}
          sx={{
            backgroundColor: theme.palette.customColors.background,
            borderRadius: "10px",
            boxShadow: "0px 4px 20px rgba(0, 0, 0, 0.3)",
            width: {
              xs: "100%",
              sm: "400px",
            },
            height: { xs: "100%", sm: "auto" },
          }}
        >
          <Stack
            direction={"row"}
            justifyContent={"space-between"}
            alignItems={"center"}
            paddingX={"10px"}
            width={"100%"}
            sx={{ backgroundColor: theme.palette.common.white }}
            borderRadius={"10px 10px 0px 0px "}
            borderBottom={"1px solid " + theme.palette.divider}
          >
            <NotificationHeader style={{ color: theme.palette.common.black }}>
              {notificationLabel}
            </NotificationHeader>
            {unReadNotificationsCount > 0 && (
              <Typography
                onClick={handleMarkAll}
                sx={{
                  fontSize: "14px",
                  color: theme.palette.primary.light,
                  ":hover": {
                    cursor: "pointer",
                    color: theme.palette.customColors.pressed,
                  },
                }}
              >
                <FormattedMessage id="notifications.markall" />
              </Typography>
            )}
          </Stack>
          {/* Render notifications */}
          <Stack
            width={"100%"}
            overflow={"auto"}
            maxHeight={{ xs: "75vh", sm: 350 }}
          >
            {notifications?.length == 0 && (
              <LightText
                sx={{
                  fontSize: "14px",
                  color: theme.palette.common.black,
                  padding: "20px",
                  textAlign: "center",
                  opacity: 0.5,
                }}
              >
                <FormattedMessage id="notifications.no.notifications" />
              </LightText>
            )}
            {notifications?.map((notification) => (
              <NotificationItem
                notification={notification}
                key={notification.id}
                onClose={toggleShowNotifications}
              />
            ))}
          </Stack>
          <AllNotificationsModal
            handleCloseDropdown={handleClose}
            updateReadStatus={updateReadStatus}
          />
        </Stack>
      </Slide>
    </>
  );
});
