import { Theme } from "@emotion/react";
import { Skeleton, SxProps, Typography } from "@mui/material";
import { ReactNode, CSSProperties } from "react";

type FontWeight = 'normal' | 'bold' | 500;

interface TextsProps {
  children: ReactNode;
  style?: CSSProperties;
  dataCy?: string;  // Remove if not needed
  sx?: SxProps<Theme>;
}

const fontSizes = {
  heading1: "2rem",
  heading2: "1.5rem",
  heading3: "1.38rem",
  heading4: "1.13rem",
  heading5: "1rem",
  heading6: "0.88rem",
  paragraph1: "1rem",
  paragraph2: "1rem",
  paragraph3: "0.88rem",
  paragraph4: "0.88rem",
  paragraph5: "0.81rem",
};

export function Heading1({ children, style }: TextsProps) {
  return (
    <Typography
      variant="h1"
      sx={{
        fontSize: fontSizes.heading1,
        fontWeight: "bold",
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function Heading1Skeleton() {
  return <TextSkeleton fontSize={fontSizes.heading1} />;
}
export function Heading2({ children, style }: TextsProps) {
  return (
    <Typography
      variant="h2"
      sx={{
        fontSize: fontSizes.heading2,
        fontWeight: "bold",
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function Heading2Skeleton() {
  return <TextSkeleton fontSize={fontSizes.heading2} />;
}
export function Heading3({ children, style }: TextsProps) {
  return (
    <Typography
      variant="h3"
      sx={{
        fontSize: fontSizes.heading3,
        fontWeight: "bold",
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function Heading3Skeleton() {
  return <TextSkeleton fontSize={fontSizes.heading3} />;
}
export function Heading4({ children, style, sx }: TextsProps) {
  return (
    <Typography
      variant="h4"
      sx={{
        fontSize: fontSizes.heading4,
        fontWeight: "bold",
        ...sx,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function Heading4Skeleton() {
  return <TextSkeleton fontSize={fontSizes.heading4} />;
}
export function Heading5({ children, style }: TextsProps) {
  return (
    <Typography
      variant="h5"
      sx={{
        fontSize: fontSizes.heading5,
        fontWeight: "bold",
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function Heading5Skeleton() {
  return <TextSkeleton fontSize={fontSizes.heading5} />;
}
export function Heading6({ children, style }: TextsProps) {
  return (
    <Typography
      variant="h6"
      sx={{
        fontSize: fontSizes.heading6,
        fontWeight: "bold",
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function Heading6Skeleton() {
  return <TextSkeleton fontSize={fontSizes.heading6} />;
}
export function Paragraph1({ children, style }: TextsProps) {
  return (
    <Typography
      variant="body1"
      sx={{
        fontSize: fontSizes.paragraph1,
        fontWeight: 500,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function Paragraph1Skeleton() {
  return <TextSkeleton fontSize={fontSizes.paragraph1} />;
}
export function Paragraph2({ children, style }: TextsProps) {
  return (
    <Typography
      variant="body1"
      sx={{
        fontSize: fontSizes.paragraph2,
        fontWeight: "normal",
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function Paragraph2Skeleton() {
  return <TextSkeleton fontSize={fontSizes.paragraph2} />;
}
export function Paragraph3({ children, style, sx }: TextsProps) {
  return (
    <Typography
      variant="body1"
      sx={{
        fontSize: fontSizes.paragraph3,
        fontWeight: 500,
        ...sx,
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function Paragraph3Skeleton() {
  return <TextSkeleton fontSize={fontSizes.paragraph3} />;
}
export function Paragraph4({ children, style }: TextsProps) {
  return (
    <Typography
      variant="body1"
      sx={{
        fontSize: fontSizes.paragraph4,
        fontWeight: "normal",
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function Paragraph4Skeleton() {
  return <TextSkeleton fontSize={fontSizes.paragraph4} />;
}
export function Paragraph5({ children, style }: TextsProps) {
  return (
    <Typography
      variant="body1"
      sx={{
        fontSize: fontSizes.paragraph5,
        fontWeight: "normal",
      }}
      style={{ ...style }}
    >
      {children}
    </Typography>
  );
}
export function Paragraph5Skeleton() {
  return <TextSkeleton fontSize={fontSizes.paragraph5} />;
}

// Define a generic TextSkeleton component
interface TextSkeletonProps {
  fontSize: string;
}

export function TextSkeleton({ fontSize }: TextSkeletonProps) {
  return <Skeleton variant="text" sx={{ fontSize }} animation="wave" />;
}
