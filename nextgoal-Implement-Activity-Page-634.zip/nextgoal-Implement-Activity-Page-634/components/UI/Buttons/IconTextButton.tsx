import theme from "@/config/theme";
import { Button } from "@mui/material";
import React from "react";
import { Paragraph3 } from "../Texts/Texts";

const iconTextButtonStyles = {
  display: "flex",
  flexDirection: "row",
  justifyContent: "start",
  paddingY: "8px",
  paddingX: "12px",
  color: theme.palette.customColors.newBlack,
  borderRadius: "10px",
  transition: "background 0.2s",
  ":hover": {
    bgcolor: theme.palette.customColors.newWhiteOff,
  },
  width: "100%",
} as const;

interface IconTextButton {
  label: string;
  Icon: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean; // Add the disabled prop
}

export default function IconTextButton({
  label,
  Icon,
  onClick,
  disabled, // Add the disabled parameter
 'aria-label': ariaLabel,
}: IconTextButton & { 'aria-label'?: string }) {
  return (
    <Button
      onClick={onClick}
      disabled={disabled} // Use the disabled prop
      sx={{
        ...iconTextButtonStyles,
    ...(disabled && {
      opacity: 0.5,
      pointerEvents: 'none'
    })
      }}
    >
      {Icon}
      <Paragraph3
        style={{
          marginLeft: "12px",
        }}
      >
        {label}
      </Paragraph3>
    </Button>
  );
}
