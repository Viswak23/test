import { IconButton, Tooltip } from "@mui/material";
import React from "react";

interface ButtonIconProps {
  Icon: React.ReactNode;
  tooltip: string;
  onClick: () => void;
  disabled?: boolean;
  color?: 'inherit' | 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning';
  size?: 'small' | 'medium' | 'large';
  sx?: object;
}
export default function ButtonIcon({
  Icon,
  tooltip,
  onClick,
  disabled,
  color = 'primary',
  size = 'medium',
  sx,
}: ButtonIconProps) {
  return (
    <Tooltip title={disabled ? '' : tooltip}>
      <span>
        <IconButton
          aria-label={tooltip}
          onClick={onClick}
          disabled={disabled}
          color={color}
          size={size}
          sx={sx}
        >
        {Icon}
        </IconButton>
      </span>
    </Tooltip>
  );
}
