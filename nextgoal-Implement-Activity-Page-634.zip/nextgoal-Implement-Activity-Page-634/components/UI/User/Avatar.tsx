import { Avatar, Skeleton } from "@mui/material";

interface AvatarProps {
  size: "sm" | "md" | "lg" | "xl";
  image?: string;
  alt: string | undefined;
}

const sizeLookup = {
  sm: 40,
  md: 56,
  lg: 70,
  xl: 128,
} as const;

const getImageSize = (size: keyof typeof sizeLookup): number => {
  const imageSize = sizeLookup[size];
  if (!imageSize) {
    throw new Error(`Invalid size: ${size}`);
  }
  return imageSize;
};

export function CustomAvatar({ size, image, alt }: AvatarProps) {
  let imageSize: number;
  try {
    imageSize = getImageSize(size);
  } catch (error) {
    console.error(error);
    imageSize = sizeLookup.md; // Fallback to medium size
  }

  return (
    <Avatar
      alt={alt}
      src={image}
      sx={{
        width: imageSize,
        height: imageSize,
      }}
    />
  );
}

export function CustomAvatarSkeleton({ size }: AvatarProps) {
  const imageSize = getImageSize(size);

  return <Skeleton variant="circular" width={imageSize} height={imageSize} />;
}
