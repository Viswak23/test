import { useTheme } from "@mui/material";
import logo from "@/public/logo.svg";
import { ListItem, ListItemIcon, ListItemText, Stack } from "@mui/material";
import Image from "next/image";
import { useIntl } from "react-intl";

interface LogoProps {
  open: boolean;
}
export default function Logo({ open }: LogoProps) {
  const theme = useTheme();
  const intl = useIntl();
  return (
    <ListItem
      sx={{
        display: "flex",
        flexDirection: open ? "row" : "column",
        alignItems: "center",
        paddingY: "8px",
        paddingX: "12px",
        color: theme.palette.customColors.newBlack,
        borderRadius: "10px",

        width: "100%",
      }}
    >
      <Stack
        direction={"row"}
        sx={{
          width: "100%",
          borderRadius: "10px",
          alignItems: "center",
          justifyContent: open ? "initial" : "center",
        }}
      >
        <ListItemIcon
          sx={[
            {
              minWidth: 0,
              justifyContent: "center",
            },
            open
              ? {
                  mr: 3,
                }
              : {
                  mr: "auto",
                },
          ]}
        ><Image src={logo} width={30} height={30} alt="Workzep Logo" priority /><Image src={logo} width={30} height={30} alt="Workzep Logo" />
        </ListItemIcon>
        <ListItemText
          primary={intl.formatMessage({ id: "application.title" })}
          sx={{
            opacity: open ? 1 : 0,
          }}
        />
        {/* <Heading4>Workzep</Heading4> */}
      </Stack>
    </ListItem>
  );
}
