import {
  Button,
  ListItem,
  ListItemIcon,
  ListItemText,
  Skeleton,
  Box,
} from "@mui/material";
import React from "react";
import theme from "@/config/theme";
import Link from "next/link";
import { LucideIcon } from "lucide-react";
import { Paragraph1Skeleton } from "../Texts/Texts";

interface NavItem {
  variant?: "link" | "button";
  onClick?: () => void;
  Icon: LucideIcon;
  open: boolean;
  active?: boolean;
  label: string;
  link?: string;
}
export function NavItem({
  Icon,
  active,
  label,
  link,
  open,
  variant = "link",
  onClick,
}: NavItem) {
  return (
    <ListItem
      sx={[
        {
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          color: active ? theme.palette.primary.main : null,
          borderRadius: "10px",
          transition: "all 0.1s ease-in-out",
          ":hover": {
            background: theme.palette.customColors.newWhiteOff,
          },
          width: "100%",
        },
        variant === "link"
          ? {
              paddingY: "8px",
              paddingX: "12px",
            }
          : {
              padding: 0,
            },
      ]}
    >
      {variant === "link" && link ? (
        <Link
          aria-label={label}
          data-cy={`nav-link-${label}`}
          href={link!}
          style={{
            display: "flex",
            width: "100%",
            borderRadius: "10px",
            justifyContent: open ? "initial" : "center",
            alignItems: "center",
          }}
        >
          <ListItemIcon
            sx={[
              {
                color: active ? theme.palette.primary.main : null,
                minWidth: 0,
                justifyContent: "center",
              },
              open
                ? {
                    mr: 3,
                  }
                : {
                    mr: "auto",
                  },
            ]}
          >
            <Icon
              strokeWidth={1.25}
              {...(active && {
                fill: theme.palette.primary.main,
              })}
            />
          </ListItemIcon>
          <ListItemText
            primary={label}
            sx={[
              open
                ? {
                    opacity: 1,
                  }
                : {
                    opacity: 0,
                  },
            ]}
          />
        </Link>
      ) : (
        <Button
          aria-label={label}
          data-cy={`nav-button-${label}`}
          onClick={onClick}
          sx={{
            display: "flex",
            minWidth: "100%",
            minHeight: "100%",
            borderRadius: "10px",
            justifyContent: open ? "initial" : "center",
            "&.MuiButtonBase-root:hover": {
              bgcolor: "transparent",
            },
            ":active": {
              backgroundColor: "transparent",
            },
            paddingY: "8px",
            paddingX: "12px",
            alignItems: "center",
            color: "inherit",
          }}
        >
          <ListItemIcon
            sx={[
              {
                minWidth: 0,
                justifyContent: "center",
              },
              open
                ? {
                    mr: 3,
                  }
                : {
                    mr: "auto",
                  },
            ]}
          >
            <Icon
              strokeWidth={1.25}
              {...(active && {
                fill: theme.palette.primary.main,
              })}
            />
          </ListItemIcon>
          <ListItemText
            primary={label}
            sx={[
                open
                  ? {
                      opacity: 1,
                      textAlign: "start",
                    }
                  : {
                      opacity: 0,
                    },
              ]}
          />
        </Button>
      )}
    </ListItem>
  );
}

export function NavItemSkeleton({ open }: { open: boolean }) {
  return (
    <ListItem
      sx={[
        {
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          borderRadius: "10px",
          width: "100%",
        },
      ]}
    >
      <Box
        style={{
          display: "flex",
          width: "100%",
          borderRadius: "10px",
          justifyContent: open ? "initial" : "center",
          alignItems: "center",
        }}
      >
        <ListItemIcon
          sx={[
            {
              minWidth: 0,

              justifyContent: "center",
            },
            open
              ? {
                  mr: 3,
                }
              : {
                  mr: "auto",
                },
          ]}
        >
          <Skeleton variant="rounded" width={24} height={24} animation="wave" />
        </ListItemIcon>
        <Box
          width={"100%"}
          sx={[
            open
              ? {
                  opacity: 1,
                }
              : {
                  opacity: 0,
                },
          ]}
        >
          <Paragraph1Skeleton />
        </Box>
      </Box>
    </ListItem>
  );
}
