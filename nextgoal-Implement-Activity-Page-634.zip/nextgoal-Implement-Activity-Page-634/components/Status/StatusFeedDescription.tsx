import { Status } from "@/src/API";
import { Stack } from "@mui/material";
import { DetailsLabel, DetailsText, ListText } from "../Common/Texts/Texts";
import { FormattedMessage } from "react-intl";

interface StatusFeedDescriptionProps {
  status?: Status | null;
}

export default function StatusFeedDescription({
  status,
}: StatusFeedDescriptionProps) {
  return (
    <Stack direction="column" spacing={2} data-cy="status-feed-item">
      <ListText>{status?.status}</ListText>

      <Stack direction="column" spacing={0}>
        <DetailsLabel>
          <FormattedMessage id="status.going.well" />
        </DetailsLabel>
        <ListText>{status?.goingWell}</ListText>
      </Stack>

      <Stack direction="column" spacing={0}>
        <DetailsLabel>
          <FormattedMessage id="status.challenges" />
        </DetailsLabel>
        <ListText>{status?.challenges}</ListText>
      </Stack>

      <Stack direction="column" spacing={0}>
        <DetailsLabel>
          <FormattedMessage id="status.room.for.improvement" />
        </DetailsLabel>
        <ListText>{status?.toImprove}</ListText>
      </Stack>
    </Stack>
  );
}
