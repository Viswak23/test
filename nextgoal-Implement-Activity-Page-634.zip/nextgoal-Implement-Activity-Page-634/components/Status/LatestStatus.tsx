import { useState } from "react";
import { Goal, Status } from "@/src/API";
import { DetailsLabel } from "../Common/Texts/Texts";
import { Stack, Tooltip, useMediaQuery, Theme, useTheme } from "@mui/material";
import { IconButton } from "@mui/material";
import { AddCircleOutline } from "@mui/icons-material";
import EditStatus from "./EditStatus";
import StatusUpdates from "./StatusUpdates";
import { FormattedMessage, useIntl } from "react-intl";
import StatusItem from "./StatusItem";
import { AttachmentFile } from "@/lib/webAttachment";
import { deleteStatusDb } from "@/lib/webStatus";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import { hoverMainToAdd, hoverMainToPressed } from "@/config/styling";
import { useEvents } from "@/contexts/EventsContext";
import ListButton from "../Common/Buttons/ListButton";

interface LatestStatusProps {
  goal: Goal;
}

export default function LatestStatus({ goal }: LatestStatusProps) {
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState(false);
  const [showUpdates, setShowUpdates] = useState(false);
  const [deleteStatus, setDeleteStatus] = useState<Status | undefined>();
  const [deleteAttachments, setDeleteAttachments] = useState<
    AttachmentFile[] | undefined
  >();
  const events = useEvents()?.events;

  const [saving, setSaving] = useState(false);

  const latestStatus = goal.status?.items ? goal.status.items[0] : undefined;
  const intl = useIntl();
  const theme = useTheme();
  const isSmallScreen = useMediaQuery((theme: Theme) =>
    theme.breakpoints.down("sm")
  );
  const showUpdatesLabel = intl.formatMessage({ id: "general.updates.show" });
  const addStatus = intl.formatMessage({ id: "statuses.add" });

  const resetState = () => {
    setEditing(false);
    setAdding(false);
    setDeleteStatus(undefined);
    setDeleteAttachments(undefined);
    setSaving(false);
  };

  const handleEdit = () => {
    setEditing(true);
  };

  const handleCloseEdit = () => {
    resetState();
  };

  const handleShowUpdates = () => {
    setShowUpdates(true);
  };

  const handleCloseUpdates = () => {
    setShowUpdates(false);
  };

  const handleAddStatus = () => {
    setAdding(true);
  };

  const handleDelete = (status: Status, attachments?: AttachmentFile[]) => {
    setDeleteStatus(status);
    setDeleteAttachments(attachments || []);
  };

  const handleDeleteCancel = () => {
    resetState();
  };

  const handleDeleteConfirmed = async () => {
    if (!deleteStatus) {
      return;
    }

    setSaving(true);
    await deleteStatusDb(deleteStatus, deleteAttachments || [], events);
    resetState();
  };

  const commentsCount =
    latestStatus && latestStatus.comments?.items
      ? latestStatus.comments?.items.length
      : 0;
  goal;

  return (
    <>
      <Stack direction="column" spacing={0} data-cy="latest-status-container">
        <Stack
          direction="row"
          spacing={1}
          alignItems={"center"}
          justifyContent="space-between"
        >
          <DetailsLabel>
            {intl.formatMessage({ id: "status.status" })}
          </DetailsLabel>
          <Stack
            direction="row"
            spacing={isSmallScreen ? 1 : 0}
            alignItems={isSmallScreen ? "center" : "flex-start"}
          >
            <IconButton
              aria-label={addStatus}
              onClick={handleAddStatus}
              size="small"
              sx={{ ...hoverMainToAdd(theme) }}
              data-cy="add-status-button"
            >
              <Tooltip title={<FormattedMessage id="statuses.add" />}>
                <AddCircleOutline />
              </Tooltip>
            </IconButton>
            <ListButton
              tooltip={intl.formatMessage({ id: "status.show.updates" })}
              onClick={handleShowUpdates}
              disabled={latestStatus == null}
              sx={{ ...hoverMainToPressed(theme) }}
              dataCy="show-status-updates-button"
            />
          </Stack>
        </Stack>

        <StatusItem
          status={latestStatus}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />
      </Stack>
      {(editing || adding) && (
        <EditStatus
          key={adding ? "adding" : latestStatus?.id}
          goal={goal}
          status={adding ? undefined : latestStatus}
          open={editing || adding}
          onClose={handleCloseEdit}
        />
      )}
      {showUpdates && (
        <StatusUpdates
          statuses={goal.status?.items}
          open={showUpdates}
          onClose={handleCloseUpdates}
        />
      )}
      {deleteStatus && (
        <ConfirmationDialog
          title={intl.formatMessage({ id: "status.delete.caption" })}
          message={intl.formatMessage({ id: "status.delete.confirmation" })}
          messageItem={deleteStatus.status || ""}
          open={!!deleteStatus}
          saving={saving}
          onCancel={handleDeleteCancel}
          onConfirm={handleDeleteConfirmed}
        />
      )}
    </>
  );
}
