import { useMemo } from "react";
import { calculateDaysOfStatus } from "@/lib/time";
import { Status } from "@/src/API";
import FeedItem from "../Feeds/FeedItem";
import { AttachmentFile, useAttachmentUrls } from "@/lib/webAttachment";
import StatusFeedDescription from "./StatusFeedDescription";
import { canDeleteDbItem } from "@/lib/webHelpers";
import { useIntl } from "react-intl";

interface StatusItemProps {
  status?: Status | null;
  onDelete?: (status: Status, attachments?: AttachmentFile[]) => void;
  onEdit?: () => void;
}

export default function StatusItem({
  status,
  onDelete,
  onEdit,
}: StatusItemProps) {
  const statusAttachments = useMemo(
    () => (status ? (status?.attachments as string[]) : []),
    [status]
  );
  const attachments = useAttachmentUrls(statusAttachments as string[]);
  const intl = useIntl();

  if (!status) {
    return null;
  }

  const handleDelete = () => {
    if (onDelete) {
      onDelete(status, attachments);
    }
  };

  const timeSinceStatus = status
    ? calculateDaysOfStatus(intl, status.createdAt)
    : "-";

  return (
    <FeedItem
      title={intl.formatMessage({ id: "status.status.update" })}
      subheader={timeSinceStatus}
      description={<StatusFeedDescription status={status} />}
      creatorEmail={status.creatorEmail}
      comments={status.comments?.items}
      attachments={attachments}
      currentGoalId={status.goalStatusId!}
      statusId={status.id}
      onDelete={handleDelete}
      deleteDisabled={!canDeleteDbItem(status)}
      onEdit={onEdit}
      tooltips={{
        editTooltip: intl.formatMessage({ id: "statuses.edit" }),
        deleteTooltip: intl.formatMessage({
          id: "status.delete.caption",
        }),
        deleteDisabledTooltip: intl.formatMessage({
          id: "status.delete.disabled.tooltip",
        }),
      }}
    />
  );
}
