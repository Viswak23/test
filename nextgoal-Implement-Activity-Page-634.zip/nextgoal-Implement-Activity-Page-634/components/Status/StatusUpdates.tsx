import { useState } from "react";
import { Status } from "@/src/API";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Stack,
} from "@mui/material";
import StatusItem from "./StatusItem";
import { AttachmentFile } from "@/lib/webAttachment";
import { deleteStatusDb } from "@/lib/webStatus";
import ConfirmationDialog from "../Common/ConfirmationDialog/ConfirmationDialog";
import { FormattedMessage, useIntl } from "react-intl";
import { useEvents } from "@/contexts/EventsContext";
import { FormTitle } from "../Common/Texts/Texts";
import HelpButton from "../Common/Buttons/HelpButton";
import HelpCollapse from "../Common/Dialog/HelpCollapse";

interface StatusUpdatesProps {
  statuses?: (Status | null)[];
  open: boolean;
  onClose: () => void;
}

// Show status updates in a dialog
export default function StatusUpdates({
  statuses,
  open,
  onClose,
}: StatusUpdatesProps) {
  const [deleteStatus, setDeleteStatus] = useState<Status | undefined>();
  const [deleteAttachments, setDeleteAttachments] = useState<
    AttachmentFile[] | undefined
  >();
  const [saving, setSaving] = useState(false);
  const intl = useIntl();
  const events = useEvents()?.events;
  const [showHelp, setShowHelp] = useState(false);

  const resetState = () => {
    setDeleteStatus(undefined);
    setDeleteAttachments(undefined);
    setSaving(false);
  };

  const handleDelete = (status: Status, attachments?: AttachmentFile[]) => {
    setDeleteStatus(status);
    setDeleteAttachments(attachments || []);
  };

  const handleDeleteCancel = () => {
    resetState();
  };

  const handleDeleteConfirmed = async () => {
    if (!deleteStatus) {
      return;
    }

    setSaving(true);
    await deleteStatusDb(deleteStatus, deleteAttachments || [], events);
    resetState();
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  return (
    <>
      <Dialog
        open={open}
        onClose={onClose}
        fullWidth={true}
        maxWidth="lg"
        data-cy="status-updates"
      >
        <DialogTitle>
          <Stack direction="row" spacing={1} alignItems={"center"}>
            <FormTitle>
              <FormattedMessage id="status.show.updates" />
            </FormTitle>
            <HelpButton
              onClick={handleToggleHelp}
              data-cy="show-status-updates-help"
            />
          </Stack>
        </DialogTitle>
        <DialogContent>
          <HelpCollapse
            showHelp={showHelp}
            helpText={intl.formatMessage({ id: "statuses.help.text" })}
          />
          {statuses?.map((statusLine) => (
            <StatusItem
              key={statusLine?.id || "nostatus"}
              status={statusLine}
              onDelete={handleDelete}
            />
          ))}
        </DialogContent>
        <DialogActions>
          <Button onClick={onClose}>
            <FormattedMessage id="general.close" />
          </Button>
        </DialogActions>
      </Dialog>
      {deleteStatus && (
        <ConfirmationDialog
          title={intl.formatMessage({ id: "status.delete.caption" })}
          message={intl.formatMessage({ id: "status.delete.confirmation" })}
          messageItem={deleteStatus.status || ""}
          open={!!deleteStatus}
          saving={saving}
          onCancel={handleDeleteCancel}
          onConfirm={handleDeleteConfirmed}
        />
      )}
    </>
  );
}
