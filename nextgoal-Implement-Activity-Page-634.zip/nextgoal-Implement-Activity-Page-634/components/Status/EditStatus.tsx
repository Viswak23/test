import { useState, useMemo } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import TextField from "@mui/material/TextField";
import { useImmer } from "use-immer";
import { Alert, Stack } from "@mui/material";
import { CreateStatusInput, UpdateStatusInput, Goal } from "@/src/API";
import { addStatusDb, updateStatusDb } from "@/lib/webStatus";
import { Help } from "@mui/icons-material";
import { useAuthStatus } from "@/lib/customHooks";
import EditDialogActions from "../Common/Dialog/EditDialogActions";
import {
  AttachmentFile,
  AttachmentOwner,
  deleteAttachments,
  saveAttachments,
  useAttachmentUrls,
} from "@/lib/webAttachment";
import HandleAttachments from "../Common/Attachment/HandleAttachments";
import { FormattedMessage, useIntl } from "react-intl";
import { log } from "@/lib/backend/actions/logger";
import HelpButton from "../Common/Buttons/HelpButton";
import { FormTitle } from "../Common/Texts/Texts";
import HelpCollapse from "../Common/Dialog/HelpCollapse";
import { useEmployees } from "@/contexts/EmployeesContext";

interface EditStatusProps {
  goal: Goal;
  status?: CreateStatusInput | UpdateStatusInput | null;
  open: boolean;
  onClose: () => void;
}

export default function EditStatus({
  goal,
  status,
  open,
  onClose,
}: EditStatusProps) {
  const defaultStatus = {
    status: "",
    goingWell: "",
    challenges: "",
    toImprove: "",
    companyId: "placeholder",
    creatorEmail: "placeholder",
  };
  const [editStatus, setEditStatus] = useImmer<
    CreateStatusInput | UpdateStatusInput
  >(
    status != null ? ({ ...status } as UpdateStatusInput) : { ...defaultStatus }
  );
  const [showHelp, setShowHelp] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savingError, setSavingError] = useState("");
  const [previewAttachments, setPreviewAttachments] = useState<
    AttachmentFile[]
  >([]);
  const [removedAttachments, setRemovedAttachments] = useState<
    AttachmentFile[]
  >([]);
  const [statusError, setStatusError] = useState("");
  const currentUser = useAuthStatus();
  const intl = useIntl();
  const employees = useEmployees()?.employees;
  const memoizedAttachments = useMemo(
    () => status?.attachments as string[],
    [status?.attachments]
  );
  const existingAttachments = useAttachmentUrls(memoizedAttachments);

  const handleStatusTextChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setStatusError("");
    setEditStatus((draft) => {
      draft.status = event.target.value;
    });
  };

  const handleGoingWellTextChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditStatus((draft) => {
      draft.goingWell = event.target.value;
    });
  };

  const handleChallengesTextChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditStatus((draft) => {
      draft.challenges = event.target.value;
    });
  };

  const handleRoomToImproveTextChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditStatus((draft) => {
      draft.toImprove = event.target.value;
    });
  };

  const resetState = () => {
    setEditStatus(
      status != null
        ? ({ ...status } as UpdateStatusInput)
        : { ...defaultStatus }
    );
    setShowHelp(false);
    setSaving(false);
    setPreviewAttachments([]);
    setRemovedAttachments([]);
    setStatusError("");
    setSavingError("");
  };

  const onCancel = () => {
    resetState();
    onClose();
  };

  const handleSave = async () => {
    if (!editStatus.status) {
      setStatusError(
        intl.formatMessage({ id: "status.error.status.required" })
      );
      return;
    }

    try {
      setSaving(true);
      // Save attachments to S3
      const newAttachments = await saveAttachments(
        previewAttachments,
        AttachmentOwner.Status
      );

      if (!status) {
        await addStatusDb(
          {
            ...editStatus,
            goalStatusId: goal.id,
            creatorEmail: currentUser?.attributes.email,
            attachments: newAttachments,
          } as CreateStatusInput,
          goal.employeeGoalsId != null,
          employees
        );
      } else {
        // Remove deleted attachments from S3
        const remainingAttachments = await deleteAttachments(
          removedAttachments,
          existingAttachments
        );

        await updateStatusDb({
          ...editStatus,
          attachments: remainingAttachments.concat(newAttachments),
        } as UpdateStatusInput);
      }
      resetState();
      onClose();
    } catch (error: any) {
      log(`Add/Edit Status: ${error.message}`);
      setSaving(false);
      setSavingError(intl.formatMessage({ id: "general.save.error" }));
    }
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  const dialogTitle = status ? (
    <FormTitle>
      <FormattedMessage id="statuses.edit" />
    </FormTitle>
  ) : (
    <FormTitle>
      <FormattedMessage id="statuses.add" />
    </FormTitle>
  );

  return (
    <Dialog
      open={open}
      onClose={onCancel}
      fullWidth={true}
      maxWidth="lg"
      disableRestoreFocus
      onKeyUp={(e) => {
        if (e.key === "Enter") handleSave();
      }}
    >
      <DialogTitle>
        <Stack direction="row" spacing={1} alignItems={"center"}>
          {dialogTitle}
          {/* Help btn */}
          <HelpButton onClick={handleToggleHelp} />
        </Stack>
      </DialogTitle>
      <DialogContent>
        <HelpCollapse
          showHelp={showHelp}
          helpText={intl.formatMessage({ id: "statuses.help.text" })}
        />
        <TextField
          autoFocus
          margin="dense"
          id="status"
          label={<FormattedMessage id="status.status" />}
          type="text"
          fullWidth
          variant="standard"
          autoComplete="off"
          helperText={statusError}
          error={statusError !== ""}
          value={editStatus.status}
          data-cy="edit-status-title-input"
          onChange={handleStatusTextChange}
        />
        <TextField
          margin="dense"
          id="going-well"
          label={<FormattedMessage id="status.going.well" />}
          type="text"
          fullWidth
          variant="standard"
          autoComplete="off"
          value={editStatus.goingWell || ""}
          data-cy="edit-status-going-well-input"
          onChange={handleGoingWellTextChange}
        />
        <TextField
          margin="dense"
          id="challenges"
          label={<FormattedMessage id="status.challenges" />}
          type="text"
          fullWidth
          variant="standard"
          autoComplete="off"
          value={editStatus.challenges || ""}
          data-cy="edit-status-challenges-input"
          onChange={handleChallengesTextChange}
        />
        <TextField
          margin="dense"
          id="room-to-improve"
          label={<FormattedMessage id="status.room.for.improvement" />}
          type="text"
          fullWidth
          variant="standard"
          autoComplete="off"
          value={editStatus.toImprove || ""}
          data-cy="edit-status-room-to-improve-input"
          onChange={handleRoomToImproveTextChange}
        />
        <HandleAttachments
          existingAttachments={existingAttachments}
          previewMedias={previewAttachments}
          setPreviewMedias={setPreviewAttachments}
          removedAttachments={removedAttachments}
          setRemovedAttachments={setRemovedAttachments}
        />
        {savingError && <Alert severity="error">{savingError}</Alert>}
      </DialogContent>
      <EditDialogActions
        saving={saving}
        onSave={handleSave}
        onCancel={onCancel}
      />
    </Dialog>
  );
}
