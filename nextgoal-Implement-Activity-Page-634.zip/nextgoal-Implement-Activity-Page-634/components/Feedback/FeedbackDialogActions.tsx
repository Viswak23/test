import { useState } from "react";
import {
  Alert,
  Button,
  DialogActions,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  FormControlLabel,
  Radio,
  RadioGroup,
  Stack,
} from "@mui/material";
import { useAuthStatus } from "@/lib/customHooks";
import { FormattedMessage, useIntl } from "react-intl";
import { useImmer } from "use-immer";
import SaveButton from "../Common/Buttons/SaveButton";
import emailjs from "@emailjs/browser";
import HandleAttachments from "../Common/Attachment/HandleAttachments";
import { AttachmentFile } from "@/lib/webAttachment";
import { hoverMainToRed } from "@/config/styling";
import theme from "@/config/theme";
import { FormTitle } from "../Common/Texts/Texts";
import HelpButton from "../Common/Buttons/HelpButton";
import HelpCollapse from "../Common/Dialog/HelpCollapse";

enum FeedbackType {
  BUG = "Bug",
  IMPROVEMENT = "Improvement",
  OTHERS = "Others",
}

interface SendFeedbackProps {
  open: boolean;
  onClose: (scrollToTop: Boolean) => void;
}

const defaultFeedback = {
  creatorEmail: "",
  feedbackType: FeedbackType.BUG,
  steps: "",
  feedbackTypeDescription: "",
  feedbackDescription: "",
};

export default function SendFeedback({ open, onClose }: SendFeedbackProps) {
  const currentUser = useAuthStatus();
  const intl = useIntl();
  const helpLabel = intl.formatMessage({ id: "general.help" });

  const [showHelp, setShowHelp] = useState(false);
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState("");
  const [editFeedback, setEditFeedback] = useImmer({
    ...defaultFeedback,
    creatorEmail: currentUser?.attributes.email,
  });
  const [typeDescriptionError, setTypeDescriptionError] = useState("");
  const [descriptionError, setDescriptionError] = useState("");
  const [previewAttachments, setPreviewAttachments] = useState<
    AttachmentFile[]
  >([]);
  const [removedAttachments, setRemovedAttachments] = useState<
    AttachmentFile[]
  >([]);

  const handleCancel = (event?: object, reason?: string) => {
    if (reason === "backdropClick") {
      // Don't do anything. Accidental click can't delete all the information.
      return;
    }

    resetState();
    onClose(false);
  };

  const handleToggleHelp = () => {
    setShowHelp(!showHelp);
  };

  const handleFilesCallback = (files: FileList) => {
    if (previewAttachments.length >= 3) {
      setSendError(
        intl.formatMessage({ id: "feedback.error.attachemnt.amount" })
      );
      return;
    }

    // Calculate the total size of files in base64 format, which increases file size by approximately 33%
    const totalCurrentFilesSize =
      (4 / 3) *
      previewAttachments.reduce(
        (acc, media) => acc + (media.file?.size || 0),
        0
      );
    const newFilesSize =
      (4 / 3) * Array.from(files).reduce((acc, file) => acc + file.size, 0);

    if (totalCurrentFilesSize + newFilesSize > 2 * 1024 * 1024) {
      setSendError(
        intl.formatMessage({ id: "feedback.error.attachemnt.exceed" })
      );
      return;
    }

    setSendError("");

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onloadend = (e) => {
        const newMedia = {
          type: file.type,
          url: URL.createObjectURL(file),
          file,
          base64: reader.result as string,
        };
        setPreviewAttachments((medias) => medias.concat(newMedia));
      };
    });
  };

  const handleFeedbackDescriptionChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setDescriptionError("");
    setEditFeedback((draft) => {
      draft.feedbackDescription = event.target.value;
    });
  };

  const handleFeedbackTypeChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setEditFeedback((draft) => {
      draft.feedbackType = event.target.value as FeedbackType;
    });
  };

  const handleFeedbackTypeDescriptionChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setTypeDescriptionError("");
    setEditFeedback((draft) => {
      draft.feedbackTypeDescription = event.target.value;
    });
  };

  const handleSend = async () => {
    if (
      editFeedback.feedbackType === FeedbackType.OTHERS &&
      !editFeedback.feedbackTypeDescription
    ) {
      setTypeDescriptionError(
        intl.formatMessage({ id: "feedback.error.type.required" })
      );
      return;
    } else if (!editFeedback.feedbackDescription) {
      setDescriptionError(
        intl.formatMessage({ id: "feedback.error.description.required" })
      );
      return;
    }

    setSending(true);
    const feedbackType =
      editFeedback.feedbackType === FeedbackType.OTHERS
        ? editFeedback.feedbackType +
          ` - ${editFeedback.feedbackTypeDescription}`
        : editFeedback.feedbackType;

    let data = {
      ...editFeedback,
      feedbackType: feedbackType,
      taigoaEmail: process.env.NEXT_PUBLIC_EMAILJS_TAIGOA_EMAIL || "",
    };

    if (previewAttachments.length > 0) {
      previewAttachments.forEach(async (item, index) => {
        data = {
          ...data,
          [`attachment${index + 1}`]: item.base64,
          [`attachment${index + 1}Name`]: item.file?.name ?? "attachment.png",
        };
      });
    }

    emailjs
      .send(
        process.env.NEXT_PUBLIC_EMAILJS_SERVICE_ID!,
        process.env.NEXT_PUBLIC_EMAILJS_FEEDBACK_TEMPLATE!,
        data,
        {
          publicKey: process.env.NEXT_PUBLIC_EMAILJS_PUBLIC_KEY,
        }
      )
      .then(
        () => {
          onClose(true);
          resetState();
        },
        (e) => {
          setSendError(
            intl.formatMessage({ id: "feedback.error.send.failed" })
          );
          setSending(false);
        }
      );
  };

  const handleStepsChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setEditFeedback((draft) => {
      draft.steps = event.target.value;
    });
  };

  const resetState = () => {
    setShowHelp(false);
    setSending(false);
    setEditFeedback({ ...defaultFeedback });
    setTypeDescriptionError("");
    setDescriptionError("");
    setSendError("");
  };

  return (
    <>
      <Dialog
        open={open}
        onClose={handleCancel}
        fullWidth={true}
        maxWidth="lg"
        disableRestoreFocus
        data-cy="add-feedback-dialog"
      >
        <DialogTitle>
          <Stack direction="row" spacing={1} alignItems={"centers"}>
            <FormTitle>
              <FormattedMessage id="feedback.title" />
            </FormTitle>

            {/* Help btn */}
            <HelpButton onClick={handleToggleHelp} />
          </Stack>
        </DialogTitle>

        {/* Help btn message */}
        <DialogContent>
          <HelpCollapse
            showHelp={showHelp}
            helpText={intl.formatMessage({ id: "feedback.help.text" })}
          />

          {/* Which feedback type? */}
          <RadioGroup
            value={editFeedback.feedbackType}
            onChange={handleFeedbackTypeChange}
          >
            <FormControlLabel
              value={FeedbackType.BUG}
              control={<Radio />}
              label={intl.formatMessage({ id: "feedback.type.bug" })}
            />
            <FormControlLabel
              value={FeedbackType.IMPROVEMENT}
              control={<Radio />}
              label={intl.formatMessage({ id: "feedback.type.improvement" })}
            />
            <FormControlLabel
              value={FeedbackType.OTHERS}
              control={<Radio />}
              label={intl.formatMessage({ id: "feedback.type.others" })}
            />
          </RadioGroup>

          {/* Description */}
          <TextField
            autoFocus
            margin="dense"
            id="description"
            data-cy="send-feedback-description"
            label={intl.formatMessage({ id: "feedback.description" })}
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            helperText={descriptionError}
            error={descriptionError !== ""}
            multiline
            name="feedbackDescription"
            onChange={handleFeedbackDescriptionChange}
          />
          {/* Steps */}
          <TextField
            margin="dense"
            id="steps"
            data-cy="send-feedback-steps-to-reproduce"
            label={intl.formatMessage({ id: "feedback.steps" })}
            type="text"
            fullWidth
            variant="standard"
            autoComplete="off"
            name="steps"
            multiline
            onChange={handleStepsChange}
          />
          <HandleAttachments
            previewMedias={previewAttachments}
            setPreviewMedias={setPreviewAttachments}
            removedAttachments={removedAttachments}
            setRemovedAttachments={setRemovedAttachments}
            existingAttachments={[]}
            handleFilesCallback={handleFilesCallback}
          />
          {sendError && <Alert severity="error">{sendError}</Alert>}
        </DialogContent>

        {/* Cancel button */}
        <DialogActions>
          <Button
            onClick={handleCancel}
            disabled={sending}
            data-cy="dialog-button-cancel"
            sx={{
              ...hoverMainToRed(theme),
            }}
          >
            <FormattedMessage id="general.cancel" />
          </Button>

          {/* Send button */}
          <SaveButton
            saving={sending}
            onClick={handleSend}
            disabled={false}
            title={intl.formatMessage({ id: "general.send" })}
          />
        </DialogActions>
      </Dialog>
    </>
  );
}
