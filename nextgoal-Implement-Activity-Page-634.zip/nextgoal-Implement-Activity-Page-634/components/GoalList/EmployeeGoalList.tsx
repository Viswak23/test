import React, { useMemo } from "react";
import { Employee, OrganizationUnit } from "@/src/API";
import { useGoals } from "@/contexts/GoalsContext";
import _ from "lodash";
import { updateEmployeeDb } from "@/lib/webEmployee";
import GoalListSub, { ParentGoal } from "./GoalListSub";
import { useIntl } from "react-intl";

type EmployeeGoalListProps = {
  employee: Employee;
  employeeOrganizationUnit?: OrganizationUnit;
  internalGoals?: boolean;
};

export default function EmployeeGoalList({
  employee,
  employeeOrganizationUnit,
  internalGoals = false,
}: EmployeeGoalListProps) {
  const goals = useGoals()?.goals;
  const intl = useIntl();

  const parentGoals: ParentGoal[] = useMemo(() => {
    if (!goals || (employeeOrganizationUnit?.id == null && !internalGoals))
      return [];

    if (internalGoals) {
      // Internal goals are shown separaterly

      return [
        {
          goal: undefined,
          orgUnitGoals: goals.filter(
            (goal) =>
              goal.employeeGoalsId === employee.id &&
              goal.goalChildGoalsId == null
          ),
        },
      ];
    }

    let parentGoals: ParentGoal[] = goals
      .filter(
        (goal) =>
          goal.organizationUnitGoalsId === employeeOrganizationUnit?.id &&
          goal.employee == null &&
          !employee.notRelevantParentGoals?.includes(goal.id)
      )
      .map((goal) => {
        return {
          goal,
          orgUnitGoals: goals.filter(
            (subgoal) =>
              subgoal.goalChildGoalsId === goal.id &&
              subgoal.employeeGoalsId === employee.id
          ),
        };
      });

    return parentGoals;
  }, [employeeOrganizationUnit, goals, employee, internalGoals]);

  const undelevantParentGoals = useMemo(() => {
    if (!employee?.notRelevantParentGoals) return [];

    return employee.notRelevantParentGoals
      .map((goalId) => {
        return goals?.find(
          (goal) =>
            goal.id === goalId &&
            goal.organizationUnitGoalsId === employeeOrganizationUnit?.id
        );
      })
      .filter((g) => g != null);
  }, [goals, employeeOrganizationUnit?.id, employee]);

  const onSetParentGoalUnrelevant = async (goalId?: string | null) => {
    if (!goalId) {
      return;
    }

    const updatedEmployee = _.cloneDeep(employee);
    if (!updatedEmployee) {
      return;
    }

    updatedEmployee.notRelevantParentGoals = [
      ...(updatedEmployee?.notRelevantParentGoals || []),
      goalId,
    ];
    await updateEmployeeDb(updatedEmployee);
  };

  const onSetParentGoalRelevant = async (goalId?: string) => {
    if (!goalId) {
      return;
    }

    const updatedEmployee = _.cloneDeep(employee);
    if (!updatedEmployee) {
      return;
    }

    updatedEmployee.notRelevantParentGoals = [
      ...(updatedEmployee?.notRelevantParentGoals || []),
    ].filter((id) => id !== goalId);
    await updateEmployeeDb(updatedEmployee);
  };

  const caption = internalGoals
    ? intl.formatMessage({ id: "goals.personal.goals" })
    : intl.formatMessage(
        { id: "goals.organization.unit.goals" },
        { name: employeeOrganizationUnit?.name }
      );

  return (
    <GoalListSub
      caption={caption}
      parentGoals={parentGoals}
      undelevantParentGoals={undelevantParentGoals}
      employee={employee}
      internalGoals={internalGoals}
      onSetParentGoalRelevant={onSetParentGoalRelevant}
      onSetParentGoalUnrelevant={onSetParentGoalUnrelevant}
    />
  );
}
