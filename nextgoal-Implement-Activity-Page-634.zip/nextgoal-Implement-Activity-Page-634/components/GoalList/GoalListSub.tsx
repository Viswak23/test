import { useState } from "react";
import { Stack, Button, Box, Paper } from "@mui/material/";
import { GroupHeadingCard } from "../Common/Texts/Texts";
import Breadcrumb, {
  BreadcrumbType,
} from "@/components/Common/Breadcrumb/Breadcrumb";
import EditGoal from "@/components/Goal/EditGoal";
import GExpandList from "@/components/Common/GList/GExpandList";
import { Employee, Goal } from "@/src/API";
import EditContribution from "../Contributions/EditContribution";
import GoalListMainInOrder from "./GoalListMainInOrder";
import { Flare } from "@mui/icons-material";
import { FormattedMessage, useIntl } from "react-intl";
import theme from "@/config/theme";
import { hoverMainToAdd, hoverMainToRedBg } from "@/config/styling";
import PageBackgroundPaper from "../Common/Layout/PageBackgroundPaper";

export interface ParentGoal {
  goal?: Goal;
  orgUnitGoals: Goal[];
  positionPath?: number[];
}

interface GoalListSubProps {
  caption: string;
  parentGoals: ParentGoal[];
  undelevantParentGoals: (Goal | undefined)[];
  employee?: Employee;
  internalGoals: boolean;
  organizationUnitId?: string;
  onSetParentGoalUnrelevant: (goalId?: string | null) => void;
  onSetParentGoalRelevant: (goalId?: string) => void;
}

export default function GoalListSub({
  caption,
  parentGoals,
  undelevantParentGoals,
  employee,
  internalGoals,
  organizationUnitId,
  onSetParentGoalUnrelevant,
  onSetParentGoalRelevant,
}: GoalListSubProps) {
  const [addingGoal, setAddingGoal] = useState<ParentGoal>();
  const [addingContributionToGoal, setAddingContributionToGoal] =
    useState<Goal>();
  const intl = useIntl();

  const handleAddClick = (goal?: ParentGoal) => {
    // Should never happen
    if (!goal) return;

    setAddingGoal(goal);
  };

  const handleCloseAddGoal = () => {
    setAddingGoal(undefined);
  };

  const handleAddContributionClick = (goal?: Goal) => {
    setAddingContributionToGoal(goal);
  };

  const handleCloseAddContribution = () => {
    setAddingContributionToGoal(undefined);
  };

  const cardStyles = {
    margin: "0px 15px 12px 15px",
    boxShadow:
      "rgba(0, 0, 0, 0.07) 0px 1px 1px, rgba(0, 0, 0, 0.07) 0px 2px 2px, rgba(0, 0, 0, 0.07) 0px 4px 4px, rgba(0, 0, 0, 0.07) 0px 8px 8px, rgba(0, 0, 0, 0.07) 0px 16px 16px",
  };

  return (
    <PageBackgroundPaper
      style={{
        ...cardStyles,
        padding: "6px 1rem 1rem 1rem",
        margin: "0px 0 24px 0",
      }}
      headerSpace={false}
      dataCy="organization-page"
    >
      <Stack
        sx={{
          textAlign: "flex-start",
          padding: "20px",
        }}
      >
        <GroupHeadingCard
          sx={{
            wordBreak: "break-word",
          }}
        >
          {caption}
        </GroupHeadingCard>
      </Stack>

      <Stack
        direction="column"
        spacing={1}
        style={{ marginTop: 6, padding: "0px 20px 20px 20px" }}
      >
        {parentGoals?.map((parentGoal) => (
          <Stack
            direction="column"
            key={parentGoal.goal?.id || "personalgoals"}
            spacing={1}
          >
            {parentGoal.goal && (
              <Stack
                direction="row"
                spacing={1}
                sx={{
                  alignItems: "center",
                  paddingBottom: "12px",
                }}
                data-cy={`parentgoal-link-${parentGoal.goal?.title}`}
              >
                {/* Star icon! */}
                <Flare sx={{ color: "primary.main" }} />

                <Breadcrumb
                  type={BreadcrumbType.SUBHEADER}
                  showMainPage={false}
                  showLastAsaLink={true}
                  currentGoalId={parentGoal.goal.id}
                />
              </Stack>
            )}
            {/* Goals, buttons */}
            <GoalListMainInOrder
              key={`ordered-goal-list-${parentGoal.orgUnitGoals.length}`}
              goals={parentGoal.orgUnitGoals}
              sx={{
                margin: "0px 15px 12px 15px",
              }}
            />

            <Stack direction={"row"} spacing={1} alignContent={"center"}>
              {/* Add contribution btn */}
              {employee && parentGoal.goal && (
                <Button
                  variant="contained"
                  onClick={() => handleAddContributionClick(parentGoal.goal)}
                  style={{ width: "174px" }}
                >
                  <FormattedMessage id="contributions.add" />
                </Button>
              )}

              {/* Add goal btn */}
              <Button
                variant="contained"
                onClick={() => handleAddClick(parentGoal)}
                style={{ width: "174px" }}
                data-cy={`organization-unit-add-goal-button-${parentGoal.goal?.title}`}
              >
                <FormattedMessage id="goals.add" />
              </Button>

              {/* Goal not relevant btn */}
              {parentGoal.goal != null &&
                parentGoal.orgUnitGoals.length === 0 && (
                  <Button
                    onClick={() =>
                      onSetParentGoalUnrelevant(parentGoal.goal?.id)
                    }
                    sx={{ width: "174px", ...hoverMainToRedBg(theme) }}
                  >
                    <FormattedMessage id="goals.goal.not.relevant" />
                  </Button>
                )}
            </Stack>
            <br />
          </Stack>

          // Unrelevant goals' toggle
        ))}
        {!internalGoals && undelevantParentGoals.length > 0 && (
          <Box style={{ marginTop: "12px", marginBottom: "12px" }}>
            <GExpandList
              title={intl.formatMessage({ id: "goals.not.relevant.goals" })}
              style={{ width: "100%" }}
            >
              {undelevantParentGoals.length === 0 &&
                intl.formatMessage({ id: "goals.no.unrelevant.goals" })}
              {undelevantParentGoals.length > 0 &&
                undelevantParentGoals.map(
                  (unrelevantGoal) =>
                    unrelevantGoal && (
                      <Stack
                        key={unrelevantGoal.id}
                        direction={{ xs: "column", sm: "row" }}
                        spacing={1}
                        alignContent={"center"}
                        justifyContent={"space-between"}
                        sx={{
                          width: "100%",
                          alignItems: "center",
                          margin: {
                            xs: "18px 0px 18px",
                            sm: "6px 0px 6px 0px",
                          },
                        }}
                      >
                        <Box
                          sx={{
                            display: "grid",
                            gridTemplateColumns: { xs: "1fr", sm: "200px 1fr" },
                            gap: { xs: 2, sm: 6 }, // space btwn columns & rows
                            justifyContent: { xs: "center", sm: "flex-start" },
                            alignItems: "center",
                            paddingBottom: { xs: "12px", sm: "6px" },
                          }}
                        >
                          <Stack direction="column">
                            <Stack
                              direction="row"
                              sx={{ alignItems: "center" }}
                            >
                              <Flare
                                sx={{
                                  color: "secondary.main",
                                  marginRight: "12px",
                                }}
                              />
                              <Breadcrumb
                                type={BreadcrumbType.SUBHEADER}
                                showMainPage={false}
                                showLastAsaLink={true}
                                currentGoalId={unrelevantGoal.id}
                              />
                            </Stack>
                          </Stack>
                        </Box>
                        <Box>
                          <Stack direction="column">
                            <Button
                              onClick={() =>
                                onSetParentGoalRelevant(unrelevantGoal.id)
                              }
                              sx={{ ...hoverMainToAdd(theme) }}
                            >
                              <FormattedMessage id="goals.goal.is.relevant" />
                            </Button>
                          </Stack>
                        </Box>
                      </Stack>
                    )
                )}
            </GExpandList>
          </Box>
        )}
      </Stack>
      {addingGoal != null && (
        <EditGoal
          open={addingGoal != null}
          parentId={addingGoal?.goal?.id}
          organizationUnitId={organizationUnitId}
          employee={employee}
          newPosition={addingGoal?.orgUnitGoals.length || 0}
          onClose={handleCloseAddGoal}
        />
      )}
      {addingContributionToGoal != undefined && (
        <EditContribution
          open={addingContributionToGoal !== undefined}
          goalId={addingContributionToGoal.id}
          onClose={handleCloseAddContribution}
        />
      )}
    </PageBackgroundPaper>
  );
}
