import { showDate, timeToTargetDate } from "@/lib/time";
import { Employee, Goal, KeyResult, OrganizationUnit } from "@/src/API";
import { Box, Stack, Tooltip, useTheme } from "@mui/material";
import {
  DataGrid,
  GridColDef,
  GridRenderCellParams,
  GridTreeNodeWithRender,
} from "@mui/x-data-grid";
import KeyResultIcon from "../KeyResults/KeyResultIcon";
import {
  calculateKeyResultsProgress,
  getKeyResultTooltip,
} from "@/lib/webKeyResults";
import { Link as MUILink } from "@mui/material";
import Link from "next/link";
import { IntlShape, useIntl } from "react-intl";
import { getLinkWithLocale } from "@/lib/localisation";
import { useSettings } from "@/contexts/SettingsInfo";

interface GoalListDashboardProps {
  goals?: (Goal | null)[];
}

const columns: GridColDef[] = [
  {
    field: "goal",
    headerName: "Title",
    width: 220,
    renderCell: (
      params: GridRenderCellParams<any, any, any, GridTreeNodeWithRender>
    ) => {
      return (
        <MUILink
          underline="hover"
          color="inherit"
          href={getLinkWithLocale(
            `/goals/${params.value.id}`,
            params.row.intl.locale
          )}
          locale={params.row.intl.locale}
          component={Link}
        >
          {params.value.title}
        </MUILink>
      );
    },
  },
  {
    field: "organizationUnit",
    headerName: "Organization Unit",
    width: 200,
    renderCell: (
      params: GridRenderCellParams<any, any, any, GridTreeNodeWithRender>
    ) => {
      if (!params.value) return null;
      return (
        <MUILink
          underline="hover"
          color="inherit"
          href={getLinkWithLocale(
            `/organization/${params.value.id}`,
            params.row.intl.locale
          )}
          locale={params.row.intl.locale}
          component={Link}
        >
          {params.value.name}
        </MUILink>
      );
    },
  },
  { field: "startDate", headerName: "Start Date", width: 100 },
  { field: "targetDate", headerName: "Target Date", width: 100 },
  {
    field: "keyResults",
    headerName: "Key Results",
    width: 160,
    renderCell: (
      params: GridRenderCellParams<any, any, any, GridTreeNodeWithRender>
    ) => {
      return (
        <Stack direction="row" spacing={1} alignItems={"center"}>
          {params.value.map((kr: KeyResult | null) => {
            return (
              <Tooltip
                title={getKeyResultTooltip(params.row.intl, kr)}
                key={kr?.id || "no-id"}
              >
                <span>
                  <KeyResultIcon keyResult={kr} />
                </span>
              </Tooltip>
            );
          })}
        </Stack>
      );
    },
  },
  {
    field: "keyResultsReadiness",
    headerName: "KR readiness",
    width: 100,
  },
  {
    field: "redFlags",
    headerName: "Red Flags",
    width: 100,
  },
  {
    field: "helpRequests",
    headerName: "Help Requests",
    width: 100,
  },
];

interface GoalGridRow {
  id: string;
  goal?: Goal | null;
  title: string;
  organizationUnit: OrganizationUnit | null | undefined;
  startDate: string;
  targetDate: string;
  keyResults: (KeyResult | null)[];
  keyResultsReadiness: string;
}

function getGoalGridRows(
  intl: IntlShape,
  goals?: (Goal | null)[],
  currentUser?: Employee | null
): GoalGridRow[] {
  return (
    goals?.map((goal) => {
      return {
        id: goal?.id || "",
        goal: goal,
        title: goal?.title || "",
        organizationUnit: goal?.organizationUnit,
        startDate: showDate(goal?.startDate, currentUser),
        targetDate: `${showDate(goal?.targetDate, currentUser)}${
          goal?.targetDate
            ? ` (${timeToTargetDate(intl, goal?.targetDate)})`
            : ""
        }`,
        keyResults: goal?.keyResults?.items || [],
        keyResultsReadiness: `${calculateKeyResultsProgress(
          goal?.keyResults?.items
        )} %`,
        redFlags:
          goal?.redFlags?.items?.filter((rf) => rf && !!!rf.resolved).length ||
          "",
        helpRequests:
          goal?.helpRequests?.items?.filter((hr) => hr && !!!hr.resolved)
            .length || "",
        intl: intl,
      };
    }) || []
  );
}

export default function GoalListDashboard({ goals }: GoalListDashboardProps) {
  const intl = useIntl();
  const dbUser = useSettings()?.dbUser;

  // Set localized column headers
  columns[0].headerName = intl.formatMessage({ id: "goals.goal.title" });
  columns[1].headerName = intl.formatMessage({
    id: "organizationunits.unit.title",
  });
  columns[2].headerName = intl.formatMessage({ id: "goals.start.date" });
  columns[3].headerName = intl.formatMessage({ id: "goals.target.date" });
  columns[4].headerName = intl.formatMessage({ id: "keyresults.title" });
  columns[5].headerName = intl.formatMessage({ id: "keyresults.kr.readiness" });
  columns[6].headerName = intl.formatMessage({ id: "redflags.title" });
  columns[7].headerName = intl.formatMessage({ id: "helprequests.title" });

  const theme = useTheme();

  return (
    <div style={{ textAlign: "center", paddingTop: "18px" }}>
      <Box
        style={{
          width: "100%",
          marginBottom: "24px",
          marginTop: "24px",
          textAlign: "center",
        }}
      >
        <DataGrid
          rows={getGoalGridRows(intl, goals, dbUser)}
          columns={columns}
          initialState={{
            pagination: {
              paginationModel: { page: 0, pageSize: 25 },
            },
          }}
          sx={{
            ".MuiDataGrid-columnHeaders": {
              backgroundColor: theme.palette.customColors?.lightest,
            },
          }}
        />
      </Box>
    </div>
  );
}
