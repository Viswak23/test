import React, { useMemo } from "react";
import { useState } from "react";
import EditGoal from "@/components/Goal/EditGoal";
import { Stack, Button, useTheme } from "@mui/material/";
import { HeadingMain2 } from "../Common/Texts/Texts";
import { useGoals } from "@/contexts/GoalsContext";
import { sortGoalSubitems, sortGoals } from "@/lib/webGoals";
import GoalListMainInOrder from "./GoalListMainInOrder";
import { Goal } from "@/src/API";
import { useRouter } from "next/navigation";
import { useIntl } from "react-intl";
import { getLinkWithLocale } from "@/lib/localisation";
import { FormattedMessage } from "react-intl";
import PageBackgroundPaper from "../Common/Layout/PageBackgroundPaper";

type GoalListMainProps = {
  organizationUnitId?: string;
};

export default function GoalListMain({
  organizationUnitId,
}: GoalListMainProps) {
  const [addingGoal, setAddingGoal] = useState(false);
  const router = useRouter();
  const goals = useGoals()?.goals!;
  const intl = useIntl();
  const theme = useTheme();

  const handleAddClick = () => {
    setAddingGoal(true);
  };

  const handleGoToArchive = () => {
    router.push(getLinkWithLocale("/goals/archive", intl.locale));
  };

  const organizationUnitGoals = useMemo(() => {
    let result;
    if (!organizationUnitId) {
      result = goals.filter(
        (goal) =>
          goal != null && !goal.organizationUnitGoalsId && !goal.employeeGoalsId
      );
    } else {
      result = goals.filter(
        (goal) =>
          goal != null && goal.organizationUnitGoalsId === organizationUnitId
      );
    }

    const newGoals: Goal[] = result
      .map((goal) => sortGoalSubitems(goal))
      .filter(Boolean) as Goal[];
    return sortGoals(newGoals);
  }, [goals, organizationUnitId]);

  const newPosition = organizationUnitGoals.length || 0;

  // We use goals length as a key in GoalListMainInOrder so that it will re-render when goals are added or removed
  return (
    <PageBackgroundPaper
      style={{
        backgroundColor: theme.palette.customColors?.lightest,
        paddingBottom: "2rem",
      }}
      headerSpace={false}
    >
      <HeadingMain2>
        <FormattedMessage id="goals.title" />
      </HeadingMain2>

      <Stack
        direction="column"
        spacing={{
          xs: 2,
          sm: 1,
        }}
        justifyContent="center"
        style={{
          marginTop: "12px",
        }}
      >
        <GoalListMainInOrder
          key={`ordered-goal-list-${organizationUnitGoals.length}`}
          goals={organizationUnitGoals}
        />
        <Stack
          direction={{ xs: "column", sm: "row" }}
          alignItems="center"
          spacing={2}
        >
          <Button
            variant="contained"
            onClick={handleAddClick}
            sx={{
              padding: { xs: 2, sm: 1 },
              minWidth: "260px",
              width: { xs: "100%", sm: "auto" },
            }}
            data-cy="add-goal-button"
          >
            <FormattedMessage id="goals.add" />
          </Button>

          <Button onClick={handleGoToArchive}>
            <FormattedMessage id="general.archive.button" />
          </Button>
        </Stack>
      </Stack>

      {addingGoal && (
        <EditGoal
          newPosition={newPosition}
          open={addingGoal}
          onClose={() => {
            setAddingGoal(false);
          }}
        />
      )}
    </PageBackgroundPaper>
  );
}
