import { useState, useRef, useEffect } from "react";
import { Goal } from "@/src/API";
import Link from "next/link";
import Source from "@mui/icons-material/Source";
import DragIndicatorIcon from "@mui/icons-material/DragIndicator";
import IconButton from "@mui/material/IconButton";
import { HeadingCard } from "@/components/Common/Texts/Texts";
import {
  Stack,
  Tooltip,
  Collapse,
  Card,
  useMediaQuery,
  Theme,
  Divider,
  useTheme,
} from "@mui/material";
import EditGoal from "@/components/Goal/EditGoal";
import { useGoals } from "@/contexts/GoalsContext";
import GoalDetailRow from "@/components/Goal/GoalDetailRow";
import LatestStatus from "@/components/Status/LatestStatus";
import { getAllRedFlagsOfGoal } from "@/lib/webRedFlags";
import GoalStatus from "@/components/Goal/GoalStatus";
import { showDate } from "@/lib/time";
import { useDrag, useDrop } from "react-dnd";
import { DragItemTypes } from "@/components/Common/DragAndDrop/DragItemTypes";
import GoalTabs from "@/components/Goal/GoalTabs";
import { getLinkWithLocale } from "@/lib/localisation";
import { FormattedMessage, useIntl } from "react-intl";
import ExpandMore from "@/components/Common/ExpandMore/ExpandMore";
import { hoverMainToPressed } from "@/config/styling";
import { useSettings } from "@/contexts/SettingsInfo";
import EditButton from "@/components/Common/Buttons/EditButton";
import DetailsButton from "@/components/Common/Buttons/DetailsButton";
// import GoalSummaryGraph from "@/components/Graphs/GoalSummaryGraph";

type GoalListItemProps = {
  goal: Goal;
  currentPosition: number;
  onPositionChange: (dragId: string, hoverIndex: number) => void;
  onPositionSave: () => void;
};

export default function GoalListItem({
  goal,
  currentPosition,
  onPositionChange,
  onPositionSave,
}: GoalListItemProps) {
  const [expanded, setExpanded] = useState(false);
  const [editGoal, setEditGoal] = useState(false);
  const ref = useRef(null);
  const cardRef = useRef(null);
  const intl = useIntl();
  const theme = useTheme();
  const dbUser = useSettings()?.dbUser;
  const isSmallScreen = useMediaQuery((theme: Theme) =>
    theme.breakpoints.down("sm")
  );

  const goalListItemDetails = intl.formatMessage({ id: "general.details" });

  const [{ isDragging }, drag, preview] = useDrag(() => ({
    type: DragItemTypes.GOAL_CARD,
    item: () => {
      return {
        id: goal.id,
        index: currentPosition,
        parentGoalId: goal.goalChildGoalsId,
      };
    },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }));
  const [{ isOver }, drop] = useDrop(() => ({
    accept: DragItemTypes.GOAL_CARD,
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
    canDrop: (item: any) => {
      return item.parentGoalId === goal.goalChildGoalsId;
    },
    hover(item: any, monitor) {
      // Example: https://codesandbox.io/s/github/react-dnd/react-dnd/tree/gh-pages/examples_hooks_ts/04-sortable/simple?from-embed=&file=/src/Container.tsx
      if (!ref.current) {
        return;
      }

      const dragIndex = item.index;
      const hoverIndex = currentPosition;
      if (item.id === goal.id || item.parentGoalId !== goal.goalChildGoalsId) {
        return;
      }

      const hoverBoundingRect = (
        ref.current as HTMLDivElement
      ).getBoundingClientRect();

      const hoverMiddleY =
        (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;
      const clientOffset = monitor.getClientOffset();
      const hoverClientY = (clientOffset as any).y - hoverBoundingRect.top;
      // Move when the dragging points match.
      if (
        dragIndex < hoverIndex &&
        hoverClientY < hoverMiddleY - hoverMiddleY * 0.5
      ) {
        return;
      }
      if (
        dragIndex > hoverIndex &&
        hoverClientY > hoverMiddleY + hoverMiddleY * 0.5
      ) {
        return;
      }

      onPositionChange(item.id, hoverIndex);
    },
    drop() {
      // Save positions to database after drop
      onPositionSave();
    },
  }));

  useEffect(() => {
    if (cardRef.current) {
      preview(cardRef.current);
    }
  }, [preview]);

  const goals = useGoals()?.goals;
  const notResolvedRedFlags = getAllRedFlagsOfGoal(goal.id, goals || [], false);
  const draggingStyle: React.CSSProperties = isDragging ? { opacity: 0.5 } : {};
  const overStyle: React.CSSProperties = isOver
    ? { background: theme.palette.customColors?.bright }
    : {};

  drag(drop(ref));

  return (
    <>
      {/* individual goals */}
      <Card
        ref={cardRef}
        style={{
          ...draggingStyle,
          ...overStyle,
          padding: "12px",
          position: "relative",
          margin: "0px 20px 20px 0px",
          boxShadow:
            "rgba(67, 71, 85, 0.27) 0px 0px 0.25em, rgba(90, 125, 188, 0.05) 0px 0.25em 1em",
        }}
        data-cy={`goal-card-${goal.title}`}
        sx={{
          width: "100%",
        }}
      >
        <Stack
          direction="column"
          spacing={1}
          style={{ margin: "10px", marginTop: "5px", marginBottom: "10px" }}
        >
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            sx={{ paddingBottom: "12px" }}
          >
            {/* above divider */}
            <Stack
              direction="row"
              spacing={2.5}
              alignItems={"center"}
              flexGrow={1}
              textOverflow={"ellipsis"}
              width={"70%"}
            >
              {/* Drag btn */}
              <IconButton
                ref={ref}
                sx={{
                  position: "absolute",
                  top: 10,
                  left: -3,
                  pr: 0,
                  "&:hover": {
                    backgroundColor: "transparent",
                    cursor: "grab",
                  },
                  "&:active": {
                    cursor: "grabbing",
                  },
                }}
                disableRipple={true}
              >
                <DragIndicatorIcon />
              </IconButton>
              <HeadingCard>{goal?.title || ""}</HeadingCard>
            </Stack>

            <Stack
              direction={isSmallScreen ? "column" : "row"}
              spacing={1}
              alignItems="center"
            >
              {/* Expand toggle btn */}
              <ExpandMore
                expand={expanded}
                onClick={() => setExpanded(!expanded)}
                sx={{ ...hoverMainToPressed(theme) }}
                style={{ marginLeft: "6px" }}
                expandedTooltip={<FormattedMessage id="general.show.less" />}
                collapsedTooltip={<FormattedMessage id="general.show.more" />}
              />

              {/* Edit btn */}
              <EditButton
                onClick={() => setEditGoal(true)}
                dataCy="goal-list-item-edit"
              />
              <DetailsButton
                dataCy="link-to-goal-details"
                href={getLinkWithLocale(`/goals/${goal.id}`, intl.locale)}
                tooltip={intl.formatMessage({ id: "goals.go.to.goal.page" })}
              />
            </Stack>
          </Stack>

          {/* Hidden from screen-readers as it's just stylistic */}
          <Divider aria-hidden="true" />

          <GoalStatus goal={goal} notResolvedRedFlags={notResolvedRedFlags} />
        </Stack>

        <Collapse in={expanded} timeout="auto" unmountOnExit>
          <Stack
            direction="column"
            spacing={2}
            sx={{ paddingTop: 2, paddingLeft: 2, paddingRight: 2 }}
          >
            {/* FIXME: Removed until the functionality is ready */}
            {/* <GoalSummaryGraph goal={goal} /> */}
            <Stack
              direction="row"
              spacing={2}
              justifyContent={{ xs: "center", sm: "flex-start" }}
            >
              {/* Start date */}
              <Stack direction="column">
                <GoalDetailRow
                  label={intl.formatMessage({ id: "goals.start.date" })}
                >
                  {goal.startDate ? `${showDate(goal.startDate, dbUser)}` : "-"}
                </GoalDetailRow>
              </Stack>

              {/* Target date */}
              <Stack direction="column">
                <GoalDetailRow
                  label={intl.formatMessage({ id: "goals.target.date" })}
                >
                  {goal.targetDate
                    ? `${showDate(goal.targetDate, dbUser)}`
                    : "-"}
                </GoalDetailRow>
              </Stack>
            </Stack>
            {/* Description */}
            <Stack sx={{ alignItems: { xs: "center", sm: "flex-start" } }}>
              <GoalDetailRow
                label={intl.formatMessage({ id: "goals.description" })}
              >
                {goal.description}
              </GoalDetailRow>
            </Stack>
            {/* Reward */}
            <Stack sx={{ alignItems: { xs: "center", sm: "flex-start" } }}>
              {goal.reward && (
                <GoalDetailRow
                  label={intl.formatMessage({ id: "goals.reward" })}
                >
                  {goal.reward}
                </GoalDetailRow>
              )}
            </Stack>
            <LatestStatus goal={goal} />{" "}
            {/* contains the code for the entire "Reward" label & user input */}
            <GoalTabs goal={goal} showKeyResults /> {/* shows user input */}
          </Stack>
        </Collapse>
      </Card>
      {editGoal && (
        <EditGoal
          key={goal.updatedAt}
          goal={goal}
          open={editGoal}
          onClose={() => {
            setEditGoal(false);
          }}
        />
      )}
    </>
  );
}
