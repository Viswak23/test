import React, { useMemo } from "react";
import { useGoals } from "@/contexts/GoalsContext";
import _ from "lodash";
import { updateOrganizationUnitDb } from "@/lib/webOrganization";
import GoalListSub, { ParentGoal } from "./GoalListSub";
import { sortGoals, sortParentGoals } from "@/lib/webGoals";
import { Goal, OrganizationUnit } from "@/src/API";
import { useIntl } from "react-intl";

type OrganizationUnitGoalListProps = {
  organizationUnit: OrganizationUnit;
  internalGoals?: boolean;
};

export default function OrganizationUnitGoalList({
  organizationUnit,
  internalGoals = false,
}: OrganizationUnitGoalListProps) {
  const parentOrgUnitId =
    organizationUnit?.organizationUnitChildOrzganizationUnitsId;
  const goals = useGoals()?.goals;
  const archivedGoals = useGoals()?.archivedGoals;
  const intl = useIntl();

  // Get all the organization unit goals that are not internal (thus has a parent)
  const orgUnitGoals = useMemo(() => {
    if (!goals) return [];

    return goals.filter(
      (goal) =>
        goal.organizationUnitGoalsId === organizationUnit?.id &&
        goal.goalChildGoalsId != null
    );
  }, [goals, organizationUnit?.id]);

  const parentGoals: ParentGoal[] = useMemo(() => {
    if (!goals || (organizationUnit?.id == null && !internalGoals)) return [];

    // We only want to show internal goals for the current organization unit
    if (internalGoals) {
      return [
        {
          goal: undefined,
          orgUnitGoals: goals.filter(
            (goal) =>
              goal.organizationUnitGoalsId === organizationUnit?.id &&
              goal.goalChildGoalsId == null
          ),
        },
      ];
    }

    // Get the parent organization unit active goals
    let resultParentGoals = goals.filter(
      (goal) =>
        goal.organizationUnitGoalsId == parentOrgUnitId && // Other might be null and other might be undefined
        goal.employee == null &&
        !organizationUnit?.notRelevantParentGoals?.includes(goal.id)
    );

    // See if there are any child goals that have a closed parent goal.
    const orgUnitGoalsWithClosedParentGoals = orgUnitGoals.filter(
      (oug) => !resultParentGoals.find((pg) => pg.id === oug.goalChildGoalsId)
    );

    const closedParentGoals = orgUnitGoalsWithClosedParentGoals.map(
      (closedParent) =>
        archivedGoals?.find((ag) => ag.id === closedParent.goalChildGoalsId)
    );

    resultParentGoals = resultParentGoals.concat(closedParentGoals as Goal[]);

    const result = resultParentGoals.map((goal) => {
      return {
        goal,
        orgUnitGoals: orgUnitGoals.filter(
          (subgoal) => subgoal.goalChildGoalsId === goal.id
        ),
      };
    });

    return sortParentGoals(result, goals.concat(archivedGoals as Goal[]));
  }, [
    organizationUnit,
    goals,
    parentOrgUnitId,
    internalGoals,
    orgUnitGoals,
    archivedGoals,
  ]);

  const undelevantParentGoals = useMemo(() => {
    if (!organizationUnit?.notRelevantParentGoals) return [];

    const result = organizationUnit.notRelevantParentGoals.map((goalId) => {
      return orgUnitGoals?.find(
        (goal) =>
          goal != null &&
          goal.id === goalId &&
          goal.organizationUnitGoalsId === parentOrgUnitId
      );
    });
    return sortGoals(result as Goal[]);
  }, [organizationUnit, parentOrgUnitId, orgUnitGoals]);

  const onSetParentGoalUnrelevant = async (goalId?: string | null) => {
    if (!goalId) {
      return;
    }

    const updatedOrganizationUnit = _.cloneDeep(organizationUnit);
    if (!updatedOrganizationUnit) {
      return;
    }

    updatedOrganizationUnit.notRelevantParentGoals = [
      ...(updatedOrganizationUnit?.notRelevantParentGoals || []),
      goalId,
    ];
    await updateOrganizationUnitDb(updatedOrganizationUnit);
  };

  const onSetParentGoalRelevant = async (goalId?: string) => {
    if (!goalId) {
      return;
    }
    const updatedOrganizationUnit = _.cloneDeep(organizationUnit);
    if (!updatedOrganizationUnit) {
      return;
    }

    updatedOrganizationUnit.notRelevantParentGoals = [
      ...(updatedOrganizationUnit?.notRelevantParentGoals || []),
    ].filter((id) => id !== goalId);
    await updateOrganizationUnitDb(updatedOrganizationUnit);
  };

  let caption = internalGoals
    ? intl.formatMessage(
        { id: "goals.organization.unit.internal.goals" },
        { name: organizationUnit?.name }
      )
    : intl.formatMessage({ id: "goals.parent.organization.unit.goals" });

  return (
    <GoalListSub
      caption={caption}
      parentGoals={parentGoals}
      undelevantParentGoals={undelevantParentGoals}
      internalGoals={internalGoals}
      organizationUnitId={organizationUnit?.id}
      onSetParentGoalRelevant={onSetParentGoalRelevant}
      onSetParentGoalUnrelevant={onSetParentGoalUnrelevant}
    />
  );
}
