import { useState } from "react";
import { Goal } from "@/src/API";
import GoalListItem from "./GoalListItem";
import { updateGoalDb } from "@/lib/webGoals";
import { Stack, SxProps, Theme } from "@mui/material";

interface GoalListMainInOrderProps {
  goals: Goal[];
  sx?: SxProps<Theme>;
}

export default function GoalListMainInOrder({
  goals,
}: GoalListMainInOrderProps) {
  function setInitialOrder() {
    return goals.map((goal) => goal.id);
  }
  const [order, setOrder] = useState<string[]>(setInitialOrder);
  const handlePositionChange = (dragId: string, hoverIndex: number) => {
    setOrder((prevOrder) => {
      const newOrder = [...prevOrder];
      newOrder.splice(prevOrder.indexOf(dragId), 1);
      newOrder.splice(hoverIndex, 0, dragId);
      return newOrder;
    });
  };

  const handleSavePositions = async () => {
    await Promise.all(
      order.map((goalId, index) => {
        const goal = goals.find((goal) => goal.id === goalId);
        if (!goal) {
          return Promise.resolve();
        }
        return updateGoalDb({ ...goal, position: index });
      })
    );
  };

  return (
    <Stack direction="column">
      {order.map((orderItem, index) => {
        const goal = goals.find((goal) => goal.id === orderItem);
        if (!goal) {
          return null;
        }
        return (
          <GoalListItem
            key={`${goal.id}-${index}`}
            goal={goal}
            currentPosition={index}
            onPositionChange={handlePositionChange}
            onPositionSave={handleSavePositions}
          />
        );
      })}
    </Stack>
  );
}
