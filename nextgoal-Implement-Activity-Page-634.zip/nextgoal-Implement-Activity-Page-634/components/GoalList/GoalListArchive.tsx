import React, { useMemo, useState } from "react";
import { Stack, Tabs, Typography, Tab } from "@mui/material/";
import { HeadingMain } from "../Common/Texts/Texts";
import { useGoals } from "@/contexts/GoalsContext";
import { sortGoals } from "@/lib/webGoals";
import GoalListMainInOrder from "./GoalListMainInOrder";
import PageBackgroundPaper from "../Common/Layout/PageBackgroundPaper";
import { FormattedMessage, useIntl } from "react-intl";
import { TabPanel } from "../Settings/TabPanel";
import { Amplify } from "aws-amplify";
import { isOwner } from "@/lib/webHelpers";

export default function GoalListArchive() {
  const [tabIndex, setTabIndex] = useState(0);
  const intl = useIntl();
  const goals = useGoals()?.archivedGoals;

  const archivedGoals = useMemo(() => {
    return sortGoals(goals?.filter((goal) => goal.employeeGoalsId === null));
  }, [goals]);

  // Assume that all the goals that are owned by current user, and are personal goals, are current user's personal goals
  const archivedPersonalGoals = useMemo(() => {
    return sortGoals(
      goals?.filter(
        (goal) => goal.employeeGoalsId != null && isOwner(goal.owner)
      )
    );
  }, [goals]);
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabIndex(newValue);
  };

  // We use goals length as a key in GoalListMainInOrder so that it will re-render when goals are added or removed
  return (
    <PageBackgroundPaper>
      <HeadingMain>
        <FormattedMessage id="archive.title" />{" "}
      </HeadingMain>

      <Stack direction="column" spacing={1} style={{ marginTop: 6 }}>
        <Tabs value={tabIndex} onChange={handleTabChange} centered>
          <Tab label={intl.formatMessage({ id: "archive.public.goals" })} />
          <Tab label={intl.formatMessage({ id: "archive.personal.goals" })} />
        </Tabs>
        <TabPanel value={tabIndex} index={0}>
          {archivedGoals.length === 0 ? (
            <Typography variant="body1">
              <FormattedMessage id="archive.public.empty.goals" />
            </Typography>
          ) : (
            <GoalListMainInOrder
              key={`ordered-goal-list-${archivedGoals.length}`}
              goals={archivedGoals}
            />
          )}
        </TabPanel>
        <TabPanel value={tabIndex} index={1}>
          {archivedPersonalGoals.length === 0 ? (
            <Typography variant="body1">
              <FormattedMessage id="archive.personal.empty.goals" />
            </Typography>
          ) : (
            <GoalListMainInOrder
              key={`ordered-personal-goal-list-${archivedPersonalGoals.length}`}
              goals={archivedPersonalGoals}
            />
          )}
        </TabPanel>
      </Stack>
    </PageBackgroundPaper>
  );
}
